import requests
import json
import pandas as pd
import time
import collections

# Ваши логин и пароль
username = 'intyres@internet.ru'
password = 'Жулихин1'

# Данные вашего клиента, предоставленные менеджером
client_id = '36'
client_secret = 'ti0yb0mYNkzDzs5vzSBVY3GcHf6WVxZhclC0hXsg'

# Используем тестовую среду
environment = 'okno2'

# URL для получения токена
token_url = f'https://{environment}.kolobox.ru/api/oauth/token'

# Данные для запроса токена
data = {
    'grant_type': 'password',
    'client_id': client_id,
    'client_secret': client_secret,
    'username': username,
    'password': password
}

# Заголовки запроса
headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
}

try:
    # Выполняем запрос на получение токена
    response = requests.post(token_url, data=data, headers=headers)
    
    # Проверяем ответ и извлекаем токен
    if response.status_code == 200:
        # Токен успешно получен
        token_data = response.json()
        access_token = token_data['access_token']
        #print('Токен доступа:', access_token)
    else:
        # Ошибка при получении токена
        print('Ошибка получения токена:', response.text)
except Exception as e:
    print('Ошибка при запросе:', e)

# Токен, полученный с использованием OAuth (замените на "мой токен")
environment = 'okno2'  # Используем тестовую среду

# Заголовки запроса с токеном
headers = {
    'Authorization': f'Bearer {access_token}'
}

# URL API для запроса каталога
url = f'https://{environment}.kolobox.ru/api/catalog/tyres/'

# Переменная для хранения всех данных
all_tyres = []

# Номер текущей страницы
page = 0

# Максимальное количество записей на странице
max_records_per_page = 50

# Максимальное количество повторных попыток
max_retries = 5

while True:
    # Формируем URL для текущей страницы
    page_url = f'{url}{page}'
    
    retries = 0
    while retries < max_retries:
        try:
            # Отправка запроса
            response = requests.get(page_url, headers=headers, timeout=5)  # Увеличьте тайм-аут до 10 секунд
            response.raise_for_status()  # Проверка успешности запроса
        
            # Обработка ответа
            tyres = response.json()
        
            # Проверка наличия данных на текущей странице
            if not tyres:
                break  # Если данных нет или номер страницы достиг 107, выходим из цикла
        
            # Добавление данных на текущей странице к общему списку
            all_tyres.extend(tyres)
        
            # Пауза между запросами
            time.sleep(1)  # Задержка 1 секунда между запросами
            break
        
        except requests.exceptions.HTTPError as http_err:
            if response.status_code == 429:
                print(f"Превышен лимит запросов: {http_err}")
                break  # Выход из цикла при ошибке 429
            else:
                raise  # Если другая ошибка, то выбрасываем ее дальше
        except requests.exceptions.Timeout:
            retries += 1
            print(f"Timeout occurred. Retrying {retries}/{max_retries}...")
            time.sleep(2)  # Задержка 2 секунды перед повторной попыткой
        except requests.exceptions.RequestException as e:
            print(f"An error occurred: {e}")
            break
    #print(len(tyres), page)
    # Если количество записей на текущей странице меньше максимального или достигли 100 страниц, прекращаем запросы
    if len(tyres) < max_records_per_page:
        break
    # Переход к следующей странице
    page += 1
'''
# Фильтрация данных
filtered_tyres = [
    tyre for tyre in all_tyres
    if tyre.get("count_local", 0) + tyre.get("count_remote", 0) >= 2
]
'''
# Фильтрация данных по наличию буквы "C" в диаметре
#filtered_tyres = [tyre for tyre in all_tyres if 'C' not in str(tyre.get("diameter", ""))]
# Фильтрация данных по бренду
filtered_tyres = [
    tyre for tyre in all_tyres
    if tyre.get("mark") not in ["Nordman", "Nokian Tyres", 'Nokian']
    and tyre.get("profile_height") != 0
    and tyre.get("image_url")  # Проверка на наличие значений в ImageUrls
]

# Создание DataFrame в соответствии с форматом автозагрузки Авито
columns = [
    "AvitoId", "Id", "EMail", "AvitoStatus", "Model", "Brand", "TireAspectRatio",
    "Quantity", "ProductType", "Address", "DifferentWidthTires", "CompanyName", 
    "ListingFee", "GoodsType", "TireSectionWidth", "RunFlat", "ImageUrls", "Condition", 
    "ContactPhone", "ManagerName", "TireType", "LoadIndex", "AdType", 
    "Description", "Category", "ContactMethod", "Price", 
    "RimDiameter", "Title", "SpeedIndex", "InternetCalls", "CallsDevices"
]

# Пример маппинга данных из API ответа в требуемый формат (заполните его корректными данными)
def map_to_avito_format(tyre):
    # Словарь для замены значений брендов
   
    def correct_model(brand, model):
        if brand == 'Goodride' and model == 'SL309':
            return 'SL 309'
        if brand == 'WestLake' and model == 'SL 309':
            return 'SL309'
        return model
    # Рассчёт статуса на основе количества товара с использованием ИЛИ
    count_local = tyre.get("count_local", None)
    count_remote = tyre.get("count_remote", None)

    # Преобразуем в числа, если значения не равны None
    try:
        count_local = int(count_local) if count_local is not None else None
        count_remote = int(count_remote) if count_remote is not None else None
    except ValueError:
        count_local = None
        count_remote = None

    # Проверка, если хотя бы одно из значений больше 2 и не равно None
    avito_status = "Активно" if (count_local is not None and count_local >= 2) or (count_remote is not None and count_remote >= 2) else "Снято с публикации"
    # Получаем бренд из данных
    original_brand = tyre.get("mark")
    original_model = tyre.get("model")
    
    # Применяем замену, если бренд есть в словаре
    mapped_brand = brand_mapping.get(original_brand, original_brand)
    # Применяем замену, если модель есть в словаре
    
    mapped_model = model_mapping.get(original_model, original_model)
    corrected_model = correct_model(mapped_brand, mapped_model)
    
    description = (
        f"<p><strong>🔥 НОВЫЕ ШИНЫ С БЕСПЛАТНОЙ ДОСТАВКОЙ ПО САМАРЕ И НОВОКУЙБЫШЕВСКУ! 🔥</strong></p>"
        "<p><br></p>"
        f"<p><strong>{mapped_brand} {corrected_model} {tyre.get('tread_width')}/{tyre.get('profile_height')} R{tyre.get('diameter')}</strong> — идеальный выбор для вашего авто!</p>"
        "<p><br></p>"
        f"<p><strong>🌟 НАШИ ПРЕИМУЩЕСТВА:</strong></p>"
        f"<p><strong>✅ Бесплатная доставка в удобное для вас время</strong> — *работаем 7 дней в неделю!*</p>"
        f"<p>✅ <strong>Предоставляем заводскую гарантию от производителя</strong> — защита вашей покупки.</p>"
        f"<p><strong>✅ Оплата по факту</strong> — сначала проверяете товар, затем платите.</p>"
        f"<p><strong>✅ Любой способ оплаты:</strong></p>"
        "<p>- 💵 Наличные</p>"
        "<p>- 📱 Перевод по номеру телефона</p>"
        "<p>- 💳 Банковская карта (Цена может увеличиться, уточняйте у менеджера)</p>"
        "<p>- 📲 QR-код</p>"
        f"<p><strong>✅ Сертифицированные склады</strong> — хранение в условиях, одобренных производителями.</p>"
        f"<p><strong>✅ Широкий ассортимент</strong> — подберем любые типоразмеры и бренды под ваш запрос!</p>"
        f"<p><strong>✅ 100% новые шины</strong> — без повреждений, следов эксплуатации или восстановления.</p>"
        f"<p><strong>✅ Продукция сертифицирована маркировкой «Честный знак»</strong> — гарантия подлинности и качества каждой шины!</p>"
        "<p><br></p>"
        f"<p><strong>📢 ВАЖНО:</strong></p>"
        f"<p><strong>❗️Доставка в другие города</strong> — через СДЭК, DPD, Деловые линии, ПЭК (требуется 100% предоплата).</p>"
        f"<p><strong>❗️НЕ работаем с доставкой Avito</strong> — организуем отправку самостоятельно.</p>"
        "<p><br></p>"
        f"<p><strong>📞 Звоните или пишите в сообщения Avito</strong> — менеджер проконсультирует по выбору, срокам и акциям!</p>"
        f"<p><strong>❤️ Подписывайтесь на наш профиль и добавляйте объявление в избранное</strong> — следите за акциями, распродажами и спецпредложениями!</p>"
        "<p><br></p>"
        f"<p><strong>🔍 ДЛЯ ПОИСКА:</strong></p>"
        "<p>колёса, шины, резина, баллоны, покрышки, доставка, акции, скидки, дисконт, низкие цены, зима, зимние шины, шипы, лето, летние шины, Самара, Новокуйбышевск</p>"
        f"<p>{tyre.get('tread_width')} {tyre.get('profile_height')} {tyre.get('diameter')} "
        f"{tyre.get('tread_width')}/{tyre.get('profile_height')} {tyre.get('diameter')} "
        f"{tyre.get('tread_width')}/{tyre.get('profile_height')}R{tyre.get('diameter')} "
        f"{tyre.get('tread_width')}-{tyre.get('profile_height')}-{tyre.get('diameter')} "
        f"{tyre.get('tread_width')} {tyre.get('profile_height')}-{tyre.get('diameter')}</p>"
        "<p><br></p>"
        f"<p><strong>🚗 Ваша безопасность начинается с качественных шин! Выбирайте надёжность — выбирайте нас!</strong></p>"
    )
    
    return {
        "AvitoId": None,
        "Id": tyre.get("id"),
        "EMail": "intyres@internet.ru",
        "AvitoStatus": avito_status,
        "Model": corrected_model,  # Используем замененное значение модели
        "Brand": mapped_brand,  # Используем замененное значение бренда
        "TireAspectRatio": tyre.get("profile_height"),
        "Quantity": tyre.get("sale_quantity"),
        "ProductType": "Шины",
        "Address": "Самарская обл., Самара",
        "DifferentWidthTires": "Нет",
        "CompanyName": "ИН Шина",
        "ListingFee": "Package",
        "GoodsType": "Шины, диски и колёса",
        "TireSectionWidth": tyre.get("tread_width"),
        "RunFlat": "Да" if tyre.get("runflat", 0) else "Нет",
        "ImageUrls": tyre.get("image_url"),
        "Condition": "Новое",
        "ContactPhone": "79270083097",
        "ManagerName": "Илья",
        "TireType": "Летние" if tyre.get("is_studded") == 0 else "Зимние нешипованные" if tyre.get("is_studded") == 1 else "Зимние шипованные" if tyre.get("is_studded") == 2 else "Неизвестный тип",
        "LoadIndex": tyre.get("load_index"),
        "AdType": "Товар приобретен на продажу",
        "Description": description,
        "Category": "Запчасти и аксессуары",
        "ContactMethod": "По телефону и в сообщениях",
        "Price": tyre.get("price"),
        "RimDiameter": tyre.get("diameter"),
        "Title": f"{mapped_brand} {mapped_model} {tyre.get('tread_width')}/{tyre.get('profile_height')} R{tyre.get('diameter')} {tyre.get('load_index')}{tyre.get('speed_index')}",
        "SpeedIndex": tyre.get("speed_index"),
        "InternetCalls": "Да",
        "CallsDevices": "4015481993"
    }

# Преобразование всех данных в формат Авито
avito_data = [map_to_avito_format(tyre) for tyre in filtered_tyres]

# Создание DataFrame для данных Авито
df_avito = pd.DataFrame(avito_data, columns=columns)

# Сохранение DataFrame в файл Excel
df_avito.to_excel('tyres_catalog_avito4.xlsx', index=False)
print("Данные успешно сохранены в файл tyres_catalog_avito4.xlsx")

# Вывод общего количества шин
print(f"Общее количество шин: {len(filtered_tyres)}")
print(f"Общее количество шин до обработки: {len(all_tyres)}")
import re
from zeep import Client
from collections import Counter
import pandas as pd
import os
# Создаем клиента SOAP
wsdl = 'http://api-b2b.4tochki.ru/WCF/ClientService.svc?wsdl'
client = Client(wsdl=wsdl)

# Список ID складов
warehouse_ids = [846, 1369, 232, 1222]
# Общий список для данных со всех складов
all_products = []

# Проверка количества моделей на каждом складе и сбор данных
for warehouse_id in warehouse_ids:
    tyre_filter = client.get_type('ns2:FindTyreFilter')(
        quality=0,
        type_list=['car', '!cartruck'],
        wrh_list=[warehouse_id]
    )
    response = client.service.GetFindTyre(
        login='sa47238',
        password='3k)VS-ZSN5',
        filter=tyre_filter,
        page=0,
        pageSize=2000
    )
    
    # Проверяем, есть ли данные в price_rest_list
    if response.price_rest_list:
        all_products.extend(response.price_rest_list.TyrePriceRest)  # Добавляем данные в общий список
        print(f"Склад {warehouse_id}: {len(response.price_rest_list.TyrePriceRest)} моделей")
    else:
        print(f"Склад {warehouse_id}: Нет доступных моделей")

# Словарь для замены значений брендов
def correct_model(brand, model):
    if brand == 'Goodride' and model == 'SL309':
        return 'SL 309'
    if brand == 'WestLake' and model == 'SL 309':
        return 'SL309'
    return model


# Общая функция создания словаря данных
def map_common(product, price_info):
    season_map = {'w': 'Зимние', 's': 'Летние', 'u': 'Всесезонные'}
    brand = getattr(product, 'marka', '')
    model = getattr(product, 'model', '')
    mapped_brand = brand_mapping.get(brand, brand)
    mapped_model = model_mapping.get(model, model)
    corrected_model = correct_model(mapped_brand, model)
    return {
        "AvitoId": None, "Id": getattr(product, 'code', ''), "EMail": "intyres@internet.ru",
        "AvitoStatus": "Активно" if getattr(price_info, 'rest', 1) >= 2 else "Снято с публикации",
        "Model": mapped_model, "Brand": mapped_brand, "TireAspectRatio": None,
        "Quantity": getattr(price_info, 'rest', 0), "ProductType": "Шины", "Address": "Самарская обл., Самара",
        "DifferentWidthTires": "Нет", "CompanyName": "ИН Шина", "ListingFee": "Package",
        "GoodsType": "Шины, диски и колёса", "TireSectionWidth": getattr(product, 'width_min', ''),
        "RunFlat": None, "ImageUrls": None, "ImageNames": None, "Condition": "Новое",
        "ContactPhone": "79270083097", "ManagerName": "Илья",
        "TireType": season_map.get(getattr(product, 'season', ''), 'Не указано'),
        "LoadIndex": None, "AdType": "Товар приобретен на продажу", "Description": None,
        "Category": "Запчасти и аксессуары", "ContactMethod": "По телефону и в сообщениях",
        "Price": getattr(price_info, 'price', ''), "RimDiameter": None, "Title": None,
        "SpeedIndex": None, "InternetCalls": "Да", "CallsDevices": "4015481993"
    }

# Вариант с PNG (если есть локально)
def map_with_png(product, price_info):
    data = map_common(product, price_info)
    filename = f"{data['Brand']} {data['Model']}.png"
    path = os.path.join("tyres_png", filename)
    if os.path.isfile(path):
        data["ImageNames"] = filename
    else:
        data["ImageUrls"] = getattr(product, 'img_big_pish', '')
    return data

# Вариант только с URL
def map_with_url(product, price_info):
    data = map_common(product, price_info)
    data["ImageUrls"] = getattr(product, 'img_big_pish', '')
    return data

# Обработка всех товаров
data_with_png = []
data_with_url = []

for p in all_products:
    for pr in p.whpr.wh_price_rest:
        data_with_png.append(map_with_png(p, pr))
        data_with_url.append(map_with_url(p, pr))

# Столбцы Авито
columns = list(data_with_png[0].keys())

# Сохранение в два файла
pd.DataFrame(data_with_png, columns=columns).to_excel("tyres_catalog_avito_power.xlsx", index=False)
pd.DataFrame(data_with_url, columns=columns).to_excel("tyres_catalog_avito_vk.xlsx", index=False)

print("✅ Файлы успешно сохранены: tyres_catalog_avito_power.xlsx и tyres_catalog_avito_vk.xlsx")

# Функция для получения информации по кодам товаров с помощью API GetGoodsInfo
def get_goods_info(login, password, code_list,wsdl,client):
    # Создаем пустой список для хранения информации о товарах
    tyre_info_list = []
    
    # Перебираем каждый код товара и получаем информацию по нему
    for code in code_list:
        response = client.service.GetGoodsInfo(
            login=login,
            password=password,
            code_list=[code]  # Отправляем каждый код товара отдельно
        )
        tyre_info_list.append(response.tyreList)  # Добавляем информацию о товаре в список
    
    return tyre_info_list  # Возвращаем список найденных шин

# Загрузка данных из Excel файла в DataFrame
file_path = 'tyres_catalog_avito_power.xlsx'
df = pd.read_excel(file_path)

# Получаем список всех кодов товаров из столбца 'AvitoId'
code_list = df['Id'].tolist()

tyre_info_list = get_goods_info('sa47238', '3k)VS-ZSN5', code_list, wsdl, client)

# Создаем новые столбцы 'LoadIndex', 'SpeedIndex', 'TireAspectRatio', 'RimDiameter', 'RunFlat', 'TireSectionWidth', 'Title', 'Description' и 'TireType' и заполняем их данными из API
load_indices = []
speed_indices = []
tire_aspect_ratios = []
rim_diameters = []
run_flats = []
tire_section_widths = []
titles = []
descriptions = []
tire_types = []

# Итерация по списку tyre_info_list и формирование данных
for tyre_info in tyre_info_list:
    for tyre in tyre_info['TyreContainer']:
        # Получение данных для описания
        load_index = tyre.load_index.split('/')[0] if hasattr(tyre, 'load_index') and tyre.load_index else None
        speed_index = tyre.speed_index.replace('(', '').replace(')', '') if hasattr(tyre, 'speed_index') and tyre.speed_index else None
        tire_aspect_ratio = int(float(tyre['height'])) if 'height' in tyre else None
        # Преобразование значения rim_diameter в строку, если это не строка
        rim_diameter = tyre['diameter']
        if rim_diameter is not None:
            rim_diameter = str(rim_diameter)
        run_flat = "Да" if tyre['puncture'] == 'Run On Flat' else "Нет"
        tire_section_width = int(float(tyre['width'])) if 'width' in tyre else None

        # Определение типа шины
        if tyre['season'] == 'w':
            tire_type = 'Зимние шипованные' if tyre['thorn'] else 'Зимние нешипованные'
        elif tyre['season'] == 's':
            tire_type = 'Летние'
        else:
            tire_type = 'Всесезонные'
 # Получение оригинального бренда и его замена из словаря, если есть
        original_brand = tyre['brand']
        mapped_brand = brand_mapping.get(original_brand, original_brand)
        
        original_model = tyre['model']
        mapped_model = model_mapping.get(original_model, original_model)
        # Формирование заголовка с учетом замененного бренда
        title = f"{mapped_brand} {mapped_model} {int(float(tyre['width']))}/{int(float(tyre['height']))} R{int(float(tyre['diameter']))} {tyre['load_index']}{tyre['speed_index']}"
        description = (
            f"<p><strong>🔥 НОВЫЕ ШИНЫ С БЕСПЛАТНОЙ ДОСТАВКОЙ ПО САМАРЕ И НОВОКУЙБЫШЕВСКУ! 🔥</strong></p>"
            f"<p><br></p>"
            f"<p><strong>{title}</strong> — идеальный выбор для вашего авто!</p>"
            f"<p><br></p>"
            f"<p><strong>🌟 НАШИ ПРЕИМУЩЕСТВА:</strong></p>"
            f"<p><strong>✅ Бесплатная доставка в удобное для вас время</strong> — *работаем 7 дней в неделю!*</p>"
            f"<p>✅ <strong>Предоставляем заводскую гарантию от производителя</strong> — защита вашей покупки.</p>"
            f"<p><strong>✅ Оплата по факту</strong> — сначала проверяете товар, затем платите.</p>"
            f"<p><strong>✅ Любой способ оплаты:</strong></p>"
            f"<p>- 💵 Наличные</p>"
            f"<p>- 📱 Перевод по номеру телефона</p>"
            f"<p>- 💳 Банковская карта (Цена может увеличиться, уточняйте у менеджера)</p>"
            f"<p>- 📲 QR-код</p>"
            f"<p><strong>✅ Сертифицированные склады</strong> — хранение в условиях, одобренных производителями.</p>"
            f"<p><strong>✅ Широкий ассортимент</strong> — подберем любые типоразмеры и бренды под ваш запрос!</p>"
            f"<p><strong>✅ 100% новые шины</strong> — без повреждений, следов эксплуатации или восстановления.</p>"
            f"<p><strong>✅ Продукция сертифицирована маркировкой «Честный знак»</strong> — гарантия подлинности и качества каждой шины!</p>"
            f"<p><br></p>"
            f"<p><strong>📢 ВАЖНО:</strong></p>"
            f"<p><strong>❗️Доставка в другие города</strong> — через СДЭК, DPD, Деловые линии, ПЭК (требуется 100% предоплата).</p>"
            f"<p><strong>❗️НЕ работаем с доставкой Avito</strong> — организуем отправку самостоятельно.</p>"
            f"<p><br></p>"
            f"<p><strong>📞 Звоните или пишите в сообщения Avito</strong> — менеджер проконсультирует по выбору, срокам и акциям!</p>"
            f"<p><strong>❤️ Подписывайтесь на наш профиль и добавляйте объявление в избранное</strong> — следите за акциями, распродажами и спецпредложениями!</p>"
            f"<p><br></p>"
            f"<p><strong>🔍 ДЛЯ ПОИСКА:</strong></p>"
            f"<p>колёса, шины, резина, баллоны, покрышки, доставка, акции, скидки, дисконт, низкие цены, зима, зимние шины, шипы, лето, летние шины, Самара, Новокуйбышевск</p>"
            f"{int(float(tyre['width']))} {int(float(tyre['height']))} {int(float(tyre['diameter']))} "
            f"{int(float(tyre['width']))}/{int(float(tyre['height']))} {int(float(tyre['diameter']))} "
            f"{int(float(tyre['width']))}/{int(float(tyre['height']))}R{int(float(tyre['diameter']))} "
            f"{int(float(tyre['width']))}-{int(float(tyre['height']))}-{int(float(tyre['diameter']))} "
            f"{int(float(tyre['width']))} {int(float(tyre['height']))}-{int(float(tyre['diameter']))} р{int(float(tyre['diameter']))} r{int(float(tyre['diameter']))} р {int(float(tyre['diameter']))}</p>"
            f"<p><br></p>"
            f"<p><strong>🚗 Ваша безопасность начинается с качественных шин! Выбирайте надёжность — выбирайте нас!</strong></p>"
        )
        # Добавление данных в списки
        load_indices.append(load_index)
        speed_indices.append(speed_index)
        tire_aspect_ratios.append(tire_aspect_ratio)
        rim_diameters.append(rim_diameter)
        run_flats.append(run_flat)
        tire_section_widths.append(tire_section_width)
        titles.append(title)
        descriptions.append(description)
        tire_types.append(tire_type)

# Добавляем новые столбцы в DataFrame
df['LoadIndex'] = load_indices
df['SpeedIndex'] = speed_indices
df['TireAspectRatio'] = tire_aspect_ratios
df['RimDiameter'] = rim_diameters
df['RunFlat'] = run_flats
df['TireSectionWidth'] = tire_section_widths
df['Title'] = titles
df['Description'] = descriptions
df['TireType'] = tire_types

# Фильтрация DataFrame для удаления строк с брендами Nordman и Nokian Tyres
df = df[~df['Brand'].isin(['Nordman', 'Nokian Tyres', 'Nokian'])]

# Удаление дубликатов по столбцу Title
initial_count = len(df)  # Количество записей до удаления дубликатов
df = df.drop_duplicates(subset='Title', keep='first')
final_count = len(df)  # Количество записей после удаления дубликатов
duplicates_removed = initial_count - final_count  # Количество удалённых дубликатов

# Вывод информации о дубликатах
print(f"Количество удалённых дубликатов по Title: {duplicates_removed}")

# Подсчёт количества записей с разными статусами
status_counts = df['AvitoStatus'].value_counts()

# Вывод результатов
print(f"Количество записей со статусами:")
print(f"Активно: {status_counts.get('Активно', 0)}")
print(f"Снято с публикации: {status_counts.get('Снято с публикации', 0)}")

# Сохраняем обновленный DataFrame в новую таблицу Excel
updated_file_path = 'tyres_catalog_avito_power_updated.xlsx'
df.to_excel(updated_file_path, index=False)
print(f"Данные успешно обновлены и сохранены в файл {updated_file_path}")

def replace_image_columns_by_id(df_base: pd.DataFrame, df_replacement: pd.DataFrame, id_col: str = 'Id') -> pd.DataFrame:
    """
    В df_base заменяет значения столбцов 'ImageUrls' и 'ImageNames' по совпадающим Id
    из df_replacement. Если замены нет — сохраняет старые значения.
    """
    df_base = df_base.copy()
    df_replacement = df_replacement.copy()

    df_base[id_col] = df_base[id_col].astype(str)
    df_replacement[id_col] = df_replacement[id_col].astype(str)

    df_replacement = df_replacement.drop_duplicates(subset=id_col, keep='first')

    replace_cols = ['ImageUrls', 'ImageNames']
    replacement_map = df_replacement.set_index(id_col)[replace_cols]

    for col in replace_cols:
        if col in df_base.columns and col in replacement_map.columns:
            # Обновляем значения, если есть в replacement_map
            df_base[col] = df_base.apply(
                lambda row: replacement_map.at[row[id_col], col]
                if row[id_col] in replacement_map.index and pd.notna(replacement_map.at[row[id_col], col])
                else row[col],
                axis=1
            )

    return df_base
df_links = pd.read_excel("tyres_catalog_avito_vk.xlsx")         # Источник с картинками
df_images = pd.read_excel("tyres_catalog_avito_power_updated.xlsx")  # Целевая таблица
# Заменяем картинки из vk → в power
df_power_with_images = replace_image_columns_by_id(df_images, df_links)
# Сохраняем результат
output_path = 'tyres_catalog_avito_power_with_images.xlsx'
df_power_with_images.to_excel(output_path, index=False)
print(f"✅ Файл {output_path} успешно сформирован — с картинками из vk-файла.")
import pandas as pd

# Загрузка таблиц
df_kolobox = pd.read_excel('tyres_catalog_avito4.xlsx')
df_power = pd.read_excel('tyres_catalog_avito_power_updated.xlsx')

# Добавляем источник
df_kolobox['Source'] = 'Kolobox'
df_power['Source'] = 'Power'

season_markup_by_source = {
    'Kolobox': {
        'Летние': 0.98,  
        'Всесезонные': 1.00,
        'Зимние шипованные': 1.00,
        'Зимние нешипованные': 1.00
    },
    'Power': {
        'Летние': 1.00,
        'Всесезонные': 1.00,
        'Зимние шипованные': 1.00,
        'Зимние нешипованные': 1.00
    }
}

# Формулы наценок для Kolobox
def calculate_markup_general(price):
    if price < 4000:
        return round(1.07 * price)
    elif 4000 <= price < 8000:
        return round(1.07 * price)
    elif 8000 <= price < 10000:
        return round(1.08 * price)
    elif 10000 <= price < 12000:
        return round(1.07 * price)
    elif 12000 <= price < 20000:
        return round(1.07 * price)
    elif 20000 <= price < 30000:
        return round(1.06 * price)
    elif price >= 30000:
        return round(1.06 * price)

def calculate_markup_maxxis_prinx(price):
    if price < 8000:
        return round(1.09 * price)
    elif 8000 <= price < 12000:
        return round(1.1 * price)
    elif 12000 <= price < 20000:
        return round(1.1 * price)
    elif 20000 <= price < 30000:
        return round(1.09 * price)
    elif price >= 30000:
        return round(1.09 * price)

# Формула наценки для Power (общая)
def calculate_markup_general_power(price):
    if price < 4000:
        return round(1.08 * price)
    elif 4000 <= price < 8000:
        return round(1.08 * price)
    elif 8000 <= price < 10000:
        return round(1.09 * price)
    elif 10000 <= price < 12000:
        return round(1.08 * price)
    elif 12000 <= price < 20000:
        return round(1.08 * price)
    elif 20000 <= price < 30000:
        return round(1.07 * price)
    elif price >= 30000:
        return round(1.07 * price)

def apply_price_markup(row):
    price = row['Price']
    source = row['Source']
    tire_type = row.get('TireType', '')
    brand = row.get('Brand', '')

    # 1. Наценка по источнику и бренду
    if source == 'Kolobox':
        if brand in ['Maxxis', 'Prinx', 'Ikon Tyres']:
            base_price = calculate_markup_maxxis_prinx(price)
        else:
            base_price = calculate_markup_general(price)

    elif source == 'Power':
        base_price = calculate_markup_general_power(price)
    else:
        base_price = price

    # 2. Коэффициент по сезону + источнику
    season_dict = season_markup_by_source.get(source, {})
    season_coeff = season_dict.get(tire_type, 1.00)

    final_price = round(base_price * season_coeff)
    return final_price


# Применение наценки
df_kolobox['Price'] = df_kolobox.apply(apply_price_markup, axis=1)
df_power['Price'] = df_power.apply(apply_price_markup, axis=1)

# Объединение таблиц
df_combined = pd.concat([df_kolobox, df_power], ignore_index=True)

# Удаление строк с отсутствующими критичными значениями
df_combined = df_combined.dropna(subset=['Model', 'Brand'])

# Удаление строк, где одновременно пусты ImageUrls и ImageNames
df_combined = df_combined[~(df_combined['ImageUrls'].isna() & df_combined['ImageNames'].isna())]

# Группировка по Title и выбор строки с минимальной ценой из "Активно", иначе просто минимальной
def select_best_row(group):
    active = group[group['AvitoStatus'] == 'Активно']
    if not active.empty:
        return active.loc[active['Price'].idxmin()]
    else:
        return group.loc[group['Price'].idxmin()]

df_final = df_combined.groupby('Title', group_keys=False).apply(select_best_row)

# Округление до кратного 50
df_final['Price'] = df_final['Price'].apply(lambda x: round(x / 50) * 50)

# Сохранение результата
output_path = 'tyres_catalog_avito_updated.xlsx'
df_final.to_excel(output_path, index=False)
print(f"Файл {output_path} успешно сформирован с учётом всех условий.")

df_links = pd.read_excel("tyres_catalog_avito_power_with_images.xlsx")         # Источник с картинками
df_images = pd.read_excel("tyres_catalog_avito_updated.xlsx")  # Целевая таблица
# Заменяем картинки из vk → в power
df_power_with_images = replace_image_columns_by_id(df_images, df_links)
# Сохраняем результат
output_path = 'tyres_catalog_avito_updated_vk.xlsx'
df_power_with_images.to_excel(output_path, index=False)
print(f"✅ Файл {output_path} успешно сформирован — с картинками из vk-файла.")

import pandas as pd
from datetime import datetime, timedelta

# Загрузка таблиц из Excel файлов
df_new = pd.read_excel('tyres_catalog_avito_updated.xlsx')
df_old = pd.read_excel('tyres_old.xlsx')

# Удаление строк из df_old, где ImageUrls пустой или None
df_old = df_old[df_old['ImageUrls'].notna() & (df_old['ImageUrls'] != '')]
# Приводим Brand и Title к единому виду в обеих таблицах
def fix_kama_title(title):
    # Меняем только если КАМА не уже с заводом
    return title.replace('КАМА', 'КАМА (Нижнекамский шинный завод)') if 'КАМА (Нижнекамский шинный завод)' not in title else title

df_old['Brand'] = df_old['Brand'].replace('КАМА', 'КАМА (Нижнекамский шинный завод)')
df_new['Brand'] = df_new['Brand'].replace('КАМА', 'КАМА (Нижнекамский шинный завод)')

df_old['Title'] = df_old['Title'].apply(fix_kama_title)
df_new['Title'] = df_new['Title'].apply(fix_kama_title)
# Приведение столбцов Id и Title к строковому типу
df_new['Id'] = df_new['Id'].astype(str)
df_old['Id'] = df_old['Id'].astype(str)
df_new['Title'] = df_new['Title'].astype(str)
df_old['Title'] = df_old['Title'].astype(str)

# Удаление столбцов TypeID и TireYear из старой таблицы
df_old.drop(columns=['TypeID', 'TireYear'], errors='ignore', inplace=True)

# Приведение столбца RimDiameter к строковому типу
df_new['RimDiameter'] = df_new['RimDiameter'].astype(str)
df_old['RimDiameter'] = df_old['RimDiameter'].astype(str)

# Создание столбца ImageNames в старой таблице, если он отсутствует
if 'ImageNames' not in df_old.columns:
    df_old['ImageNames'] = None

# Объединение таблиц с учетом дополнительных полей ImageNames и ImageUrls из df_new
df_old = df_old.merge(
    df_new[['Title', 'Price', 'Description', 'ImageUrls', 'ImageNames']],
    on='Title',
    how='left',
    suffixes=('', '_new')
)

# Замена значений в столбце Brand
df_old['Brand'] = df_old['Brand'].replace({
    'Nokian': 'Nokian Tyres',
    'CONTINENTAL Tires': 'Continental',
})

# Обновление столбцов Price и Description
df_old['Price'] = df_old.apply(lambda row: row['Price_new'] if pd.notna(row['Price_new']) else row['Price'], axis=1)
df_old['Description'] = df_old.apply(lambda row: row['Description_new'] if pd.notna(row['Description_new']) else row['Description'], axis=1)

# Логика работы с ImageUrls и ImageNames
df_old['ImageNames'] = df_old.apply(
    lambda row: row['ImageNames_new'] if pd.notna(row['ImageNames_new']) else row['ImageNames'],
    axis=1
)
df_old['ImageUrls'] = df_old.apply(
    lambda row: None if pd.notna(row['ImageNames_new']) else row['ImageUrls_new'] if pd.notna(row['ImageUrls_new']) else row['ImageUrls'],
    axis=1
)

# Удаление временных столбцов
df_old.drop(columns=['Price_new', 'Description_new', 'ImageUrls_new', 'ImageNames_new'], inplace=True)

# Обновление статуса публикации на основании новой таблицы
df_old = df_old.merge(df_new[['Title', 'AvitoStatus']], on='Title', how='left', suffixes=('', '_new'))

# Установить статус "Снято с публикации" для записей, которых нет в новой таблице, или если в новой таблице статус "Снято с публикации"
df_old['AvitoStatus'] = df_old.apply(
    lambda row: 'Снято с публикации' if pd.isna(row['AvitoStatus_new']) or row['AvitoStatus_new'] == 'Снято с публикации' else 'Активно',
    axis=1
)

# Удаление временного столбца AvitoStatus_new
df_old.drop(columns=['AvitoStatus_new'], inplace=True)
# Добавление недостающих строк из новой таблицы в старую
df_combined = pd.concat([df_old, df_new[~df_new['Title'].isin(df_old['Title'])]])

# Удаление дубликатов по комбинации столбцов
columns_to_check = ['Brand', 'LoadIndex', 'Model', 'RimDiameter', 'SpeedIndex', 'TireAspectRatio', 'TireSectionWidth', 'RunFlat']
df_combined.drop_duplicates(subset=columns_to_check, keep='first', inplace=True)

# Удаление дубликатов по Id
df_combined.drop_duplicates(subset=['Id'], keep='first', inplace=True)

# Добавление столбца DateEnd, если его нет
if 'DateEnd' not in df_combined.columns:
    df_combined['DateEnd'] = None

# Обновление столбца DateEnd
current_date = datetime.now()
date_plus_one_month = (current_date + timedelta(days=30)).strftime('%Y-%m-%d')
df_combined['DateEnd'] = df_combined['AvitoStatus'].apply(
    lambda status: '2024-04-11' if status == 'Снято с публикации' else date_plus_one_month
)

# Сохранение объединенной таблицы в новый файл Excel
df_combined.to_excel('tyres_combined.xlsx', index=False)
print("Объединенные данные успешно сохранены в файл tyres_combined.xlsx")
df_links = pd.read_excel('tyres_catalog_avito_updated_vk.xlsx')       # Источник с картинками
df_target = pd.read_excel('tyres_combined.xlsx')                      # Целевая таблица

df_combined_updated = replace_image_columns_by_id(df_target, df_links)
df_combined_updated.to_excel('tyres_combined_vk.xlsx', index=False)
print("✅ Файл tyres_combined_vk.xlsx успешно сформирован — с обновлёнными картинками.")
import pandas as pd

# Функция для обновления AdStatus в зависимости от сезона и тарифа
def update_ad_status(df, season, tariff):
    # Изначально заполняем все "Free"
    df['AdStatus'] = 'Free'
    
    if season == 2:  # Зимний сезон
        df.loc[df['TireType'].str.contains('Зимние', na=False), 'AdStatus'] = tariff
    elif season == 1:  # Летний сезон
        df.loc[df['TireType'].str.contains('Летние', na=False), 'AdStatus'] = tariff

# Загрузка объединенной таблицы
file_path = 'tyres_combined.xlsx'
df = pd.read_excel(file_path)

# Параметры для обновления AdStatus
season = 0  # Пример: 2 - Зимний сезон (если 0, то все останется Free)
tariff = 'x5_7'  # Пример тарифа

# Обновление AdStatus
update_ad_status(df, season, tariff)

# Сохранение обновленной таблицы в новый файл
updated_file_path = 'tyres_combined_with_adstatus.xlsx'
df.to_excel(updated_file_path, index=False)
print(f"Файл {updated_file_path} успешно обновлен")
df_links = pd.read_excel('tyres_combined_vk.xlsx')                    # Источник с картинками
df_target = pd.read_excel('tyres_combined_with_adstatus.xlsx')       # Целевая таблица

df_adstatus_updated = replace_image_columns_by_id(df_target, df_links)
output_file = 'tyres_combined_with_adstatus_vk.xlsx'
df_adstatus_updated.to_excel(output_file, index=False)
print(f"✅ Файл {output_file} успешно сформирован — с обновлёнными картинками.")
# Списки значений
RimDiameter = [4, 5, 5.5, 6, 6.5, 6.7, 7, 8, 9, 10, 11, 12, "12C", 13, 13.5, "13C", 14, 14.5, "14C", 15, 15.3, 15.5, "15C", 16, 16.1, 16.5, "16C", 17, "17C", 18, "18С", 19, 20, 21, 22, 23, 24, 24.5, 25, 26, 26.5, 27, 28, 29, 30, 30.5, 31, 32, 33, 34, 35, 36, 38, 40, 42, 44, 45, 46, 48, 50, 55]

TireAspectRatio = [4.5, 5, 6, 7, 8, 8.5, 9, 9.5, 10, 10.5, 11.5, 12.5, 13.5, 15.5, 20, 25, 26, 27, 28, 29, 30, 32, 35, 37, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105, 180, 400, 420, 500, 530, 600, 700, 710, 720, 740]

TireSectionWidth = [2.25, 3.25, 3.75, 4, 4.00, 4.25, 5, 5.00, 5.10, 5.40, 5.50, 5.60, 6, 6.00, 6.5, 6.25, 6.40, 6.50, 6.7, 6.95, 7, 7.00, 7.5, 7.50, 8, 8.3, 8.4, 8.5, 8.15, 8.25, 8.40, 9, 9.00, 9.5, 10, 10.00, 10.5, 10.8, 11, 11.00, 11.2, 11.5, "11L", 12, 12.00, 12.4, 12.5, 13, 13.00, 13.6, 14, 14.00, 14.5, 14.9, 14.25, 14.75, 15, 15.00, 15.3, 15.5, 16, 16.00, 16.5, 16.9, 16.24, 17.5, 18, 18.00, 18.4, 18.7, 18.8, 19.5, 20, 20.5, 20.8, 21, 21.3, 21.5, 21.8, "21L", 22, 23, 23.1, 23.5, "23.5L", 24, 24.0, 24.5, 25, 26, 26.5, 27, 28, 28.1, "28L", 29.5, 30, 30.5, 31, 31.5, 32, 33, 35, 37, 38, 40, 65, 71, 75, 85, 87, 95, 115, 125, 130, 135, 145, 150, 155, 165, 175, 185, 190, 195, 200, 205, 215, 225, 230, 235, 240, 245, 255, 260, 265, 270, 275, 285, 295, 300, 305, 315, 320, 325, 335, 340, 345, 355, 360, 365, 370, 375, 380, 385, 390, 395, 400, 405, 415, 420, 425, 435, 440, 445, 455, 460, 480, 500, 520, 530, 540, 550, 560, 580, 600, 605, 620, 650, 690, 700, 710, 800, 850, 900, 1025, 1050, 1065, 1100, 1200, 1220, 1280, 1300, 1500, 1600]

import pandas as pd
from datetime import datetime 

# Ссылка на изображение доставки (Google Диск)
delivery_image_url = 'https://drive.google.com/uc?export=view&id=1pOQmlXtyEXGmf5ZF4Iwwh14YKRPen9z3'

# Загрузка таблицы
file_path = 'tyres_combined_with_adstatus.xlsx'
df = pd.read_excel(file_path)

# Заполнение пустых значений в столбце Address
df['Address'].fillna('Самарская обл., Самара', inplace=True)
df['Quantity'] = 'за 1 шт.'

# Добавляем столбец с константным значением
df['Delivery'] = 'Свой партнер ПЭК | Свой партнер СДЭК | Свой партнер Деловые Линии | Свой партнер DPD | Свой курьер'

# Добавляем столбец с кол-во шин в остатках
df['Stock'] = 20

now = datetime.now()
formatted_date = now.strftime("%Y-%m-%dT%H:%M:%S")

df['Date'] = formatted_date

# Добавляем столбцы InternetCalls и CallsDevices в таблицу
df['InternetCalls'] = 'Да'
df['CallsDevices'] = '4015481993'

# Функция обработки ImageUrls: исправляем зону доставки, но не трогаем первое изображение
def clean_image_urls(image_urls):
    if pd.isna(image_urls):
        return delivery_image_url  # Если пусто, добавляем только зону доставки

    urls = image_urls.split(" | ")  # Разбиваем строку на список

    # Первое изображение (главное фото) остаётся без изменений
    main_image = urls[0] if urls else None

    # Проверяем остальные изображения
    other_images = urls[1:]  # Все кроме первого
    unique_images = list(set(other_images))  # Удаляем дубликаты

    # Отделяем ссылки на Авито и Google Диск
    avito_links = [url for url in unique_images if "avito.ru/autoload" in url]
    google_drive_links = [url for url in unique_images if delivery_image_url in url]

    # Определяем **единственную** ссылку на зону доставки
    if google_drive_links:
        delivery_link = delivery_image_url  # Оставляем Google Диск
    elif avito_links:
        delivery_link = avito_links[-1]  # Оставляем последнюю ссылку Авито
    else:
        delivery_link = delivery_image_url  # Если доставки вообще нет, добавляем Google Диск

    # Собираем итоговый список (первое изображение + остальные + 1 зона доставки)
    cleaned_urls = [main_image] + [url for url in unique_images if url not in google_drive_links and url not in avito_links]
    cleaned_urls.append(delivery_link)  # Добавляем только **одну** ссылку на доставку

    return " | ".join([url for url in cleaned_urls if url])

# Применяем функцию очистки
df['ImageUrls'] = df['ImageUrls'].apply(clean_image_urls)

# Преобразование всех значений в строки
df['RimDiameter'] = df['RimDiameter'].astype(str)

# Фильтрация строк, чтобы оставить только те, которые соответствуют допустимым значениям
df = df[df['RimDiameter'].isin([str(item) for item in RimDiameter])]
df = df[df['TireAspectRatio'].isin(TireAspectRatio)]
df = df[df['TireSectionWidth'].isin(TireSectionWidth)]

# Удаление строк, где LoadIndex меньше 18
df = df[df['LoadIndex'] >= 18]

# Сохранение обновленной таблицы
updated_file_path = 'tyres_last.xlsx'
df.to_excel(updated_file_path, index=False)
print(f"Файл {updated_file_path} успешно обновлен")
df_links = pd.read_excel('tyres_combined_with_adstatus_vk.xlsx')     # Источник с картинками
df_target = pd.read_excel('tyres_last.xlsx')                          # Целевая таблица

df_last_updated = replace_image_columns_by_id(df_target, df_links)
output_file = 'tyres_last_vk.xlsx'
df_last_updated.to_excel(output_file, index=False)
print(f"✅ Файл {output_file} успешно сформирован — с обновлёнными картинками.")
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime
import math

# === Параметры ===
excel_path = "tyres_last_vk.xlsx"
output_prefix = "vk_yml_output_part"  # имена файлов: vk_yml_output_part1.xml, ...
num_parts = 5

default_currency = "RUB"
default_category_id = 1
shop_name = "ИН Шина"
shop_url = "https://vk.com/in_shina"
company_name = "ИН Шина"

# === Фиксированное описание ===
fixed_description_template = """
Новые шины с бесплатной доставкой по Самаре и Новокуйбышевску.

!!!{title}!!!

✅ Доставка шин производится в любое комфортное для вас время.
✅ Предоставляем заводскую гарантию.
✅ Оплата по факту получения товара.

✅ Любой способ оплаты:
- Банковской картой (Цена может увеличиться, уточняйте у менеджера)
- Наличные
- Перевод по номеру телефона
- QR-Код

✅ Наша продукция хранится на складах, которые проходят проверки от производителей.
✅ Возможность заказа новых шин любого производителя по всем доступным типоразмерам.
✅ У нас в продаже абсолютно новые шины - без эксплуатации и каких-либо повреждений.

👤 По всем вопросам вас проконсультирует менеджер по телефону или в личных сообщениях в ВК.
Будем рады вам помочь ❤️

⚠️Важно:
❗️В другие города отправляем транспортными компаниями по 100% предоплате

🎊 Подписывайтесь на наше сообщество, чтобы не пропустить новые акции, распродажи и выгодные предложения!
""".strip()

# === Загрузка Excel ===
df = pd.read_excel(excel_path)

# === Делим таблицу на части ===
split_dfs = []
chunk_size = math.ceil(len(df) / num_parts)
for i in range(num_parts):
    start = i * chunk_size
    end = (i + 1) * chunk_size
    split_dfs.append(df.iloc[start:end])

# === Функция генерации одного XML-файла ===
def generate_yml(df_chunk, output_file):
    yml_catalog = ET.Element("yml_catalog", date=datetime.now().strftime("%Y-%m-%d %H:%M"))
    shop = ET.SubElement(yml_catalog, "shop")

    ET.SubElement(shop, "name").text = shop_name
    ET.SubElement(shop, "company").text = company_name
    ET.SubElement(shop, "url").text = shop_url

    currencies = ET.SubElement(shop, "currencies")
    ET.SubElement(currencies, "currency", id=default_currency, rate="1")

    categories = ET.SubElement(shop, "categories")
    ET.SubElement(categories, "category", id="1").text = "Шины и диски"

    offers = ET.SubElement(shop, "offers")

    for _, row in df_chunk.iterrows():
        offer_id = str(row["Id"])
        price = str(int(row["Price"])) if pd.notna(row["Price"]) else "0"
        title = row["Title"] if pd.notna(row["Title"]) else "Без названия"
        description = fixed_description_template.format(title=title)
        available = "true" if row.get("AvitoStatus", "").strip() == "Активно" else "false"
        image_urls = str(row["ImageUrls"]).split(" | ") if pd.notna(row["ImageUrls"]) else []

        offer = ET.SubElement(offers, "offer", id=offer_id, available=available)
        ET.SubElement(offer, "price").text = price
        ET.SubElement(offer, "currencyId").text = default_currency
        ET.SubElement(offer, "categoryId").text = str(default_category_id)
        ET.SubElement(offer, "name").text = title
        ET.SubElement(offer, "description").text = description

        if pd.notna(row.get("TireType")):
            ET.SubElement(offer, "param", name="Сезон").text = str(row["TireType"])
        if pd.notna(row.get("RunFlat")):
            ET.SubElement(offer, "param", name="RunFlat").text = str(row["RunFlat"])

        for img_url in image_urls:
            img_url = img_url.strip()
            if img_url:
                ET.SubElement(offer, "picture").text = img_url

    tree = ET.ElementTree(yml_catalog)
    tree.write(output_file, encoding="utf-8", xml_declaration=True)
    print(f"✅ Файл сохранён: {output_file}")

# === Генерация всех частей ===
for i, chunk_df in enumerate(split_dfs, start=1):
    filename = f"{output_prefix}{i}.xml"
    generate_yml(chunk_df, filename)
