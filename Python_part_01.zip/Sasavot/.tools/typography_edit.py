from pathlib import Path
import re
root=Path('R:/Python/Sasavot')
def edit(path, fn):
 p=root/path; p.write_text(fn(p.read_text(encoding='utf-8-sig')),encoding='utf-8')
edit('project.godot',lambda s:s.replace('window/stretch/mode="viewport"','window/stretch/mode="canvas_items"'))
def theme(s):
 s=s.replace('load_steps=13','load_steps=15')
 s=s.replace('[sub_resource type="StyleBoxFlat" id="Panel"]','[ext_resource type="FontFile" path="res://assets/fonts/NotoSans.ttf" id="ui"]\n[ext_resource type="FontFile" path="res://assets/fonts/RussoOne.ttf" id="display"]\n\n[sub_resource type="StyleBoxFlat" id="Panel"]')
 s=s.replace('default_font_size = 13','default_font = ExtResource("ui")\ndefault_font_size = 14')
 s=s.replace('Color(0.65, 0.59, 0.62, 1)','Color(0.76, 0.71, 0.74, 1)').replace('Color(0.43, 0.38, 0.4, 1)','Color(0.56, 0.53, 0.55, 1)')
 for typ,size in [('Button',14),('NavButton',12),('Label',14),('MutedLabel',13)]:
  s=re.sub(r'(?m)^'+typ+r'/font_sizes/font_size = \d+',f'{typ}/font_sizes/font_size = {size}',s)
 s+='\n'
 for typ,size in [('CaptionLabel',12),('SmallLabel',13),('BodyLabel',14),('HeadingLabel',18),('CounterLabel',22),('BrandLabel',29),('EditionLabel',10),('StatusLabel',11),('MonitorLabel',8),('PropLabel',6)]:
  s+=f'{typ}/base_type = &"Label"\n{typ}/font_sizes/font_size = {size}\n'
 for typ in ['TitleLabel','BrandLabel','EditionLabel','StatusLabel']:
  s+=f'{typ}/fonts/font = ExtResource("display")\n'
 for role,size in [('caption',12),('small',13),('body',14),('button',14),('heading',18),('title',22),('counter',22)]:
  s+=f'Typography/font_sizes/{role} = {size}\n'
 s+='MonitorText/base_type = &"RichTextLabel"\nMonitorText/font_sizes/normal_font_size = 8\n'
 return s
edit('resources/themes/sasa_theme.tres',theme)
def scene(s):
 blocks=s.split('\n[node ')
 mapping={'Logo':'BrandLabel','Edition':'EditionLabel','Header':'SmallLabel','Caption':'CaptionLabel','ViewersValue':'CounterLabel','MoneyValue':'CounterLabel','HypeLabel':'CaptionLabel','EnergyLabel':'CaptionLabel','Status':'StatusLabel','Toast':'MutedLabel','SaveStatus':'MutedLabel','DebugLabel':'CaptionLabel','Eyebrow':'EditionLabel','ModalTitle':'TitleLabel'}
 for i,b in enumerate(blocks):
  m=re.match(r'name="([^"]+)"',b)
  if m and m[1] in mapping:
   b=re.sub(r'\ntheme_override_font_sizes/font_size = \d+','',b)
   b=re.sub(r'\ntheme_type_variation = &"[^"]+"','',b)
   b+='\ntheme_type_variation = &"'+mapping[m[1]]+'"\n'
  blocks[i]=b
 return '\n[node '.join(blocks)
edit('src/features/stream/scenes/main_game.tscn',scene)
edit('src/features/stream/ui/sasa_ui.gd',lambda s:s.replace('font_size: int = 13','role: StringName = &"body"').replace('"font_size", font_size','"font_size", THEME.get_font_size(role, &"Typography")'))
def controller(s):
 # Call sites select semantic roles; concrete sizes belong to the theme.
 s=re.sub(r', (12|13|14|15|16|18|24)(?=, &|\)\))',lambda m:', &"'+({'12':'small','13':'body','14':'body','15':'body','16':'heading','18':'heading','24':'heading'}[m[1]])+'"',s)
 s=s.replace('child.text = "Восстановление: %d с" % remaining if remaining > 0 else "Готово"','child.text = _move_status(str(child.get_meta("cooldown_id")))\n\t\t\telif child is Button and child.has_meta("move_id"):\n\t\t\t\tchild.disabled = _move_status(str(child.get_meta("move_id"))) != "Готово"')
 s=s.replace('\t\t\t\tvar remaining: int = app.moves.remaining(str(child.get_meta("cooldown_id")), app.stream.elapsed)\n','')
 s=s.replace('else "Пропустить событие" if kind == "event"','else "Пропустить событие" if kind == "event"')
 s=s.replace('\tfor id: String in app.catalog.moves:', '\tif not app.stream.state.is_streaming:\n\t\tmodal_body.add_child(SasaUI.label("Сначала начните эфир"))\n\tfor id: String in app.catalog.moves:')
 s=s.replace('\t\tvar left: int = app.moves.remaining(id, app.stream.elapsed)\n','\t\tif not app.stream.state.is_streaming:\n\t\t\tmodal_body.add_child(SasaUI.label("Только во время эфира", &"small", &"MutedLabel"))\n')
 s=s.replace('"Восстановление: %d с" % left if left > 0 else "Готово"','_move_status(id)')
 s=s.replace('modal_body.add_child(SasaUI.button("Использовать",','var move_button: Button = SasaUI.button("Использовать",')
 s=s.replace('\t\t))\n\tmodal_body.add_child(SasaUI.label("Энергия', '\t\t)\n\t\tmove_button.set_meta("move_id", id)\n\t\tmove_button.disabled = _move_status(id) != "Готово"\n\t\tmodal_body.add_child(move_button)\n\tmodal_body.add_child(SasaUI.label("Энергия')
 s=s.replace('button.disabled = level >= definition.max_level','button.disabled = level >= definition.max_level or app.stream.state.money < app.upgrades.cost(app.stream.state, id)')
 s=s.replace('\tmodal_body.add_child(SasaUI.button("Пропустить", func() -> void: _resolve_event(false)))\n','')
 s=s.replace('func _resolve_event(accept: bool) -> void:\n','func _resolve_event(accept: bool) -> void:\n\tif modal_kind != "event" or app.events.pending == null:\n\t\treturn\n')
 s=s.replace('"Прогресс сохранён"','"Сохранено ✓"')
 s=s.replace('func _show_upgrades() -> void:', '''func _move_status(id: String) -> String:
\tif not app.stream.state.is_streaming:
\t\treturn "НЕДОСТУПНО"
\tvar remaining: int = app.moves.remaining(id, app.stream.elapsed)
\tif remaining > 0:
\t\treturn "Восстановление: %d с" % remaining
\tvar definition: ActionDefinition = app.catalog.moves[id]
\tif app.stream.state.money < definition.money_cost:
\t\treturn "Не хватает монет"
\tvar energy_cost: float = definition.energy_cost / float(app.upgrades.stats(app.stream.state)["max_energy"]) * app.config.base_energy
\tif app.stream.state.energy < energy_cost:
\t\treturn "Не хватает энергии"
\treturn "Готово"

func _show_upgrades() -> void:''')
 return s
edit('src/features/stream/ui/main_game_controller.gd',controller)
