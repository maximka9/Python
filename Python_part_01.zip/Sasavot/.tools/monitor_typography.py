exec(open('.tools/typography_edit.py',encoding='utf-8').read().split("edit('project.godot'")[0])
def room(s):
 blocks=s.split('\n[node ')
 result=[]
 for b in blocks:
  m=re.match(r'name="Row(\d+)"',b)
  if m:
   n=int(m[1])
   if n>=4: continue
   b=re.sub(r'offset_top = [\d.]+',f'offset_top = {n*11}.0',b)
   b=re.sub(r'offset_bottom = [\d.]+',f'offset_bottom = {n*11+11}.0',b)
  if 'theme_override_font_sizes/normal_font_size = 7' in b:
   b=b.replace('theme_override_font_sizes/normal_font_size = 7','theme_type_variation = &"MonitorText"')
  if 'theme_override_font_sizes/font_size = 7' in b:
   b=b.replace('theme_override_font_sizes/font_size = 7','theme_type_variation = &"MonitorLabel"')
  if 'theme_override_font_sizes/font_size = 6' in b:
   b=b.replace('theme_override_font_sizes/font_size = 6','theme_type_variation = &"PropLabel"')
  result.append(b)
 return '\n[node '.join(result)
edit('src/features/stream/scenes/room_view.tscn',room)
edit('src/features/stream/ui/room_view.gd',lambda s:s.replace('CHAT_LIMIT: int = 6','CHAT_LIMIT: int = 4').replace('1.0 if live else 0.45','1.0 if live else 0.75'))
