from pathlib import Path
labels = {
 'stream_types/just_chatting': ('Just Chatting', 'Общение с чатом. Больше хайпа от событий.'),
 'stream_types/dota_2': ('Dota 2', 'Потные катки и верные зрители.'),
 'stream_types/irl': ('IRL', 'Выйди в город — собери новый онлайн.'),
 'upgrades/microphone': ('Микрофон', '+1 к силе клика'),
 'upgrades/monitor': ('Монитор', '+10% к доходу'),
 'upgrades/camera': ('Камера', '+10% хайпа за клик'),
 'upgrades/chair': ('Кресло', '+10 к вместимости энергии'),
 'upgrades/internet': ('Интернет', '+5% к онлайну'),
 'moves/beer': ('Взять пиво', '−10 энергии · +15 хайпа. Онлайн ×1.15 на 20 с · откат 30 с'),
 'moves/collab': ('Коллаб', '−100 монет · +25 хайпа. Онлайн ×1.35 на 30 с · откат 60 с'),
 'events/meme': ('Чат разогнал мем', 'Подхватить мем: +12 хайпа, бонус онлайну на 20 с.'),
 'events/clip': ('Клип залетел', 'Поделиться клипом: +20 хайпа, +15 монет, бонус онлайну.'),
 'events/collab_offer': ('Предложили коллаб', 'Пригласить гостя: −100 монет, +25 хайпа. Откат коллаба действует.'),
 'events/beer_offer': ('Взять пиво?', '−10 энергии, +15 хайпа. Откат мува действует.'),
 'events/shipping': ('Чат начал шипперить', 'Подыграть чату: +18 хайпа, бонус онлайну на 20 с.'),
}
for name, (title, desc) in labels.items():
 p = Path('resources') / (name + '.tres')
 text = p.read_text(encoding='utf-8')
 start = text.index('title = ')
 end = text.index('\n', text.index('"', text.index('description = ') + 15) + 1)
 # Preserve all numerical effect fields after the description's closing quote.
 lines = text.splitlines()
 index = next(i for i,line in enumerate(lines) if line.startswith(('viewer_multiplier =', 'base_cost =', 'money_cost =', 'hype_gain =')))
 p.write_text(text[:start] + f'title = "{title}"\ndescription = "{desc}"\n' + '\n'.join(lines[index:]) + '\n', encoding='utf-8')
