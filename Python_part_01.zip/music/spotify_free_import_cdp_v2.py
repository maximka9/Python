#!/usr/bin/env python3
"""
Spotify Free playlist importer via Spotify Web Player + Playwright.

No Spotify Developer API key is used.
You log into Spotify manually in the browser.
The script reads a CSV with columns: title, artist.

Recommended input: spotify_import.csv
"""

from __future__ import annotations

import argparse
import csv
import re
import sys
import time
import unicodedata
from pathlib import Path
from urllib.parse import quote

from playwright.sync_api import (
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)

DEFAULT_INPUT = "spotify_import.csv"
DEFAULT_RESULTS = "spotify_import_results.csv"
DEFAULT_PROFILE = ".spotify-browser-profile"

ADD_TO_PLAYLIST_PATTERNS = (
    r"Add to playlist",
    r"Добавить в плейлист",
    r"Zu Playlist hinzufügen",
)

DONE_PATTERNS = (
    r"^Done$",
    r"^Готово$",
    r"^Fertig$",
    r"^Speichern$",
    r"^Save$",
)

LOGIN_HINTS = (
    "Log in",
    "Войти",
    "Anmelden",
)


def norm(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).casefold()
    text = re.sub(r"[^\w\s]+", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def tokens(text: str) -> set[str]:
    return {x for x in norm(text).split() if len(x) >= 2}


def candidate_score(row_text: str, title: str, artist: str) -> float:
    """
    Simple local fuzzy score. No AI/API calls.
    Search results usually contain title + artist + album.
    """
    row_n = norm(row_text)
    title_n = norm(title)
    artist_n = norm(artist)

    score = 0.0
    if title_n and title_n in row_n:
        score += 0.68
    if artist_n and artist_n in row_n:
        score += 0.27

    wanted_title = tokens(title)
    wanted_artist = tokens(artist)
    row_tokens = tokens(row_text)

    if wanted_title:
        score += 0.03 * (
            len(wanted_title & row_tokens) / max(1, len(wanted_title))
        )
    if wanted_artist:
        score += 0.02 * (
            len(wanted_artist & row_tokens) / max(1, len(wanted_artist))
        )

    return min(score, 1.0)


def read_input(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    if not rows:
        raise SystemExit(f"CSV пуст: {path}")

    required = {"title", "artist"}
    if not required.issubset(rows[0].keys()):
        raise SystemExit(
            f"В CSV нужны колонки title и artist. Сейчас: {list(rows[0].keys())}"
        )

    result = []
    for i, row in enumerate(rows, start=1):
        title = (row.get("title") or "").strip()
        artist = (row.get("artist") or "").strip()
        if not title:
            continue
        result.append(
            {
                "index": str(i),
                "title": title,
                "artist": artist,
                "source": (row.get("source") or "").strip(),
                "original": (row.get("original") or "").strip(),
            }
        )
    return result


def load_completed(path: Path) -> set[str]:
    if not path.exists():
        return set()

    completed = set()
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("status") == "added":
                completed.add(row.get("key", ""))
    return completed


RESULT_FIELDS = [
    "key",
    "index",
    "title",
    "artist",
    "status",
    "score",
    "matched_row",
    "error",
]


def append_result(
    path: Path,
    *,
    key: str,
    index: str,
    title: str,
    artist: str,
    status: str,
    score: float | None = None,
    matched_row: str = "",
    error: str = "",
) -> None:
    new_file = not path.exists()
    with path.open("a", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=RESULT_FIELDS)
        if new_file:
            writer.writeheader()
        writer.writerow(
            {
                "key": key,
                "index": index,
                "title": title,
                "artist": artist,
                "status": status,
                "score": "" if score is None else f"{score:.3f}",
                "matched_row": matched_row.replace("\n", " | "),
                "error": error,
            }
        )


def _nearest_track_container(track_link):
    """
    Search pages do not always use data-testid=tracklist-row.
    Prefer the nearest ancestor that also contains an artist link.
    """
    selectors = [
        "xpath=ancestor::*[@data-testid='tracklist-row'][1]",
        "xpath=ancestor::*[@role='row'][1]",
        "xpath=ancestor::*[.//a[contains(@href, '/artist/')]][1]",
    ]

    for selector in selectors:
        try:
            loc = track_link.locator(selector)
            if loc.count() and loc.first.is_visible():
                return loc.first
        except Exception:
            pass

    # Fallback: climb a few levels and pick a compact block containing the track.
    try:
        cur = track_link
        for _ in range(7):
            cur = cur.locator("..")
            if not cur.count():
                break
            text = cur.inner_text(timeout=800).strip()
            if 0 < len(text) <= 700:
                # A useful track/card block usually has multiple links or a button.
                links = cur.locator("a").count()
                buttons = cur.locator("button").count()
                if links >= 2 or buttons >= 1:
                    return cur
    except Exception:
        pass

    return track_link


def _title_similarity(actual: str, wanted: str) -> float:
    a = norm(actual)
    w = norm(wanted)
    if not a or not w:
        return 0.0
    if a == w:
        return 1.0
    if a in w or w in a:
        return 0.90

    at = tokens(actual)
    wt = tokens(wanted)
    if not at or not wt:
        return 0.0

    intersection = len(at & wt)
    union = len(at | wt)
    jaccard = intersection / max(1, union)
    coverage = intersection / max(1, len(wt))
    return max(jaccard, coverage * 0.92)


def _artist_similarity(container_text: str, artist: str) -> float:
    if not artist.strip():
        return 1.0

    c = norm(container_text)
    a = norm(artist)

    if a and a in c:
        return 1.0

    wanted = tokens(artist)
    got = tokens(container_text)
    if not wanted:
        return 1.0
    return len(wanted & got) / max(1, len(wanted))


def visible_track_candidates(page, max_candidates=20):
    """
    Discover actual Spotify track links. This works across multiple search layouts:
    cards, compact results, and classic track rows.
    """
    selectors = [
        'a[href^="/track/"]',
        'a[href*="open.spotify.com/track/"]',
    ]

    links = None
    for selector in selectors:
        try:
            candidate = page.locator(selector)
            if candidate.count():
                links = candidate
                break
        except Exception:
            pass

    if links is None:
        return []

    results = []
    seen_hrefs = set()

    for i in range(min(links.count(), 80)):
        link = links.nth(i)
        try:
            if not link.is_visible():
                continue

            href = (link.get_attribute("href") or "").strip()
            if not href or href in seen_hrefs:
                continue
            seen_hrefs.add(href)

            title_text = link.inner_text(timeout=1200).strip()
            aria = (link.get_attribute("aria-label") or "").strip()
            if not title_text:
                title_text = aria
            if not title_text:
                continue

            container = _nearest_track_container(link)
            try:
                container_text = container.inner_text(timeout=1200).strip()
            except Exception:
                container_text = title_text

            results.append(
                {
                    "link": link,
                    "container": container,
                    "title_text": title_text,
                    "container_text": container_text,
                    "href": href,
                }
            )

            if len(results) >= max_candidates:
                break
        except Exception:
            continue

    return results


def find_best_track(page, title: str, artist: str):
    candidates = visible_track_candidates(page)
    if not candidates:
        return None, None, "", 0.0, []

    scored = []
    for c in candidates:
        title_score = _title_similarity(c["title_text"], title)
        artist_score = _artist_similarity(c["container_text"], artist)

        # Title is decisive; artist disambiguates versions/covers.
        score = 0.74 * title_score + 0.26 * artist_score

        # Exact/contained title + exact artist should be effectively certain.
        if title_score >= 0.99 and artist_score >= 0.99:
            score = 1.0

        scored.append((score, c))

    scored.sort(key=lambda x: x[0], reverse=True)
    best_score, best = scored[0]

    debug = [
        (
            round(score, 3),
            c["title_text"],
            c["container_text"].replace("\n", " | ")[:260],
            c["href"],
        )
        for score, c in scored[:5]
    ]

    return (
        best["link"],
        best["container"],
        best["container_text"],
        best_score,
        debug,
    )


def click_first_visible_text(page, patterns, timeout_ms=2500) -> bool:
    deadline = time.time() + timeout_ms / 1000
    regex = re.compile("|".join(f"(?:{p})" for p in patterns), re.I)

    while time.time() < deadline:
        # Buttons / menu items first.
        for role in ("menuitem", "button"):
            try:
                loc = page.get_by_role(role, name=regex)
                for i in range(min(loc.count(), 10)):
                    x = loc.nth(i)
                    if x.is_visible():
                        x.click(timeout=1500)
                        return True
            except Exception:
                pass

        # Fallback to visible text.
        try:
            loc = page.get_by_text(regex)
            for i in range(min(loc.count(), 15)):
                x = loc.nth(i)
                if x.is_visible():
                    x.click(timeout=1500)
                    return True
        except Exception:
            pass

        page.wait_for_timeout(150)

    return False


def click_playlist_name(page, playlist_name: str, timeout_ms=4500) -> bool:
    deadline = time.time() + timeout_ms / 1000
    exact = re.compile(rf"^{re.escape(playlist_name)}$", re.I)

    while time.time() < deadline:
        # Prefer open menu/dialog so we don't click the sidebar playlist accidentally.
        for root_sel in ('[role="menu"]', '[role="dialog"]'):
            try:
                roots = page.locator(root_sel)
                for r in range(roots.count()):
                    root = roots.nth(r)
                    if not root.is_visible():
                        continue
                    loc = root.get_by_text(exact)
                    for i in range(loc.count()):
                        x = loc.nth(i)
                        if x.is_visible():
                            x.click(timeout=1500)
                            return True
            except Exception:
                pass

        # Generic fallback.
        try:
            loc = page.get_by_text(exact)
            visible = [loc.nth(i) for i in range(loc.count()) if loc.nth(i).is_visible()]
            # Last visible element is often the submenu/dialog entry rather than sidebar.
            if visible:
                visible[-1].click(timeout=1500)
                return True
        except Exception:
            pass

        page.wait_for_timeout(150)

    return False


def maybe_confirm_done(page):
    click_first_visible_text(page, DONE_PATTERNS, timeout_ms=900)


def add_track_to_playlist(page, track_link, container, playlist_name: str) -> None:
    target = container if container is not None else track_link

    try:
        target.scroll_into_view_if_needed(timeout=3000)
        target.hover(timeout=2000)
    except Exception:
        pass

    # Prefer Spotify's own More button where available.
    more_selectors = [
        'button[data-testid="more-button"]',
        'button[aria-label*="More"]',
        'button[aria-label*="more"]',
        'button[aria-label*="Ещё"]',
        'button[aria-label*="Еще"]',
        'button[aria-label*="Mehr"]',
    ]

    clicked_more = False
    for selector in more_selectors:
        try:
            loc = target.locator(selector)
            for i in range(min(loc.count(), 8)):
                button = loc.nth(i)
                if button.is_visible():
                    button.click(timeout=1800)
                    clicked_more = True
                    break
        except Exception:
            pass
        if clicked_more:
            break

    # Fallback to Spotify's context menu.
    if not clicked_more:
        try:
            target.click(button="right", timeout=3000)
        except Exception:
            track_link.click(button="right", timeout=3000)

    page.wait_for_timeout(300)

    if not click_first_visible_text(page, ADD_TO_PLAYLIST_PATTERNS, timeout_ms=3500):
        raise RuntimeError(
            'Не нашёл "Add to playlist / Добавить в плейлист" после открытия меню.'
        )

    page.wait_for_timeout(350)

    if not click_playlist_name(page, playlist_name, timeout_ms=5500):
        raise RuntimeError(
            f'Не нашёл плейлист "{playlist_name}" в меню добавления.'
        )

    page.wait_for_timeout(250)
    maybe_confirm_done(page)



def main():
    parser = argparse.ArgumentParser(
        description="Импорт CSV в Spotify через уже запущенный обычный Chrome (CDP)."
    )
    parser.add_argument(
        "--input",
        default=DEFAULT_INPUT,
        help=f"CSV с title,artist (по умолчанию {DEFAULT_INPUT})",
    )
    parser.add_argument(
        "--playlist",
        help="Точное имя заранее созданного Spotify-плейлиста",
    )
    parser.add_argument(
        "--results",
        default=DEFAULT_RESULTS,
        help="CSV с прогрессом/ошибками",
    )
    parser.add_argument(
        "--min-score",
        type=float,
        default=0.72,
        help="Минимальная уверенность совпадения 0..1 (по умолчанию 0.72)",
    )
    parser.add_argument(
        "--cdp",
        default="http://127.0.0.1:9222",
        help="Адрес Chrome DevTools Protocol",
    )
    parser.add_argument(
        "--max-tracks",
        type=int,
        default=0,
        help="Обработать только первые N строк (0 = все). Удобно для теста.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Показывать несколько найденных Spotify-кандидатов.",
    )
    args = parser.parse_args()

    input_path = Path(args.input).resolve()
    results_path = Path(args.results).resolve()

    if not input_path.exists():
        raise SystemExit(f"Не найден файл: {input_path}")

    playlist_name = (args.playlist or input(
        "Точное имя заранее созданного плейлиста Spotify: "
    )).strip()
    if not playlist_name:
        raise SystemExit("Название плейлиста не может быть пустым.")

    tracks = read_input(input_path)
    if args.max_tracks and args.max_tracks > 0:
        tracks = tracks[:args.max_tracks]
    completed = load_completed(results_path)

    print(f"Входных треков: {len(tracks)}")
    print(f"Уже добавлено по журналу: {len(completed)}")
    print(f'Целевой плейлист: "{playlist_name}"')
    print(f"Chrome CDP: {args.cdp}")
    print(f"Журнал: {results_path}")
    print()

    with sync_playwright() as p:
        try:
            browser = p.chromium.connect_over_cdp(args.cdp, timeout=10000)
        except Exception as exc:
            print("\nНЕ УДАЛОСЬ ПОДКЛЮЧИТЬСЯ К CHROME.")
            print("Сначала запустите Chrome с remote debugging на порту 9222.")
            print("Можно использовать приложенный start_spotify_chrome.bat")
            print(f"\nТехническая ошибка: {type(exc).__name__}: {exc}")
            raise SystemExit(2)

        if not browser.contexts:
            raise SystemExit("Chrome подключён, но контекст браузера не найден.")

        context = browser.contexts[0]

        spotify_pages = [
            pg for pg in context.pages
            if "spotify.com" in (pg.url or "").lower()
        ]

        if spotify_pages:
            page = spotify_pages[0]
            print(f"Использую открытую вкладку Spotify: {page.url}")
        else:
            page = context.new_page()
            page.goto(
                "https://open.spotify.com/",
                wait_until="domcontentloaded",
                timeout=30000,
            )
            print("Открыл Spotify в подключённом Chrome.")

        print(
            "\nПроверьте окно Chrome:\n"
            "- вы должны быть уже авторизованы в Spotify;\n"
            f'- плейлист "{playlist_name}" должен существовать;\n'
            "- Spotify Web Player должен открываться без страницы входа.\n"
        )
        input("Когда всё готово, нажмите Enter здесь... ")

        try:
            page.goto(
                "https://open.spotify.com/",
                wait_until="domcontentloaded",
                timeout=30000,
            )
            page.wait_for_timeout(1000)
            body_text = page.locator("body").inner_text(timeout=4000)
            lower = body_text.casefold()
            if (
                ("log in" in lower or "войти" in lower or "welcome back" in lower)
                and ("your library" not in lower and "моя медиатека" not in lower)
            ):
                print(
                    "\nПохоже, эта вкладка Spotify ещё не авторизована.\n"
                    "Войдите вручную в ЭТОМ окне Chrome, затем снова запустите скрипт."
                )
                raise SystemExit(3)
        except PlaywrightTimeoutError:
            pass

        added = 0
        not_found = 0
        ambiguous = 0
        errors = 0

        for n, item in enumerate(tracks, start=1):
            title = item["title"]
            artist = item["artist"]
            key = norm(f"{title}|||{artist}")

            if key in completed:
                continue

            query = f"{title} {artist}".strip()
            print(f"[{n}/{len(tracks)}] {artist} — {title}")

            try:
                search_url = "https://open.spotify.com/search/" + quote(query, safe="")
                page.goto(search_url, wait_until="domcontentloaded", timeout=30000)

                try:
                    page.wait_for_selector(
                        'a[href^="/track/"], a[href*="open.spotify.com/track/"]',
                        timeout=8000,
                    )
                except PlaywrightTimeoutError:
                    pass

                page.wait_for_timeout(700)
                track_link, container, row_text, score, debug_rows = find_best_track(
                    page, title, artist
                )

                if args.debug:
                    print("  Spotify candidates:")
                    if not debug_rows:
                        print("    (track links not found)")
                    for ds, dt, dc, dh in debug_rows:
                        print(f"    {ds:.3f} | {dt} | {dc[:160]} | {dh}")

                if track_link is None:
                    not_found += 1
                    append_result(
                        results_path,
                        key=key,
                        index=item["index"],
                        title=title,
                        artist=artist,
                        status="not_found",
                        error="Нет строк результатов поиска",
                    )
                    print("  -> не найдено")
                    continue

                if score < args.min_score:
                    ambiguous += 1
                    append_result(
                        results_path,
                        key=key,
                        index=item["index"],
                        title=title,
                        artist=artist,
                        status="ambiguous",
                        score=score,
                        matched_row=row_text,
                        error="Низкая уверенность совпадения",
                    )
                    print(f"  -> сомнительно ({score:.2f}), пропуск")
                    continue

                add_track_to_playlist(page, track_link, container, playlist_name)

                append_result(
                    results_path,
                    key=key,
                    index=item["index"],
                    title=title,
                    artist=artist,
                    status="added",
                    score=score,
                    matched_row=row_text,
                )
                completed.add(key)
                added += 1
                print(f"  -> добавлено ({score:.2f})")

                page.wait_for_timeout(400)

            except KeyboardInterrupt:
                print("\nОстановлено пользователем. Прогресс сохранён.")
                break
            except Exception as exc:
                errors += 1
                msg = f"{type(exc).__name__}: {exc}"
                append_result(
                    results_path,
                    key=key,
                    index=item["index"],
                    title=title,
                    artist=artist,
                    status="error",
                    error=msg,
                )
                print(f"  -> ошибка: {msg}")

                try:
                    screenshot = results_path.with_name(
                        f"spotify_error_{item['index']}.png"
                    )
                    page.screenshot(path=str(screenshot), full_page=False)
                    print(f"     скриншот: {screenshot.name}")
                except Exception:
                    pass

                if errors >= 5 and added == 0:
                    print(
                        "\nПервые 5 попыток не сработали. "
                        "Останавливаюсь, чтобы не продолжать с неправильным интерфейсом."
                    )
                    break

        print("\nГотово / остановлено.")
        print(f"Добавлено в этом запуске: {added}")
        print(f"Не найдено: {not_found}")
        print(f"Сомнительные совпадения: {ambiguous}")
        print(f"Ошибки: {errors}")
        print(f"Журнал: {results_path}")
        print("\nChrome оставлен открытым.")


if __name__ == "__main__":
    main()
