import numpy as np
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import time
from ipywidgets import interactive, IntSlider, fixed
from IPython.display import display
import itertools
import pandas as pd
import imageio.v2 as imageio
import os
import shutil
def himmelblau(x, y):
    # Минимумы: f(3, 2) = 0, f(-2.805, 3.131) = 0, f(-3.779, -3.283) = 0, f(3.584, -1.848) = 0
    return (x**2 + y - 11)**2 + (x + y**2 - 7)**2

def rastrigin(x, y):
    # Минимум: f(0, 0) = 0
    A = 10
    return A * 2 + (x**2 - A * np.cos(2 * np.pi * x)) + (y**2 - A * np.cos(2 * np.pi * y))

def rosenbrock(x, y):
    # Минимум: f(1, 1) = 0
    a = 1
    b = 100
    return (a - x)**2 + b * (y - x**2)**2

def eggholder(x, y):
    # Минимум: f(512, 404.2319) ≈ -959.6407
    # Ограничения: -512 <= x, y <= 512
    sqrt_arg1 = np.abs(x / 2 + (y + 47))
    sqrt_arg2 = np.abs(x - (y + 47))
    term1 = -(y + 47) * np.sin(np.sqrt(sqrt_arg1))
    term2 = -x * np.sin(np.sqrt(sqrt_arg2))
    return term1 + term2

def grad_himmelblau(x, y):
    # df/dx = 4x(x^2 + y - 11) + 2(x + y^2 - 7)
    # df/dy = 2(x^2 + y - 11) + 4y(x + y^2 - 7)
    df_dx = 4 * x * (x**2 + y - 11) + 2 * (x + y**2 - 7)
    df_dy = 2 * (x**2 + y - 11) + 4 * y * (x + y**2 - 7)
    return df_dx, df_dy

def grad_rastrigin(x, y):
    A = 10
    # df/dx = 2x + 2πA sin(2πx)
    # df/dy = 2y + 2πA sin(2πy)
    df_dx = 2 * x + 2 * np.pi * A * np.sin(2 * np.pi * x)
    df_dy = 2 * y + 2 * np.pi * A * np.sin(2 * np.pi * y)
    return df_dx, df_dy

def grad_rosenbrock(x, y):
    a = 1
    b = 100
    # df/dx = -2(a - x) - 4bx(y - x^2)
    # df/dy = 2b(y - x^2)
    df_dx = -2 * (a - x) - 4 * b * x * (y - x**2)
    df_dy = 2 * b * (y - x**2)
    return df_dx, df_dy

# --- Класс агента (частицы) с элементами PSO ---
class LazyBirdPSO:
    def __init__(self, bounds, inertia=0.7, cognitive_rate=1.5, social_rate=1.5):
        self.bounds = bounds  # Границы поиска [(min_x, max_x), (min_y, max_y)]
        self.x = random.uniform(bounds[0][0], bounds[0][1])
        self.y = random.uniform(bounds[1][0], bounds[1][1])
        # Начальная скорость пропорциональна размеру области поиска
        self.vx = random.uniform(-abs(bounds[0][1]-bounds[0][0])*0.1, abs(bounds[0][1]-bounds[0][0])*0.1)
        self.vy = random.uniform(-abs(bounds[1][1]-bounds[1][0])*0.1, abs(bounds[1][1]-bounds[1][0])*0.1)
        self.best_x = self.x # Лучшая персональная позиция X
        self.best_y = self.y # Лучшая персональная позиция Y
        self.best_value = float('inf') # Лучшее персональное значение
        # Параметры, влияющие на движение
        self.inertia = inertia # Коэффициент инерции
        self.cognitive_rate = cognitive_rate # Когнитивный коэффициент
        self.social_rate = social_rate # Социальный коэффициент

    def update_position(self, func, best_overall_x, best_overall_y):
        # Оценка функции в текущей позиции
        try:
            current_value = func(self.x, self.y)
            if np.isnan(current_value) or np.isinf(current_value):
                 current_value = float('inf') # Считаем плохим результатом, если NaN или бесконечность
        except (ValueError, RuntimeWarning): # Например, из-за отрицательного числа под корнем или предупреждений
            current_value = float('inf') # Считаем плохим результатом в случае ошибки вычисления

        # Обновляем лучшее персональное значение и позицию
        if current_value < self.best_value:
            self.best_value = current_value
            self.best_x = self.x
            self.best_y = self.y

        # Обновление скорости (влияние инерции, личного опыта и опыта стаи)
        r1 = random.random()
        r2 = random.random()

        # Когнитивный компонент (притяжение к лучшему персональному положению)
        cognitive_vx = self.cognitive_rate * r1 * (self.best_x - self.x)
        cognitive_vy = self.cognitive_rate * r1 * (self.best_y - self.y)

        # Социальный компонент (притяжение к лучшему глобальному положению)
        social_vx = self.social_rate * r2 * (best_overall_x - self.x)
        social_vy = self.social_rate * r2 * (best_overall_y - self.y)

        # Новая скорость
        self.vx = self.inertia * self.vx + cognitive_vx + social_vx
        self.vy = self.inertia * self.vy + cognitive_vy + social_vy

        # Ограничение максимальной скорости (чтобы частицы не "вылетали" слишком далеко)
        max_speed_x = (self.bounds[0][1] - self.bounds[0][0]) * 0.2 # 20% от диапазона X
        max_speed_y = (self.bounds[1][1] - self.bounds[1][0]) * 0.2 # 20% от диапазона Y
        self.vx = np.clip(self.vx, -max_speed_x, max_speed_x)
        self.vy = np.clip(self.vy, -max_speed_y, max_speed_y)

        # Обновление позиции
        self.x += self.vx
        self.y += self.vy

        # Удержание частиц в границах поиска (строгое)
        self.x = np.clip(self.x, self.bounds[0][0], self.bounds[0][1])
        self.y = np.clip(self.y, self.bounds[1][0], self.bounds[1][1])

# --- Класс для алгоритма PSO ---
class LazyBirdAlgorithmPSO:
    def __init__(self, func, bounds, num_birds=30, max_iter=100, 
                 inertia=0.7, cognitive_rate=1.5, social_rate=1.5,
                 expected_value_stop=None, tolerance_stop=1e-7): # Новые параметры
        self.func = func # Целевая функция
        self.bounds = bounds # Границы поиска
        self.num_birds = num_birds # Количество частиц (птиц)
        self.max_iter = max_iter # Максимальное число итераций
        self.inertia = inertia # Коэффициент инерции
        self.cognitive_rate = cognitive_rate # Когнитивный коэффициент
        self.social_rate = social_rate # Социальный коэффициент
        self.expected_value_stop = expected_value_stop # Ожидаемое значение для остановки
        self.tolerance_stop = tolerance_stop # Точность для остановки

        # Инициализация частиц
        self.birds = [LazyBirdPSO(bounds, inertia=inertia, cognitive_rate=cognitive_rate, social_rate=social_rate)
                      for _ in range(num_birds)]

        # Инициализация лучших глобальных значений
        self.best_overall_value = float('inf') # Лучшее найденное значение функции
        self.best_overall_x = None # Координата X лучшего решения
        self.best_overall_y = None # Координата Y лучшего решения
        self._initial_evaluation() # Первичная оценка позиций и поиск лучшей начальной точки

    def _initial_evaluation(self):
        # Оцениваем начальные позиции всех частиц и находим лучшую
        for bird in self.birds:
            try:
                current_value = self.func(bird.x, bird.y)
                if np.isnan(current_value) or np.isinf(current_value):
                    current_value = float('inf')
            except (ValueError, RuntimeWarning):
                current_value = float('inf')

            bird.best_value = current_value # Устанавливаем начальное лучшее персональное значение
            bird.best_x = bird.x
            bird.best_y = bird.y

            if current_value < self.best_overall_value:
                self.best_overall_value = current_value
                self.best_overall_x = bird.x
                self.best_overall_y = bird.y
        # Если все начальные точки плохие (inf), установим первую частицу как лучшую
        if self.best_overall_x is None and self.birds:
             self.best_overall_x = self.birds[0].x
             self.best_overall_y = self.birds[0].y
             self.best_overall_value = self.birds[0].best_value # Используем ее значение


    def _update_global_best(self):
        # Обновляем лучшую глобальную позицию на основе лучших персональных позиций частиц
        for bird in self.birds:
            if bird.best_value < self.best_overall_value:
                self.best_overall_value = bird.best_value
                self.best_overall_x = bird.best_x
                self.best_overall_y = bird.best_y

    def run(self):
        self.convergence_history = [] # Для отслеживания лучшего значения по итерациям
        self.birds_position_history = [] # История позиций всех частиц
        self.global_best_history = [] # История лучшей найденной точки
        actual_iterations = 0 # Счетчик фактических итераций

        if self.best_overall_x is None: # Если инициализация не удалась
             print("Предупреждение: Не удалось инициализировать глобальную лучшую позицию.")
             return float('inf'), (None, None), actual_iterations # Возвращаем 0 итераций

        # Сохраняем состояние перед первой итерацией (итерация 0)
        initial_birds_positions = [(bird.x, bird.y) for bird in self.birds]
        self.birds_position_history.append(initial_birds_positions)
        self.global_best_history.append((self.best_overall_x, self.best_overall_y, self.best_overall_value))
        self.convergence_history.append(self.best_overall_value)


        for iteration in range(self.max_iter):
            actual_iterations += 1
            current_birds_positions = [] # Позиции на текущей итерации
            for bird in self.birds:
                # Передаем лучшую глобальную позицию для обновления скорости
                bird.update_position(self.func, self.best_overall_x, self.best_overall_y)
                current_birds_positions.append((bird.x, bird.y))

            # Обновляем глобальный лучший результат после движения всех частиц
            self._update_global_best()

            # Сохраняем историю (состояние *после* итерации)
            self.convergence_history.append(self.best_overall_value)
            self.birds_position_history.append(current_birds_positions)
            self.global_best_history.append((self.best_overall_x, self.best_overall_y, self.best_overall_value))

            # Проверка условия досрочной остановки
            if self.expected_value_stop is not None and \
               self.best_overall_value != float('inf') and \
               abs(self.best_overall_value - self.expected_value_stop) < self.tolerance_stop:
                # print(f"Остановка на итерации {actual_iterations} для {self.func.__name__}, значение: {self.best_overall_value:.4f}")
                break
        
        # Возвращаем лучшее найденное значение, координаты и фактическое число итераций
        return self.best_overall_value, (self.best_overall_x, self.best_overall_y), actual_iterations
        # --- Функция для численного расчета градиента ---
def numerical_gradient(func, x, y, h=1e-7): # Небольшое h для точности
    try:
        f_x_plus_h = func(x + h, y)
    except (ValueError, RuntimeWarning, OverflowError):
        f_x_plus_h = float('inf') # Обработка ошибок при вычислении
    try:
        f_x_minus_h = func(x - h, y)
    except (ValueError, RuntimeWarning, OverflowError):
        f_x_minus_h = float('inf')

    try:
        f_y_plus_h = func(x, y + h)
    except (ValueError, RuntimeWarning, OverflowError):
        f_y_plus_h = float('inf')
    try:
        f_y_minus_h = func(x, y - h)
    except (ValueError, RuntimeWarning, OverflowError):
        f_y_minus_h = float('inf')

    # Если какое-либо значение - inf, градиент в этой точке может быть очень большим или неопределенным
    # В таких случаях можно вернуть 0 или большое значение, но для простоты вернем 0,
    # т.к. это проблемная точка, и алгоритм, вероятно, должен ее избегать.
    if any(val == float('inf') for val in [f_x_plus_h, f_x_minus_h, f_y_plus_h, f_y_minus_h]):
        # Если и прямой, и обратный шаг дают inf, то градиент не определен нормально.
        # Если только один из них inf, можно попытаться использовать одностороннюю разность,
        # но для простоты пока вернем 0.
        grad_x = 0.0
        grad_y = 0.0
        # Можно также попробовать вернуть очень большое значение, чтобы "оттолкнуть" от этой точки
        # grad_x = 1e10 if f_x_plus_h == float('inf') else -1e10 # Пример
    else:
        grad_x = (f_x_plus_h - f_x_minus_h) / (2 * h)
        grad_y = (f_y_plus_h - f_y_minus_h) / (2 * h)
    
    # Дополнительная проверка на NaN/inf, которые могли возникнуть из-за деления на очень малое h
    if np.isnan(grad_x) or np.isinf(grad_x): grad_x = 0.0
    if np.isnan(grad_y) or np.isinf(grad_y): grad_y = 0.0
        
    return grad_x, grad_y
    # --- Класс для алгоритма стохастического градиентного спуска (SGD) ---
class StochasticGradientDescent:
    def __init__(self, func, bounds, learning_rate=0.01, max_iter=100,
                 expected_value_stop=None, tolerance_stop=1e-7, grad_func=None):
        self.func = func
        self.grad_func = grad_func
        self.bounds = bounds
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.expected_value_stop = expected_value_stop
        self.tolerance_stop = tolerance_stop

        # Начальная позиция
        self.x = random.uniform(bounds[0][0], bounds[0][1])
        self.y = random.uniform(bounds[1][0], bounds[1][1])
        
        self.best_x = self.x
        self.best_y = self.y
        try:
            initial_value = self.func(self.x, self.y)
            if np.isnan(initial_value) or np.isinf(initial_value):
                self.best_value = float('inf')
            else:
                self.best_value = initial_value
        except (ValueError, RuntimeWarning, OverflowError):
            self.best_value = float('inf')

    def run(self):
        self.convergence_history = []
        self.path_history = []
        self.global_best_history = []
        actual_iterations = 0

        current_x, current_y = self.x, self.y
        try:
            current_value = self.func(current_x, current_y)
            if np.isnan(current_value) or np.isinf(current_value):
                current_value = float('inf')
        except (ValueError, RuntimeWarning, OverflowError):
            current_value = float('inf')
        
        self.path_history.append((current_x, current_y, current_value))
        self.global_best_history.append((self.best_x, self.best_y, self.best_value))
        self.convergence_history.append(self.best_value)

        for iteration in range(self.max_iter):
            actual_iterations += 1
            
            if self.grad_func:
                 grad_x, grad_y = self.grad_func(current_x, current_y)
            else:
                 grad_x, grad_y = numerical_gradient(self.func, current_x, current_y)

            if np.isnan(grad_x) or np.isinf(grad_x): grad_x = 0.0
            if np.isnan(grad_y) or np.isinf(grad_y): grad_y = 0.0

            new_x = current_x - self.learning_rate * grad_x
            new_y = current_y - self.learning_rate * grad_y

            new_x = np.clip(new_x, self.bounds[0][0], self.bounds[0][1])
            new_y = np.clip(new_y, self.bounds[1][0], self.bounds[1][1])
            
            current_x, current_y = new_x, new_y

            try:
                current_value = self.func(current_x, current_y)
                if np.isnan(current_value) or np.isinf(current_value):
                    current_value = float('inf')
            except (ValueError, RuntimeWarning, OverflowError):
                current_value = float('inf')

            if current_value < self.best_value:
                self.best_value = current_value
                self.best_x = current_x
                self.best_y = current_y

            self.path_history.append((current_x, current_y, current_value))
            self.global_best_history.append((self.best_x, self.best_y, self.best_value))
            self.convergence_history.append(self.best_value)

            if self.expected_value_stop is not None and \
               self.best_value != float('inf') and \
               abs(self.best_value - self.expected_value_stop) < self.tolerance_stop:
                break
        
        return self.best_value, (self.best_x, self.best_y), actual_iterations
        # --- Визуализация результатов (статическая) ---
def plot_results(func, bounds, best_pos=None, history=None): # best_pos и history теперь необязательны
    x_min, x_max = bounds[0]
    y_min, y_max = bounds[1]
    # Генерируем точки для графика
    x_range = np.linspace(x_min, x_max, 150) # Разрешение сетки
    y_range = np.linspace(y_min, y_max, 150)
    X, Y = np.meshgrid(x_range, y_range)

    # Вычисляем Z, обрабатывая возможные ошибки в функции
    Z = np.full_like(X, float('nan')) # Инициализируем массив NaN
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            try:
                val = func(X[i, j], Y[i, j])
                if not (np.isnan(val) or np.isinf(val)):
                     Z[i, j] = val
            except (ValueError, RuntimeWarning): # Обработка ошибок вычисления
                pass # Оставляем NaN

    fig = plt.figure(figsize=(18, 7)) # Размер фигуры

    # 3D график поверхности
    ax1 = fig.add_subplot(121, projection='3d')
    surf = ax1.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8, edgecolor='none', vmin=np.nanmin(Z), vmax=np.nanmax(Z))
    fig.colorbar(surf, ax=ax1, shrink=0.5, aspect=10, label='Значение f(X, Y)')

    # Отображаем лучшую найденную точку, если она передана
    if best_pos and best_pos[0] is not None and best_pos[1] is not None:
        try:
            best_val = func(best_pos[0], best_pos[1])
            if not (np.isnan(best_val) or np.isinf(best_val)):
                 ax1.scatter(best_pos[0], best_pos[1], best_val, color='red', s=150, depthshade=True,
                           label=f'Лучшее: ({best_pos[0]:.3f}, {best_pos[1]:.3f})\nЗнач: {best_val:.3f}')
            else:
                 z_pos = np.nanmin(Z) if np.any(~np.isnan(Z)) else 0
                 ax1.scatter(best_pos[0], best_pos[1], z_pos, color='red', s=150,
                           label=f'Лучшая позиция: ({best_pos[0]:.3f}, {best_pos[1]:.3f})\nЗначение: Некорректно')
        except (ValueError, RuntimeWarning):
             z_pos = np.nanmin(Z) if np.any(~np.isnan(Z)) else 0
             ax1.scatter(best_pos[0], best_pos[1], z_pos, color='red', s=150,
                       label=f'Лучшая позиция: ({best_pos[0]:.3f}, {best_pos[1]:.3f})\nЗначение: Ошибка')
        ax1.legend() # Показываем легенду только если есть точка

    ax1.set_title(f'3D график функции {func.__name__}')
    ax1.set_xlabel('Ось X')
    ax1.set_ylabel('Ось Y')
    ax1.set_zlabel('Значение f(X, Y)')

    # Контурный график
    ax2 = fig.add_subplot(122)
    levels = np.nanpercentile(Z, np.linspace(0, 100, 50))
    contour = ax2.contourf(X, Y, Z, levels=levels, cmap='viridis', extend='both')
    fig.colorbar(contour, ax=ax2, label='Значение f(X, Y)')
    if best_pos and best_pos[0] is not None and best_pos[1] is not None:
        ax2.scatter(best_pos[0], best_pos[1], color='red', s=100, edgecolors='black',
                    label=f'Лучшая точка ({best_pos[0]:.3f}, {best_pos[1]:.3f})')
        ax2.legend() # Показываем легенду только если есть точка

    ax2.set_title(f'Контурный график функции {func.__name__}')
    ax2.set_xlabel('Ось X')
    ax2.set_ylabel('Ось Y')
    ax2.set_aspect('equal', adjustable='box')
    ax2.set_xlim(bounds[0])
    ax2.set_ylim(bounds[1])

    plt.tight_layout() # Автоматическая компоновка
    plt.suptitle(f'Визуализация функции: {func.__name__}', fontsize=16, y=1.02) # Общий заголовок
    plt.show()

# --- Функция для генерации кадра анимации ---
def generate_animation_frame(iteration, func, bounds, x_grid, y_grid, z_grid, 
                             agent_history, global_best_history, output_dir, is_sgd=False, algorithm_name='PSO'): # Добавлены is_sgd и algorithm_name
    fig, ax = plt.subplots(figsize=(8, 7))
    levels = np.nanpercentile(z_grid, np.linspace(0, 100, 50))
    # Убедимся, что levels не пустой и содержит хотя бы 2 значения, иначе contourf может выдать ошибку
    if levels is None or len(levels) < 2:
        # Используем Z если levels проблемные, или дефолтные, если Z тоже плох
        min_z, max_z = np.nanmin(z_grid), np.nanmax(z_grid)
        if np.isnan(min_z) or np.isnan(max_z) or min_z == max_z:
            levels = np.linspace(0,1,10) # запасной вариант
        else:
            levels = np.linspace(min_z, max_z, 10)

    contour = ax.contourf(x_grid, y_grid, z_grid, levels=levels, cmap='viridis', extend='both')
    fig.colorbar(contour, ax=ax, label='Значение f(X, Y)')

    if iteration < len(agent_history):
        if is_sgd:
            # Для SGD, agent_history это path_history (траектория)
            # global_best_history это global_best_history_sgd (лучшая точка)
            current_pos_sgd = agent_history[iteration] # (x, y, value)
            ax.scatter(current_pos_sgd[0], current_pos_sgd[1], color='lime', s=70, edgecolors='black', 
                       alpha=1.0, label=f'{algorithm_name} Позиция', zorder=6)
            # Рисуем путь SGD
            path_x = [p[0] for p in agent_history[:iteration+1]]
            path_y = [p[1] for p in agent_history[:iteration+1]]
            ax.plot(path_x, path_y, color='yellow', linestyle='--', linewidth=2, label=f'{algorithm_name} Путь', zorder=5)
        else:
            # Для PSO, agent_history это birds_history
            birds_positions = agent_history[iteration]
            birds_x = [pos[0] for pos in birds_positions]
            birds_y = [pos[1] for pos in birds_positions]
            ax.scatter(birds_x, birds_y, color='white', s=30, edgecolors='black', alpha=0.7, label=f'{algorithm_name} Частицы', zorder=5)

    # Отображение лучшей найденной позиции на данный момент (для обоих алгоритмов)
    if iteration < len(global_best_history):
        best_x_hist, best_y_hist, best_val_hist = global_best_history[iteration]
        if best_x_hist is not None and best_y_hist is not None:
             # Убедимся, что значение корректно для отображения
             val_str = f'{best_val_hist:.3f}' if not (np.isnan(best_val_hist) or np.isinf(best_val_hist)) else 'N/A'
             ax.scatter(best_x_hist, best_y_hist, color='red', s=150, edgecolors='black', marker='*', zorder=7,
                       label=f'Лучшее ({best_x_hist:.3f}, {best_y_hist:.3f})\nЗнач: {val_str}')

    ax.set_title(f'{algorithm_name} - Итерация {iteration} - Функция: {func.__name__}')
    ax.set_xlabel('Ось X')
    ax.set_ylabel('Ось Y')
    ax.legend(loc='upper right')
    ax.set_xlim(bounds[0])
    ax.set_ylim(bounds[1])
    ax.set_aspect('equal', adjustable='box')

    # Сохранение кадра
    frame_filename = os.path.join(output_dir, f"frame_{iteration:04d}.png")
    plt.savefig(frame_filename)
    plt.close(fig)
    return frame_filename

expected_minima = {
    'himmelblau': [ # Теперь это список минимумов
        (3.0, 2.0),
        (-2.805118, 3.131312),
        (-3.779310, -3.283186),
        (3.584428, -1.848126)
    ],
    'rastrigin': (0.0, 0.0),
    'rosenbrock': (1.0, 1.0),
    'eggholder': (512.0, 404.2319)
}

functions_to_optimize = {
    'himmelblau': {'func': himmelblau, 'grad': grad_himmelblau, 'bounds': [(-6, 6), (-6, 6)]},
    'rastrigin':  {'func': rastrigin, 'grad': grad_rastrigin, 'bounds': [(-5.12, 5.12), (-5.12, 5.12)]},
    'rosenbrock': {'func': rosenbrock, 'grad': grad_rosenbrock, 'bounds': [(-5, 5), (-5, 5)]},
    'eggholder': {'func': eggholder, 'grad': None, 'bounds': [(-512, 512), (-512, 512)]} # None -> будет использован численный
}

# Ожидаемые значения функций для критерия остановки
expected_values_for_stop = {
    'himmelblau': 0.0,
    'rastrigin': 0.0,
    'rosenbrock': 0.0,
    'eggholder': -959.6407 # f(512, 404.2319)
}
STOPPING_TOLERANCE = 1e-4 # Порог для остановки
MAX_ITERATIONS_CAP = 500 # Максимальное количество итераций для каждого запуска

inertias = np.linspace(0.6, 0.9, 2)        # Пример: [0.6, 0.9]
cognitive_rates = np.linspace(1.0, 2.5, 2) # Пример: [1.0, 2.5]
social_rates = np.linspace(1.0, 2.5, 2)    # Пример: [1.0, 2.5]
num_birds_list = np.linspace(30, 50, 2, dtype=int) # Пример: [30, 50]

param_grid_pso = list(itertools.product(inertias, cognitive_rates, social_rates, num_birds_list)) # Переименовано в param_grid_pso
total_combinations_pso = len(param_grid_pso) # Переименовано

# --- Параметры для SGD Grid Search ---
learning_rates_sgd = np.logspace(-5, -1, 5)  # Пример: [0.0001, 0.001, 0.01, 0.1]
param_grid_sgd = list(itertools.product(learning_rates_sgd))
total_combinations_sgd = len(param_grid_sgd)
# Список для хранения всех результатов PSO
all_results_pso = [] # Переименовано из all_results

# Цикл по функциям для PSO
for func_name, config in functions_to_optimize.items():
    func_to_optimize = config['func']
    bounds = config['bounds']

    print(f"\n=== Оптимизация функции: {func_name} ===")

    best_value_for_func = float('inf')
    best_pos_for_func = (None, None)
    best_params_for_func = None
    best_actual_iters_for_func = 0 # Для хранения фактических итераций лучшего запуска
    best_time_for_func = 0 # Для хранения времени лучшего запуска
    best_history_for_func = {
        'convergence': None,
        'birds': None,
        'global': None
    }

    start_time_func_pso = time.time()
    # count = 0 # Счетчик больше не нужен для вывода

    # Grid Search по параметрам для текущей функции (PSO)
    for params_pso in param_grid_pso: # Используем param_grid_pso
        inertia, cognitive_rate, social_rate, num_birds = params_pso # max_iter убран из params
        
        run_start_time = time.time() # Начало замера времени

        # Создаем и запускаем алгоритм
        algo = LazyBirdAlgorithmPSO(func_to_optimize, bounds,
                                  num_birds=int(num_birds),
                                  max_iter=MAX_ITERATIONS_CAP,   # Используем MAX_ITERATIONS_CAP
                                  inertia=inertia,
                                  cognitive_rate=cognitive_rate,
                                  social_rate=social_rate,
                                  expected_value_stop=expected_values_for_stop.get(func_name), # Передаем ожидаемое значение
                                  tolerance_stop=STOPPING_TOLERANCE) # Передаем точность
        current_best_value, current_best_pos, actual_iters = algo.run() # Получаем фактические итерации

        run_end_time = time.time() # Конец замера времени
        execution_time = run_end_time - run_start_time

        # Вычисляем евклидово расстояние
        expected_min = expected_minima[func_name]
        found_x, found_y = current_best_pos
        euclidean_distance = np.nan

        if found_x is not None and found_y is not None:
            if func_name == 'himmelblau':
                # Для Химмельблау ищем расстояние до ближайшего из известных минимумов
                distances = [np.sqrt((found_x - ex_x)**2 + (found_y - ex_y)**2) for ex_x, ex_y in expected_min]
                euclidean_distance = min(distances) if distances else np.nan
            else:
                # Для других функций - как и раньше
                expected_x, expected_y = expected_min
                euclidean_distance = np.sqrt((found_x - expected_x)**2 + (found_y - expected_y)**2)


        # Сохраняем результат текущего запуска (для итоговой таблицы)
        result_entry = {
            'Function': func_name,
            'n_birds': int(num_birds),
            'Actual_Iterations': actual_iters, # Используем фактические итерации
            'inertia': round(inertia, 3),
            'cognitive_rate': round(cognitive_rate, 3),
            'social_rate': round(social_rate, 3), # Добавлено social_rate
            'Found_Value': current_best_value if found_x is not None else np.nan,
            'Found_X': found_x if found_x is not None else np.nan,
            'Found_Y': found_y if found_x is not None else np.nan,
            'Euclidean_Distance': euclidean_distance,
            'Execution_Time_s': round(execution_time, 4) # Добавлено время выполнения
        }
        all_results_pso.append(result_entry)

        # Обновляем лучший результат для текущей функции
        if found_x is not None and current_best_value < best_value_for_func:
            best_value_for_func = current_best_value
            best_pos_for_func = current_best_pos
            best_params_for_func = params_pso # params теперь (inertia, cog, soc, num_birds)
            best_actual_iters_for_func = actual_iters # Сохраняем фактические итерации
            best_time_for_func = execution_time # Сохраняем время
            best_history_for_func['convergence'] = algo.convergence_history
            best_history_for_func['birds'] = algo.birds_position_history
            best_history_for_func['global'] = algo.global_best_history
    end_time_func_pso = time.time()

    # --- Визуализация и GIF для лучшего результата функции (PSO) ---
    if best_params_for_func:
        print(f"\n--- Лучший результат для функции {func_name} --- ")
        print(f"  Лучшее значение: {best_value_for_func}")
        print(f"  Лучшая позиция (x, y): {best_pos_for_func}")
        best_i, best_c, best_s, best_nb = best_params_for_func
        print(f"  Лучшие параметры: частицы={int(best_nb)}, факт_итераций={best_actual_iters_for_func}, inertia={best_i:.3f}, cognitive_rate={best_c:.3f}, social_rate={best_s:.3f}, время={best_time_for_func:.4f}с")
        # --- Генерация GIF (остается здесь, т.к. относится к лучшему запуску) ---
        if best_history_for_func['birds'] and best_history_for_func['global']:
            # Создаем сетку для фона анимации
            x_anim = np.linspace(bounds[0][0], bounds[0][1], 100)
            y_anim = np.linspace(bounds[1][0], bounds[1][1], 100)
            X_anim, Y_anim = np.meshgrid(x_anim, y_anim)
            Z_anim = np.full_like(X_anim, float('nan'))
            try:
                func_vec_anim = np.vectorize(func_to_optimize, otypes=[float])
                Z_computed = func_vec_anim(X_anim, Y_anim)
                Z_computed[np.isinf(Z_computed)] = np.nan
                Z_computed[np.abs(Z_computed) > 1e10] = np.nan
                Z_anim = Z_computed
            except Exception as e:
                print(f"Предупреждение (PSO GIF): Не удалось вычислить Z для фона анимации: {e}. Используется обходной путь.")
                for i_idx in range(X_anim.shape[0]):
                    for j_idx in range(X_anim.shape[1]):
                        try:
                            val = func_to_optimize(X_anim[i_idx, j_idx], Y_anim[i_idx, j_idx])
                            if not (np.isnan(val) or np.isinf(val) or abs(val) > 1e10):
                                Z_anim[i_idx, j_idx] = val
                        except (ValueError, RuntimeWarning, OverflowError):
                            pass

            # Создаем временную папку для кадров
            frames_dir = f"frames_pso_{func_name}"
            if not os.path.exists(frames_dir):
                os.makedirs(frames_dir)
            else:
                 # Очищаем, если папка уже есть
                 shutil.rmtree(frames_dir)
                 os.makedirs(frames_dir)

            filenames = []
            num_frames = len(best_history_for_func['birds'])
            for i in range(num_frames):
                filename = generate_animation_frame(
                    i, func_to_optimize, bounds,
                    X_anim, Y_anim, Z_anim,
                    best_history_for_func['birds'],
                    best_history_for_func['global'],
                    frames_dir,
                    is_sgd=False, # Явно указываем, что это PSO
                    algorithm_name='PSO'
                )
                filenames.append(filename)
            # Создаем GIF
            gif_path = f"pso_optimization_{func_name}.gif"
            # Увеличим duration для более медленной анимации, loop=0 для бесконечного цикла
            with imageio.get_writer(gif_path, mode='I', duration=300, loop=0) as writer:
                 for filename in filenames:
                     image = imageio.imread(filename)
                     writer.append_data(image)
            # Удаляем временную папку с кадрами
            try:
                shutil.rmtree(frames_dir)
            except OSError as e:
                print(f"Ошибка при удалении временной папки {frames_dir}: {e}")
        else:
            print("Не удалось сгенерировать GIF: отсутствуют данные истории.")
    else:
        print(f"Не найдено корректных результатов для {func_name} (PSO). Невозможно построить графики или GIF.")
        # ========== Начало блока SGD ==========
all_results_sgd = []

# Цикл по функциям для SGD
for func_name, config in functions_to_optimize.items():
    func_to_optimize = config['func']
    grad_to_use = config['grad'] # Получаем функцию градиента (может быть None)
    bounds = config['bounds']

    print(f"\n=== Оптимизация функции (SGD): {func_name} ===")

    best_value_for_func_sgd = float('inf')
    best_pos_for_func_sgd = (None, None)
    best_params_for_func_sgd = None
    best_actual_iters_for_func_sgd = 0
    best_time_for_func_sgd = 0
    best_history_for_func_sgd = {
        'path': None, # Траектория SGD
        'global': None # Лучшая точка SGD на каждой итерации
    }

    start_time_func_sgd = time.time()

    # Grid Search по параметрам для текущей функции (SGD)
    for params_sgd in param_grid_sgd:
        learning_rate = params_sgd[0]
        
        run_start_time_sgd = time.time()

        algo_sgd = StochasticGradientDescent(func_to_optimize, bounds,
                                          learning_rate=learning_rate,
                                          max_iter=MAX_ITERATIONS_CAP,
                                          grad_func=grad_to_use, # Передаем аналитический или None
                                          expected_value_stop=expected_values_for_stop.get(func_name),
                                          tolerance_stop=STOPPING_TOLERANCE)
        current_best_value_sgd, current_best_pos_sgd, actual_iters_sgd = algo_sgd.run()
        
        run_end_time_sgd = time.time()
        execution_time_sgd = run_end_time_sgd - run_start_time_sgd

        expected_min = expected_minima[func_name]
        found_x_sgd, found_y_sgd = current_best_pos_sgd
        euclidean_distance_sgd = np.nan

        if found_x_sgd is not None and found_y_sgd is not None:
            if func_name == 'himmelblau':
                distances_sgd = [np.sqrt((found_x_sgd - ex_x)**2 + (found_y_sgd - ex_y)**2) for ex_x, ex_y in expected_min]
                euclidean_distance_sgd = min(distances_sgd) if distances_sgd else np.nan
            else:
                expected_x, expected_y = expected_min
                euclidean_distance_sgd = np.sqrt((found_x_sgd - expected_x)**2 + (found_y_sgd - expected_y)**2)
        
        result_entry_sgd = {
            'Function': func_name,
            'Learning_Rate': round(learning_rate, 5), # Специфичный параметр SGD
            'Actual_Iterations': actual_iters_sgd,
            'Found_Value': current_best_value_sgd if found_x_sgd is not None else np.nan,
            'Found_X': found_x_sgd if found_x_sgd is not None else np.nan,
            'Found_Y': found_y_sgd if found_x_sgd is not None else np.nan,
            'Euclidean_Distance': euclidean_distance_sgd,
            'Execution_Time_s': round(execution_time_sgd, 4)
        }
        all_results_sgd.append(result_entry_sgd)

        if found_x_sgd is not None and current_best_value_sgd < best_value_for_func_sgd:
            best_value_for_func_sgd = current_best_value_sgd
            best_pos_for_func_sgd = current_best_pos_sgd
            best_params_for_func_sgd = params_sgd # (learning_rate,)
            best_actual_iters_for_func_sgd = actual_iters_sgd
            best_time_for_func_sgd = execution_time_sgd
            best_history_for_func_sgd['path'] = algo_sgd.path_history
            best_history_for_func_sgd['global'] = algo_sgd.global_best_history
            
    end_time_func_sgd = time.time()

    # --- Визуализация и GIF для лучшего результата функции (SGD) ---
    if best_params_for_func_sgd:
        print(f"\n--- Лучший результат для функции {func_name} (SGD) ---")
        print(f"  Лучшее значение: {best_value_for_func_sgd}")
        print(f"  Лучшая позиция (x, y): {best_pos_for_func_sgd}")
        best_lr_sgd = best_params_for_func_sgd[0]
        print(f"  Лучшие параметры: learning_rate={best_lr_sgd:.5f}, факт_итераций={best_actual_iters_for_func_sgd}, время={best_time_for_func_sgd:.4f}с")

        if best_history_for_func_sgd['path'] and best_history_for_func_sgd['global']:
            x_anim_sgd = np.linspace(bounds[0][0], bounds[0][1], 100)
            y_anim_sgd = np.linspace(bounds[1][0], bounds[1][1], 100)
            X_anim_sgd, Y_anim_sgd = np.meshgrid(x_anim_sgd, y_anim_sgd)
            Z_anim_sgd = np.full_like(X_anim_sgd, float('nan'))
            try:
                func_vec_anim_sgd = np.vectorize(func_to_optimize, otypes=[float])
                Z_computed_sgd = func_vec_anim_sgd(X_anim_sgd, Y_anim_sgd)
                Z_computed_sgd[np.isinf(Z_computed_sgd)] = np.nan
                Z_computed_sgd[np.abs(Z_computed_sgd) > 1e10] = np.nan # Ограничение значений
                Z_anim_sgd = Z_computed_sgd
            except Exception as e_sgd:
                print(f"Предупреждение (SGD GIF): Не удалось вычислить Z для фона анимации: {e_sgd}. Используется обходной путь.")
                for i_idx_sgd in range(X_anim_sgd.shape[0]):
                    for j_idx_sgd in range(X_anim_sgd.shape[1]):
                        try:
                            val_sgd = func_to_optimize(X_anim_sgd[i_idx_sgd, j_idx_sgd], Y_anim_sgd[i_idx_sgd, j_idx_sgd])
                            if not (np.isnan(val_sgd) or np.isinf(val_sgd) or abs(val_sgd) > 1e10):
                                Z_anim_sgd[i_idx_sgd, j_idx_sgd] = val_sgd
                        except (ValueError, RuntimeWarning, OverflowError):
                            pass
            
            frames_dir_sgd = f"frames_sgd_{func_name}"
            if not os.path.exists(frames_dir_sgd):
                os.makedirs(frames_dir_sgd)
            else:
                shutil.rmtree(frames_dir_sgd)
                os.makedirs(frames_dir_sgd)

            filenames_sgd = []
            num_frames_sgd = len(best_history_for_func_sgd['path']) # Используем длину path_history
            for i_sgd in range(num_frames_sgd):
                filename_sgd = generate_animation_frame(
                    i_sgd, func_to_optimize, bounds,
                    X_anim_sgd, Y_anim_sgd, Z_anim_sgd,
                    best_history_for_func_sgd['path'], # Передаем path_history
                    best_history_for_func_sgd['global'], # Передаем global_best_history
                    frames_dir_sgd,
                    is_sgd=True,
                    algorithm_name='SGD'
                )
                filenames_sgd.append(filename_sgd)

            gif_path_sgd = f"sgd_optimization_{func_name}.gif"
            with imageio.get_writer(gif_path_sgd, mode='I', duration=150, loop=0) as writer_sgd: # Уменьшил duration для SGD
                 for filename_sgd_item in filenames_sgd:
                     image_sgd = imageio.imread(filename_sgd_item)
                     writer_sgd.append_data(image_sgd)
            try:
                shutil.rmtree(frames_dir_sgd)
            except OSError as e_sgd_rm:
                print(f"Ошибка при удалении временной папки {frames_dir_sgd}: {e_sgd_rm}")
        else:
            print("Не удалось сгенерировать GIF для SGD: отсутствуют данные истории.")
    else:
        print(f"Не найдено корректных результатов для {func_name} (SGD). Невозможно построить графики или GIF.")

# ========== Конец блока SGD ==========
results_df_pso = pd.DataFrame(all_results_pso)
# Находим индекс лучшего запуска для каждой функции на основе 'Found_Value'
# Если есть NaN в Found_Value, они будут проигнорированы idxmin, что корректно
def get_idxmin_or_nan(series):
    if series.empty or series.isnull().all():
        return np.nan
    return series.idxmin()

best_idx_series_pso = results_df_pso.groupby('Function')['Found_Value'].apply(get_idxmin_or_nan).dropna()
if not best_idx_series_pso.empty:
    best_idx_df_pso = results_df_pso.loc[best_idx_series_pso.astype(int)]

    # Выбираем столбцы для итоговой таблицы PSO
    summary_table_pso = best_idx_df_pso[['Function', 'n_birds', 'Actual_Iterations', 
                                   'inertia', 'cognitive_rate', 'social_rate', 
                                   'Found_X', 'Found_Y', 'Found_Value', 
                                   'Euclidean_Distance', 'Execution_Time_s']]

    # Переименовываем столбцы для вывода
    summary_table_pso.columns = ['Функция (PSO)', 'Кол-во частиц', 'Факт_Итераций', 
                             'Инерция', 'Когнитив_кэф', 'Социальн_кэф', 
                             'Найденный_X', 'Найденный_Y', 'Лучшее_Значение', 
                             'Евклидово_Расстояние', 'Время_Выполнения_с']

    print("\n--- Итоговая таблица лучших результатов (PSO) ---")
    print(summary_table_pso.to_string(index=False))
    summary_table_pso.to_csv('summary_results_pso.csv', index=False, encoding='utf-8-sig')
else:
    print("\n--- Не удалось сформировать итоговую таблицу для PSO (нет валидных данных) ---")
    # --- Итоговая таблица для SGD ---
results_df_sgd = pd.DataFrame(all_results_sgd)
if not results_df_sgd.empty:
    best_idx_series_sgd = results_df_sgd.groupby('Function')['Found_Value'].apply(get_idxmin_or_nan).dropna()
    if not best_idx_series_sgd.empty:
        best_idx_df_sgd = results_df_sgd.loc[best_idx_series_sgd.astype(int)]

        summary_table_sgd = best_idx_df_sgd[['Function', 'Learning_Rate', 'Actual_Iterations', 
                                           'Found_X', 'Found_Y', 'Found_Value', 
                                           'Euclidean_Distance', 'Execution_Time_s']]

        summary_table_sgd.columns = ['Функция (SGD)', 'Скорость_обучения', 'Факт_Итераций', 
                                     'Найденный_X', 'Найденный_Y', 'Лучшее_Значение', 
                                     'Евклидово_Расстояние', 'Время_Выполнения_с']

        print("\n--- Итоговая таблица лучших результатов (SGD) ---")
        print(summary_table_sgd.to_string(index=False))
        summary_table_sgd.to_csv('summary_results_sgd.csv', index=False, encoding='utf-8-sig')
    else:
        print("\n--- Не удалось сформировать итоговую таблицу для SGD (нет валидных данных после группировки) ---")
else:
    print("\n--- Не удалось сформировать итоговую таблицу для SGD (нет данных для DataFrame) ---")

# --- Класс для алгоритма стохастического градиентного спуска (SGD) ---
# Убедимся, что обе таблицы существуют
if 'summary_table_pso' in locals() and 'summary_table_sgd' in locals():
    # Приводим названия функций к одному названию столбца
    summary_table_pso = summary_table_pso.rename(columns={'Функция (PSO)': 'Функция'})
    summary_table_sgd = summary_table_sgd.rename(columns={'Функция (SGD)': 'Функция'})

    # Объединяем таблицы по столбцу 'Функция'
    summary_table_total = pd.merge(summary_table_pso, summary_table_sgd, on='Функция', how='outer', suffixes=('_PSO', '_SGD'))

    # Сохраняем результат
    summary_table_total.to_csv('summary_results_total.csv', index=False, encoding='utf-8-sig')

    print("\n--- Общая итоговая таблица лучших результатов (PSO + SGD) ---")
    print(summary_table_total.to_string(index=False))
else:
    print("\n--- Не удалось сформировать общую таблицу: отсутствуют данные PSO или SGD ---")
