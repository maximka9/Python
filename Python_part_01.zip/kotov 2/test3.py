import random
import numpy as np
from pyeasyga import pyeasyga
import time # Добавляем импорт time
import pandas as pd # Добавляем импорт pandas
import itertools # Добавляем импорт itertools

# --- 📥 Входные данные ---

# --- Параметры для автоматической генерации данных ---
NUM_SPECIALISTS_GEN = 20 # Для 10 специалистов 2^10 = 1024 (перебор возможен)
NUM_TOTAL_SKILLS_GEN = 7
NUM_REQUIRED_SKILLS_GEN = 4
AVG_SKILLS_PER_SPECIALIST = 3 # Среднее количество навыков у одного специалиста
MIN_COST_SPECIALIST = 50
MAX_COST_SPECIALIST = 200

def generate_problem_instance(num_specialists, num_total_skills, num_required, avg_skills, min_cost, max_cost):
    """Генерирует входные данные для задачи."""
    #print(f"\n--- Генерация входных данных ---")
    #print(f"Специалистов: {num_specialists}, Всего навыков: {num_total_skills}, Требуется навыков: {num_required}")

    # 1. Генерация пула всех возможных навыков
    all_possible_skills = {f"skill_{i}" for i in range(num_total_skills)}

    # 2. Генерация специалистов
    generated_specialists_data = []
    for i in range(num_specialists):
        num_skills_for_specialist = max(1, min(num_total_skills, int(random.gauss(avg_skills, 1)))) # хотя бы 1 навык
        skills = random.sample(list(all_possible_skills), k=num_skills_for_specialist)
        cost = random.randint(min_cost, max_cost)
        generated_specialists_data.append({"id": i, "skills": set(skills), "cost": cost})
        # print(f"  Специалист {i}: Навыки {skills}, Стоимость {cost}")


    # 3. Генерация требуемых навыков для проекта
    if num_required > num_total_skills:
        raise ValueError("Количество требуемых навыков не может превышать общее количество навыков.")
    generated_required_skills = set(random.sample(list(all_possible_skills), k=num_required))
    #print(f"Сгенерированные требуемые навыки: {generated_required_skills}")

    # 4. Генерация матрицы совместимости (конфликтности)
    # C[i][j] - конфликтность между специалистом i и j. 0 - идеально, 1 - полная несовместимость.
    generated_compatibility_matrix = np.random.rand(num_specialists, num_specialists)
    np.fill_diagonal(generated_compatibility_matrix, 0) # Нет конфликта с самим собой
    # Обеспечение симметричности C[i][j] = C[j][i]
    for i in range(num_specialists):
        for j in range(i + 1, num_specialists):
            generated_compatibility_matrix[j][i] = generated_compatibility_matrix[i][j]
    # print(f"Сгенерирована матрица совместимости размером {num_specialists}x{num_specialists}")

    return generated_specialists_data, generated_required_skills, generated_compatibility_matrix

# --- Используем сгенерированные данные ---
specialists_data, required_skills_project, compatibility_matrix_data = generate_problem_instance(
    NUM_SPECIALISTS_GEN,
    NUM_TOTAL_SKILLS_GEN,
    NUM_REQUIRED_SKILLS_GEN,
    AVG_SKILLS_PER_SPECIALIST,
    MIN_COST_SPECIALIST,
    MAX_COST_SPECIALIST
)
N_SPECIALISTS = len(specialists_data) # Обновляем N_SPECIALISTS на основе сгенерированных

# --- Общие параметры ---
ALPHA = 1.0
BETA = 1.0
GAMMA = 100.0
DELTA = 500.0
K_MIN = 4
K_MAX = 7

# --- Параметры ГА ---
MAX_GA_GENERATIONS_PER_RUN = 3000 # Увеличено до 3000
EARLY_STOPPING_PATIENCE = 100     # Можно увеличить терпение, если максимум поколений больше
BF_PROXIMITY_THRESHOLD = 0.01     # Порог для сравнения с результатом перебора

population_sizes_grid = [50, 100]
crossover_probabilities_grid = [0.7, 0.9]
mutation_probabilities_grid = [0.05, 0.1]

# --- 🧬 Представление решения (хромосома) и функции ГА ---

def create_individual(data):
    """Создает случайного индивида (хромосому) - бинарный вектор."""
    n_specialists = data["n_specialists"]
    return [random.randint(0, 1) for _ in range(n_specialists)]

def fitness(individual, data):
    """
    Вычисляет приспособленность индивида.
    Цель: минимизировать стоимость, конфликтность и штрафы.
    pyeasyga максимизирует фитнес, поэтому возвращаем - (взвешенная сумма).
    """
    specialists = data["specialists"]
    required_skills = data["required_skills"]
    compatibility_matrix = data["compatibility_matrix"]
    alpha = data["alpha"]
    beta = data["beta"]
    gamma = data["gamma"]
    delta = data["delta"]
    k_min = data["k_min"]
    k_max = data["k_max"]
    n_specialists = data["n_specialists"]

    # --- Расчет компонентов целевой функции ---
    
    # 1. TotalCost
    total_cost = 0
    current_team_indices = [] # Индексы выбранных специалистов
    for i in range(n_specialists):
        if individual[i] == 1:
            total_cost += specialists[i]["cost"]
            current_team_indices.append(i)

    # 2. ConflictLevel
    conflict_level = 0
    for i in range(len(current_team_indices)):
        for j in range(i + 1, len(current_team_indices)):
            spec_idx1 = current_team_indices[i]
            spec_idx2 = current_team_indices[j]
            conflict_level += compatibility_matrix[spec_idx1][spec_idx2]

    # 3. Penalty за непокрытые навыки
    penalty_skills = 0
    covered_skills = set()
    for i in current_team_indices:
        covered_skills.update(specialists[i]["skills"])
    
    uncovered_skills_count = len(required_skills - covered_skills)
    penalty_skills = uncovered_skills_count * gamma

    # 4. (Опционально) Penalty за размер команды
    penalty_team_size = 0
    num_selected = sum(individual)
    if k_min is not None and num_selected < k_min:
        penalty_team_size += (k_min - num_selected)
    if k_max is not None and num_selected > k_max:
        penalty_team_size += (num_selected - k_max)

    # Общая взвешенная оценка (минимизируем)
    raw_fitness = (alpha * total_cost + 
                   beta * conflict_level + 
                   penalty_skills +
                   delta * penalty_team_size)
    
    # pyeasyga максимизирует, поэтому возвращаем отрицательное значение
    return -raw_fitness

def calculate_fitness_components(individual_chromosome, specialists_data_fc, required_skills_fc,
                                 compatibility_matrix_fc, alpha_fc, beta_fc, gamma_fc, delta_fc,
                                 k_min_fc, k_max_fc, n_specialists_fc):
    total_cost = 0
    current_team_indices = []
    for i in range(n_specialists_fc):
        if individual_chromosome[i] == 1:
            total_cost += specialists_data_fc[i]["cost"]
            current_team_indices.append(i)

    conflict_level = 0
    for i in range(len(current_team_indices)):
        for j in range(i + 1, len(current_team_indices)):
            spec_idx1 = current_team_indices[i]
            spec_idx2 = current_team_indices[j]
            conflict_level += compatibility_matrix_fc[spec_idx1][spec_idx2]

    conflict_scaling_factor = 1.0
    if n_specialists_fc > 0 and k_max_fc > 1:
        avg_team_size_est = (k_min_fc + k_max_fc) / 2.0
        if avg_team_size_est < 1: avg_team_size_est = 1
        avg_cost_per_spec = sum(s['cost'] for s in specialists_data_fc) / n_specialists_fc
        estimated_total_cost = avg_cost_per_spec * avg_team_size_est
        num_pairs_in_avg_team = avg_team_size_est * (avg_team_size_est - 1) / 2.0
        if num_pairs_in_avg_team < 0.01 : num_pairs_in_avg_team = 0.01
        estimated_total_conflict = num_pairs_in_avg_team * 0.5
        if estimated_total_conflict > 0.01:
            conflict_scaling_factor = estimated_total_cost / estimated_total_conflict
        elif conflict_level > 0:
            conflict_scaling_factor = estimated_total_cost / 0.1 
    scaled_conflict_term = beta_fc * (conflict_level * conflict_scaling_factor)

    covered_skills = set()
    for i in current_team_indices:
        covered_skills.update(specialists_data_fc[i]["skills"])
    uncovered_skills_units = len(required_skills_fc - covered_skills)
    penalty_skills_value = uncovered_skills_units * gamma_fc

    team_size_penalty_units = 0
    num_selected = sum(individual_chromosome)
    if k_min_fc is not None and num_selected < k_min_fc:
        team_size_penalty_units += (k_min_fc - num_selected)
    if k_max_fc is not None and num_selected > k_max_fc:
        team_size_penalty_units += (num_selected - k_max_fc)
    penalty_size_value = team_size_penalty_units * delta_fc

    raw_fitness = (alpha_fc * total_cost + scaled_conflict_term + 
                   penalty_skills_value + penalty_size_value)
    return raw_fitness, total_cost, conflict_level, penalty_skills_value, penalty_size_value, individual_chromosome

def fitness_ga_adapter(individual, data_ga):
    raw_fitness, _, _, _, _, _ = calculate_fitness_components(
        individual,
        data_ga["specialists"],
        data_ga["required_skills"],
        data_ga["compatibility_matrix"],
        data_ga["alpha"],
        data_ga["beta"],
        data_ga["gamma"],
        data_ga["delta"],
        data_ga["k_min"],
        data_ga["k_max"],
        data_ga["n_specialists"]
    )
    return -raw_fitness

def create_individual_ga_adapter(data_ga):
    n_specialists = data_ga["n_specialists"]
    return [random.randint(0, 1) for _ in range(n_specialists)]

def brute_force_solver(specialists_list_bf, required_skills_set_bf, compat_matrix_bf,
                       alpha_bf, beta_bf, gamma_bf, delta_bf, k_min_bf, k_max_bf, n_specs_bf):
    print("\n--- Запуск полного перебора --- ")

    start_time_bf = time.time()
    best_raw_fitness_bf = float('inf')
    best_team_chromosome_bf = None
    details_of_best_bf = {}
    num_combinations = 2**n_specs_bf
    print(f"Всего комбинаций: {num_combinations} (N_специалистов={n_specs_bf})")

    for i, team_chromosome_tuple in enumerate(itertools.product([0, 1], repeat=n_specs_bf)):
        team_chromosome_list = list(team_chromosome_tuple)
        raw_fitness, cost, conflict, p_s, p_z, _ = \
            calculate_fitness_components(team_chromosome_list, specialists_list_bf, required_skills_set_bf, compat_matrix_bf,
                                         alpha_bf, beta_bf, gamma_bf, delta_bf, k_min_bf, k_max_bf, n_specs_bf)
        if raw_fitness < best_raw_fitness_bf:
            best_raw_fitness_bf = raw_fitness
            best_team_chromosome_bf = team_chromosome_list
            details_of_best_bf = {"cost": cost, "conflict": conflict, "penalty_skills": p_s, "penalty_size": p_z}
        if num_combinations > 1000 and (i + 1) % (num_combinations // 100 + 1) == 0:
             print(f"  Проверено {i+1}/{num_combinations} ({((i+1)/num_combinations*100):.1f}%) ...", end='\r')
    end_time_bf = time.time()
    execution_time_bf = end_time_bf - start_time_bf
    print(f"\nПолный перебор завершен. Время: {execution_time_bf:.3f}с")
    if best_team_chromosome_bf:
        selected_ids_bf = [specialists_list_bf[i]["id"] for i, sel in enumerate(best_team_chromosome_bf) if sel]
        print(f"Лучшее (перебор): Фитнес={best_raw_fitness_bf:.2f}, Команда ID={selected_ids_bf}")
        return {
            'N Запуска': "Перебор", 'Популяция': "N/A", 'P(кросс)': "N/A", 'P(мутац)': "N/A",
            'Факт. поколений': "N/A",
            'Целевая ф-я (min)': f"{best_raw_fitness_bf:.2f}",
            'ID команды': ', '.join(map(str, selected_ids_bf)) if selected_ids_bf else "-",
            'Стоимость': details_of_best_bf.get("cost", 0),
            'Конфликт': f"{details_of_best_bf.get('conflict', 0):.2f}",
            'Штраф_навыки': f"{details_of_best_bf.get('penalty_skills', 0):.2f}",
            'Штраф_размер': f"{details_of_best_bf.get('penalty_size', 0):.2f}",
            'Время (с)': f"{execution_time_bf:.3f}",
            'raw_fitness_float': best_raw_fitness_bf
        }
    return None

# --- Запуск генетического алгоритма ---
if __name__ == "__main__":
    print("--- Генерация общей задачи для Grid Search и Перебора ---")
    specialists_data, required_skills_project, compatibility_matrix_data = generate_problem_instance(
        NUM_SPECIALISTS_GEN, NUM_TOTAL_SKILLS_GEN, NUM_REQUIRED_SKILLS_GEN,
        AVG_SKILLS_PER_SPECIALIST, MIN_COST_SPECIALIST, MAX_COST_SPECIALIST)
    N_SPECIALISTS = len(specialists_data)
    print(f"Сгенерировано {N_SPECIALISTS} специалистов. Требуемые навыки: {required_skills_project}\n")

    all_run_results = []
    brute_force_optimal_fitness = float('inf')
    brute_force_result_dict = brute_force_solver(specialists_data, required_skills_project, compatibility_matrix_data,
                                            ALPHA, BETA, GAMMA, DELTA, K_MIN, K_MAX, N_SPECIALISTS)
    if brute_force_result_dict:
        all_run_results.append(brute_force_result_dict)
        brute_force_optimal_fitness = brute_force_result_dict.get('raw_fitness_float', float('inf'))

    param_grid = list(itertools.product(population_sizes_grid, crossover_probabilities_grid, mutation_probabilities_grid))
    run_counter = 0
    for pop_size, cross_prob, mut_prob in param_grid:
        run_counter += 1
        print(f"--- Запуск ГА {run_counter}/{len(param_grid)}: Поп={pop_size}, P(c)={cross_prob:.2f}, P(m)={mut_prob:.2f} ---")
        current_ga_data_for_run = {
            "specialists": specialists_data, "required_skills": required_skills_project,
            "compatibility_matrix": compatibility_matrix_data, "alpha": ALPHA, "beta": BETA,
            "gamma": GAMMA, "delta": DELTA, "k_min": K_MIN, "k_max": K_MAX, "n_specialists": N_SPECIALISTS
        }
        ga = pyeasyga.GeneticAlgorithm(
            seed_data=current_ga_data_for_run, population_size=pop_size, generations=1,
            crossover_probability=cross_prob, mutation_probability=mut_prob, elitism=True, maximise_fitness=True)
        ga.create_individual = create_individual_ga_adapter
        ga.fitness_function = fitness_ga_adapter
        start_time_ga = time.time()
        best_fitness_of_ga_run = float('inf')
        generations_without_improvement = 0
        actual_generations_this_run = 0

        for gen_idx in range(MAX_GA_GENERATIONS_PER_RUN):
            ga.run(n_workers=1)
            actual_generations_this_run += 1
            current_max_fitness, _ = ga.best_individual()
            current_min_objective_ga = -current_max_fitness if current_max_fitness is not None else float('inf')

            if current_min_objective_ga < best_fitness_of_ga_run:
                best_fitness_of_ga_run = current_min_objective_ga
                generations_without_improvement = 0
            else:
                generations_without_improvement += 1
            
            stop_this_ga_run = False
            stop_message = ""

            if brute_force_optimal_fitness != float('inf'):
                if best_fitness_of_ga_run <= brute_force_optimal_fitness + BF_PROXIMITY_THRESHOLD:
                    stop_this_ga_run = True
                    stop_message = f"ГА ({best_fitness_of_ga_run:.2f}) достиг оптимума перебора ({brute_force_optimal_fitness:.2f})"
            elif generations_without_improvement >= EARLY_STOPPING_PATIENCE:
                stop_this_ga_run = True
                stop_message = f"Нет улучшений {EARLY_STOPPING_PATIENCE} поколений"

            if stop_this_ga_run:
                print(f"    Ранняя остановка: {stop_message} на {actual_generations_this_run} поколении.")
                break
        
        end_time_ga = time.time()
        execution_time_ga = end_time_ga - start_time_ga
        final_ga_fitness_raw, final_ga_chromosome = ga.best_individual()
        final_actual_objective_value = -final_ga_fitness_raw if final_ga_fitness_raw is not None else float('inf')
        
        _, cost, conflict, p_skills, p_size, _ = calculate_fitness_components(
            final_ga_chromosome if final_ga_chromosome else [0]*N_SPECIALISTS, 
            specialists_data, required_skills_project, compatibility_matrix_data,
            ALPHA, BETA, GAMMA, DELTA, K_MIN, K_MAX, N_SPECIALISTS
        )
        selected_specialists_info_ga = [specialists_data[i] for i, sel in enumerate(final_ga_chromosome) if sel] if final_ga_chromosome else []

        all_run_results.append({
            'N Запуска': f"ГА {run_counter}", 'Популяция': pop_size, 'P(кросс)': f"{cross_prob:.2f}",
            'P(мутац)': f"{mut_prob:.2f}", 'Факт. поколений': actual_generations_this_run,
            'Целевая ф-я (min)': f"{final_actual_objective_value:.2f}",
            'ID команды': ', '.join(map(str, [s['id'] for s in selected_specialists_info_ga])) if selected_specialists_info_ga else "-",
            'Стоимость': cost, 'Конфликт': f"{conflict:.2f}",
            'Штраф_навыки': f"{p_skills:.2f}", 'Штраф_размер': f"{p_size:.2f}",
            'Время (с)': f"{execution_time_ga:.3f}"
        })
        print(f"Завершено ГА {run_counter}. Лучшее: {final_actual_objective_value:.2f}. Поколений: {actual_generations_this_run}. Время: {execution_time_ga:.3f}с\n")

    if all_run_results:
        df_results = pd.DataFrame(all_run_results)
        column_order = ['N Запуска', 'Популяция', 'P(кросс)', 'P(мутац)', 'Факт. поколений',
                        'Целевая ф-я (min)', 'Стоимость', 'Конфликт', 'Штраф_навыки',
                        'Штраф_размер', 'ID команды', 'Время (с)']
        df_results = df_results.reindex(columns=column_order)
        print("\n" + "="*110)
        print("ИТОГОВЫЕ РЕЗУЛЬТАТЫ (ГА Grid Search + Перебор)".center(110))
        print("="*110)
        print(df_results.to_string(index=False))
        output_filename = "team_formation_GA_vs_BruteForce_results.csv"
        df_results.to_csv(output_filename, index=False, encoding='utf-8-sig')
        print(f"\nРезультаты сохранены в файл: {output_filename}")
    else:
        print("\nНе было выполнено ни одного запуска.")

