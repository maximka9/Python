import numpy as np
import random
import matplotlib.pyplot as plt
import time 
import itertools
import pandas as pd
import imageio
import os
import shutil
from pyeasyga import pyeasyga
# --------------------- Целевые функции ----------------------
def himmelblau(x, y):
    # Минимумы: f(3, 2) = 0, f(-2.805, 3.131) = 0, f(-3.779, -3.283) = 0, f(3.584, -1.848) = 0
    return (x**2 + y - 11)**2 + (x + y**2 - 7)**2

def rastrigin(x, y):
    # Минимум: f(0, 0) = 0
    A = 10
    return A * 2 + (x**2 - A * np.cos(2 * np.pi * x)) + (y**2 - A * np.cos(2 * np.pi * y))

def rosenbrock(x, y):
    # Минимум: f(1, 1) = 0
    a = 1
    b = 100
    return (a - x)**2 + b * (y - x**2)**2

def eggholder(x, y):
    # Минимум: f(512, 404.2319) ≈ -959.6407
    # Ограничения: -512 <= x, y <= 512
    if not (-512 <= x <= 512 and -512 <= y <= 512):
        return float('inf') # Штраф за выход за пределы
    sqrt_arg1 = np.abs(x / 2 + (y + 47))
    sqrt_arg2 = np.abs(x - (y + 47))
    term1 = -(y + 47) * np.sin(np.sqrt(sqrt_arg1))
    term2 = -x * np.sin(np.sqrt(sqrt_arg2))
    return term1 + term2

# --- Константы и параметры для Генетического Алгоритма ---
MAX_GENERATIONS = 1000  # Максимальное количество поколений
STOPPING_TOLERANCE = 1e-4  # Точность для досрочной остановки

# Словарь с функциями для оптимизации, их границами и ожидаемыми результатами
functions_to_optimize_ga = {
    'himmelblau': {
        'func': himmelblau,
        'bounds': [(-6.0, 6.0), (-6.0, 6.0)],
        'expected_value': 0.0,
        # Для Химмельблау несколько минимумов, сохраним их все для расчета расстояния
        'expected_coords_list': [(3.0, 2.0), (-2.805118, 3.131312), (-3.779310, -3.283186), (3.584428, -1.848126)],
        'display_expected_coords': "Multiple" # Что отображать в таблице
    },
    'rastrigin':  {
        'func': rastrigin,
        'bounds': [(-5.12, 5.12), (-5.12, 5.12)],
        'expected_value': 0.0,
        'expected_coords_list': [(0.0, 0.0)],
        'display_expected_coords': "(0.0, 0.0)"
    },
    'rosenbrock': {
        'func': rosenbrock,
        'bounds': [(-5.0, 5.0), (-5.0, 5.0)],
        'expected_value': 0.0,
        'expected_coords_list': [(1.0, 1.0)],
        'display_expected_coords': "(1.0, 1.0)"
    },
    'eggholder':  {
        'func': eggholder,
        'bounds': [(-512.0, 512.0), (-512.0, 512.0)],
        'expected_value': -959.6407,
        'expected_coords_list': [(512.0, 404.2319)],
        'display_expected_coords': "(512.0, 404.2319)"
    }
}

population_sizes = [25, 50, 100, 150, 300, 500]        # Размеры популяции
crossover_probabilities = np.linspace(0.0, 1.0, 10)  # Вероятности кроссовера
mutation_probabilities = np.linspace(0.01, 0.51, 10)  # Вероятности мутации
param_grid_ga = list(itertools.product(population_sizes, crossover_probabilities, mutation_probabilities))

def create_individual_ga(data):
    """Создает случайного индивида (решение) для генетического алгоритма."""
    bounds = data['bounds']
    return [random.uniform(bounds[0][0], bounds[0][1]),
            random.uniform(bounds[1][0], bounds[1][1])]

def fitness_ga(individual, data):
    """
    Вычисляет приспособленность индивида.
    Поскольку pyeasyga максимизирует, а мы минимизируем целевую функцию,
    приспособленность = -значение_функции.
    """
    x, y = individual[0], individual[1]
    target_func = data['func']
    try:
        value = target_func(x, y)
        # Обработка некорректных значений (NaN, inf) или слишком больших/малых
        if np.isnan(value) or np.isinf(value) or abs(value) > 1e12:
            return -float('inf')  # Очень плохая приспособленность
        return -value  # Возвращаем отрицательное значение, так как pyeasyga максимизирует
    except (ValueError, RuntimeWarning, OverflowError):
        # В случае ошибки вычисления функции также возвращаем очень плохую приспособленность
        return -float('inf')

def generate_ga_animation_frame(iteration, func_name_str, bounds, x_grid, y_grid, z_grid,
                                current_population_coords, # Список координат [(x,y), ...] всех индивидов
                                best_ind_info_this_iter,   # Информация о лучшем индивиде в этом поколении ((x,y), значение_функции)
                                output_dir, algorithm_name='ГА'):
    """Генерирует и сохраняет один кадр анимации для генетического алгоритма."""
    fig, ax = plt.subplots(figsize=(10, 8))
    
    levels = np.nanpercentile(z_grid, np.linspace(0, 100, 40))
    if levels is None or len(levels) < 2 or np.all(np.isnan(levels)) or (np.nanmin(levels) == np.nanmax(levels) and not np.all(np.isnan(levels))):
        min_z_safe, max_z_safe = np.nanmin(z_grid), np.nanmax(z_grid)
        if np.isnan(min_z_safe) or np.isnan(max_z_safe) or min_z_safe == max_z_safe:
            levels = np.linspace(0, 1, 10) # Абсолютно запасной вариант
        else:
            levels = np.linspace(min_z_safe, max_z_safe + 1e-9, 10) # Добавляем малое число для случая плоской поверхности
            
    contour = ax.contourf(x_grid, y_grid, z_grid, levels=levels, cmap='viridis', extend='both', alpha=0.7)
    fig.colorbar(contour, ax=ax, label=f'Значение f(X, Y) для {func_name_str}')

    if current_population_coords:
        pop_x = [p[0] for p in current_population_coords if p and p[0] is not None]
        pop_y = [p[1] for p in current_population_coords if p and p[1] is not None]
        if pop_x and pop_y: # Рисуем, только если есть что рисовать
            ax.scatter(pop_x, pop_y, color='deepskyblue', s=25, alpha=0.6, label=f'{algorithm_name} Популяция', zorder=5, edgecolors='black', linewidth=0.5)

    if best_ind_info_this_iter and \
       best_ind_info_this_iter[0] and \
       best_ind_info_this_iter[0][0] is not None and \
       best_ind_info_this_iter[0][1] is not None:
        
        best_coords_iter, best_val_iter = best_ind_info_this_iter
        val_str = f'{best_val_iter:.4f}' if not (np.isnan(best_val_iter) or np.isinf(best_val_iter)) else 'N/A'
        ax.scatter(best_coords_iter[0], best_coords_iter[1], color='red', s=120, edgecolors='black', marker='*', zorder=7,
                   label=f'Лучший в поколении ({best_coords_iter[0]:.3f}, {best_coords_iter[1]:.3f})\\nЗнач: {val_str}')

    ax.set_title(f'{algorithm_name} - Поколение {iteration} - Функция: {func_name_str}', fontsize=14)
    ax.set_xlabel('Ось X', fontsize=12)
    ax.set_ylabel('Ось Y', fontsize=12)
    ax.legend(loc='upper right', fontsize=9)
    ax.set_xlim(bounds[0])
    ax.set_ylim(bounds[1])
    ax.set_aspect('equal', adjustable='box')
    plt.tight_layout()

    frame_filename = os.path.join(output_dir, f"frame_ga_{iteration:04d}.png")
    try:
        plt.savefig(frame_filename)
    except Exception as e:
        print(f"Ошибка сохранения кадра {frame_filename}: {e}")
        return None # Возвращаем None в случае ошибки
    plt.close(fig)
    return frame_filename

if __name__ == "__main__":
    all_results_ga = [] 

    for func_name, config in functions_to_optimize_ga.items():
        func_to_optimize = config['func']
        bounds = config['bounds']
        expected_value = config['expected_value']
        expected_coords_list = config['expected_coords_list']
        display_expected_coords_str = config['display_expected_coords']

        print(f"\\n======= Оптимизация функции: {func_name} (Генетический Алгоритм) =======")

        best_value_for_func = float('inf')
        best_pos_for_func = (None, None)
        best_params_for_func = None
        best_actual_gens_for_func = 0
        best_time_for_func = 0.0
        
        best_population_history_for_gif = None
        best_individual_value_history_for_gif = None 

        for i_param_set, params_ga in enumerate(param_grid_ga):
            pop_size, crossover_prob, mutation_prob = params_ga
            
            #print(f"\\n  --- Запуск для {func_name} с параметрами: Популяция={pop_size}, Кроссовер={crossover_prob}, Мутация={mutation_prob} ({i_param_set+1}/{len(param_grid_ga)}) ---")
            
            run_start_time = time.time()

            ga_data_for_run = {'func': func_to_optimize, 'bounds': bounds}
            ga = pyeasyga.GeneticAlgorithm(
                ga_data_for_run,
                population_size=pop_size,
                generations=1, 
                crossover_probability=crossover_prob,
                mutation_probability=mutation_prob,
                elitism=True,
                maximise_fitness=True 
            )
            ga.create_individual = create_individual_ga 
            ga.fitness_function = fitness_ga          

            current_run_population_history = [] 
            current_run_best_individual_history = [] 
            
            actual_generations_this_run = 0
            best_value_this_run = float('inf') 
            best_coords_this_run = (None, None)

            for gen in range(MAX_GENERATIONS):
                ga.run(n_workers=1) 
                actual_generations_this_run += 1

                pop_coords_for_frame = []
                if hasattr(ga, 'current_generation') and ga.current_generation:
                     for individual in ga.current_generation:
                         if individual.genes:
                            pop_coords_for_frame.append(tuple(individual.genes))
                current_run_population_history.append(pop_coords_for_frame)

                current_gen_best_fitness, current_gen_best_genes = ga.best_individual()
                current_gen_func_value = float('inf') 
                current_gen_coords = (None, None)

                if current_gen_best_genes is not None and current_gen_best_fitness is not None and current_gen_best_fitness != -float('inf'):
                    current_gen_func_value = -current_gen_best_fitness 
                    current_gen_coords = tuple(current_gen_best_genes)
                
                current_run_best_individual_history.append((current_gen_coords, current_gen_func_value))
                
                if current_gen_func_value < best_value_this_run:
                    best_value_this_run = current_gen_func_value
                    best_coords_this_run = current_gen_coords
                
                if abs(best_value_this_run - expected_value) < STOPPING_TOLERANCE:
                    print(f"    Достигнута целевая точность на поколении {actual_generations_this_run}. Значение: {best_value_this_run:.5f}")
                    break
            
            run_end_time = time.time()
            execution_time_this_run = run_end_time - run_start_time
            if actual_generations_this_run >= 1000:
                print(f"    Завершено поколений: {actual_generations_this_run}. Лучшее значение: {best_value_this_run:.5f} в точке {best_coords_this_run}. Время: {execution_time_this_run:.3f} сек.")

            euclidean_distance = np.nan
            if best_coords_this_run and best_coords_this_run[0] is not None and best_coords_this_run[1] is not None:
                distances_to_minima = []
                for ex_coords in expected_coords_list:
                    dist = np.sqrt((best_coords_this_run[0] - ex_coords[0])**2 + (best_coords_this_run[1] - ex_coords[1])**2)
                    distances_to_minima.append(dist)
                if distances_to_minima:
                    euclidean_distance = min(distances_to_minima)

            result_entry = {
                'Function': func_name,
                'PopSize': pop_size,
                'Generations': actual_generations_this_run,
                'CrossoverProb': crossover_prob,
                'MutationProb': mutation_prob,
                'Best Value': best_value_this_run if (best_coords_this_run and best_coords_this_run[0] is not None) else np.nan,
                'Coordinates': f"({best_coords_this_run[0]:.4f}, {best_coords_this_run[1]:.4f})" if (best_coords_this_run and best_coords_this_run[0] is not None) else "N/A",
                'Expected Value': expected_value,
                'Expected Coordinates': display_expected_coords_str,
                'Euclidean_Distance': euclidean_distance,
                'Execution_Time_s': round(execution_time_this_run, 4)
            }
            all_results_ga.append(result_entry)

            if best_coords_this_run and best_coords_this_run[0] is not None and best_value_this_run < best_value_for_func:
                best_value_for_func = best_value_this_run
                best_pos_for_func = best_coords_this_run
                best_params_for_func = params_ga
                best_actual_gens_for_func = actual_generations_this_run
                best_time_for_func = execution_time_this_run
                best_population_history_for_gif = current_run_population_history
                best_individual_value_history_for_gif = current_run_best_individual_history
        
        if best_pos_for_func and best_pos_for_func[0] is not None:
            print(f"\\n  --- Лучший результат для функции {func_name} (ГА) ---")
            print(f"    Лучшее найденное значение: {best_value_for_func:.5f}")
            print(f"    Координаты: ({best_pos_for_func[0]:.4f}, {best_pos_for_func[1]:.4f})")
            if best_params_for_func:
                 best_pop, best_cross, best_mut = best_params_for_func
                 print(f"    Параметры: Популяция={best_pop}, Кроссовер={best_cross}, Мутация={best_mut}")
            print(f"    Поколений: {best_actual_gens_for_func}, Время: {best_time_for_func:.3f} сек.")

            if best_population_history_for_gif and best_individual_value_history_for_gif:
                print(f"    Генерация GIF для {func_name}...")
                x_anim = np.linspace(bounds[0][0], bounds[0][1], 80) 
                y_anim = np.linspace(bounds[1][0], bounds[1][1], 80)
                X_anim, Y_anim = np.meshgrid(x_anim, y_anim)
                Z_anim = np.full_like(X_anim, float('nan'))
                
                try: 
                    for r_idx in range(X_anim.shape[0]):
                        for c_idx in range(X_anim.shape[1]):
                            try:
                                val = func_to_optimize(X_anim[r_idx, c_idx], Y_anim[r_idx, c_idx])
                                if not (np.isnan(val) or np.isinf(val) or abs(val) > 1e10): 
                                    Z_anim[r_idx, c_idx] = val
                            except (ValueError, RuntimeWarning, OverflowError):
                                pass 
                except Exception as e_Zanim:
                     print(f"Предупреждение (ГА GIF): Не удалось полностью вычислить Z для фона анимации {func_name}: {e_Zanim}")

                frames_dir_ga = f"frames_ga_{func_name}"
                if os.path.exists(frames_dir_ga):
                    shutil.rmtree(frames_dir_ga)
                os.makedirs(frames_dir_ga, exist_ok=True)

                filenames_ga = []
                total_generations_in_history = min(best_actual_gens_for_func, len(best_population_history_for_gif), len(best_individual_value_history_for_gif))

                for history_idx in range(total_generations_in_history):
                    actual_generation_number = history_idx + 1

                    # Генерируем кадр для первого поколения, каждого 10-го и последнего поколения
                    if (actual_generation_number == 1 or
                        actual_generation_number % 20 == 0 or
                        actual_generation_number == total_generations_in_history):
                        
                        frame_filename = generate_ga_animation_frame(
                            actual_generation_number, 
                            func_name, bounds, # Передаем имя функции (строку)
                            X_anim, Y_anim, Z_anim,
                            best_population_history_for_gif[history_idx],
                            best_individual_value_history_for_gif[history_idx], 
                            frames_dir_ga,
                            algorithm_name='ГА'
                        )
                        if frame_filename and os.path.exists(frame_filename): 
                             filenames_ga.append(frame_filename)
                        else:
                             print(f"Предупреждение: кадр для поколения {actual_generation_number} для {func_name} не был создан или не найден.")
                
                if filenames_ga: 
                    gif_path_ga = f"ga_optimization_{func_name}.gif"
                    with imageio.get_writer(gif_path_ga, mode='I', duration=300, loop=0) as writer:
                        for filename in filenames_ga:
                            try:
                                image = imageio.imread(filename)
                                writer.append_data(image)
                            except Exception as e_img_read:
                                print(f"Ошибка чтения кадра {filename} для GIF: {e_img_read}")
                    print(f"    GIF сохранен: {gif_path_ga}")
                else:
                    print(f"    Не удалось создать GIF для {func_name}: нет кадров.")

                try: 
                    if os.path.exists(frames_dir_ga):
                        shutil.rmtree(frames_dir_ga)
                except OSError as e_rm_frames:
                    print(f"    Ошибка при удалении временной папки {frames_dir_ga}: {e_rm_frames}")
            else:
                print(f"    Не удалось сгенерировать GIF для {func_name}: отсутствуют данные истории лучшего запуска.")
        else:
            print(f"\\n  Не найдено корректных результатов для функции {func_name} (ГА).")

    

if all_results_ga:
    results_df_ga = pd.DataFrame(all_results_ga)
    
    best_summary_results = []
    if not results_df_ga.empty:
        for func_n in results_df_ga['Function'].unique():
            func_df = results_df_ga[results_df_ga['Function'] == func_n].copy()
            # Обработка NaN перед поиском минимума, чтобы избежать ошибки, если все значения NaN
            func_df.dropna(subset=['Best Value'], inplace=True)
            if not func_df.empty:
                best_row = func_df.loc[func_df['Best Value'].idxmin()]
                best_summary_results.append(best_row)
    
    if best_summary_results:
        summary_table_ga = pd.DataFrame(best_summary_results)
        summary_table_ga = summary_table_ga[[
            'Function', 'PopSize', 'Generations', 'CrossoverProb', 'MutationProb',
            'Best Value', 'Coordinates', 'Expected Value', 'Expected Coordinates', 'Euclidean_Distance', 'Execution_Time_s'
        ]]

        summary_table_ga.columns = [
            'Функция (ГА)', 'Размер популяции', 'Кол-во поколений', 'Вер-ть кроссовера', 'Вер-ть мутации',
            'Лучшее значение', 'Найденные координаты', 'Ожидаемое значение', 'Ожидаемые координаты',
            'Евклидово расстояние', 'Время выполнения (с)'
        ]
        
        # Округляем числовые значения для красивого вывода
        cols_to_round = ['Лучшее значение', 'Ожидаемое значение', 'Евклидово расстояние', 'Вер-ть кроссовера', 'Вер-ть мутации']
        for col in cols_to_round:
            if col in summary_table_ga.columns:
                 summary_table_ga[col] = pd.to_numeric(summary_table_ga[col], errors='coerce').round(5)

        print("\\n\\n========== Итоговая таблица лучших результатов (Генетический Алгоритм) ==========")
        print(summary_table_ga.to_string(index=False))
        
        csv_filename_ga = 'summary_results_ga.csv'
        try:
            summary_table_ga.to_csv(csv_filename_ga, index=False, encoding='utf-8-sig')
            print(f"\\nИтоговая таблица сохранена в файл: {csv_filename_ga}")
        except Exception as e_csv:
            print(f"\\nОшибка сохранения таблицы в CSV: {e_csv}")
    else:
        print("\\n--- Не удалось сформировать итоговую таблицу для ГА (нет валидных данных после выбора лучших) ---")
else:
    print("\\n--- Не удалось получить результаты для ГА (список результатов пуст) ---")