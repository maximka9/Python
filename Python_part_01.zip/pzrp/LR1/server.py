import socket
import cv2
import numpy as np
import pickle
import struct
import time

HOST = '0.0.0.0' 
PORT = 65432

def restore_image(image):
    """ Восстановление изображения медианным фильтром для цветных изображений """
    if not isinstance(image, np.ndarray) or image.ndim != 3:
        print("[!] Ошибка: restore_image ожидает 3D numpy array (цветное изображение).")
        # Возвращаем как есть
        return image
    try:
        restored = np.zeros_like(image)
        for i in range(image.shape[2]): # Работает и для 3 (BGR/RGB), и для 4 (BGRA) каналов
            restored[..., i] = cv2.medianBlur(image[..., i], 3) # Размер ядра 3x3
        return restored
    except Exception as e:
        print(f"[!] Ошибка при применении медианного фильтра: {e}")
        return image # Возвращаем исходное в случае ошибки фильтрации

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # Разрешаем переиспользование адреса
    try:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[+] Сервер слушает на {HOST}:{PORT} (ожидание подключений...)")

        while True: # Основной цикл для обработки нескольких клиентов
            conn = None
            try:
                conn, addr = s.accept()
                print(f"\n[+] Новое подключение от {addr}")

                with conn:
                    raw_size = conn.recv(8)
                    if not raw_size or len(raw_size) != 8:
                         print("[!] Ошибка: не удалось получить размер данных или получен некорректный размер.")
                         continue # Переходим к следующей итерации цикла accept

                    data_size = struct.unpack("Q", raw_size)[0]
                    print(f"[+] Ожидаемый размер данных: {data_size} байт")

                    data = b""
                    bytes_received = 0
                    conn.settimeout(10.0) # Таймаут на получение данных
                    try:
                        while bytes_received < data_size:
                            chunk_size = min(4096, data_size - bytes_received)
                            packet = conn.recv(chunk_size)
                            if not packet:
                                # Соединение разорвано до получения всех данных
                                raise ConnectionAbortedError(f"Соединение разорвано клиентом. Получено {bytes_received}/{data_size} байт.")
                            data += packet
                            bytes_received += len(packet)
                    except socket.timeout:
                        print("[!] Ошибка: Таймаут при получении данных.")
                        continue 
                    except ConnectionAbortedError as e:
                        print(f"[!] Ошибка: {e}")
                        continue 
                    finally:
                        conn.settimeout(None) # Сбрасываем таймаут

                    if bytes_received != data_size:
                         print(f"[!] Предупреждение: Получено {bytes_received} байт, ожидалось {data_size}. Попытка обработки...")

                    print(f"[+] Данные ({bytes_received} байт) получены от клиента.")

                    # --- Десериализация полученного (зашумленного) изображения --- 
                    noisy_image = None
                    try:
                        noisy_image = pickle.loads(data)
                        print("[+] Данные успешно десериализованы.")

                        if not isinstance(noisy_image, np.ndarray) or noisy_image.ndim < 2:
                             print("[!] Ошибка: десериализованные данные не являются корректным numpy array (изображением).")
                             continue
                        print(f"[*] Получено изображение формы: {noisy_image.shape}")

                    except (pickle.UnpicklingError, EOFError, struct.error, TypeError, ValueError, ModuleNotFoundError, AttributeError) as e:
                        print(f"[!] КРИТИЧЕСКАЯ ОШИБКА: Не удалось десериализовать полученные данные: {e}")
                        continue

                    # --- Восстановление изображения медианным фильтром --- 
                    print("[*] Применение медианного фильтра для восстановления...")
                    restored_image = restore_image(noisy_image)
                    if restored_image is noisy_image: # Проверяем, вернула ли функция тот же объект (из-за ошибки)
                         print("[!] Восстановление не удалось или не применялось из-за ошибки.")
                         # Все равно попытаемся отправить то, что есть
                         restored_image = noisy_image # Явно присвоим
                    else:
                        print("[+] Изображение восстановлено.")

                    # --- Отправка ВОССТАНОВЛЕННОГО изображения клиенту --- 
                    try:
                        restored_data = pickle.dumps(restored_image)
                        data_len = len(restored_data)
                        print(f"[+] Отправка восстановленного изображения ({data_len} байт) клиенту...")
                        conn.sendall(struct.pack("Q", data_len))
                        conn.sendall(restored_data)
                        print("[+] Восстановленное изображение отправлено.")
                    except (pickle.PicklingError, struct.error) as e:
                        print(f"[!] Ошибка сериализации или упаковки размера восстановленного изображения: {e}")
                    except socket.error as e:
                        print(f"[!] Ошибка сокета при отправке восстановленного изображения: {e}")

            except ConnectionResetError:
                print(f"[!] Соединение с {addr} было сброшено.")
            except socket.error as e:
                 print(f"[!] Ошибка сокета во время обработки клиента {addr if 'addr' in locals() else ''}: {e}")
            except Exception as e:
                print(f"[!] Непредвиденная ошибка при обработке клиента {addr if 'addr' in locals() else ''}: {e}")
            finally:
                 if 'addr' in locals():
                      print(f"[*] Обработка клиента {addr} завершена.")

    except socket.error as e:
        print(f"[!] Критическая ошибка сокета сервера (bind/listen): {e}")
    except KeyboardInterrupt:
        print("\n[+] Сервер останавливается по запросу пользователя (Ctrl+C).")
    except Exception as e:
        print(f"[!] Критическая ошибка сервера: {e}")
    finally:
        print("[*] Сервер завершил работу.")
