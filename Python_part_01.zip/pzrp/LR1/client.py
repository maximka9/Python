import socket
import cv2
import pickle
import struct
from skimage.metrics import structural_similarity as ssim
import numpy as np
import math
import random # Добавлено для шума

HOST = '25.21.47.82' # <-- ЗАМЕНИТЬ НА IP-АДРЕС HAMACHI СЕРВЕРА
PORT = 65432

# Загружаем оригинальное изображение
try:
    original_image = cv2.imread('images/input.jpg', cv2.IMREAD_COLOR)
    if original_image is None:
        raise FileNotFoundError("Не удалось загрузить images/input.jpg. Убедитесь, что файл существует.")
except FileNotFoundError as e:
    print(f"[!] Ошибка: {e}")
    exit()
except Exception as e:
    print(f"[!] Непредвиденная ошибка при загрузке изображения: {e}")
    exit()

def add_salt_pepper_noise(image, salt_prob=0.02, pepper_prob=0.02):
    """ Добавляет шум 'соль и перец' к изображению """
    noisy_image = np.copy(image)
    total_pixels = image.size // image.shape[2] # Количество пикселей на канал

    # Добавление "соли" (белые точки)
    num_salt = np.ceil(salt_prob * total_pixels)
    salt_coords = [np.random.randint(0, i - 1, int(num_salt)) for i in image.shape[:2]]
    noisy_image[salt_coords[0], salt_coords[1], :] = 255

    # Добавление "перца" (черные точки)
    num_pepper = np.ceil(pepper_prob * total_pixels)
    pepper_coords = [np.random.randint(0, i - 1, int(num_pepper)) for i in image.shape[:2]]
    noisy_image[pepper_coords[0], pepper_coords[1], :] = 0

    print(f"[+] Добавлен шум 'соль и перец' (salt={salt_prob*100:.1f}%, pepper={pepper_prob*100:.1f}%)")
    return noisy_image

def psnr(original, compared):
    """ Расчет PSNR (Peak Signal-to-Noise Ratio) """
    mse = np.mean((original - compared) ** 2)
    if mse == 0:
        return 100  # Изображения идентичны
    max_pixel = 255.0
    return 20 * np.log10(max_pixel / np.sqrt(mse))

# Добавляем шум к оригинальному изображению
noisy_image_local = add_salt_pepper_noise(original_image)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    try:
        print(f"[*] Попытка подключения к {HOST}:{PORT}...")
        s.connect((HOST, PORT))
        print("[+] Соединение с сервером установлено")

        # Сериализуем ЗАШУМЛЕННОЕ изображение
        data = pickle.dumps(noisy_image_local)

        # Отправляем размер и зашумленное изображение
        print(f"[+] Отправка зашумленного изображения ({len(data)} байт)")
        s.sendall(struct.pack("Q", len(data)))
        s.sendall(data)
        print("[+] Зашумленное изображение отправлено.")

        def receive_image(sock):
            # Получаем размер данных
            raw_size = sock.recv(8)
            if not raw_size or len(raw_size) != 8:
                raise Exception("Ошибка: не удалось получить размер данных или получен некорректный размер.")
            data_size = struct.unpack("Q", raw_size)[0]
            print(f"[+] Ожидаемый размер данных: {data_size} байт")

            # Получаем данные
            data = b""
            bytes_received = 0
            while bytes_received < data_size:
                chunk_size = min(4096, data_size - bytes_received)
                packet = sock.recv(chunk_size)
                if not packet:
                    raise Exception(f"Ошибка: соединение разорвано. Получено {bytes_received}/{data_size} байт.")
                data += packet
                bytes_received += len(packet)
                # print(f"[+] Получено {bytes_received}/{data_size} байт") # Для отладки

            if bytes_received != data_size:
                 print(f"[!] Предупреждение: Получено {bytes_received} байт, ожидалось {data_size}.")
                 # Можно выбросить исключение или попытаться обработать

            print("[+] Все ожидаемые данные получены.")
            # Десериализация
            try:
                 received_img = pickle.loads(data)
                 if not isinstance(received_img, np.ndarray):
                      raise TypeError("Полученные данные не являются numpy array.")
                 return received_img
            except pickle.UnpicklingError as e:
                raise Exception(f"Ошибка десериализации: {e}. Данные могли быть повреждены.")
            except Exception as e:
                raise Exception(f"Непредвиденная ошибка при обработке полученных данных: {e}")


        # --- Получение ВОССТАНОВЛЕННОГО изображения с сервера ---
        print("[*] Ожидание ВОССТАНОВЛЕННОГО изображения с сервера...")
        restored_image = None
        error_occurred = False

        try:
            restored_image = receive_image(s)
            print("[+] Восстановленное изображение получено")
            if not isinstance(restored_image, np.ndarray) or restored_image.size == 0:
                print("[!] Предупреждение: Полученное восстановленное изображение некорректно или пусто.")
                # restored_image = np.zeros_like(original_image) # Можно создать плейсхолдер
                error_occurred = True # Считаем ошибкой, если пришло не изображение

        except Exception as e:
            print(f"[!] Ошибка при получении восстановленного изображения с сервера: {e}")
            error_occurred = True

        # --- Оценка качества (только если восстановленное изображение получено корректно) ---
        if not error_occurred:
            print("[*] Оценка качества изображений...")

            # 1. Сравнение Оригинал vs Зашумленное (локально)
            try:
                if original_image.shape != noisy_image_local.shape:
                     print(f"[!] Размеры оригинала {original_image.shape} и локального шумного {noisy_image_local.shape} не совпадают.")
                     psnr_noisy = ssim_noisy = float('nan')
                else:
                    psnr_noisy = psnr(original_image, noisy_image_local)
                    data_range = original_image.max() - original_image.min()
                    if data_range == 0: data_range = 255.0
                    ssim_noisy = ssim(original_image, noisy_image_local, multichannel=True, data_range=data_range, channel_axis=2)
                    print(f"PSNR (Оригинал vs Шумное локально): {psnr_noisy:.2f} dB")
                    print(f"SSIM (Оригинал vs Шумное локально): {ssim_noisy:.4f}")
            except ValueError as e:
                 print(f"[!] Ошибка при расчете метрик для шумного изображения: {e}.")
                 psnr_noisy = ssim_noisy = float('nan')

            # 2. Сравнение Оригинал vs Восстановленное (с сервера)
            try:
                if original_image.shape != restored_image.shape:
                    print(f"[!] Размеры оригинала {original_image.shape} и восстановленного {restored_image.shape} не совпадают! Расчет метрик невозможен.")
                    psnr_restored = ssim_restored = float('nan')
                else:
                    psnr_restored = psnr(original_image, restored_image)
                    data_range = original_image.max() - original_image.min()
                    if data_range == 0: data_range = 255.0
                    ssim_restored = ssim(original_image, restored_image, multichannel=True, data_range=data_range, channel_axis=2)
                    print(f"PSNR (Оригинал vs Восстановленное сервером): {psnr_restored:.2f} dB")
                    print(f"SSIM (Оригинал vs Восстановленное сервером): {ssim_restored:.4f}")
            except ValueError as e:
                print(f"[!] Ошибка при расчете метрик для восстановленного изображения: {e}.")
                psnr_restored = ssim_restored = float('nan')
            except Exception as e:
                print(f"[!] Непредвиденная ошибка при расчете метрик для восстановленного изображения: {e}.")
                psnr_restored = ssim_restored = float('nan')


            # Отображение изображений
            cv2.imshow("Original", original_image)
            cv2.imshow("Noisy (Sent by Client)", noisy_image_local)
            cv2.imwrite("images/noisy_sent.jpg", noisy_image_local) # Сохраняем локально зашумленное
            cv2.imshow("Restored (Received from Server)", restored_image)
            cv2.imwrite("images/restored_received.jpg", restored_image) # Сохраняем восстановленное сервером


            print("[i] Нажмите любую клавишу в окне изображения для завершения...")
            cv2.waitKey(0)
            cv2.destroyAllWindows()
        else:
            print("[!] Не удалось получить или обработать восстановленное изображение для оценки качества.")

    except socket.error as e:
        print(f"[!] Ошибка сокета: {e}")
    except ConnectionRefusedError:
        print(f"[!] Ошибка: не удалось подключиться к серверу {HOST}:{PORT}. Убедитесь, что сервер запущен и доступен.")
    except Exception as e:
        print(f"[!] Непредвиденная ошибка на клиенте: {e}")
