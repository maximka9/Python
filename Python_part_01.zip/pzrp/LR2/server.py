from flask import Flask, Response, request, jsonify
import cv2
import numpy as np
import base64
import threading
import time
app = Flask(__name__)

# Глобальная переменная для хранения последнего ОБРАБОТАННОГО кадра (в формате JPEG bytes)
latest_processed_frame = None
frame_lock = threading.Lock() # Блокировка для безопасного доступа к кадру из разных потоков

@app.route('/upload', methods=['POST'])
def upload_frame():
    global latest_processed_frame
    try:
        # Получаем base64 строку и временную метку из данных формы
        jpeg_base64 = request.form['image']
        client_timestamp_str = request.form['timestamp']
        client_timestamp = float(client_timestamp_str)

        # Декодируем base64 обратно в байты
        jpeg_bytes = base64.b64decode(jpeg_base64)
        # Декодируем JPEG байты в кадр OpenCV (в формате BGR)
        frame = cv2.imdecode(np.frombuffer(jpeg_bytes, np.uint8), cv2.IMREAD_COLOR)
        if frame is None:
            print("Ошибка: Не удалось декодировать полученный кадр JPEG")
            return jsonify({"status": "error", "message": "Invalid image data"}), 400

        # --- Обработка кадра --- #
        # Пример: применяем детектор границ Canny
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        processed_frame = cv2.Canny(gray_frame, 50, 150)

        # --- Расчет и отображение задержки --- #
        server_time_after_processing = time.time()
        latency = server_time_after_processing - client_timestamp
        latency_ms = int(latency * 1000) # Задержка в миллисекундах

        # Преобразуем результат Canny (ч/б) в BGR для отрисовки цветного текста
        processed_frame_bgr = cv2.cvtColor(processed_frame, cv2.COLOR_GRAY2BGR)

        # Рисуем текст с задержкой на кадре (в BGR)
        font = cv2.FONT_HERSHEY_SIMPLEX
        text = f"Latency: {latency_ms} ms"
        org = (10, 30) # Координаты нижнего левого угла текста
        fontScale = 0.7
        color = (0, 255, 0) # Зеленый цвет (BGR)
        thickness = 2
        cv2.putText(processed_frame_bgr, text, org, font, fontScale, color, thickness, cv2.LINE_AA)

        # Устанавливаем кадр с текстом для кодирования
        processed_frame_to_encode = processed_frame_bgr

        # Кодируем ОБРАБОТАННЫЙ кадр (с текстом) обратно в JPEG
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]
        result, encoded_processed_image = cv2.imencode('.jpg', processed_frame_to_encode, encode_param)

        if not result:
            print("Ошибка: Не удалось закодировать обработанный кадр в JPEG")
            return jsonify({"status": "error", "message": "Failed to encode processed image"}), 500

        # Обновляем глобальную переменную с последним обработанным кадром
        with frame_lock:
            global latest_processed_frame
            latest_processed_frame = encoded_processed_image.tobytes()

        return jsonify({"status": "success"}), 200

    except KeyError:
        print("Ошибка: В запросе отсутствует поле 'image' или 'timestamp'")
        return jsonify({"status": "error", "message": "'image' or 'timestamp' field missing"}), 400
    except Exception as e:
        print(f"Неожиданная ошибка при обработке кадра: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

def generate_frames():
    """Генератор, который отдает последний обработанный кадр в формате MJPEG."""
    while True:
        with frame_lock:
            frame_bytes = latest_processed_frame

        if frame_bytes is None:

            time.sleep(0.1)
            continue

        # Формируем часть MJPEG ответа
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.03) # ~30 FPS max

@app.route('/processed_stream')
def processed_stream():
    """Эндпоинт, который отдает MJPEG поток."""
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    print("Сервер запущен на http://0.0.0.0:5000")
    print("Эндпоинт для получения кадров: POST /upload")
    print("Эндпоинт для просмотра MJPEG потока: GET /processed_stream")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True) 