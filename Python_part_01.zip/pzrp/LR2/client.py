import cv2
import requests
import time
import base64

# <-- ЗАМЕНИТЬ НА IP-АДРЕС HAMACHI СЕРВЕРА -->
SERVER_IP = '25.21.47.82'
SERVER_URL = f'http://{SERVER_IP}:5000/upload'
# Используйте 0 для основной веб-камеры
# Если не работает, попробуйте 1 или другие индексы,
# или путь к видеофайлу 'path/to/your/video.mp4'
VIDEO_SOURCE = 0

cap = cv2.VideoCapture(VIDEO_SOURCE)

if not cap.isOpened():
    print(f"Ошибка: Не удалось открыть источник видео: {VIDEO_SOURCE}")
    exit()

print(f"Источник видео {VIDEO_SOURCE} открыт. Отправка кадров на {SERVER_URL}...")

# Уменьшение разрешения для снижения нагрузки
# cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
# cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

frame_count = 0
start_time = time.time()

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Ошибка: Не удалось получить кадр. Поток завершен или источник недоступен.")
            # Если это видеофайл, можно выйти
            if isinstance(VIDEO_SOURCE, str):
                 break
            # Если камера, попробуем переподключиться или подождать
            cap.release()
            time.sleep(5)
            cap = cv2.VideoCapture(VIDEO_SOURCE)
            if not cap.isOpened():
                print("Ошибка: Не удалось переподключиться к камере.")
                break
            continue

        # Кодируем кадр в JPEG
        # quality от 0 до 100, чем выше, тем лучше качество и больше размер
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 80]
        result, encoded_image = cv2.imencode('.jpg', frame, encode_param)

        if not result:
            print("Ошибка: Не удалось закодировать кадр в JPEG")
            continue

        # Кодируем байты JPEG в base64 для безопасной передачи в JSON/form-data
        jpeg_base64 = base64.b64encode(encoded_image).decode('utf-8')

        try:
            # Получаем текущее время перед отправкой
            client_timestamp = time.time()
            timestamp_str = f"{client_timestamp:.6f}" # Форматируем с микросекундами

            # Отправляем кадр и временную метку на сервер
            # Добавляем proxies=None, чтобы игнорировать системные настройки прокси
            proxies_to_use = {
                "http": None,
                "https": None,
            }
            # Добавляем 'timestamp' в данные
            response = requests.post(
                SERVER_URL,
                data={'image': jpeg_base64, 'timestamp': timestamp_str},
                timeout=1, # timeout 1 секунда
                proxies=proxies_to_use
            )
            response.raise_for_status() # Проверка на HTTP ошибки (4xx, 5xx)
            # print(f"Кадр {frame_count} отправлен. Статус: {response.status_code}")

        except requests.exceptions.RequestException as e:
            print(f"Ошибка отправки кадра: {e}")
            # Добавим паузу перед следующей попыткой
            time.sleep(1)

        frame_count += 1

        # Небольшая пауза, чтобы не перегружать CPU и сеть
        # Подбирайте значение в зависимости от желаемого FPS и возможностей сети/сервера
        # time.sleep(1 / Желаемый_FPS) - например, 1/15 = 0.066
        time.sleep(0.05) # Примерно 20 FPS, если отправка быстрая

finally:
    end_time = time.time()
    duration = end_time - start_time
    fps = frame_count / duration if duration > 0 else 0
    print("\nЗавершение работы клиента.")
    print(f"Всего отправлено кадров: {frame_count}")
    print(f"Продолжительность: {duration:.2f} сек")
    print(f"Средний FPS отправки: {fps:.2f}")
    cap.release()
    print("Источник видео освобожден.") 