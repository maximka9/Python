import io

def decode_int(data, index):
    """Декодирует целое число Bencode."""
    index += 1  # Пропускаем 'i'
    end_index = data.find(b'e', index)
    if end_index == -1:
        raise ValueError("Не найден 'e' для завершения целого числа")
    num_str = data[index:end_index]
    index = end_index + 1
    try:
        return int(num_str), index
    except ValueError:
        raise ValueError(f"Неверное целое число: {num_str!r}")

def decode_string(data, index):
    """Декодирует строку Bencode."""
    colon_index = data.find(b':', index)
    if colon_index == -1:
        raise ValueError("Не найдено ':' для разделения длины строки")
    try:
        length = int(data[index:colon_index])
    except ValueError:
        raise ValueError(f"Неверная длина строки: {data[index:colon_index]!r}")
    
    start_index = colon_index + 1
    end_index = start_index + length
    if end_index > len(data):
        raise ValueError("Длина строки превышает размер данных")
        
    string_data = data[start_index:end_index]
    index = end_index
    return string_data, index

def decode_list(data, index):
    """Декодирует список Bencode."""
    index += 1  # Пропускаем 'l'
    items = []
    while index < len(data) and data[index:index+1] != b'e':
        item, index = decode_next(data, index)
        items.append(item)
    
    if index >= len(data) or data[index:index+1] != b'e':
        raise ValueError("Не найден 'e' для завершения списка или данные закончились")
        
    index += 1  # Пропускаем 'e'
    return items, index

def decode_dict(data, index):
    """Декодирует словарь Bencode."""
    index += 1  # Пропускаем 'd'
    result_dict = {}
    last_key = None
    while index < len(data) and data[index:index+1] != b'e':
        # Ключ должен быть строкой
        key, index = decode_string(data, index)
        
        # # Проверка сортировки ключей (закомментировано для совместимости с некоторыми трекерами)
        # if last_key is not None and key <= last_key:
        #      # Логгируем предупреждение вместо ошибки
        #      logger.warning(f"Обнаружены неотсортированные ключи в словаре Bencode: {key!r} <= {last_key!r}. Спецификация нарушена, но продолжаем парсинг.")
        #      # raise ValueError(f"Ключи словаря не отсортированы: {key!r} <= {last_key!r}")
        # last_key = key

        # Значение может быть любым типом
        value, index = decode_next(data, index)
        result_dict[key] = value

    if index >= len(data) or data[index:index+1] != b'e':
        raise ValueError("Не найден 'e' для завершения словаря или данные закончились")
        
    index += 1  # Пропускаем 'e'
    return result_dict, index

def decode_next(data, index):
    """Определяет тип следующего элемента Bencode и вызывает соответствующий декодер."""
    if index >= len(data):
        raise ValueError("Неожиданный конец данных")
        
    marker = data[index:index+1]
    
    if marker == b'i':
        return decode_int(data, index)
    elif marker == b'l':
        return decode_list(data, index)
    elif marker == b'd':
        return decode_dict(data, index)
    elif marker.isdigit():
        return decode_string(data, index)
    else:
        raise ValueError(f"Неверный маркер Bencode: {marker!r} в позиции {index}")

def bdecode(data: bytes):
    """
    Декодирует Bencode-кодированные байты.
    
    Args:
        data: Байты для декодирования.

    Returns:
        Декодированный Python объект (int, bytes, list, или dict).
    """
    if not isinstance(data, bytes):
        raise TypeError("Входные данные должны быть байтами")
        
    try:
        result, index = decode_next(data, 0)
        if index != len(data):
             raise ValueError(f"Лишние данные после основного объекта Bencode, начиная с индекса {index}")
        return result
    except IndexError:
        raise ValueError("Неожиданный конец данных при парсинге")
    except ValueError as e:
        # Добавляем контекст к ошибке
        # raise ValueError(f"Ошибка парсинга Bencode: {e}") from e
        # Возвращаем оригинальную ошибку для лучшей трассировки
        raise e

# Пример использования (можно раскомментировать для теста)
# if __name__ == '__main__':
#     test_data = b'd4:infod5:lengthi1024e4:name8:file.txt12:piece lengthi256e6:pieces20:abcdefghijklmnopqrstee7:announce21:http://tracker.example.com/announcee'
#     decoded = bdecode(test_data)
#     print(decoded)
#     # Ожидаемый вывод примерно такой:
#     # {b'info': {b'length': 1024, b'name': b'file.txt', b'piece length': 256, b'pieces': b'abcdefghijklmnopqrst'}, b'announce': b'http://tracker.example.com/announce'}

#     test_list = b'l4:spami42ei-3elbee'
#     decoded_list = bdecode(test_list)
#     print(decoded_list)
#     # Ожидаемый вывод: [b'spam', 42, -3, [b'b']]

#     try:
#         bdecode(b'ie') # Неверное целое
#     except ValueError as e:
#         print(f"Поймали ожидаемую ошибку: {e}")

#     try:
#         bdecode(b'len') # Неверный формат строки
#     except ValueError as e:
#         print(f"Поймали ожидаемую ошибку: {e}")
        
#     try:
#         bdecode(b'd3:keyi1e3:keye') # Повторяющийся ключ (или неотсортированный)
#     except ValueError as e:
#         print(f"Поймали ожидаемую ошибку: {e}")
        
#     try:
#         bdecode(b'li1e') # Не закончен список
#     except ValueError as e:
#         print(f"Поймали ожидаемую ошибку: {e}") 