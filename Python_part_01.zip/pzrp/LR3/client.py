import asyncio
import hashlib
import logging
import math
import os
import random
import socket
import struct
import time
import urllib.parse
from typing import List, Dict, Tuple, Optional
WRITE_TIMEOUT = 10  # секунд, можно настроить по-своему
import aiohttp

# Импортируем наш парсер bencode
try:
    from bencode_parser import bdecode, decode_dict, decode_list, decode_int, decode_string, decode_next
except ImportError:
    print("Ошибка: Не удалось импортировать 'bencode_parser'. Убедитесь, что файл bencode_parser.py находится в той же директории.")
    # Предоставим базовые заглушки, чтобы избежать NameError при запуске
    def bdecode(data): raise NotImplementedError("bdecode не импортирован")
    # ... можно добавить и другие, если анализатор кода будет ругаться

# --- Константы ---
BLOCK_SIZE = 2**14  # 16 KiB - стандартный размер блока для запроса
PEER_ID_PREFIX = b'-PY0001-' # Пример префикса Peer ID
PROTOCOL_NAME = b'BitTorrent protocol'
HANDSHAKE_LEN = 68 # 1 (длина) + 19 (имя протокола) + 8 (резерв) + 20 (инфохеш) + 20 (пир айди)
CONNECT_TIMEOUT = 10 # Таймаут соединения с пиром
READ_TIMEOUT = 15 # Таймаут чтения от пира
MAX_PEER_CONNECTIONS = 40 # Максимальное кол-во одновременных соединений с пирами
MAX_PENDING_REQUESTS = 5 # Максимальное кол-во ожидающих запросов на одного пира

# --- Логгирование ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Класс для хранения информации о торренте ---
class Torrent:
    def __init__(self, metadata: dict):
        self.metadata = metadata
        self.info = metadata[b'info']
        self.announce_list = metadata.get(b'announce-list', [[metadata[b'announce']]]) # Поддержка announce-list
        self.announce = metadata[b'announce'] # Основной трекер
        self.info_hash = hashlib.sha1(self._encode_info()).digest()

        # Информация о файле/файлах
        if b'files' in self.info: # Мультифайловый торрент
            self.is_multi_file = True
            self.files = [{'path': os.path.join(*[p.decode('utf-8', errors='ignore') for p in file[b'path']]),
                           'length': file[b'length']}
                          for file in self.info[b'files']]
            self.total_size = sum(file['length'] for file in self.files)
            self.file_name = self.info[b'name'].decode('utf-8', errors='ignore') # Имя папки
        else: # Одиночный файл
            self.is_multi_file = False
            self.file_name = self.info[b'name'].decode('utf-8', errors='ignore')
            self.total_size = self.info[b'length']
            self.files = [{'path': self.file_name, 'length': self.total_size}]

        self.piece_length = self.info[b'piece length']
        self.pieces_hashes_raw = self.info[b'pieces']
        self.num_pieces = len(self.pieces_hashes_raw) // 20
        self.piece_hashes = [self.pieces_hashes_raw[i*20:(i+1)*20] for i in range(self.num_pieces)]

        if len(self.pieces_hashes_raw) % 20 != 0:
            raise ValueError("Некорректная длина хэшей кусков")
        if len(self.piece_hashes) != self.num_pieces:
             raise ValueError("Количество хэшей кусков не совпадает с расчетным")

        logger.info(f"Торрент загружен: {self.file_name}")
        logger.info(f"Размер: {self.total_size / (1024*1024):.2f} MB")
        logger.info(f"Количество кусков: {self.num_pieces}, Размер куска: {self.piece_length / 1024} KB")
        logger.info(f"Инфо-хэш: {self.info_hash.hex()}")
        # Выбираем первый трекер из списка или основной
        self.tracker_url = self._get_tracker_url()
        logger.info(f"Трекер: {self.tracker_url}")


    def _encode_info(self):
        """Кодирует словарь info обратно в bencode формат для вычисления info_hash."""
        def encode_item(item):
            if isinstance(item, bytes):
                return str(len(item)).encode() + b':' + item
            elif isinstance(item, str): # Кодируем строки как UTF-8 байты
                encoded_item = item.encode('utf-8')
                return str(len(encoded_item)).encode() + b':' + encoded_item
            elif isinstance(item, int):
                return b'i' + str(item).encode() + b'e'
            elif isinstance(item, list):
                encoded_list = b'l'
                for sub_item in item:
                    encoded_list += encode_item(sub_item)
                return encoded_list + b'e'
            elif isinstance(item, dict):
                encoded_dict = b'd'
                # Ключи словаря info должны быть байтами и отсортированы
                try:
                    # Сортируем ключи как байты
                     sorted_keys = sorted(item.keys())
                except TypeError:
                     # Если ключи не байты (что странно для info), пробуем сортировать как есть
                     logger.warning("Ключи в info словаре не являются байтами, попытка стандартной сортировки.")
                     sorted_keys = sorted(item.keys())

                for key in sorted_keys:
                    encoded_dict += encode_item(key) # Ключ уже должен быть байтами
                    encoded_dict += encode_item(item[key])
                return encoded_dict + b'e'
            else:
                raise TypeError(f"Неподдерживаемый тип для Bencode: {type(item)}")

        # Важно кодировать именно оригинальный 'info' словарь
        return encode_item(self.info)

    def _get_tracker_url(self) -> str:
         """Пытается получить рабочий HTTP/HTTPS трекер из announce-list или announce."""
         urls = []
         if self.announce_list:
             # Flatten the list of lists
             urls.extend([url.decode('utf-8', errors='ignore') for tier in self.announce_list for url in tier])
         if self.announce:
             urls.append(self.announce.decode('utf-8', errors='ignore'))

         for url in urls:
             if url.startswith('http://') or url.startswith('https://'):
                 logger.debug(f"Выбран HTTP/S трекер: {url}")
                 return url
         # Если не нашли http/https, пробуем UDP, хотя клиент его не поддерживает
         for url in urls:
              if url.startswith('udp://'):
                  logger.warning(f"Найден UDP трекер {url}, но он не поддерживается этим клиентом.")
                  # Можно вернуть его, если других нет, но он не будет работать
                  # return url
         raise ValueError("Не найден поддерживаемый HTTP/HTTPS трекер в торрент-файле")


    def get_piece_size(self, piece_index: int) -> int:
        """Возвращает размер указанного куска (последний может быть меньше)."""
        if piece_index < 0 or piece_index >= self.num_pieces:
            raise IndexError("Неверный индекс куска")
        if piece_index == self.num_pieces - 1: # Последний кусок
            return self.total_size - (self.num_pieces - 1) * self.piece_length
        else:
            return self.piece_length

    def get_block_info(self, piece_index: int, block_offset: int, block_length: int) -> Tuple[int, int, int]:
         """Проверяет корректность запроса блока и возвращает (индекс, смещение, длина)."""
         piece_size = self.get_piece_size(piece_index)
         if block_offset < 0 or block_offset >= piece_size:
             raise ValueError(f"Неверное смещение блока ({block_offset}) для куска {piece_index} размером {piece_size}")
         if block_length <= 0 or block_length > BLOCK_SIZE:
              raise ValueError(f"Неверная длина блока: {block_length}")
         if block_offset + block_length > piece_size:
             # Корректируем длину последнего блока в куске
             block_length = piece_size - block_offset
             if block_length <= 0:
                 raise ValueError("Неверный расчет длины последнего блока")
         return piece_index, block_offset, block_length


# --- Управление загрузкой кусков ---
class PieceManager:
    def __init__(self, torrent: Torrent):
        self.torrent = torrent
        # Статус каждого куска: 0 - не скачан, 1 - скачивается, 2 - скачан и проверен
        self.piece_status = [0] * torrent.num_pieces
        self.pieces_data = [None] * torrent.num_pieces # Хранит данные скачанных кусков
        self.piece_received_bytes = [0] * torrent.num_pieces # Счетчик полученных байт для каждого куска
        # Теперь храним (время_запроса, (ip, port)) для каждого ожидающего блока
        self.pending_blocks: Dict[Tuple[int, int], Tuple[float, Tuple[str, int]]] = {}
        self.missing_pieces = list(range(torrent.num_pieces)) # Список индексов недостающих кусков
        self.downloaded_bytes = 0 # Общее количество скачанных байт (может быть неточным)
        self._file_handles = {} # Словарь для хранения открытых файловых дескрипторов
        self._init_files() # Создаем файлы/папки и открываем дескрипторы

    def _init_files(self):
        """Создает директории и файлы (если не существуют) и открывает их для записи."""
        current_offset = 0
        for file_info in self.torrent.files:
            file_path = os.path.abspath(file_info['path']) # Используем абсолютный путь
            file_dir = os.path.dirname(file_path)

            if not os.path.exists(file_dir):
                try:
                    os.makedirs(file_dir)
                    logger.info(f"Создана директория: {file_dir}")
                except OSError as e:
                    logger.error(f"Не удалось создать директорию {file_dir}: {e}")
                    raise

            # Открываем файл в бинарном режиме для чтения и записи ('rb+')
            # Если файла нет, он будет создан. Если есть, он будет открыт без обрезки.
            try:
                # Проверяем, существует ли файл и имеет ли он ожидаемый размер
                # Это базовая проверка на случай, если файл уже частично скачан
                create_new = True
                if os.path.exists(file_path):
                     # Пока не будем реализовывать докачку, просто перезаписываем
                     logger.warning(f"Файл {file_path} уже существует. Он будет перезаписан.")
                     # file_size = os.path.getsize(file_path)
                     # if file_size == file_info['length']:
                     #     logger.info(f"Файл {file_path} уже существует и имеет правильный размер.")
                     #     # Здесь можно было бы реализовать проверку хэшей и докачку
                     #     create_new = False
                     # else:
                     #     logger.warning(f"Файл {file_path} существует, но имеет неверный размер ({file_size} != {file_info['length']}). Будет перезаписан.")

                # if create_new:
                 # Используем 'wb+' для создания/перезаписи и позиционирования
                # 'wb+' создает файл, если его нет, или обрезает до нуля, если есть.
                # Нам нужно 'rb+', чтобы не обрезать, но создать, если нет.
                # Проверим существование и создадим пустой файл, если нужно.
                if not os.path.exists(file_path):
                    open(file_path, 'wb').close() # Создаем пустой файл

                # Открываем для бинарного чтения/записи
                f = open(file_path, 'rb+')
                # Важно: Не используем f.truncate(), так как это может быть медленно
                # для больших файлов. Вместо этого будем писать в нужные позиции.
                # Предварительное выделение места может быть полезным, но не обязательно.
                # f.seek(file_info['length'] - 1)
                # f.write(b'\0')

                self._file_handles[file_path] = f
                logger.debug(f"Открыт файл для записи: {file_path}")
            except IOError as e:
                logger.error(f"Не удалось открыть или создать файл {file_path}: {e}")
                raise

            current_offset += file_info['length']

    def close_files(self):
        """Закрывает все открытые файловые дескрипторы."""
        for f in self._file_handles.values():
            try:
                f.close()
            except IOError as e:
                logger.warning(f"Ошибка при закрытии файла: {e}")
        self._file_handles.clear()
        logger.info("Все файлы закрыты.")


    def _get_file_offset(self, piece_index: int, block_offset: int) -> Optional[Tuple[object, int]]:
        """Находит файл и смещение внутри файла для данного блока куска."""
        global_offset = piece_index * self.torrent.piece_length + block_offset
        current_offset = 0
        for file_info in self.torrent.files:
            file_path_abs = os.path.abspath(file_info['path'])
            if current_offset <= global_offset < current_offset + file_info['length']:
                file_handle = self._file_handles.get(file_path_abs)
                if file_handle:
                    relative_offset = global_offset - current_offset
                    return file_handle, relative_offset
                else:
                    logger.error(f"Не найден файловый дескриптор для {file_path_abs}")
                    return None # Ошибка - дескриптор должен быть
            current_offset += file_info['length']
        logger.error(f"Не удалось найти файл для смещения {global_offset}")
        return None # Ошибка - смещение вне диапазона

    def write_block(self, piece_index: int, block_offset: int, data: bytes):
        """Записывает блок данных в соответствующий файл(ы)."""
        logger.debug(f"Запись блока: кусок {piece_index}, смещение {block_offset}, длина {len(data)}")

        # Проверяем, есть ли уже этот кусок целиком
        if self.piece_status[piece_index] == 2:
             logger.warning(f"Попытка записи блока для уже завершенного куска {piece_index}")
             return

        # Находим файл и смещение для начала блока
        result = self._get_file_offset(piece_index, block_offset)
        if not result:
            logger.error(f"Не удалось получить позицию для записи блока куска {piece_index} смещения {block_offset}")
            return
        file_handle, file_offset = result

        try:
             # Позиционируемся и записываем
             file_handle.seek(file_offset)
             file_handle.write(data)
             # file_handle.flush() # Можно убрать для производительности, ОС сама сбросит
             logger.debug(f"Блок записан в {file_handle.name} по смещению {file_offset}")
        except IOError as e:
             logger.error(f"Ошибка записи блока в файл {file_handle.name}: {e}")
             # Возможно, стоит обработать ошибку более серьезно (например, остановить загрузку)
             return

    def add_block_to_piece(self, piece_index: int, block_offset: int, data: bytes):
         """Добавляет блок к куску, обновляет счетчики и инициирует проверку хэша, если кусок собран."""
         # Игнорируем, если кусок уже скачан и проверен
         if self.piece_status[piece_index] == 2:
             return

         piece_size = self.torrent.get_piece_size(piece_index)

         # Инициализируем буфер, статус и счетчик, если буфер еще не создан
         if self.pieces_data[piece_index] is None:
             logger.debug(f"Инициализация буфера для куска {piece_index} (размер: {piece_size}).")
             self.pieces_data[piece_index] = bytearray(piece_size)
             self.piece_status[piece_index] = 1 # Устанавливаем статус "скачивается"
             self.piece_received_bytes[piece_index] = 0 # Сбрасываем счетчик байт
             try:
                 self.missing_pieces.remove(piece_index) # Удаляем из списка недостающих
             except ValueError:
                 # Может произойти, если кусок был возвращен в missing_pieces после неудачной проверки,
                 # а затем сразу пришел новый блок.
                 logger.debug(f"Кусок {piece_index} не найден в missing_pieces при инициализации буфера.")
                 pass

         # Проверяем корректность смещения и размера блока
         current_piece_buffer = self.pieces_data[piece_index]
         # Эта проверка теперь избыточна, т.к. мы инициализируем выше, но оставим на всякий случай
         if current_piece_buffer is None:
              logger.error(f"Критическая ошибка: буфер для куска {piece_index} все еще None после инициализации!")
              return

         if block_offset + len(data) > len(current_piece_buffer):
             logger.error(f"Ошибка: блок выходит за границы куска {piece_index}. "
                          f"Смещение {block_offset}, Длина {len(data)}, Размер буфера {len(current_piece_buffer)}")
             # Не сбрасываем кусок, т.к. это может быть единичный сбойный блок
             return

         # Копируем данные блока в буфер куска
         # Проверяем, не записываем ли мы поверх уже полученных данных (простейший вариант)
         # TODO: Нужна более надежная проверка на дубликаты блоков
         already_received_bytes_for_block = 0
         # Простой способ проверить - посмотреть, не нулевые ли байты в целевом диапазоне
         # (это сработает, только если bytearray инициализируется нулями, что так и есть)
         target_slice = current_piece_buffer[block_offset : block_offset + len(data)]
         # if any(target_slice):
         #     logger.warning(f"Попытка записать блок ({piece_index}, {block_offset}) поверх уже существующих данных. Пропускаем.")
         #     # Удаляем из pending, т.к. мы его обработали (проигнорировали)
         #     self.pending_blocks.pop((piece_index, block_offset), None)
         #     return

         current_piece_buffer[block_offset : block_offset + len(data)] = data
         # Увеличиваем счетчик только на количество *новых* байт (пока не реализовано)
         # Пока просто увеличиваем на размер блока
         newly_received_count = len(data)
         # Только увеличиваем счетчик, если блок действительно новый (проверка выше закомментирована)
         self.piece_received_bytes[piece_index] += newly_received_count
         self.downloaded_bytes += newly_received_count # Увеличиваем общий счетчик скачанного

         logger.debug(f"Добавлен блок ({newly_received_count} байт) к куску {piece_index}. "
                      f"Всего получено для куска: {self.piece_received_bytes[piece_index]}/{piece_size}")

         # Удаляем блок из ожидающих ответа
         self.pending_blocks.pop((piece_index, block_offset), None)

         # Проверяем, завершен ли кусок
         if self.piece_received_bytes[piece_index] == piece_size:
             # Дополнительная проверка статуса - он должен быть 1
             if self.piece_status[piece_index] == 1:
                # logger.info(f"Все байты ({piece_size}) для куска {piece_index} получены. Проверка хэша...")
                 self.check_and_save_piece(piece_index)
             else:
                 # Странная ситуация: байты сошлись, а статус не 1 (может быть 0 или 2?)
                 logger.warning(f"Все байты для куска {piece_index} получены, но его статус {self.piece_status[piece_index]}. Хэш не проверяется.")
         elif self.piece_received_bytes[piece_index] > piece_size:
             logger.error(f"Ошибка: получено больше байт ({self.piece_received_bytes[piece_index]}) "
                          f"чем размер куска ({piece_size}) для индекса {piece_index}. Сброс куска.")
             # Сбрасываем состояние куска
             self.piece_status[piece_index] = 0
             self.pieces_data[piece_index] = None
             self.piece_received_bytes[piece_index] = 0
             if piece_index not in self.missing_pieces:
                 self.missing_pieces.append(piece_index)
             # Удаляем все ожидающие блоки для этого куска
             blocks_to_remove = [(idx, offset) for idx, offset in self.pending_blocks if idx == piece_index]
             for block_key in blocks_to_remove:
                 if block_key in self.pending_blocks:
                     del self.pending_blocks[block_key]

    def check_and_save_piece(self, piece_index):
         """Проверяет хэш куска и, если он верный, записывает на диск."""
         # Проверяем, что кусок действительно находится в статусе "скачивается"
         # и для него есть буфер данных.
         if self.piece_status[piece_index] != 1 or self.pieces_data[piece_index] is None:
             logger.warning(f"Попытка проверить/сохранить кусок {piece_index}, который не находится в статусе 'скачивается' "
                          f"(статус: {self.piece_status[piece_index]}) или не имеет данных.")
             return False

         # Проверяем, что получены все байты (дополнительная проверка)
         piece_size = self.torrent.get_piece_size(piece_index)
         if self.piece_received_bytes[piece_index] != piece_size:
              logger.warning(f"Попытка проверить кусок {piece_index}, для которого получено {self.piece_received_bytes[piece_index]} байт, "
                           f"а ожидалось {piece_size}. Проверка отменена.")
              # Не сбрасываем кусок, просто ждем остальные байты
              return False

         logger.debug(f"Начинаем проверку хэша для куска {piece_index}...")
         piece_data = bytes(self.pieces_data[piece_index]) # Преобразуем bytearray в bytes для хэширования
         expected_hash = self.torrent.piece_hashes[piece_index]
         actual_hash = hashlib.sha1(piece_data).digest()

         if actual_hash == expected_hash:
            # logger.info(f"Кусок {piece_index} успешно проверен (Хэш: {actual_hash.hex()[:8]}...). Запись на диск...")
             self.piece_status[piece_index] = 2
             self._write_piece_to_disk(piece_index, piece_data)
             # Освобождаем память от данных куска после записи
             self.pieces_data[piece_index] = None
             # Не сбрасываем piece_received_bytes, т.к. он больше не нужен для этого куска
             return True
         else:
             logger.warning(f"Хэш куска {piece_index} не совпал! Ожидался {expected_hash.hex()}, получен {actual_hash.hex()}. Кусок будет скачан заново.")
             self.piece_status[piece_index] = 0 # Сбрасываем статус
             self.pieces_data[piece_index] = None # Очищаем неверные данные
             self.piece_received_bytes[piece_index] = 0 # Сбрасываем счетчик байт!
             if piece_index not in self.missing_pieces:
                 self.missing_pieces.append(piece_index) # Добавляем обратно в список недостающих
             # TODO: Возможно, стоит наказать пира, от которого пришел плохой кусок?
             # Удаляем все ожидающие блоки для этого куска, т.к. их нужно запросить заново
             blocks_to_remove = [(idx, offset) for idx, offset in self.pending_blocks if idx == piece_index]
             if blocks_to_remove:
                 logger.debug(f"Удаляем {len(blocks_to_remove)} ожидающих блоков для неудачного куска {piece_index}.")
                 for block_key in blocks_to_remove:
                      if block_key in self.pending_blocks:
                          del self.pending_blocks[block_key]
             return False

    def _write_piece_to_disk(self, piece_index, piece_data):
         """Записывает целый кусок на диск, распределяя по файлам."""
         piece_size = len(piece_data)
         piece_offset = piece_index * self.torrent.piece_length
         logger.debug(f"Запись куска {piece_index} (размер {piece_size}) на диск, смещение {piece_offset}")

         written_bytes = 0
         while written_bytes < piece_size:
             # Находим файл и смещение для текущей части куска
             global_offset = piece_offset + written_bytes
             result = self._get_file_offset(piece_index, written_bytes) # Ищем по смещению внутри куска
             if not result:
                  logger.error(f"Не удалось получить позицию для записи части куска {piece_index} со смещением {written_bytes}")
                  # Это серьезная ошибка, возможно, стоит прервать запись
                  return
             file_handle, file_offset = result

             # Определяем, сколько байт писать в этот файл
             file_path = file_handle.name
             file_info = next(f for f in self.torrent.files if os.path.abspath(f['path']) == file_path)
             bytes_left_in_file = file_info['length'] - file_offset
             bytes_to_write_in_file = min(piece_size - written_bytes, bytes_left_in_file)

             if bytes_to_write_in_file <= 0:
                  logger.error(f"Ошибка расчета записи для куска {piece_index}: bytes_to_write_in_file={bytes_to_write_in_file}")
                  break # Предотвращаем бесконечный цикл

             try:
                 file_handle.seek(file_offset)
                 data_chunk = piece_data[written_bytes : written_bytes + bytes_to_write_in_file]
                 file_handle.write(data_chunk)
                 # logger.debug(f"Записано {bytes_to_write_in_file} байт в {file_path} по смещению {file_offset}")
                 written_bytes += bytes_to_write_in_file
             except IOError as e:
                 logger.error(f"Ошибка записи куска {piece_index} в файл {file_path}: {e}")
                 # Возможно, стоит остановить запись куска
                 return

         logger.debug(f"Кусок {piece_index} полностью записан на диск.")

    def get_next_block_request(self, peer_info: Tuple[str, int], peer_bitfield: bytes) -> Optional[Tuple[int, int, int]]:
        """Выбирает следующий блок для запроса у пира, учитывая его битовое поле."""
        # Простейшая стратегия: проходим по недостающим кускам и ищем тот, что есть у пира
        # TODO: Реализовать более умную стратегию (например, Rarest First)
        current_time = time.monotonic()

        # Сначала проверим зависшие запросы (по таймауту)
        # Теперь итерация по копии, чтобы можно было удалять элементы
        for block_key, (req_time, req_peer_info) in list(self.pending_blocks.items()):
             # Таймаут увеличен, т.к. дисковая запись может быть медленной
             if current_time - req_time > READ_TIMEOUT * 4: # Увеличиваем таймаут
                 logger.warning(f"Запрос блока {block_key} от пира {req_peer_info} завис (>{READ_TIMEOUT*4} сек). Отмена.")
                 # Удаляем из ожидающих
                 del self.pending_blocks[block_key]
                 # Возвращаем кусок в очередь, если он еще не скачан
                 piece_idx = block_key[0]
                 if self.piece_status[piece_idx] != 2:
                     if piece_idx not in self.missing_pieces:
                          self.missing_pieces.append(piece_idx)
                     # Сбрасываем статус на 0, чтобы его можно было запросить снова
                     self.piece_status[piece_idx] = 0
                     self.pieces_data[piece_idx] = None
                     self.piece_received_bytes[piece_idx] = 0
                     logger.info(f"Кусок {piece_idx} возвращен в очередь из-за таймаута запроса блока.")

        # Ищем недостающий кусок, который есть у пира
        # Перемешиваем список, чтобы разные пиры запрашивали разные куски
        # random.shuffle(self.missing_pieces) # Пока уберем shuffle для детерминизма
        sorted_missing = sorted(self.missing_pieces) # Попробуем запрашивать по порядку

        for piece_idx in sorted_missing:
            if self.piece_status[piece_idx] == 0: # Если кусок еще не начали качать
                if self._peer_has_piece(peer_bitfield, piece_idx):
                    piece_size = self.torrent.get_piece_size(piece_idx)
                    block_offset = 0
                    block_length = min(BLOCK_SIZE, piece_size)
                    block_key = (piece_idx, block_offset)
                    if block_key not in self.pending_blocks:
                        logger.debug(f"Выбран новый кусок {piece_idx} для скачивания у {peer_info}. Блок: {block_key}")
                        self.pending_blocks[block_key] = (current_time, peer_info)
                        self.piece_status[piece_idx] = 1 # Отмечаем как "скачивается"
                        # Не удаляем из missing_pieces здесь, удаляем при инициализации буфера в add_block_to_piece
                        return self.torrent.get_block_info(piece_idx, block_offset, block_length)
            elif self.piece_status[piece_idx] == 1: # Если кусок скачивается
                 if self._peer_has_piece(peer_bitfield, piece_idx):
                     piece_size = self.torrent.get_piece_size(piece_idx)
                     num_blocks = math.ceil(piece_size / BLOCK_SIZE)
                     for block_idx in range(num_blocks):
                         block_offset = block_idx * BLOCK_SIZE
                         block_key = (piece_idx, block_offset)
                         # Проверяем, не запрошен ли уже этот блок
                         if block_key not in self.pending_blocks:
                              # Проверяем, есть ли уже данные для этого блока (на случай частичной сборки)
                              # Это усложняет логику, пока пропустим
                              # if self.pieces_data[piece_idx] and any(self.pieces_data[piece_idx][block_offset:block_offset+BLOCK_SIZE]):
                              #      continue # Данные для этого блока уже есть (или часть их), пропускаем

                              actual_block_length = min(BLOCK_SIZE, piece_size - block_offset)
                              if actual_block_length <= 0: continue

                              logger.debug(f"Выбран следующий блок {block_key} куска {piece_idx} для скачивания у {peer_info}.")
                              self.pending_blocks[block_key] = (current_time, peer_info)
                              return self.torrent.get_block_info(piece_idx, block_offset, actual_block_length)
        return None

    def _peer_has_piece(self, peer_bitfield: bytes, piece_index: int) -> bool:
        """Проверяет, есть ли указанный кусок у пира по его битовому полю."""
        if not peer_bitfield:
            return False # У пира нет битового поля (еще не прислал)
        byte_index = piece_index // 8
        bit_index = 7 - (piece_index % 8) # Биты считаются слева направо (от старшего к младшему)
        if byte_index >= len(peer_bitfield):
            return False # Битовое поле пира короче, чем наш индекс (значит куска точно нет)
        return (peer_bitfield[byte_index] >> bit_index) & 1


    def is_complete(self) -> bool:
        """Проверяет, все ли куски скачаны и проверены."""
        return all(status == 2 for status in self.piece_status)

    def get_download_progress(self) -> Tuple[int, int, float]:
         """Возвращает (скачанные байты, всего байт, процент)."""
         # Считаем завершенные куски для более точного прогресса записи на диск
         completed_pieces = sum(1 for status in self.piece_status if status == 2)
         completed_bytes = sum(self.torrent.get_piece_size(i) for i, status in enumerate(self.piece_status) if status == 2)

         # Приближенно считаем байты в процессе скачивания (статус 1)
         # Это очень грубо, т.к. кусок может быть почти скачан или только начат
         # in_progress_bytes = sum(self.piece_received_bytes[i] for i, status in enumerate(self.piece_status) if status == 1)
         # total_downloaded_approx = completed_bytes + in_progress_bytes

         # Используем completed_bytes для более стабильного отображения прогресса
         progress_percent = (completed_bytes / self.torrent.total_size) * 100 if self.torrent.total_size > 0 else 0
         # Возвращаем completed_bytes, total_size, progress_percent, completed_pieces
         return completed_bytes, self.torrent.total_size, progress_percent


# --- Логика взаимодействия с пиром ---
class PeerConnection:
    def __init__(self, peer_info: Tuple[str, int], torrent: Torrent, piece_manager: PieceManager, peer_id: bytes, info_hash: bytes, writer_queue: asyncio.Queue):
        self.peer_ip = peer_info[0]
        self.peer_port = peer_info[1]
        self.torrent = torrent
        self.piece_manager = piece_manager
        self.my_peer_id = peer_id
        self.info_hash = info_hash
        self.writer_queue = writer_queue # Очередь для асинхронной записи на диск
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None
        self.remote_peer_id: Optional[bytes] = None
        self.bitfield: Optional[bytes] = None # Битовое поле пира
        self.am_choking = True # Я блокирую пира?
        self.am_interested = False # Я заинтересован в пире?
        self.peer_choking = True # Пир блокирует меня?
        self.peer_interested = False # Пир заинтересован во мне?
        self.pending_requests = 0 # Количество блоков, запрошенных у этого пира
        self.last_message_time = time.monotonic() # Время последнего сообщения от пира
        self._connected = False
        self._closing = False
        self._buffer = b'' # Буфер для чтения данных

    async def connect(self):
        """Устанавливает соединение с пиром и выполняет рукопожатие."""
        try:
            logger.info(f"Попытка соединения с пиром {self.peer_ip}:{self.peer_port}")
            future = asyncio.open_connection(self.peer_ip, self.peer_port)
            self.reader, self.writer = await asyncio.wait_for(future, timeout=CONNECT_TIMEOUT)
            self._connected = True
            logger.info(f"Соединение с {self.peer_ip}:{self.peer_port} установлено.")

            # 1. Отправляем рукопожатие
            handshake_msg = self._create_handshake()
            self.writer.write(handshake_msg)
            await self.writer.drain()
            logger.debug(f"Отправлено рукопожатие пиру {self.peer_ip}:{self.peer_port}")

            # 2. Получаем рукопожатие от пира
            peer_handshake = await self._read_data(HANDSHAKE_LEN)
            if not peer_handshake or len(peer_handshake) != HANDSHAKE_LEN:
                 logger.warning(f"Пир {self.peer_ip}:{self.peer_port} не прислал полное рукопожатие.")
                 await self.close()
                 return False

            # 3. Проверяем рукопожатие пира
            if not self._verify_handshake(peer_handshake):
                 logger.warning(f"Неверное рукопожатие от пира {self.peer_ip}:{self.peer_port}")
                 await self.close()
                 return False

            logger.info(f"Рукопожатие с пиром {self.peer_ip}:{self.peer_port} (ID: {self.remote_peer_id.hex() if self.remote_peer_id else 'N/A'}) успешно.")
            self.last_message_time = time.monotonic() # Обновляем время после успешного хендшейка
            return True

        except (asyncio.TimeoutError, ConnectionRefusedError, OSError) as e:
            logger.warning(f"Не удалось подключиться к пиру {self.peer_ip}:{self.peer_port}: {e}")
            await self.close() # Убедимся, что соединение закрыто
            return False
        except Exception as e:
            logger.error(f"Неожиданная ошибка при подключении к {self.peer_ip}:{self.peer_port}: {e}", exc_info=True)
            await self.close()
            return False

    def _create_handshake(self) -> bytes:
        """Создает сообщение рукопожатия."""
        return struct.pack('>B19s8x20s20s',
                           len(PROTOCOL_NAME), # Длина имени протокола (19)
                           PROTOCOL_NAME,
                           self.info_hash,
                           self.my_peer_id)

    def _verify_handshake(self, handshake: bytes) -> bool:
        """Проверяет рукопожатие, полученное от пира."""
        if len(handshake) != HANDSHAKE_LEN:
            logger.debug(f"Неверная длина рукопожатия: {len(handshake)}")
            return False
        try:
            pstrlen, pstr, info_hash, peer_id = struct.unpack('>B19s8x20s20s', handshake)
            if pstrlen != len(PROTOCOL_NAME) or pstr != PROTOCOL_NAME:
                logger.debug(f"Неверное имя протокола: {pstr}")
                return False
            if info_hash != self.info_hash:
                logger.debug(f"Неверный инфо-хэш: {info_hash.hex()}")
                # В некоторых случаях пир может работать с несколькими торрентами,
                # но по стандарту инфо-хэш должен совпадать.
                return False
            # Сохраняем ID пира
            self.remote_peer_id = peer_id
            # Опционально: проверить, что peer_id не совпадает с нашим
            if self.remote_peer_id == self.my_peer_id:
                 logger.warning(f"Обнаружено соединение с самим собой ({self.peer_ip}:{self.peer_port}). Закрытие.")
                 return False
            return True
        except struct.error as e:
            logger.error(f"Ошибка распаковки рукопожатия: {e}")
            return False


    async def run(self):
         """Основной цикл обработки сообщений от пира."""
         if not self._connected or not self.reader or not self.writer:
              logger.error("Попытка запустить обработку для не подключенного пира.")
              return

         try:
              # Отправляем interested, если нам нужны куски
              if self.piece_manager.missing_pieces:
                  await self._send_interested()

              while self._connected and not self._closing:
                  # Читаем сообщение от пира
                  message = await self._read_message()
                  if message is None:
                      # Соединение закрыто или ошибка чтения
                      logger.info(f"Соединение с пиром {self.peer_ip}:{self.peer_port} потеряно.")
                      break # Выходим из цикла

                  # Обрабатываем сообщение
                  await self.handle_message(message)

                  # Проверяем таймаут Keep-Alive
                  if time.monotonic() - self.last_message_time > 60 * 2: # 2 минуты без сообщений
                      logger.warning(f"Таймаут Keep-Alive для пира {self.peer_ip}:{self.peer_port}. Отправка Keep-Alive.")
                      await self._send_keep_alive() # Отправляем keep-alive, чтобы проверить соединение
                      # Можно также закрыть соединение, если keep-alive не помогает
                      # break

                  # Запрашиваем новые блоки, если пир нас не блокирует и мы заинтересованы
                  await self._request_pieces_if_needed()

                  # Небольшая пауза, чтобы не загружать CPU
                  await asyncio.sleep(0.01)

         except asyncio.IncompleteReadError as e:
              logger.warning(f"Соединение с пиром {self.peer_ip}:{self.peer_port} неожиданно закрыто: {e}")
         except ConnectionResetError:
              logger.warning(f"Соединение с пиром {self.peer_ip}:{self.peer_port} сброшено.")
         except asyncio.CancelledError:
              logger.info(f"Задача для пира {self.peer_ip}:{self.peer_port} отменена.")
         except Exception as e:
              logger.error(f"Ошибка в цикле обработки пира {self.peer_ip}:{self.peer_port}: {e}", exc_info=True)
         finally:
              await self.close()

    async def _read_data(self, n_bytes: int) -> Optional[bytes]:
         """Читает ровно n байт из потока."""
         if not self.reader or self._closing:
             return None
         try:
             data = await asyncio.wait_for(self.reader.readexactly(n_bytes), timeout=READ_TIMEOUT)
             self.last_message_time = time.monotonic() # Обновляем время при получении данных
             return data
         except (asyncio.IncompleteReadError, ConnectionResetError, asyncio.TimeoutError, OSError) as e:
             logger.warning(f"Ошибка чтения {n_bytes} байт от {self.peer_ip}:{self.peer_port}: {e}")
             await self.close() # Закрываем соединение при ошибке чтения
             return None
         except asyncio.CancelledError:
             logger.info(f"Чтение от {self.peer_ip}:{self.peer_port} отменено.")
             await self.close()
             return None

    async def _read_message(self) -> Optional[Dict]:
        """Читает и парсит следующее сообщение от пира."""
        # 1. Читаем длину сообщения (4 байта)
        len_prefix = await self._read_data(4)
        if len_prefix is None:
            return None # Соединение закрыто или ошибка

        msg_len = struct.unpack('>I', len_prefix)[0]

        # 2. Обрабатываем Keep-Alive (длина 0)
        if msg_len == 0:
            logger.debug(f"Получен Keep-Alive от {self.peer_ip}:{self.peer_port}")
            self.last_message_time = time.monotonic() # Обновляем время
            return {'id': -1, 'len': 0} # Специальный ID для Keep-Alive

        # 3. Читаем остальную часть сообщения (ID + payload)
        if msg_len > BLOCK_SIZE * 2: # Защита от слишком больших сообщений
             logger.error(f"Получено слишком большое сообщение ({msg_len} байт) от {self.peer_ip}:{self.peer_port}. Закрытие.")
             await self.close()
             return None

        msg_body = await self._read_data(msg_len)
        if msg_body is None:
            return None # Соединение закрыто или ошибка

        # 4. Парсим ID сообщения и payload
        msg_id = msg_body[0]
        payload = msg_body[1:]

        return {'id': msg_id, 'len': msg_len, 'payload': payload}

    async def handle_message(self, msg: Dict):
        """Обрабатывает сообщение в зависимости от его ID."""
        msg_id = msg['id']
        payload = msg.get('payload')

        if msg_id == 0: # Choke
            logger.debug(f"Получен Choke от {self.peer_ip}:{self.peer_port}")
            self.peer_choking = True
            # TODO: Возможно, стоит отменить запросы, отправленные этому пиру?
            # Но они могут быть выполнены позже, когда пир сделает unchoke.
        elif msg_id == 1: # Unchoke
            logger.debug(f"Получен Unchoke от {self.peer_ip}:{self.peer_port}")
            self.peer_choking = False
            # Теперь можно запрашивать блоки
            await self._request_pieces_if_needed()
        elif msg_id == 2: # Interested
            logger.debug(f"Получен Interested от {self.peer_ip}:{self.peer_port}")
            self.peer_interested = True
            # TODO: Если мы не сид, нужно будет сделать Unchoke этому пиру (логика anti-snubbing/choking)
            # Пока мы только качаем, это не так важно.
        elif msg_id == 3: # Not Interested
            logger.debug(f"Получен Not Interested от {self.peer_ip}:{self.peer_port}")
            self.peer_interested = False
            # TODO: Можно сделать Choke этому пиру, если он был Unchoked
        elif msg_id == 4: # Have
            if payload and len(payload) == 4:
                piece_index = struct.unpack('>I', payload)[0]
                logger.debug(f"Получен Have ({piece_index}) от {self.peer_ip}:{self.peer_port}")

                # Проверяем корректность индекса
                if piece_index >= self.torrent.num_pieces:
                    logger.warning(f"Получен Have с некорректным индексом {piece_index} (всего {self.torrent.num_pieces}) от {self.peer_ip}")
                    return # Игнорируем некорректное сообщение

                # Если bitfield еще не получен, инициализируем его нулями
                if self.bitfield is None:
                    bitfield_len = math.ceil(self.torrent.num_pieces / 8)
                    self.bitfield = bytearray(bitfield_len) # Создаем пустое поле
                    logger.info(f"Инициализировано пустое битовое поле для пира {self.peer_ip}, т.к. Have получен до Bitfield.")

                # Обновляем битовое поле пира (даже если оно было None до этого)
                byte_index = piece_index // 8
                bit_index = 7 - (piece_index % 8)
                if byte_index < len(self.bitfield):
                    self.bitfield[byte_index] |= (1 << bit_index)
                    # Если мы еще не заинтересованы, а кусок нам нужен, отправляем Interested
                    if not self.am_interested and self.piece_manager.piece_status[piece_index] != 2:
                        await self._send_interested()
                else:
                    # Эта ситуация не должна возникать, если мы правильно инициализировали bitfield
                    logger.error(f"Ошибка: Индекс {piece_index} выходит за пределы рассчитанного битового поля {len(self.bitfield)} пира {self.peer_ip}")

            else:
                 logger.warning(f"Получено некорректное Have сообщение от {self.peer_ip}:{self.peer_port}")
        elif msg_id == 5: # Bitfield
             expected_len = math.ceil(self.torrent.num_pieces / 8)
             if payload and len(payload) == expected_len:
                 logger.debug(f"Получен Bitfield (длина {len(payload)}) от {self.peer_ip}:{self.peer_port}")
                 self.bitfield = bytearray(payload) # Сохраняем как изменяемый bytearray
                 # Проверяем, заинтересованы ли мы в этом пире
                 if not self.am_interested:
                     for i in range(self.torrent.num_pieces):
                         if self.piece_manager.piece_status[i] != 2 and self.piece_manager._peer_has_piece(self.bitfield, i):
                             await self._send_interested()
                             break # Одного нужного куска достаточно для интереса
             else:
                  logger.warning(f"Получен Bitfield неверной длины ({len(payload) if payload else 0}, ожидалось {expected_len}) от {self.peer_ip}:{self.peer_port}. Игнорируем.")
                  # Можно закрыть соединение с таким пиром.
                  # await self.close()
        elif msg_id == 6: # Request
             if payload and len(payload) == 12:
                 index, begin, length = struct.unpack('>III', payload)
                 logger.debug(f"Получен Request (Piece: {index}, Begin: {begin}, Length: {length}) от {self.peer_ip}:{self.peer_port}")
                 # TODO: Реализовать логику отдачи (если мы сидир или разрешаем отдачу)
                 # if not self.am_choking and self.peer_interested:
                 #     # Проверить, есть ли у нас этот кусок
                 #     # Прочитать блок с диска
                 #     # Отправить сообщение Piece
                 # else:
                 #     logger.warning(f"Получен Request от {self.peer_ip}, но мы его чокаем или он не заинтересован.")
                 pass # Пока игнорируем запросы
             else:
                 logger.warning(f"Получено некорректное Request сообщение от {self.peer_ip}:{self.peer_port}")
        elif msg_id == 7: # Piece
            if payload and len(payload) >= 8: # Минимум 8 байт (index, begin) + данные
                index, begin = struct.unpack('>II', payload[:8])
                block_data = payload[8:]
                block_len = len(block_data)
                logger.debug(f"Получен Piece (Index: {index}, Begin: {begin}, Length: {block_len}) от {self.peer_ip}:{self.peer_port}")

                # Проверяем валидность индекса и смещения
                if index >= self.torrent.num_pieces:
                    logger.warning(f"Получен блок с неверным индексом {index} от {self.peer_ip}")
                    return
                # Проверка смещения begin не нужна, т.к. add_block_to_piece проверяет границы
                # if begin % BLOCK_SIZE != 0 or begin < 0:
                #     logger.warning(f"Получен блок с неверным смещением {begin} от {self.peer_ip}")
                #     return

                # Уменьшаем счетчик ожидающих запросов (если блок был в pending_blocks)
                if (index, begin) in self.piece_manager.pending_blocks:
                    self.pending_requests = max(0, self.pending_requests - 1)
                else:
                    # Блок мог прийти без запроса (некоторые клиенты так делают)
                    # или после таймаута нашего запроса
                    logger.debug(f"Получен блок ({index}, {begin}), который не был в списке ожидающих от {self.peer_ip}")

                # Передаем блок менеджеру кусков.
                # Он обработает добавление данных, проверку завершения и хэша.
                self.piece_manager.add_block_to_piece(index, begin, block_data)

                # --- Удалена логика проверки завершения куска отсюда --- 

                # Запрашиваем следующий блок, если нужно
                await self._request_pieces_if_needed()

            else:
                 logger.warning(f"Получено некорректное Piece сообщение от {self.peer_ip}:{self.peer_port}")
        elif msg_id == 8: # Cancel
             if payload and len(payload) == 12:
                 index, begin, length = struct.unpack('>III', payload)
                 logger.debug(f"Получен Cancel (Piece: {index}, Begin: {begin}, Length: {length}) от {self.peer_ip}:{self.peer_port}")
                 # TODO: Если мы отдаем куски, нужно отменить отправку этого блока
                 pass # Пока игнорируем
             else:
                 logger.warning(f"Получено некорректное Cancel сообщение от {self.peer_ip}:{self.peer_port}")

        elif msg_id == 9: # Port
             # Используется для DHT, игнорируем
             logger.debug(f"Получен Port от {self.peer_ip}:{self.peer_port}. Игнорируем.")
             pass
        elif msg_id == -1: # Keep-Alive (уже обработан в _read_message)
             pass
        else:
            logger.warning(f"Получено неизвестное сообщение (ID: {msg_id}) от {self.peer_ip}:{self.peer_port}")

    async def _send_message(self, msg_id: Optional[int], payload: bytes = b''):
        """Формирует и отправляет сообщение пиру."""
        if not self.writer or self._closing:
             logger.warning(f"Попытка отправки сообщения закрытому пиру {self.peer_ip}")
             return

        if msg_id is None: # Keep-Alive
             msg = struct.pack('>I', 0)
             logger.debug(f"Отправка Keep-Alive пиру {self.peer_ip}:{self.peer_port}")
        else:
             length = 1 + len(payload) # 1 байт ID + payload
             msg = struct.pack('>IB', length, msg_id) + payload
             logger.debug(f"Отправка сообщения ID {msg_id} (len {length}) пиру {self.peer_ip}:{self.peer_port}")

        try:
            self.writer.write(msg)
            await asyncio.wait_for(self.writer.drain(), timeout=WRITE_TIMEOUT)
        except (asyncio.TimeoutError, ConnectionResetError, OSError) as e:
            logger.warning(f"Ошибка отправки сообщения пиру {self.peer_ip}:{self.peer_port}: {e}")
            await self.close() # Закрываем соединение при ошибке записи
        except asyncio.CancelledError:
             logger.info(f"Отправка пиру {self.peer_ip}:{self.peer_port} отменена.")
             await self.close()

    async def _send_interested(self):
        if not self.am_interested:
             await self._send_message(2) # Interested ID = 2
             self.am_interested = True

    async def _send_not_interested(self):
         if self.am_interested:
             await self._send_message(3) # Not Interested ID = 3
             self.am_interested = False

    async def _send_request(self, piece_index: int, block_offset: int, block_length: int):
         payload = struct.pack('>III', piece_index, block_offset, block_length)
         await self._send_message(6, payload) # Request ID = 6
         self.pending_requests += 1

    async def _send_keep_alive(self):
         await self._send_message(None) # None ID для Keep-Alive

    async def _request_pieces_if_needed(self):
        """Запрашивает блоки, если пир доступен и есть что качать."""
        if self._closing or self.peer_choking or not self.am_interested:
            return # Не можем запрашивать

        while self.pending_requests < MAX_PENDING_REQUESTS:
             # Получаем следующий блок для запроса у этого пира
             # Передаем информацию о текущем пире
             request_info = self.piece_manager.get_next_block_request((self.peer_ip, self.peer_port), self.bitfield)
             if request_info:
                 piece_idx, block_offset, block_length = request_info
                 logger.debug(f"Запрос блока: Кусок {piece_idx}, Смещение {block_offset}, Длина {block_length} у пира {self.peer_ip}")
                 await self._send_request(piece_idx, block_offset, block_length)
             else:
                 # Нет доступных блоков для запроса у этого пира прямо сейчас
                 break # Выходим из цикла запросов


    async def close(self):
        """Закрывает соединение с пиром и очищает его зависшие запросы."""
        if not self._closing:
             self._closing = True
             peer_addr = (self.peer_ip, self.peer_port)
             logger.info(f"Закрытие соединения с пиром {peer_addr}")

             # Закрываем writer/reader
             self._connected = False
             if self.writer:
                 try:
                     self.writer.close()
                     await self.writer.wait_closed()
                 except (ConnectionResetError, BrokenPipeError, OSError):
                     pass # Сокет мог уже быть закрыт
                 except Exception as e:
                     logger.warning(f"Ошибка при закрытии writer для {peer_addr}: {e}")
             self.reader = None
             self.writer = None

             # Очищаем ожидающие блоки, которые были запрошены у этого пира
             if self.piece_manager:
                 blocks_to_remove = []
                 pieces_to_requeue = set()
                 # Итерируем по копии ключей, т.к. словарь может меняться
                 for block_key, (req_time, req_peer_info) in list(self.piece_manager.pending_blocks.items()):
                     if req_peer_info == peer_addr:
                         blocks_to_remove.append(block_key)
                         piece_idx = block_key[0]
                         # Если кусок был в процессе скачивания, помечаем его для возврата в очередь
                         if self.piece_manager.piece_status[piece_idx] == 1:
                              pieces_to_requeue.add(piece_idx)

                 if blocks_to_remove:
                     logger.info(f"Удаляем {len(blocks_to_remove)} зависших запросов блока для закрытого пира {peer_addr}.")
                     for block_key in blocks_to_remove:
                         # Доп. проверка, что ключ все еще существует (на случай гонки потоков, хотя ее не должно быть с asyncio)
                         if block_key in self.piece_manager.pending_blocks:
                            del self.piece_manager.pending_blocks[block_key]

                 # Возвращаем затронутые куски в очередь недостающих
                 if pieces_to_requeue:
                      logger.info(f"Возвращаем куски {list(pieces_to_requeue)} в очередь из-за закрытия пира {peer_addr}.")
                      for piece_idx in pieces_to_requeue:
                           # Сбрасываем статус и данные, только если кусок не был завершен (статус 2)
                           if self.piece_manager.piece_status[piece_idx] != 2:
                                self.piece_manager.piece_status[piece_idx] = 0
                                self.piece_manager.pieces_data[piece_idx] = None
                                self.piece_manager.piece_received_bytes[piece_idx] = 0
                                if piece_idx not in self.piece_manager.missing_pieces:
                                     self.piece_manager.missing_pieces.append(piece_idx)


# --- Клиент ---
class TorrentClient:
    def __init__(self, torrent_path: str):
        self.torrent_path = torrent_path
        self.torrent: Optional[Torrent] = None
        self.piece_manager: Optional[PieceManager] = None
        self.peer_id: bytes = self._generate_peer_id()
        self.peers: List[Tuple[str, int]] = []
        self.active_peer_connections: Dict[Tuple[str, int], PeerConnection] = {}
        self.writer_queue = asyncio.Queue() # Очередь для записи на диск
        self.port = 6881 # Порт, который мы анонсируем трекеру (пока статичный)
        self._running = False
        self._tracker_task: Optional[asyncio.Task] = None # Теперь это будет Task
        self._peer_tasks: List[asyncio.Task] = []
        self._status_task: Optional[asyncio.Task] = None
        # self._writer_task: Optional[asyncio.Task] = None

    def _generate_peer_id(self) -> bytes:
        """Генерирует уникальный Peer ID."""
        rand_bytes = bytes(''.join(random.choice('0123456789abcdefghijklmnopqrstuvwxyz') for _ in range(12)), 'ascii')
        return PEER_ID_PREFIX + rand_bytes

    async def load_torrent(self):
        """Загружает и парсит торрент-файл."""
        try:
            with open(self.torrent_path, 'rb') as f:
                torrent_data = f.read()
            metadata = bdecode(torrent_data)
            self.torrent = Torrent(metadata)
            self.piece_manager = PieceManager(self.torrent)
            return True
        except FileNotFoundError:
            logger.error(f"Ошибка: Торрент-файл не найден по пути {self.torrent_path}")
            return False
        except ValueError as e:
             logger.error(f"Ошибка парсинга торрент-файла или метаданных: {e}")
             return False
        except Exception as e:
            logger.error(f"Неожиданная ошибка при загрузке торрента: {e}", exc_info=True)
            return False

    async def contact_tracker(self, first_call=False) -> Tuple[List[Tuple[str, int]], int]:
        """
        Отправляет запрос трекеру и получает список пиров и интервал.

        Returns:
            Кортеж (список пиров, интервал опроса в секундах).
            Возвращает пустой список и дефолтный интервал при ошибке.
        """
        default_interval = 1800 # 30 минут по умолчанию
        if not self.torrent or not self.piece_manager:
             logger.error("Торрент не загружен, невозможно связаться с трекером.")
             return [], default_interval

        params = {
            'info_hash': self.torrent.info_hash,
            'peer_id': self.peer_id,
            'port': self.port,
            'uploaded': 0, # TODO: Обновлять статистику
            'downloaded': self.piece_manager.downloaded_bytes,
            'left': max(0, self.torrent.total_size - self.piece_manager.downloaded_bytes), # left не может быть < 0
            'compact': 1, # Запрашиваем компактный список пиров
            'numwant': 50, # Сколько пиров мы хотим получить
            # 'event' должен быть только 'started', 'stopped', 'completed'
            # Не отправляем 'event' при периодических запросах
            # 'event': 'started' if first_call else ('completed' if self.piece_manager.is_complete() else None)
             'event': 'started' if first_call else None
        }
        # Указываем event=completed один раз при завершении
        # if self.piece_manager.is_complete() and not hasattr(self, '_completed_event_sent'):
        #     params['event'] = 'completed'
        #     self._completed_event_sent = True # Флаг, что отправили

        # Указываем event=stopped при остановке клиента (в методе stop)

        params = {k: v for k, v in params.items() if v is not None}

        tracker_url = self.torrent.tracker_url
        full_url = tracker_url + ('?' if '?' not in tracker_url else '&') + urllib.parse.urlencode(params, doseq=True, quote_via=urllib.parse.quote)

        logger.info(f"Запрос к трекеру: {tracker_url}...")
        # logger.debug(f"Полный URL запроса к трекеру: {full_url}") # Отладка

        try:
            async with aiohttp.ClientSession() as session:
                 async with session.get(full_url, timeout=15) as response:
                     if response.status != 200:
                         logger.error(f"Ошибка от трекера {tracker_url}: Статус {response.status}, Ответ: {await response.text()}")
                         return [], default_interval # Возвращаем дефолтный интервал

                     tracker_response_data = await response.read()
                     logger.debug("Ответ от трекера получен.")

            tracker_response = bdecode(tracker_response_data)

            if b'failure reason' in tracker_response:
                failure = tracker_response[b'failure reason'].decode('utf-8', errors='ignore')
                logger.error(f"Трекер вернул ошибку: {failure}")
                return [], default_interval

            peers_data = tracker_response.get(b'peers')
            if not peers_data:
                 logger.warning("Трекер не вернул список пиров.")
                 # Некоторые трекеры могут не возвращать пиров, но вернуть интервал
                 interval = tracker_response.get(b'interval', default_interval)
                 return [], interval

            peers_list = []
            if isinstance(peers_data, bytes): # Компактный формат
                 if len(peers_data) % 6 != 0:
                     logger.error("Некорректная длина компактного списка пиров.")
                     # Не можем доверять такому ответу, используем дефолтный интервал
                     return [], default_interval
                 for i in range(0, len(peers_data), 6):
                      ip_bytes = peers_data[i:i+4]
                      port_bytes = peers_data[i+4:i+6]
                      ip = socket.inet_ntoa(ip_bytes)
                      port = struct.unpack('>H', port_bytes)[0]
                      if port != 0:
                          peers_list.append((ip, port))

            elif isinstance(peers_data, list): # Словарь-формат
                 for peer_dict in peers_data:
                      ip = peer_dict.get(b'ip').decode('utf-8', errors='ignore')
                      port = peer_dict.get(b'port')
                      if ip and port and isinstance(port, int) and port != 0:
                           peers_list.append((ip, port))
            else:
                 logger.error(f"Неизвестный формат списка пиров: {type(peers_data)}")
                 return [], default_interval

            interval = tracker_response.get(b'interval', default_interval)
            logger.info(f"Получено {len(peers_list)} пиров от трекера. Следующий анонс через {interval} сек.")

            return peers_list, interval

        except aiohttp.ClientError as e:
            logger.error(f"Ошибка HTTP при запросе к трекеру {tracker_url}: {e}")
            # Возвращаем пустой список и увеличенный интервал для повтора
            return [], 600 # Повтор через 10 минут при ошибке сети
        except ValueError as e:
             logger.error(f"Ошибка декодирования ответа трекера: {e}")
             return [], default_interval
        except Exception as e:
            logger.error(f"Неожиданная ошибка при общении с трекером {tracker_url}: {e}", exc_info=True)
            return [], default_interval

    # УДАЛЕНО: async def contact_tracker_periodically(self, interval: int):
    # Эта логика перенесена в _run_tracker_loop

    async def _run_tracker_loop(self):
        """Основной цикл периодического опроса трекера."""
        first = True
        interval = 30 # Начнем с короткого интервала для первого запроса
        while self._running:
            try:
                # Пауза *перед* запросом (кроме первого раза)
                if not first:
                    await asyncio.sleep(interval)
                else:
                     # Небольшая пауза перед самым первым запросом, чтобы клиент успел инициализироваться
                     await asyncio.sleep(0.1)

                if not self._running: break # Проверяем еще раз после sleep

                logger.info("Начинаем опрос трекера...")
                new_peers, interval = await self.contact_tracker(first_call=first)
                first = False

                if new_peers:
                    # Добавляем только уникальных пиров, которых еще нет в активных соединениях
                    added_count = 0
                    current_active_peers = set(self.active_peer_connections.keys())
                    for p in new_peers:
                        if p not in current_active_peers and p not in self.peers:
                            self.peers.append(p)
                            added_count += 1
                    if added_count > 0:
                        logger.info(f"Добавлено {added_count} новых уникальных пиров в очередь.")
                    # Ограничим размер очереди self.peers, чтобы не хранить слишком много
                    MAX_PEER_QUEUE_SIZE = 300
                    if len(self.peers) > MAX_PEER_QUEUE_SIZE:
                         self.peers = self.peers[-MAX_PEER_QUEUE_SIZE:] # Оставляем последних

                # Устанавливаем минимальный интервал (например, 5 минут)
                interval = max(interval, 300)
                logger.info(f"Следующий опрос трекера через {interval} секунд.")

            except asyncio.CancelledError:
                logger.info("Цикл опроса трекера отменен.")
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле опроса трекера: {e}", exc_info=True)
                # Увеличиваем интервал при ошибке, чтобы не спамить трекер
                interval = max(interval * 2, 600) # Удваиваем, минимум 10 минут
                logger.info(f"Повторная попытка опроса трекера через {interval} секунд.")
                first = False # Считаем, что первая попытка была, хоть и неудачная

    async def _manage_peer_connections(self):
        """Поддерживает пул активных соединений с пирами."""
        while self._running:
            # 1. Убираем завершенные/закрытые соединения
            closed_peers = []
            for peer_addr, connection in list(self.active_peer_connections.items()):
                if connection._closing or not connection._connected:
                     closed_peers.append(peer_addr)
            for peer_addr in closed_peers:
                if peer_addr in self.active_peer_connections: # Доп. проверка
                    del self.active_peer_connections[peer_addr]
                    logger.info(f"Соединение с пиром {peer_addr} удалено из активных.")

            # Обновляем список активных тасков пиров
            # (Убираем завершенные таски)
            finished_tasks = []
            for task in self._peer_tasks:
                if task.done():
                    finished_tasks.append(task)
                    try:
                        task.result() # Проверяем наличие исключений в завершенных задачах
                    except asyncio.CancelledError:
                        pass # Ожидаемая отмена
                    except Exception as e:
                        logger.warning(f"Таск пира завершился с ошибкой: {e}", exc_info=True) # Логируем unexpected ошибки
            self._peer_tasks = [task for task in self._peer_tasks if task not in finished_tasks]


            # 2. Добавляем новые соединения, если есть свободные слоты
            needed = MAX_PEER_CONNECTIONS - len(self.active_peer_connections)
            if needed > 0 and self.peers:
                 peers_to_try = []
                 # Берем пиров из начала списка, пока он не опустеет или не наберем нужное кол-во
                 while needed > 0 and self.peers:
                      peer_addr = self.peers.pop(0) # Берем и удаляем первого
                      if peer_addr not in self.active_peer_connections:
                          peers_to_try.append(peer_addr)
                          needed -= 1

                 connect_tasks = []
                 for peer_addr in peers_to_try:
                      # Создаем таск для асинхронного подключения и запуска пира
                      connect_tasks.append(asyncio.create_task(self._connect_and_run_peer(peer_addr)))

                 if connect_tasks:
                     # Ждем завершения попыток подключения (не обязательно, но можно)
                     # await asyncio.wait(connect_tasks, timeout=CONNECT_TIMEOUT + 1)
                     # Задачи пиров будут добавлены в self._peer_tasks внутри _connect_and_run_peer
                     pass

            # 3. Логика запроса у трекера при малом кол-ве пиров удалена,
            # так как этим теперь занимается _run_tracker_loop

            # Пауза перед следующей проверкой
            await asyncio.sleep(5) # Проверяем каждые 5 секунд

    async def _connect_and_run_peer(self, peer_addr):
         """Попытка подключения к пиру и запуск его обработки."""
         if peer_addr in self.active_peer_connections or not self._running:
              return # Уже подключен или клиент останавливается

         logger.info(f"Попытка установить новое соединение с пиром {peer_addr}")
         try:
              peer = PeerConnection(peer_addr, self.torrent, self.piece_manager, self.peer_id, self.torrent.info_hash, self.writer_queue)
              connected = await peer.connect()
              if connected and self._running: # Проверяем self._running еще раз
                   self.active_peer_connections[peer_addr] = peer
                   task = asyncio.create_task(peer.run())
                   self._peer_tasks.append(task)
                   logger.debug(f"Таск для пира {peer_addr} создан и добавлен.")
              # else: # Если не удалось подключиться или клиент остановлен
              #     logger.info(f"Не удалось подключиться к {peer_addr} или клиент остановлен.")
              #     # Не добавляем пира обратно в очередь self.peers, т.к. трекер даст новых
         except Exception as e:
              logger.error(f"Ошибка при подключении/запуске пира {peer_addr}: {e}", exc_info=True)


    async def _status_reporter(self):
         """Периодически выводит статус загрузки."""
         start_time = time.time()
         last_downloaded = 0
         while self._running:
             await asyncio.sleep(10) # Отчет каждые 10 секунд
             if not self.piece_manager or not self.torrent or not self._running: continue # Доп проверка _running

             downloaded, total, progress = self.piece_manager.get_download_progress()
             elapsed_time = time.time() - start_time
             current_speed = (downloaded - last_downloaded) / 10 # Байт в секунду за последние 10 сек
             avg_speed = downloaded / elapsed_time if elapsed_time > 0 else 0

             # Считаем активных пиров (тех, кто нас не чокает и заинтересован)
             # Это очень упрощенно, лучше считать пиров, от которых реально идут данные
             active_downloading_peers = sum(1 for p in self.active_peer_connections.values() if not p.peer_choking and p.am_interested)

             logger.info(
                 f"Прогресс: {progress:.2f}% ({downloaded/1024/1024:.2f}/{total/1024/1024:.2f} MB) | "
                 f"Пиры: {len(self.active_peer_connections)} ({active_downloading_peers} активных) / {len(self.peers)} в очереди | "
                 f"Куски: {self.torrent.num_pieces - len(self.piece_manager.missing_pieces)}/{self.torrent.num_pieces} | "
                 f"Скорость: {current_speed / 1024:.1f} KB/s (Avg: {avg_speed / 1024:.1f} KB/s)"
             )
             last_downloaded = downloaded

             if self.piece_manager.is_complete():
                 logger.info("Загрузка завершена!")
                 await self._notify_tracker_completed() # Уведомим трекер о завершении
                 self._running = False # Останавливаем клиент
                 break # Выходим из цикла статуса


    # async def _disk_writer(self): ... (остается без изменений)

    async def _notify_tracker_completed(self):
        """Отправляет сообщение 'completed' трекеру."""
        if not self.torrent or not self.piece_manager: return
        logger.info("Уведомление трекера о завершении загрузки...")
        params = {
            'info_hash': self.torrent.info_hash,
            'peer_id': self.peer_id,
            'port': self.port,
            'uploaded': 0, # TODO
            'downloaded': self.piece_manager.downloaded_bytes, # Отправляем финальное значение
            'left': 0,
            'compact': 1,
            'event': 'completed'
        }
        params = {k: v for k, v in params.items() if v is not None}
        tracker_url = self.torrent.tracker_url
        full_url = tracker_url + ('?' if '?' not in tracker_url else '&') + urllib.parse.urlencode(params, doseq=True, quote_via=urllib.parse.quote)

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(full_url, timeout=10) as response:
                    if response.status != 200:
                        logger.warning(f"Не удалось уведомить трекер {tracker_url} о завершении: Статус {response.status}")
                    else:
                        logger.info("Трекер уведомлен о завершении.")
        except Exception as e:
            logger.warning(f"Ошибка при уведомлении трекера о завершении: {e}")


    async def _notify_tracker_stopped(self):
         """Отправляет сообщение 'stopped' трекеру."""
         if not self.torrent or not self.piece_manager: return
         logger.info("Уведомление трекера об остановке клиента...")
         params = {
             'info_hash': self.torrent.info_hash,
             'peer_id': self.peer_id,
             'port': self.port,
             'uploaded': 0, # TODO
             'downloaded': self.piece_manager.downloaded_bytes, # Отправляем финальное значение
             'left': max(0, self.torrent.total_size - self.piece_manager.get_download_progress()[0]), # Отправляем актуальное значение left
             'compact': 1,
             'event': 'stopped'
         }
         params = {k: v for k, v in params.items() if v is not None}
         tracker_url = self.torrent.tracker_url
         full_url = tracker_url + ('?' if '?' not in tracker_url else '&') + urllib.parse.urlencode(params, doseq=True, quote_via=urllib.parse.quote)

         try:
             # Используем send_beacon если возможно, иначе обычный get/post
             # Но для простоты оставим get с малым таймаутом
             async with aiohttp.ClientSession() as session:
                 async with session.get(full_url, timeout=5) as response:
                     if response.status != 200:
                         logger.warning(f"Не удалось уведомить трекер {tracker_url} об остановке: Статус {response.status}")
                     else:
                         logger.info("Трекер уведомлен об остановке.")
         except Exception as e:
             logger.warning(f"Ошибка при уведомлении трекера об остановке: {e}")


    async def start(self):
        """Запускает клиент."""
        if not await self.load_torrent():
            return

        logger.info(f"Клиент запущен с Peer ID: {self.peer_id.hex()}")
        self._running = True

        # Запускаем задачи
        self._tracker_task = asyncio.create_task(self._run_tracker_loop()) # Запускаем цикл трекера
        self._status_task = asyncio.create_task(self._status_reporter())
        # self._writer_task = asyncio.create_task(self._disk_writer())

        # Основной цикл управления соединениями
        manage_peers_task = asyncio.create_task(self._manage_peer_connections())

        try:
            # Ожидаем завершения основных задач
            done, pending = await asyncio.wait(
                 [manage_peers_task, self._tracker_task, self._status_task],
                 return_when=asyncio.FIRST_COMPLETED,
            )
            # Если _manage_peer_connections завершился (например, из-за ошибки),
            # или статус репортер завершился (загрузка окончена), останавливаем все
            logger.info("Одна из основных задач завершилась, инициируем остановку.")

        except asyncio.CancelledError:
             logger.info("Основная задача ожидания отменена.")
        finally:
             await self.stop()


    async def stop(self):
        """Останавливает клиент и закрывает соединения."""
        if not hasattr(self, '_running') or not self._running: return # Предотвращаем повторный вызов
        logger.info("Остановка клиента...")
        self._running = False # Сигнал для всех циклов остановиться

        # 1. Уведомляем трекер об остановке (делаем это до отмены задач)
        await self._notify_tracker_stopped()

        # 2. Отменяем основные задачи
        tasks_to_cancel = []
        if self._tracker_task and not self._tracker_task.done():
             tasks_to_cancel.append(self._tracker_task)
        if self._status_task and not self._status_task.done():
            tasks_to_cancel.append(self._status_task)
        # Таск manage_peers должен быть отменен внешним событием (например, завершением загрузки или KeyboardInterrupt)
        # Если он еще работает, его тоже можно отменить, но это может быть излишне
        # current_tasks = asyncio.all_tasks()
        # for task in current_tasks:
        #      # Найдем manage_peers_task по имени или другим способом, если нужно
        #      pass

        if tasks_to_cancel:
             logger.info(f"Отмена {len(tasks_to_cancel)} основных задач...")
             for task in tasks_to_cancel:
                  task.cancel()
             await asyncio.wait(tasks_to_cancel, timeout=2, return_when=asyncio.ALL_COMPLETED)
             logger.info("Основные задачи отменены.")


        # 3. Закрываем соединения с пирами
        logger.info(f"Закрытие {len(self.active_peer_connections)} активных соединений...")
        close_tasks = []
        # Создаем копию словаря перед итерацией, т.к. close может его изменить
        peers_to_close = list(self.active_peer_connections.values())
        for peer in peers_to_close:
             # Используем create_task, чтобы закрытие шло параллельно
             close_tasks.append(asyncio.create_task(peer.close()))
        if close_tasks:
             # Даем время на корректное закрытие
             done, pending = await asyncio.wait(close_tasks, timeout=5)
             if pending:
                  logger.warning(f"{len(pending)} соединений с пирами не закрылись за 5 сек.")
                  for task in pending:
                      task.cancel() # Принудительно отменяем зависшие

        # 4. Отменяем оставшиеся таски пиров (если они не завершились после close)
        peer_tasks_to_cancel = [task for task in self._peer_tasks if not task.done()]
        if peer_tasks_to_cancel:
             logger.info(f"Отмена {len(peer_tasks_to_cancel)} оставшихся задач пиров...")
             for task in peer_tasks_to_cancel:
                  task.cancel()
             await asyncio.wait(peer_tasks_to_cancel, timeout=2, return_when=asyncio.ALL_COMPLETED)
             logger.info("Задачи пиров отменены.")


        # 5. Закрываем файлы
        if self.piece_manager:
            self.piece_manager.close_files()

        logger.info("Клиент остановлен.")


# --- Точка входа ---
async def main():
    # Путь к вашему торрент-файлу
    # Убедитесь, что путь указан правильно
    torrent_file_path = os.path.join('torrent', 'NCHE.tar.xz-ed850f8818acdd85c6da7051d1976fac5f4b2d30.torrent')
    # Проверяем существование файла перед созданием клиента
    if not os.path.exists(torrent_file_path):
         # Попробуем абсолютный путь из задания, если относительный не сработал
         abs_torrent_path = r'C:\Users\Максим\Python\pzrp\LR3\torrent\library.torrent'
         if os.path.exists(abs_torrent_path):
              torrent_file_path = abs_torrent_path
         else:
              logger.error(f"Торрент-файл не найден ни по относительному пути '{torrent_file_path}', ни по абсолютному '{abs_torrent_path}'")
              return

    logger.info(f"Используется торрент-файл: {torrent_file_path}")

    client = TorrentClient(torrent_file_path)
    try:
        await client.start()
    except KeyboardInterrupt:
        logger.info("Получен сигнал KeyboardInterrupt. Завершение работы...")
    except Exception as e:
         logger.critical(f"Критическая ошибка в главном потоке: {e}", exc_info=True)
    finally:
        await client.stop()

if __name__ == "__main__":
    # В Windows может потребоваться выбрать правильный event loop policy
    # if os.name == 'nt':
    #      asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    try:
         asyncio.run(main())
    except KeyboardInterrupt:
         logger.info("Программа прервана пользователем.")
    except Exception as e:
         logger.critical(f"Критическая ошибка в главном потоке: {e}", exc_info=True)