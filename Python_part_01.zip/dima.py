import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

def create_sports_ground_plan():
    fig, ax = plt.subplots(figsize=(16, 10)) # Увеличим размер для лучшей детализации

    # Общие размеры площадки
    ground_width = 100  # метры
    ground_height = 60  # метры

    # 0. Основная территория
    ground = patches.Rectangle((0, 0), ground_width, ground_height, linewidth=2, edgecolor='black', facecolor='#ABEBC6', label='Общая территория') # Светло-зеленый
    ax.add_patch(ground)

    # 1. Футбольное поле (мини-футбол)
    fp_width = 40
    fp_height = 20
    fp_x = (ground_width - fp_width) / 2  # Центрируем
    fp_y = ground_height - fp_height - 5   # В верхней части
    football_pitch = patches.Rectangle((fp_x, fp_y), fp_width, fp_height, linewidth=1.5, edgecolor='white', facecolor='#2ECC71', label='Футбольное поле') # Насыщенный зеленый
    ax.add_patch(football_pitch)
    # Разметка футбольного поля (упрощенная)
    center_circle = patches.Circle((fp_x + fp_width / 2, fp_y + fp_height / 2), radius=fp_height / 4, edgecolor='white', facecolor='none', linewidth=1)
    ax.add_patch(center_circle)
    center_line = plt.Line2D([fp_x + fp_width / 2, fp_x + fp_width / 2], [fp_y, fp_y + fp_height], color='white', linewidth=1)
    ax.add_artist(center_line)
    # Ворота (условно)
    goal_1 = patches.Rectangle((fp_x - 1, fp_y + fp_height/2 - 3), 1, 6, edgecolor='white', facecolor='grey', linewidth=1)
    goal_2 = patches.Rectangle((fp_x + fp_width, fp_y + fp_height/2 - 3), 1, 6, edgecolor='white', facecolor='grey', linewidth=1)
    ax.add_patch(goal_1)
    ax.add_patch(goal_2)
    ax.text(fp_x + fp_width / 2, fp_y + fp_height + 1, 'Футбольное поле', ha='center', va='bottom', fontsize=9)


    # 2. Универсальная площадка (баскетбол/волейбол)
    mp_width = 28
    mp_height = 15
    mp_x = 10
    mp_y = 10 # В нижней левой части
    multipurpose_court = patches.Rectangle((mp_x, mp_y), mp_width, mp_height, linewidth=1.5, edgecolor='#3498DB', facecolor='#AED6F1', label='Универсальная площадка') # Голубой
    ax.add_patch(multipurpose_court)
    # Условные баскетбольные щиты
    hoop_1 = patches.Circle((mp_x + 2, mp_y + mp_height / 2), radius=0.5, color='#E74C3C')
    hoop_2 = patches.Circle((mp_x + mp_width - 2, mp_y + mp_height / 2), radius=0.5, color='#E74C3C')
    ax.add_patch(hoop_1)
    ax.add_patch(hoop_2)
    ax.text(mp_x + mp_width / 2, mp_y - 2, 'Универсальная площадка', ha='center', va='top', fontsize=9)


    # 3. Зона воркаута
    wo_size = 12
    wo_x = mp_x + mp_width + 10
    wo_y = 10 # Рядом с универсальной площадкой
    workout_area = patches.Rectangle((wo_x, wo_y), wo_size, wo_size, linewidth=1.5, edgecolor='#7F8C8D', facecolor='#D5DBDB', label='Зона воркаута') # Серый
    ax.add_patch(workout_area)
    # Условные тренажеры (маленькие прямоугольники)
    for i in range(3):
        bar = patches.Rectangle((wo_x + 2 + i*3, wo_y + 2), 1, 3, facecolor='#566573')
        ax.add_patch(bar)
    ax.text(wo_x + wo_size / 2, wo_y - 2, 'Зона воркаута', ha='center', va='top', fontsize=9)

    # 4. Беговые дорожки (прямой участок)
    track_length = ground_height - 2 * 5 # Отступы сверху и снизу
    track_width = 8 # 4 дорожки по 2м (условно)
    track_x = ground_width - track_width - 5 # Справа
    track_y = 5
    running_track_bg = patches.Rectangle((track_x, track_y), track_width, track_length, linewidth=1.5, edgecolor='#E74C3C', facecolor='#F5B7B1', label='Беговые дорожки') # Красноватый
    ax.add_patch(running_track_bg)
    for i in range(1, 4): # Линии разметки
        lane_line = plt.Line2D([track_x + i*(track_width/4), track_x + i*(track_width/4)], [track_y, track_y + track_length], color='white', linestyle='--', linewidth=0.8)
        ax.add_artist(lane_line)
    ax.text(track_x + track_width / 2, track_y - 2, 'Беговые дорожки', ha='center', va='top', fontsize=9)

    # 5. Основные дорожки (упрощенно)
    path_width = 2
    # Путь от входа (снизу-центр) к площадкам
    main_path_1 = patches.Rectangle(((ground_width/2 - path_width/2), 0), path_width, mp_y, facecolor='#FAD7A0', edgecolor='#DC7633', linewidth=1)
    ax.add_patch(main_path_1)
    # Горизонтальный путь
    main_path_2 = patches.Rectangle((mp_x + mp_width, mp_y + mp_height/2 - path_width/2), wo_x - (mp_x+mp_width), path_width, facecolor='#FAD7A0', edgecolor='#DC7633', linewidth=1)
    ax.add_patch(main_path_2)
    main_path_3 = patches.Rectangle((0, mp_y + mp_height + 2), ground_width - track_width - 5 -0, path_width, facecolor='#FAD7A0', edgecolor='#DC7633', linewidth=1, label='Пешеходные дорожки')
    ax.add_patch(main_path_3)


    # 6. Зоны озеленения (условно)
    # Деревья (круги)
    tree_radius = 1.5
    tree_positions = [
        (5, ground_height - 5), (10, ground_height - 8), (5, 5), (10, 8),
        (ground_width - 5, 5), (ground_width - 10, 8),
        (fp_x - 5, fp_y + fp_height / 2), (fp_x + fp_width + 5, fp_y + fp_height / 2),
        (mp_x - 3, mp_y + mp_height/2), (wo_x + wo_size + 3, wo_y + wo_size/2)
    ]
    for i, pos in enumerate(tree_positions):
        label = 'Деревья' if i == 0 else None # Метка только для первого дерева
        tree = patches.Circle(pos, tree_radius, facecolor='#229954', edgecolor='#1E8449', label=label)
        ax.add_patch(tree)

    # Кустарники/цветники (прямоугольники/полигоны)
    shrubs_1 = patches.Rectangle((0, ground_height - 3), ground_width, 3, facecolor='#58D68D', edgecolor='none', label='Кустарники/Газоны') # Верхняя полоса
    ax.add_patch(shrubs_1)
    shrubs_2 = patches.Rectangle((0, 0), 3, ground_height, facecolor='#58D68D', edgecolor='none') # Левая полоса
    ax.add_patch(shrubs_2)


    # Настройка осей и заголовка
    ax.set_xlim(-5, ground_width + 5)
    ax.set_ylim(-5, ground_height + 5)
    ax.set_aspect('equal', adjustable='box')
    plt.title('Детализированный План Спортивной Площадки (100м x 60м)', fontsize=16)
    plt.xlabel('Ширина (м)', fontsize=12)
    plt.ylabel('Длина (м)', fontsize=12)
    ax.grid(True, linestyle=':', alpha=0.5)

    # Легенда (может быть много элементов, разместим сбоку)
    handles, labels = ax.get_legend_handles_labels()
    # Фильтруем дубликаты для легенды
    by_label = dict(zip(labels, handles))
    ax.legend(by_label.values(), by_label.keys(), loc='center left', bbox_to_anchor=(1, 0.5), fontsize=9)
    plt.tight_layout(rect=[0, 0, 0.85, 1]) # Оставляем место для легенды

    plt.show()

if __name__ == '__main__':
    create_sports_ground_plan()
