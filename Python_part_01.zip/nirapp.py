from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
import json

app = Flask(__name__)

def create_connection():
    return psycopg2.connect(
        host='localhost',
        database='dorogi_2024',
        user='postgres',
        password='Rk.rdtyysqvjhc98'
    )

@app.route('/route', methods=['POST'])
def find_route():
    data = request.get_json()
    start_point = data['start_point']
    end_point = data['end_point']

    conn = create_connection()
    start_vertex = get_nearest_vertex(start_point[0], start_point[1], conn)
    end_vertex = get_nearest_vertex(end_point[0], end_point[1], conn)

    route, total_cost = calculate_route(start_vertex, end_vertex, conn)
    conn.close()

    return jsonify({
        'route': route,  # Маршрут с геометрией и стоимостью каждого ребра
        'total_cost': total_cost  # Общая стоимость маршрута
    })

def get_nearest_vertex(lat, lon, conn):
    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        query = f"""
        SELECT id, ST_Distance(the_geom, ST_SetSRID(ST_MakePoint({lon}, {lat}), 4326)) AS distance
        FROM edges_vertices_pgr
        ORDER BY distance
        LIMIT 1;
        """
        cur.execute(query)
        return cur.fetchone()['id']

def calculate_route(start_vertex, end_vertex, conn):
    route = []
    total_cost = 0
    edges_query = """
        SELECT seq, di.node, di.edge, e.weight AS cost, ST_AsGeoJSON(e.geometry) as geom
        FROM pgr_dijkstra(
            'SELECT id, source, target, weight AS cost FROM edges',
            %s, %s, directed := true
        ) as di
        JOIN edges e ON di.edge = e.id
    """
    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(edges_query, (start_vertex, end_vertex))
        route_segments = cur.fetchall()

        for segment in route_segments:
            if segment['edge'] is not None and segment['edge'] > 0:  # Убедитесь, что ID ребра валиден
                edge_data = {
                    'id': segment['edge'],
                    'cost': segment['cost'],
                    'geometry': json.loads(segment['geom'])
                }
                route.append(edge_data)
                total_cost += segment['cost']

    return route, total_cost


    return route, total_cost
if __name__ == '__main__':
    app.run(debug=True)