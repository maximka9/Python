import nextcord
import random
import string
import json
import os
import time
from nextcord.ui import Button, View, Select, Modal, TextInput
from nextcord import Interaction, SlashOption
from nextcord.ext import commands, tasks


intents = nextcord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True


MODERATOR_ROLE = ["event-менеджер", "support", "DS Support"]
sessions = {}
moderator_lobbies = {}
BANS_FILE = "global_bans.json"
TARGET_CATEGORY_ID = 1373002617105678456

AFK_TIMEOUT_SECONDS = 180

GAME_POSITIONS = {
    "DOTA2": ["Carry", "Mid", "Offlane", "Soft Sup", "Hard Sup"],
    "CS2": ["Entry", "AWP", "Support", "Lurker", "IGL"],
    "VALORANT": ["Duelist", "Initiator", "Controller", "Sentinel", "Flex"]
}


def has_any_role(*role_names):
    async def predicate(ctx):
        if not ctx.guild:
            return False
        return any(role.name in role_names for role in ctx.author.roles)
    return commands.check(predicate)


# ---------- Data Handling ----------
def load_bans():
    try:
        if os.path.exists(BANS_FILE):
            with open(BANS_FILE, "r") as f:
                return json.load(f).get('bans', [])
        return []
    except Exception as e:
        print(f"Ошибка загрузки банов: {e}")
        return []

def save_bans(banned_users):
    try:
        data = {'bans': banned_users}
        with open(BANS_FILE, "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Ошибка сохранения банов: {e}")

global_bans = load_bans()


# ---------- Moderation Components ----------
class BanModal(Modal):
    def __init__(self):
        super().__init__(title="Глобальный бан", timeout=300)
        self.user_id = TextInput(
            label="Введите ID пользователя",
            placeholder="123456789012345678",
            required=True
        )
        self.add_item(self.user_id)

    async def callback(self, interaction: Interaction):
        try:
            user_id = int(self.user_id.value)
            if user_id in global_bans:
                await interaction.response.send_message("⚠️ Пользователь уже забанен!", ephemeral=True)
                return

            global_bans.append(user_id)
            save_bans(global_bans)

            for session in sessions.values():
                for team in ["A", "B"]:
                    for i in range(5):
                        if session.teams[team][i] and session.teams[team][i].id == user_id:
                            session.teams[team][i] = None
                            session.registration_times[team][i] = None
                await session.update_registration_messages()

            await interaction.response.send_message(f"✅ Пользователь {user_id} забанен!", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("❌ Неверный формат ID!", ephemeral=True)


class UnbanModal(Modal):
    def __init__(self):
        super().__init__(title="Разбан пользователя", timeout=300)
        self.user_id = TextInput(
            label="Введите ID пользователя",
            placeholder="123456789012345678",
            required=True
        )
        self.add_item(self.user_id)

    async def callback(self, interaction: Interaction):
        try:
            user_id = int(self.user_id.value)
            if user_id not in global_bans:
                await interaction.response.send_message("⚠️ Пользователь не забанен!", ephemeral=True)
                return

            global_bans.remove(user_id)
            save_bans(global_bans)
            await interaction.response.send_message(f"✅ Пользователь {user_id} разбанен!", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("❌ Неверный формат ID!", ephemeral=True)


class ModerationView(View):
    def __init__(self, session_id):
        super().__init__(timeout=300)
        self.session_id = session_id

    @nextcord.ui.button(label="Забанить", style=nextcord.ButtonStyle.danger, emoji="🔨")
    async def ban_button(self, button: Button, interaction: Interaction):
        await interaction.response.send_modal(BanModal())

    @nextcord.ui.button(label="Разбанить", style=nextcord.ButtonStyle.success, emoji="🔓")
    async def unban_button(self, button: Button, interaction: Interaction):
        await interaction.response.send_modal(UnbanModal())


# ---------- Quick Kick Components ----------
class QuickKickButton(Button):
    def __init__(self, session_id, user, team, index, position_name, row_num):
        team_emoji = "🟢" if team == "A" else "🔴"
        super().__init__(
            style=nextcord.ButtonStyle.danger,
            label=f"{position_name}: {user.display_name}",
            emoji=team_emoji,
            row=row_num
        )
        self.session_id = session_id
        self.target_user_id = user.id

    async def callback(self, interaction: Interaction):
        if not any(role.name in MODERATOR_ROLE for role in interaction.user.roles):
            await interaction.response.send_message("❌ Только модераторы могут кикать!", ephemeral=True)
            return

        session = sessions.get(self.session_id)
        if not session:
            await interaction.response.send_message("❌ Лобби не найдено!", ephemeral=True)
            return

        kicked = False
        for team in ["A", "B"]:
            for i in range(5):
                if session.teams[team][i] and session.teams[team][i].id == self.target_user_id:
                    session.teams[team][i] = None
                    session.registration_times[team][i] = None
                    kicked = True

        if kicked:
            session.confirmed_players.discard(self.target_user_id)
            await session.update_registration_messages()
            await interaction.response.defer()
        else:
            await interaction.response.send_message("⚠️ Игрок уже не в лобби!", ephemeral=True)


def build_quick_kick_view(session_id):
    session = sessions.get(session_id)
    view = View(timeout=None)
    if not session:
        return view

    btn_count = 0
    for team in ["A", "B"]:
        for i in range(5):
            user = session.teams[team][i]
            if user:
                row_num = btn_count // 5
                if row_num > 4:
                    break
                view.add_item(QuickKickButton(
                    session_id, user, team, i,
                    session.positions[i], row_num
                ))
                btn_count += 1

    return view


# ---------- Lobby Classes ----------
class GameSelectView(View):
    def __init__(self):
        super().__init__(timeout=30)
        self.selected_game = None

    @nextcord.ui.button(label="CS2", style=nextcord.ButtonStyle.grey, emoji="🔫")
    async def cs_button(self, button: Button, interaction: Interaction):
        await self.handle_selection("CS2", interaction)

    @nextcord.ui.button(label="DOTA2", style=nextcord.ButtonStyle.grey, emoji="⚔️")
    async def dota_button(self, button: Button, interaction: Interaction):
        await self.handle_selection("DOTA2", interaction)

    @nextcord.ui.button(label="VALORANT", style=nextcord.ButtonStyle.grey, emoji="💥")
    async def valorant_button(self, button: Button, interaction: Interaction):
        await self.handle_selection("VALORANT", interaction)

    async def handle_selection(self, game: str, interaction: Interaction):
        self.selected_game = game
        await interaction.response.defer()
        self.stop()


class LobbySession:
    def __init__(self, guild, game, creator_id):
        self.moderator_roles = [role for role in guild.roles if role.name in MODERATOR_ROLE]
        self.id = ''.join(random.choices(string.ascii_uppercase, k=4))
        self.game = game
        self.creator_id = creator_id
        self.game_role_ids = {
            "CS2": 1146447521904865280,
            "DOTA2": 1146447504381067305,
            "VALORANT": 1146447601529520138
        }
        self.positions = GAME_POSITIONS.get(game, [f"Слот {i+1}" for i in range(5)])
        self.teams = {"A": [None] * 5, "B": [None] * 5}
        self.registration_times = {"A": [None] * 5, "B": [None] * 5}
        self.confirmed_players = set()
        self.category = None
        self.created_channels = []
        self.reg_channel = None
        self.waiting_channel = None
        self.spectator_channel = None
        self.registration_message = None
        self.kick_message = None
        self.waiting_message = None

    async def update_registration_messages(self):
        role_id = self.game_role_ids.get(self.game)
        role_mention = f"<@&{role_id}>" if role_id else ""

        embed = nextcord.Embed(
            title=f"🎮 {self.game} Лобби | Код: `{self.id}`",
            color=0x00ff00,
            description=f"**Составы команд:**\nУчастники: {role_mention}\n"
        )

        team_a = "\n".join([
            f"**{self.positions[i]}:** {u.mention if u else '▫️ Свободно'}"
            for i, u in enumerate(self.teams['A'])
        ])
        team_b = "\n".join([
            f"**{self.positions[i]}:** {u.mention if u else '▫️ Свободно'}"
            for i, u in enumerate(self.teams['B'])
        ])

        embed.add_field(name="🍀 Команда A", value=team_a, inline=True)
        embed.add_field(name="🩸 Команда B", value=team_b, inline=True)
        embed.set_footer(text="Нажмите кнопку для выбора позиции")

        try:
            if self.registration_message:
                await self.registration_message.edit(embed=embed, view=RegistrationView(self.id))

            if self.waiting_channel:
                if not self.waiting_message:
                    self.waiting_message = await self.waiting_channel.send(embed=embed)
                else:
                    await self.waiting_message.edit(embed=embed)
        except Exception as e:
            print(f"Ошибка обновления сообщений: {e}")

        has_players = any(
            self.teams[t][i] is not None
            for t in ["A", "B"] for i in range(5)
        )
        kick_embed = nextcord.Embed(
            title="👮 Панель модератора",
            description="Нажмите на игрока для кика" if has_players else "Ожидание игроков...",
            color=0xff6600
        )
        try:
            if self.kick_message:
                kick_view = build_quick_kick_view(self.id) if has_players else View(timeout=None)
                await self.kick_message.edit(embed=kick_embed, view=kick_view)
        except Exception as e:
            print(f"Ошибка обновления панели кика: {e}")


class TeamButton(Button):
    def __init__(self, session_id, team, index):
        session = sessions.get(session_id)
        position_name = session.positions[index] if session else str(index + 1)
        style = nextcord.ButtonStyle.success if team == "A" else nextcord.ButtonStyle.danger
        emoji = "🟢" if team == "A" else "🔴"
        super().__init__(
            style=style,
            label=position_name,
            emoji=emoji,
            row=index
        )
        self.session_id = session_id
        self.team = team
        self.index = index

    async def callback(self, interaction: Interaction):
        session = sessions.get(self.session_id)
        if not session:
            await interaction.response.send_message("⚠️ Лобби не найдено!", ephemeral=True)
            return

        required_role = session.game_role_ids.get(session.game)
        if required_role:
            role = interaction.guild.get_role(required_role)
            if role and role not in interaction.user.roles:
                await interaction.response.send_message(
                    f"❌ Требуется роль {role.mention} для регистрации!",
                    ephemeral=True
                )
                return

        if interaction.user.id in global_bans:
            await interaction.response.send_message("🚫 Вы забанены во всех лобби!", ephemeral=True)
            return

        user = interaction.user
        current_team = session.teams[self.team]

        if current_team[self.index] == user:
            current_team[self.index] = None
            session.registration_times[self.team][self.index] = None
            session.confirmed_players.discard(user.id)
            await session.update_registration_messages()
            await interaction.response.send_message("✅ Вы вышли из регистрации!", ephemeral=True)
            return

        for t in ["A", "B"]:
            for i, u in enumerate(session.teams[t]):
                if u == user:
                    session.teams[t][i] = None
                    session.registration_times[t][i] = None

        if current_team[self.index] is None:
            current_team[self.index] = user
            session.registration_times[self.team][self.index] = time.time()
            await session.update_registration_messages()
            await interaction.response.defer()
        else:
            await interaction.response.send_message("⛔ Место занято!", ephemeral=True)


class RegistrationView(View):
    def __init__(self, session_id):
        super().__init__(timeout=None)
        self.session_id = session_id
        for i in range(5):
            self.add_item(TeamButton(session_id, "A", i))
            self.add_item(TeamButton(session_id, "B", i))


class CloseSelect(Select):
    def __init__(self, session_id):
        options = [
            nextcord.SelectOption(label="Удалить лобби", emoji="🗑️", value="delete"),
            nextcord.SelectOption(label="Создать комнаты", emoji="🎮", value="create_rooms"),
            nextcord.SelectOption(label="Модерация (баны)", emoji="👮", value="moderation")
        ]
        super().__init__(
            placeholder="Выберите действие...",
            min_values=1,
            max_values=1,
            options=options
        )
        self.session_id = session_id

    async def callback(self, interaction: Interaction):
        session = sessions.get(self.session_id)
        if not session:
            await interaction.response.send_message("❌ Лобби не найдено!", ephemeral=True)
            return

        value = self.values[0]

        if value == "delete":
            session = sessions.pop(self.session_id, None)
            if not session:
                await interaction.response.send_message("❌ Лобби не найдено!", ephemeral=True)
                return

            moderator_lobbies.pop(session.creator_id, None)

            try:
                for channel in session.created_channels:
                    await channel.delete()
            except Exception as e:
                print(f"Ошибка удаления: {e}")

            if self.session_id in global_bans:
                global_bans.remove(self.session_id)
                save_bans(global_bans)

            await interaction.response.send_message("✅ Лобби и все каналы удалены!", ephemeral=True)

        elif value == "create_rooms":
            if session.reg_channel:
                await session.reg_channel.delete()
                session.created_channels.remove(session.reg_channel)
                session.reg_channel = None

            if session.waiting_channel:
                await session.waiting_channel.edit(name="🎥-Просмотр")
                session.spectator_channel = session.waiting_channel
                session.waiting_channel = None

            session.team_channels = {}
            for team in ["A", "B"]:
                overwrites = {
                    interaction.guild.default_role: nextcord.PermissionOverwrite(connect=False),
                    interaction.user: nextcord.PermissionOverwrite(connect=True)
                }
                for user in session.teams[team]:
                    if user:
                        overwrites[user] = nextcord.PermissionOverwrite(connect=True)

                channel = await session.category.create_voice_channel(
                    name=f"🔊-Команда-{team}-{session.id}",
                    overwrites=overwrites
                )
                session.team_channels[team] = channel
                session.created_channels.append(channel)

            await interaction.response.send_message("✅ Комнаты созданы!", ephemeral=True)

        elif value == "moderation":
            view = ModerationView(self.session_id)
            await interaction.response.send_message(
                "🔧 Выберите действие модерации:",
                view=view,
                ephemeral=True
            )


class CloseManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.afk_check.start()

    def cog_unload(self):
        self.afk_check.cancel()

    @tasks.loop(seconds=30)
    async def afk_check(self):
        now = time.time()
        for session_id, session in list(sessions.items()):
            if not session.waiting_channel:
                continue

            try:
                voice_member_ids = {m.id for m in session.waiting_channel.members}
            except Exception:
                continue

            changed = False
            for team in ["A", "B"]:
                for i in range(5):
                    user = session.teams[team][i]
                    reg_time = session.registration_times[team][i]
                    if not user or not reg_time:
                        continue

                    if user.id in voice_member_ids:
                        session.confirmed_players.add(user.id)
                    elif user.id not in session.confirmed_players:
                        if now - reg_time > AFK_TIMEOUT_SECONDS:
                            session.teams[team][i] = None
                            session.registration_times[team][i] = None
                            changed = True

            if changed:
                try:
                    await session.update_registration_messages()
                except Exception as e:
                    print(f"Ошибка авто-кика: {e}")

    @afk_check.before_loop
    async def before_afk_check(self):
        await self.bot.wait_until_ready()

    @nextcord.slash_command(name="close", description="Создать клоз")
    @has_any_role(*MODERATOR_ROLE)
    async def start(self, interaction: Interaction):
        existing_id = moderator_lobbies.get(interaction.user.id)
        if existing_id and existing_id in sessions:
            await interaction.response.send_message(
                f"❌ У вас уже есть активное лобби (код: `{existing_id}`). "
                f"Удалите его через /close_menu, прежде чем создавать новое.",
                ephemeral=True
            )
            return

        view = GameSelectView()
        await interaction.response.send_message(
            "🎮 Выберите игру для лобби:",
            view=view,
            ephemeral=False
        )

        await view.wait()

        if not view.selected_game:
            await interaction.followup.send("❌ Время выбора игры истекло!", ephemeral=True)
            return

        guild = interaction.guild
        category = guild.get_channel(TARGET_CATEGORY_ID)

        if not category or not isinstance(category, nextcord.CategoryChannel):
            await interaction.followup.send("❌ Категория для лобби не найдена!", ephemeral=True)
            return

        session = LobbySession(guild, view.selected_game, interaction.user.id)
        session.category = category

        try:
            overwrites = {
                guild.default_role: nextcord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=False,
                    connect=True
                )
            }
            for role in session.moderator_roles:
                overwrites[role] = nextcord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                    manage_channels=True
                )

            session.reg_channel = await category.create_text_channel(
                name=f"📝-регистрация-{session.game}-{session.id}",
                overwrites=overwrites
            )
            session.created_channels.append(session.reg_channel)

            game_role_id = session.game_role_ids.get(view.selected_game)
            if game_role_id:
                game_role = interaction.guild.get_role(game_role_id)
                if game_role:
                    try:
                        session.waiting_channel = await category.create_voice_channel(
                            name=f"🎙️-Ожидание-{session.game}-{session.id}"
                        )
                        session.created_channels.append(session.waiting_channel)
                        await session.reg_channel.send(
                            f"{game_role.mention} Регистрация открыта! "
                            f"Присоединяйтесь к каналу - {session.waiting_channel.mention}"
                        )
                    except Exception as e:
                        print(f"Ошибка создания голосового канала: {e}")

            reg_view = RegistrationView(session.id)
            session.registration_message = await session.reg_channel.send(
                embed=nextcord.Embed(description="⚙️ Идет настройка лобби...", color=0x00ff00),
                view=reg_view
            )

            kick_embed = nextcord.Embed(
                title="👮 Панель модератора",
                description="Ожидание игроков...",
                color=0xff6600
            )
            session.kick_message = await session.reg_channel.send(
                embed=kick_embed, view=View(timeout=None)
            )

            sessions[session.id] = session
            moderator_lobbies[interaction.user.id] = session.id

            await interaction.followup.send(
                f"🎉 Лобби {session.game} создано! Код: `{session.id}`",
                ephemeral=True
            )

            await session.update_registration_messages()
        except Exception as e:
            await interaction.followup.send(f"❌ Ошибка: {str(e)}", ephemeral=True)

    @nextcord.slash_command(name="close_menu", description="Управление лобби")
    @has_any_role(*MODERATOR_ROLE)
    async def close(
            self,
            interaction: Interaction,
            session_id: str = SlashOption(
                description="ID лобби (оставьте пустым для автоопределения)",
                required=False,
                default=None
            )
    ):
        try:
            if not session_id:
                session_id = moderator_lobbies.get(interaction.user.id)

            if not session_id or session_id not in sessions:
                await interaction.response.send_message(
                    "❌ Активное лобби не найдено! Создайте новое через /close.",
                    ephemeral=True
                )
                return

            view = View()
            view.add_item(CloseSelect(session_id))
            await interaction.response.send_message("🔧 Выберите действие:", view=view, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"⚠️ Ошибка: {str(e)}", ephemeral=True)

    @nextcord.slash_command(name="close_ban_list", description="Показать список забаненных пользователей")
    @has_any_role("event-менеджер", "Admin", "DS Support")
    async def ban_list(self, interaction: Interaction):
        try:
            if not global_bans:
                await interaction.response.send_message("ℹ️ Список банов пуст", ephemeral=True)
                return

            banned_users = []
            guild = interaction.guild

            for user_id in global_bans:
                try:
                    user = await guild.fetch_member(user_id)
                    banned_users.append(f"{user.mention} (ID: {user.id})")
                except nextcord.NotFound:
                    banned_users.append(f"❌ Пользователь не найден (ID: {user_id})")
                except nextcord.HTTPException:
                    banned_users.append(f"⚠️ Ошибка запроса (ID: {user_id})")

            embed = nextcord.Embed(
                title="📜 Список глобальных банов",
                color=0xff0000,
                description="\n".join(banned_users) if banned_users else "Список пуст"
            )
            embed.set_footer(text=f"Всего забанено: {len(global_bans)}")

            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(
                f"❌ Ошибка при получении списка банов: {str(e)}",
                ephemeral=True
            )


def setup(bot):
    bot.add_cog(CloseManager(bot))
