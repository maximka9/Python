from __future__ import annotations

import random
import sqlite3
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple
from zoneinfo import ZoneInfo

import nextcord
from nextcord.ext import commands

from cogs.clan_membership import (
    HIDDEN_CLANS,
    chief_suffix_for_clan,
    get_member_clan_names,
)

ADMIN_ID = 428880831294078987
LOG_CHANNEL_ID = 1337500460709314661
DAILY_LIMIT = 10
PET_PROGRESS_MAX = 25
PET_BUY_COST = 5
BERLIN_TZ = ZoneInfo("Europe/Berlin")

DATA_DIR = Path("data")
DB_PATH = DATA_DIR / "reputation.sqlite3"

HEART_REACTION_EMOJIS = {
    "❤", "❤️", "♥", "♥️",
    "🧡", "💛", "💚", "🩵", "💙", "💜", "🤎", "🖤", "🩶", "🤍", "🩷", "✅"
}

CROSS_REACTION_EMOJIS = {"❌", "✖", "✖️", "✕", "❎", "🤡"}

FOODS = {
    "grass": {"label": "Трава", "cost": 1, "emoji": "⭐"},
    "apple": {"label": "Яблоко", "cost": 3, "emoji": "🍎"},
    "gummy": {"label": "Мармеладки", "cost": 5, "emoji": "🍬"},
    "omeletto": {"label": "Омлетто", "cost": 10, "emoji": "🍳"},
}

RANKS = [
    "Нейтрал",
    "Миньон",
    "Кабанчик",
    "ПТУ",
    "Стример",
    "Импровизатор",
    "Конструктивный",
    "МЧС",
    "Канадка",
    "Хоубист",
]

@dataclass(frozen=True)
class PetDef:
    key: str
    name: str
    emoji: str
    rarity: str
    reward_blood: int
    weight: int


PET_POOL: List[PetDef] = [
    PetDef("cat", "Кот", "🐱", "обычный", 400, 30),
    PetDef("dog", "Собака", "🐶", "обычный", 500, 24),
    PetDef("rabbit", "Заяц", "🐰", "обычный", 650, 20),
    PetDef("parrot", "Попугай", "🦜", "необычный", 1000, 13),
    PetDef("panda", "Панда", "🐼", "редкий", 2200, 8),
    PetDef("tiger", "Тигр", "🐯", "легендарный", 5000, 5),
]
PET_BY_KEY = {pet.key: pet for pet in PET_POOL}


def day_key_local() -> str:
    return datetime.now(BERLIN_TZ).strftime("%Y-%m-%d")


def rank_from_rep(rep: int) -> str:
    if rep < 0:
        return "Нищий"
    idx = rep // 10
    if idx >= len(RANKS):
        idx = len(RANKS) - 1
    return RANKS[idx]


def normalize_emoji(value: str) -> str:
    return (value or "").replace("\ufe0f", "")


def reaction_vote_from_emoji(value: str) -> Optional[int]:
    norm = normalize_emoji(value)
    heart_norm = {normalize_emoji(x) for x in HEART_REACTION_EMOJIS}
    cross_norm = {normalize_emoji(x) for x in CROSS_REACTION_EMOJIS}
    if norm in heart_norm:
        return 1
    if norm in cross_norm:
        return -1
    return None


class RepDB:
    def __init__(self, path: Path):
        self.path = path
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path)
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA foreign_keys=ON;")
        return con

    def _column_exists(self, con: sqlite3.Connection, table: str, column: str) -> bool:
        cur = con.execute(f"PRAGMA table_info({table})")
        return any(str(row[1]) == column for row in cur.fetchall())

    def _init_db(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rep_users (
                    guild_id INTEGER NOT NULL,
                    user_id  INTEGER NOT NULL,
                    rep INTEGER NOT NULL DEFAULT 0,
                    given_plus INTEGER NOT NULL DEFAULT 0,
                    given_minus INTEGER NOT NULL DEFAULT 0,
                    received_plus INTEGER NOT NULL DEFAULT 0,
                    received_minus INTEGER NOT NULL DEFAULT 0,
                    stars_received INTEGER NOT NULL DEFAULT 0,
                    bio TEXT,
                    PRIMARY KEY (guild_id, user_id)
                )
                """
            )

            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rep_daily (
                    guild_id INTEGER NOT NULL,
                    user_id  INTEGER NOT NULL,
                    day_key  TEXT NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (guild_id, user_id, day_key)
                )
                """
            )

            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rep_votes (
                    guild_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    voter_id INTEGER NOT NULL,
                    target_id INTEGER NOT NULL,
                    vote INTEGER NOT NULL,
                    PRIMARY KEY (guild_id, message_id, voter_id)
                )
                """
            )

            if not self._column_exists(con, "rep_votes", "day_key"):
                con.execute("ALTER TABLE rep_votes ADD COLUMN day_key TEXT")

            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rep_daily_target (
                    guild_id INTEGER NOT NULL,
                    voter_id INTEGER NOT NULL,
                    target_id INTEGER NOT NULL,
                    day_key TEXT NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (guild_id, voter_id, target_id, day_key)
                )
                """
            )

            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rep_reactions (
                    guild_id INTEGER NOT NULL,
                    message_id INTEGER NOT NULL,
                    reactor_id INTEGER NOT NULL,
                    target_id INTEGER NOT NULL,
                    vote INTEGER NOT NULL,
                    emoji TEXT NOT NULL,
                    day_key TEXT NOT NULL,
                    PRIMARY KEY (guild_id, message_id, reactor_id)
                )
                """
            )

            con.execute(
                """
                CREATE TABLE IF NOT EXISTS rep_pets (
                    guild_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    pet_key TEXT NOT NULL,
                    progress INTEGER NOT NULL DEFAULT 0,
                    last_feed_day TEXT,
                    PRIMARY KEY (guild_id, user_id)
                )
                """
            )
            con.commit()

    def ensure_user(self, guild_id: int, user_id: int):
        with self._connect() as con:
            con.execute(
                "INSERT OR IGNORE INTO rep_users(guild_id, user_id) VALUES(?, ?)",
                (guild_id, user_id),
            )
            con.commit()

    def get_user(self, guild_id: int, user_id: int):
        self.ensure_user(guild_id, user_id)
        with self._connect() as con:
            cur = con.execute(
                """
                SELECT rep, given_plus, given_minus, received_plus, received_minus
                FROM rep_users
                WHERE guild_id=? AND user_id=?
                """,
                (guild_id, user_id),
            )
            return cur.fetchone()

    def get_rep(self, guild_id: int, user_id: int) -> int:
        row = self.get_user(guild_id, user_id)
        return int(row[0]) if row else 0

    def get_daily_used(self, guild_id: int, user_id: int, day: str) -> int:
        with self._connect() as con:
            cur = con.execute(
                "SELECT used FROM rep_daily WHERE guild_id=? AND user_id=? AND day_key=?",
                (guild_id, user_id, day),
            )
            row = cur.fetchone()
            return int(row[0]) if row else 0

    def inc_daily_used(self, con: sqlite3.Connection, guild_id: int, user_id: int, day: str, delta: int):
        con.execute(
            """
            INSERT INTO rep_daily(guild_id, user_id, day_key, used)
            VALUES(?, ?, ?, 0)
            ON CONFLICT(guild_id, user_id, day_key) DO NOTHING
            """,
            (guild_id, user_id, day),
        )
        con.execute(
            """
            UPDATE rep_daily
            SET used = MAX(0, used + ?)
            WHERE guild_id=? AND user_id=? AND day_key=?
            """,
            (int(delta), guild_id, user_id, day),
        )

    def daily_target_used(self, guild_id: int, voter_id: int, target_id: int, day: str) -> int:
        with self._connect() as con:
            cur = con.execute(
                """
                SELECT used FROM rep_daily_target
                WHERE guild_id=? AND voter_id=? AND target_id=? AND day_key=?
                """,
                (guild_id, voter_id, target_id, day),
            )
            row = cur.fetchone()
            return int(row[0]) if row else 0

    def set_daily_target_used(
        self,
        con: sqlite3.Connection,
        guild_id: int,
        voter_id: int,
        target_id: int,
        day: str,
        used: int,
    ):
        con.execute(
            """
            INSERT INTO rep_daily_target(guild_id, voter_id, target_id, day_key, used)
            VALUES(?, ?, ?, ?, 0)
            ON CONFLICT(guild_id, voter_id, target_id, day_key) DO NOTHING
            """,
            (guild_id, voter_id, target_id, day),
        )
        con.execute(
            """
            UPDATE rep_daily_target
            SET used=?
            WHERE guild_id=? AND voter_id=? AND target_id=? AND day_key=?
            """,
            (int(used), guild_id, voter_id, target_id, day),
        )

    def vote_exists(self, guild_id: int, message_id: int, voter_id: int) -> bool:
        with self._connect() as con:
            cur = con.execute(
                "SELECT 1 FROM rep_votes WHERE guild_id=? AND message_id=? AND voter_id=?",
                (guild_id, message_id, voter_id),
            )
            return cur.fetchone() is not None

    def reaction_exists(self, guild_id: int, message_id: int, reactor_id: int) -> bool:
        with self._connect() as con:
            cur = con.execute(
                "SELECT 1 FROM rep_reactions WHERE guild_id=? AND message_id=? AND reactor_id=?",
                (guild_id, message_id, reactor_id),
            )
            return cur.fetchone() is not None

    def _apply_rep_delta(
        self,
        con: sqlite3.Connection,
        guild_id: int,
        voter_id: int,
        target_id: int,
        amount: int,
    ):
        if amount > 0:
            con.execute(
                """
                UPDATE rep_users
                SET rep = rep + ?,
                    received_plus = received_plus + 1
                WHERE guild_id=? AND user_id=?
                """,
                (amount, guild_id, target_id),
            )
            con.execute(
                """
                UPDATE rep_users
                SET given_plus = given_plus + 1
                WHERE guild_id=? AND user_id=?
                """,
                (guild_id, voter_id),
            )
        else:
            con.execute(
                """
                UPDATE rep_users
                SET rep = rep + ?,
                    received_minus = received_minus + 1
                WHERE guild_id=? AND user_id=?
                """,
                (amount, guild_id, target_id),
            )
            con.execute(
                """
                UPDATE rep_users
                SET given_minus = given_minus + 1
                WHERE guild_id=? AND user_id=?
                """,
                (guild_id, voter_id),
            )

    def _rollback_rep_delta(
        self,
        con: sqlite3.Connection,
        guild_id: int,
        voter_id: int,
        target_id: int,
        amount: int,
    ):
        if amount > 0:
            con.execute(
                """
                UPDATE rep_users
                SET rep = rep - ?,
                    received_plus = MAX(0, received_plus - 1)
                WHERE guild_id=? AND user_id=?
                """,
                (amount, guild_id, target_id),
            )
            con.execute(
                """
                UPDATE rep_users
                SET given_plus = MAX(0, given_plus - 1)
                WHERE guild_id=? AND user_id=?
                """,
                (guild_id, voter_id),
            )
        else:
            con.execute(
                """
                UPDATE rep_users
                SET rep = rep - ?,
                    received_minus = MAX(0, received_minus - 1)
                WHERE guild_id=? AND user_id=?
                """,
                (amount, guild_id, target_id),
            )
            con.execute(
                """
                UPDATE rep_users
                SET given_minus = MAX(0, given_minus - 1)
                WHERE guild_id=? AND user_id=?
                """,
                (guild_id, voter_id),
            )

    def apply_text_vote(
        self,
        guild_id: int,
        message_id: int,
        voter_id: int,
        target_id: int,
        amount: int,
    ) -> Tuple[bool, str]:
        day = day_key_local()
        if amount == 0:
            return False, "Нулевое значение не засчитывается."

        used = self.get_daily_used(guild_id, voter_id, day)
        if used >= DAILY_LIMIT:
            return False, f"Лимит выдач на сегодня исчерпан: {used}/{DAILY_LIMIT}"

        if self.daily_target_used(guild_id, voter_id, target_id, day) >= 1:
            return False, "Ты уже менял репутацию этому человеку сегодня."

        if self.vote_exists(guild_id, message_id, voter_id):
            return False, "Ты уже оценивал это сообщение."

        with self._connect() as con:
            try:
                con.execute("BEGIN")
                con.execute("INSERT OR IGNORE INTO rep_users(guild_id, user_id) VALUES(?, ?)", (guild_id, voter_id))
                con.execute("INSERT OR IGNORE INTO rep_users(guild_id, user_id) VALUES(?, ?)", (guild_id, target_id))

                con.execute(
                    """
                    INSERT INTO rep_votes(guild_id, message_id, voter_id, target_id, vote, day_key)
                    VALUES(?, ?, ?, ?, ?, ?)
                    """,
                    (guild_id, message_id, voter_id, target_id, amount, day),
                )

                self._apply_rep_delta(con, guild_id, voter_id, target_id, amount)
                self.inc_daily_used(con, guild_id, voter_id, day, +1)
                self.set_daily_target_used(con, guild_id, voter_id, target_id, day, 1)
                con.commit()
                return True, "OK"
            except sqlite3.IntegrityError:
                con.rollback()
                return False, "Уже засчитано."
            except Exception:
                con.rollback()
                return False, "Ошибка БД."

    def apply_reaction_add(
        self,
        guild_id: int,
        message_id: int,
        reactor_id: int,
        target_id: int,
        amount: int,
        emoji: str,
    ) -> Tuple[bool, str]:
        day = day_key_local()
        if amount == 0:
            return False, "Эта реакция не учитывается."

        used = self.get_daily_used(guild_id, reactor_id, day)
        if used >= DAILY_LIMIT:
            return False, f"Лимит выдач на сегодня исчерпан: {used}/{DAILY_LIMIT}"

        if self.daily_target_used(guild_id, reactor_id, target_id, day) >= 1:
            return False, "Ты уже менял репутацию этому человеку сегодня."

        if self.reaction_exists(guild_id, message_id, reactor_id):
            return False, "Эта реакция уже учтена."

        with self._connect() as con:
            try:
                con.execute("BEGIN")
                con.execute("INSERT OR IGNORE INTO rep_users(guild_id, user_id) VALUES(?, ?)", (guild_id, reactor_id))
                con.execute("INSERT OR IGNORE INTO rep_users(guild_id, user_id) VALUES(?, ?)", (guild_id, target_id))
                con.execute(
                    """
                    INSERT INTO rep_reactions(guild_id, message_id, reactor_id, target_id, vote, emoji, day_key)
                    VALUES(?, ?, ?, ?, ?, ?, ?)
                    """,
                    (guild_id, message_id, reactor_id, target_id, amount, emoji, day),
                )
                self._apply_rep_delta(con, guild_id, reactor_id, target_id, amount)
                self.inc_daily_used(con, guild_id, reactor_id, day, +1)
                self.set_daily_target_used(con, guild_id, reactor_id, target_id, day, 1)
                con.commit()
                return True, "OK"
            except sqlite3.IntegrityError:
                con.rollback()
                return False, "Уже засчитано."
            except Exception:
                con.rollback()
                return False, "Ошибка БД."

    def apply_reaction_remove(
        self,
        guild_id: int,
        message_id: int,
        reactor_id: int,
        emoji: str,
    ) -> Tuple[bool, str]:
        with self._connect() as con:
            try:
                con.execute("BEGIN")
                cur = con.execute(
                    """
                    SELECT target_id, vote, day_key, emoji
                    FROM rep_reactions
                    WHERE guild_id=? AND message_id=? AND reactor_id=?
                    """,
                    (guild_id, message_id, reactor_id),
                )
                row = cur.fetchone()
                if not row:
                    con.rollback()
                    return False, "Нет записи об этой реакции."

                target_id = int(row[0])
                amount = int(row[1])
                original_day = str(row[2])
                saved_emoji = str(row[3])

                if normalize_emoji(saved_emoji) != normalize_emoji(emoji):
                    con.rollback()
                    return False, "Удалена другая реакция, учтённую запись не трогаем."

                con.execute(
                    "DELETE FROM rep_reactions WHERE guild_id=? AND message_id=? AND reactor_id=?",
                    (guild_id, message_id, reactor_id),
                )
                self._rollback_rep_delta(con, guild_id, reactor_id, target_id, amount)
                self.inc_daily_used(con, guild_id, reactor_id, original_day, -1)
                self.set_daily_target_used(con, guild_id, reactor_id, target_id, original_day, 0)
                con.commit()
                return True, "OK"
            except Exception:
                con.rollback()
                return False, "Ошибка БД."

    def admin_adjust_rep(self, guild_id: int, target_id: int, delta: int):
        self.ensure_user(guild_id, target_id)
        with self._connect() as con:
            con.execute(
                "UPDATE rep_users SET rep = rep + ? WHERE guild_id=? AND user_id=?",
                (int(delta), guild_id, target_id),
            )
            con.commit()

    def top_users(self, guild_id: int, limit: int = 10) -> List[Tuple[int, int]]:
        with self._connect() as con:
            cur = con.execute(
                """
                SELECT user_id, rep FROM rep_users
                WHERE guild_id=?
                ORDER BY rep DESC, user_id ASC
                LIMIT ?
                """,
                (guild_id, int(limit)),
            )
            return [(int(r[0]), int(r[1])) for r in cur.fetchall()]

    def bottom_users(self, guild_id: int, limit: int = 10) -> List[Tuple[int, int]]:
        with self._connect() as con:
            cur = con.execute(
                """
                SELECT user_id, rep FROM rep_users
                WHERE guild_id=?
                ORDER BY rep ASC, user_id ASC
                LIMIT ?
                """,
                (guild_id, int(limit)),
            )
            return [(int(r[0]), int(r[1])) for r in cur.fetchall()]

    def all_users(self, guild_id: int) -> List[Tuple[int, int]]:
        with self._connect() as con:
            cur = con.execute(
                """
                SELECT user_id, rep FROM rep_users
                WHERE guild_id=?
                ORDER BY rep DESC, user_id ASC
                """,
                (guild_id,),
            )
            return [(int(r[0]), int(r[1])) for r in cur.fetchall()]

    def rank_position(self, guild_id: int, user_id: int) -> int:
        self.ensure_user(guild_id, user_id)
        with self._connect() as con:
            cur = con.execute(
                "SELECT rep FROM rep_users WHERE guild_id=? AND user_id=?",
                (guild_id, user_id),
            )
            rep = int(cur.fetchone()[0])
            cur2 = con.execute(
                "SELECT COUNT(*) FROM rep_users WHERE guild_id=? AND rep > ?",
                (guild_id, rep),
            )
            higher = int(cur2.fetchone()[0])
            return higher + 1

    def get_pet(self, guild_id: int, user_id: int) -> Optional[Tuple[str, int, Optional[str]]]:
        with self._connect() as con:
            cur = con.execute(
                "SELECT pet_key, progress, last_feed_day FROM rep_pets WHERE guild_id=? AND user_id=?",
                (guild_id, user_id),
            )
            row = cur.fetchone()
            if not row:
                return None
            return str(row[0]), int(row[1]), (str(row[2]) if row[2] is not None else None)

    def buy_random_pet(self, guild_id: int, user_id: int) -> Tuple[bool, str, Optional[PetDef]]:
        if self.get_pet(guild_id, user_id):
            return False, "У тебя уже есть питомец.", None

        self.ensure_user(guild_id, user_id)
        current_rep = self.get_rep(guild_id, user_id)
        if current_rep < PET_BUY_COST:
            return False, f"Недостаточно репутации. Нужно {PET_BUY_COST} ⭐.", None

        pet = random.choices(PET_POOL, weights=[p.weight for p in PET_POOL], k=1)[0]
        with self._connect() as con:
            try:
                con.execute("BEGIN")
                con.execute(
                    "UPDATE rep_users SET rep = rep - ? WHERE guild_id=? AND user_id=? AND rep >= ?",
                    (PET_BUY_COST, guild_id, user_id, PET_BUY_COST),
                )
                if con.total_changes <= 0:
                    con.rollback()
                    return False, f"Недостаточно репутации. Нужно {PET_BUY_COST} ⭐.", None

                con.execute(
                    "INSERT INTO rep_pets(guild_id, user_id, pet_key, progress, last_feed_day) VALUES(?, ?, ?, 0, NULL)",
                    (guild_id, user_id, pet.key),
                )
                con.commit()
                return True, f"Тебе выпал питомец: {pet.emoji} {pet.name}.", pet
            except Exception:
                con.rollback()
                return False, "Не удалось купить питомца.", None

    def feed_pet(self, guild_id: int, user_id: int, food_key: str) -> Tuple[bool, str, Optional[int]]:
        pet_row = self.get_pet(guild_id, user_id)
        if not pet_row:
            return False, "У тебя пока нет питомца.", None

        food = FOODS.get(food_key)
        if not food:
            return False, "Неизвестная еда.", None

        pet_key, progress, last_feed_day = pet_row
        today = day_key_local()

        if progress >= PET_PROGRESS_MAX:
            return False, "Питомец уже вырос. Его можно продавать.", progress

        if last_feed_day == today:
            return False, "Сегодня питомец уже был накормлен.", progress

        cost = int(food["cost"])
        self.ensure_user(guild_id, user_id)
        if self.get_rep(guild_id, user_id) < cost:
            return False, f"Недостаточно репутации. Нужно {cost} ⭐.", progress

        new_progress = min(PET_PROGRESS_MAX, progress + cost)

        with self._connect() as con:
            try:
                con.execute("BEGIN")
                con.execute(
                    "UPDATE rep_users SET rep = rep - ? WHERE guild_id=? AND user_id=? AND rep >= ?",
                    (cost, guild_id, user_id, cost),
                )
                if con.total_changes <= 0:
                    con.rollback()
                    return False, f"Недостаточно репутации. Нужно {cost} ⭐.", progress

                con.execute(
                    """
                    UPDATE rep_pets
                    SET progress=?, last_feed_day=?
                    WHERE guild_id=? AND user_id=? AND pet_key=?
                    """,
                    (new_progress, today, guild_id, user_id, pet_key),
                )
                con.commit()
                return True, f"Питомец накормлен: +{cost} к прогрессу.", new_progress
            except Exception:
                con.rollback()
                return False, "Не удалось покормить питомца.", progress

    def sell_pet(self, guild_id: int, user_id: int) -> Tuple[bool, str, Optional[PetDef]]:
        pet_row = self.get_pet(guild_id, user_id)
        if not pet_row:
            return False, "У тебя нет питомца.", None

        pet_key, progress, _last_feed_day = pet_row
        pet = PET_BY_KEY.get(pet_key)
        if pet is None:
            return False, "Питомец не найден в конфиге.", None

        if progress < PET_PROGRESS_MAX:
            return False, "Питомец ещё не вырос до 25/25.", pet

        with self._connect() as con:
            try:
                con.execute("BEGIN")
                con.execute(
                    "DELETE FROM rep_pets WHERE guild_id=? AND user_id=?",
                    (guild_id, user_id),
                )
                con.commit()
                return True, "Питомец продан.", pet
            except Exception:
                con.rollback()
                return False, "Не удалось продать питомца.", None


class ReputationMenuView(nextcord.ui.View):
    def __init__(self, cog: "ReputationCog", guild_id: int, profile_target_id: int, owner_id: int, page: str = "profile"):
        super().__init__(timeout=300)
        self.cog = cog
        self.guild_id = guild_id
        self.profile_target_id = profile_target_id
        self.owner_id = owner_id
        self.page = page
        self.notice: Optional[str] = None
        self.rebuild_items()

    async def interaction_check(self, interaction: nextcord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Это меню принадлежит другому пользователю.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True

    def rebuild_items(self):
        self.clear_items()
        self._add_nav_buttons()

        if self.page == "pet":
            self._add_pet_buttons()
        elif self.page == "feed":
            self._add_food_buttons()

    def _make_button(self, *, label: str, style: nextcord.ButtonStyle, callback, disabled: bool = False, row: int = 0):
        button = nextcord.ui.Button(label=label, style=style, disabled=disabled, row=row)
        button.callback = callback
        self.add_item(button)

    def _add_nav_buttons(self):
        self._make_button(
            label="Профиль",
            style=nextcord.ButtonStyle.primary,
            callback=self.show_profile,
            disabled=self.page == "profile",
        )
        self._make_button(
            label="Топ-10",
            style=nextcord.ButtonStyle.secondary,
            callback=self.show_top,
            disabled=self.page == "top",
        )
        self._make_button(
            label="Плохиши",
            style=nextcord.ButtonStyle.secondary,
            callback=self.show_bad,
            disabled=self.page == "bad",
        )
        self._make_button(
            label="Топ кланов",
            style=nextcord.ButtonStyle.secondary,
            callback=self.show_clans,
            disabled=self.page == "clans",
        )
        self._make_button(
            label="Мой питомец",
            style=nextcord.ButtonStyle.success,
            callback=self.show_pet,
            disabled=self.page == "pet",
        )

    def _add_pet_buttons(self):
        pet_row = self.cog.db.get_pet(self.guild_id, self.owner_id)
        has_pet = pet_row is not None
        can_sell = bool(has_pet and pet_row[1] >= PET_PROGRESS_MAX)
        can_feed = bool(has_pet and pet_row[1] < PET_PROGRESS_MAX and pet_row[2] != day_key_local())

        self._make_button(
            label=f"Купить питомца ({PET_BUY_COST} ⭐)",
            style=nextcord.ButtonStyle.secondary,
            callback=self.buy_pet,
            disabled=has_pet,
            row=1,
        )
        self._make_button(
            label="Купить еду",
            style=nextcord.ButtonStyle.primary,
            callback=self.open_feed_menu,
            disabled=not can_feed,
            row=1,
        )
        self._make_button(
            label="Продать",
            style=nextcord.ButtonStyle.danger,
            callback=self.sell_pet,
            disabled=not can_sell,
            row=1,
        )

    def _add_food_buttons(self):
        pet_row = self.cog.db.get_pet(self.guild_id, self.owner_id)
        has_pet = pet_row is not None
        disabled = not has_pet
        self._make_button(label="Трава · 1 ⭐", style=nextcord.ButtonStyle.secondary, callback=self.feed_grass, disabled=disabled, row=1)
        self._make_button(label="Яблоко · 3 ⭐", style=nextcord.ButtonStyle.secondary, callback=self.feed_apple, disabled=disabled, row=1)
        self._make_button(label="Мармеладки · 5 ⭐", style=nextcord.ButtonStyle.secondary, callback=self.feed_gummy, disabled=disabled, row=1)
        self._make_button(label="Омлетто · 10 ⭐", style=nextcord.ButtonStyle.secondary, callback=self.feed_omeletto, disabled=disabled, row=1)
        self._make_button(label="Назад", style=nextcord.ButtonStyle.primary, callback=self.show_pet, row=2)

    async def render(self, interaction: nextcord.Interaction):
        self.rebuild_items()
        embed = await self.cog.build_page_embed(
            guild=interaction.guild,
            page=self.page,
            profile_target_id=self.profile_target_id,
            owner_id=self.owner_id,
            note=self.notice,
        )
        self.notice = None
        try:
            await interaction.response.edit_message(embed=embed, view=self)
        except nextcord.InteractionResponded:
            await interaction.edit_original_message(embed=embed, view=self)

    async def show_profile(self, interaction: nextcord.Interaction):
        self.page = "profile"
        await self.render(interaction)

    async def show_top(self, interaction: nextcord.Interaction):
        self.page = "top"
        await self.render(interaction)

    async def show_bad(self, interaction: nextcord.Interaction):
        self.page = "bad"
        await self.render(interaction)

    async def show_clans(self, interaction: nextcord.Interaction):
        self.page = "clans"
        await self.render(interaction)

    async def show_pet(self, interaction: nextcord.Interaction):
        self.page = "pet"
        await self.render(interaction)

    async def open_feed_menu(self, interaction: nextcord.Interaction):
        self.page = "feed"
        await self.render(interaction)

    async def buy_pet(self, interaction: nextcord.Interaction):
        ok, msg, pet = self.cog.db.buy_random_pet(self.guild_id, self.owner_id)
        self.page = "pet"
        self.notice = msg if not ok else f"Тебе выпал питомец: {pet.emoji} {pet.name} ({pet.rarity})."
        await self.render(interaction)

    async def sell_pet(self, interaction: nextcord.Interaction):
        ok, msg, pet = self.cog.db.sell_pet(self.guild_id, self.owner_id)
        if ok and pet and interaction.guild:
            log_channel = interaction.guild.get_channel(LOG_CHANNEL_ID)
            if log_channel is None:
                try:
                    log_channel = await self.cog.bot.fetch_channel(LOG_CHANNEL_ID)
                except Exception:
                    log_channel = None
            log_text = (
                f"<@{ADMIN_ID}>\n"
                f"Пользователь {interaction.user.mention} ({interaction.user}) продаёт питомца "
                f"{pet.emoji} **{pet.name}** ({pet.rarity}) за **{pet.reward_blood} blood**."
            )
            if log_channel is not None:
                try:
                    await log_channel.send(log_text)
                except Exception:
                    self.notice = "Питомец продан, но лог в канал отправить не удалось."
                else:
                    self.notice = f"Питомец продан. Администратор увидит лог на {pet.reward_blood} blood."
            else:
                self.notice = "Питомец продан, но лог-канал не найден."
        else:
            self.notice = msg

        self.page = "pet"
        await self.render(interaction)

    async def _feed(self, interaction: nextcord.Interaction, food_key: str):
        ok, msg, progress = self.cog.db.feed_pet(self.guild_id, self.owner_id, food_key)
        self.page = "pet"
        if ok:
            self.notice = f"{msg} Текущий прогресс: {progress}/{PET_PROGRESS_MAX}."
        else:
            self.notice = msg
        await self.render(interaction)

    async def feed_grass(self, interaction: nextcord.Interaction):
        await self._feed(interaction, "grass")

    async def feed_apple(self, interaction: nextcord.Interaction):
        await self._feed(interaction, "apple")

    async def feed_gummy(self, interaction: nextcord.Interaction):
        await self._feed(interaction, "gummy")

    async def feed_omeletto(self, interaction: nextcord.Interaction):
        await self._feed(interaction, "omeletto")


class ReputationCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.db = RepDB(DB_PATH)
        self.text_detector = None

    def _get_member_rank_map(
        self,
        guild: nextcord.Guild,
        member: Optional[nextcord.Member],
    ) -> dict[str, str]:
        if member is None:
            return {}

        rank_cog = self.bot.get_cog("ClanRankCog")
        if rank_cog is None:
            return {}

        try:
            if hasattr(rank_cog, "get_user_rank_map"):
                data = rank_cog.get_user_rank_map(guild, member) or {}
                result: dict[str, str] = {}
                for clan_name, rank_text in data.items():
                    clan_name = str(clan_name)
                    rank_text = str(rank_text).strip()
                    if clan_name in HIDDEN_CLANS:
                        continue
                    if not rank_text:
                        continue
                    result[clan_name] = rank_text
                return result

            row = rank_cog.db.get_user_rank_row(guild.id, member.id)
            if not row:
                return {}

            stored_clan = str(row[0]).strip()
            rank_name = str(row[4]).strip()
            rank_emoji = str(row[5]).strip()

            if stored_clan in HIDDEN_CLANS:
                return {}

            member_clans = get_member_clan_names(member)
            if stored_clan not in member_clans:
                return {}

            parts = [part for part in [rank_name, rank_emoji] if part]
            rank_text = " ".join(parts).strip()
            if not rank_text:
                return {}

            return {stored_clan: rank_text}
        except Exception:
            return {}

    async def build_page_embed(
        self,
        guild: nextcord.Guild,
        page: str,
        profile_target_id: int,
        owner_id: int,
        note: Optional[str] = None,
    ) -> nextcord.Embed:
        if page == "profile":
            return await self.build_profile_embed(guild, profile_target_id, viewer_id=owner_id, note=note)
        if page == "top":
            return await self.build_top_embed(guild, top=True, note=note)
        if page == "bad":
            return await self.build_top_embed(guild, top=False, note=note)
        if page == "clans":
            return await self.build_clan_top_embed(guild, note=note)
        if page in {"pet", "feed"}:
            return await self.build_pet_embed(guild, owner_id, note=note, feeding_page=(page == "feed"))
        return nextcord.Embed(title="Репутация", description="Неизвестная страница.")

    async def build_profile_embed(
        self,
        guild: nextcord.Guild,
        user_id: int,
        viewer_id: int,
        note: Optional[str] = None,
    ) -> nextcord.Embed:
        member = guild.get_member(user_id)
        name = member.display_name if member else f"User {user_id}"
        avatar_url = member.display_avatar.url if member else None

        rep, gp, gm, _rp, _rm = self.db.get_user(guild.id, user_id)
        pos = self.db.rank_position(guild.id, user_id)
        status = rank_from_rep(int(rep))
        used_today = self.db.get_daily_used(guild.id, viewer_id, day_key_local())
        given_total = int(gp) + int(gm)
        pet_summary = self._pet_summary_line(guild.id, user_id)

        clans = get_member_clan_names(member)
        rank_map = self._get_member_rank_map(guild, member)

        main_lines = [
            f"**Репутация:** {rep} ⭐",
            f"**Статус:** {status}",
            f"**Клан:** {', '.join(clans) if clans else 'Без клана'}",
            f"**Место в топе:** #{pos}",
        ]

        if rank_map:
            main_lines.append("**Клановые ранги:**")
            for clan_name in sorted(rank_map.keys(), key=lambda x: x.lower()):
                suf = chief_suffix_for_clan(member, clan_name)
                main_lines.append(f"• **{clan_name}** — {rank_map[clan_name]}{suf}")

        embed = nextcord.Embed(title=f"👤 Профиль: {name}")
        if avatar_url:
            embed.set_thumbnail(url=avatar_url)
        if note:
            embed.description = f"> {note}"

        embed.add_field(
            name="Основное",
            value="\n".join(main_lines),
            inline=False,
        )
        embed.add_field(
            name="Статистика",
            value=f"**Поставлено оценок:** {given_total}",
            inline=False,
        )
        embed.add_field(
            name="Питомец",
            value=pet_summary,
            inline=False,
        )
        embed.set_footer(text=f"Твои выдачи сегодня: {used_today}/{DAILY_LIMIT}")
        return embed

    async def build_top_embed(self, guild: nextcord.Guild, top: bool, note: Optional[str] = None) -> nextcord.Embed:
        rows = self.db.top_users(guild.id, 10) if top else self.db.bottom_users(guild.id, 10)
        title = "🏆 Топ-10" if top else "😈 Плохиши-10"
        embed = nextcord.Embed(title=title)
        if note:
            embed.description = f"> {note}\n\n"

        if not rows:
            embed.description = (embed.description or "") + "Пока пусто."
            return embed

        lines = []
        for i, (uid, rep) in enumerate(rows, start=1):
            member = guild.get_member(uid)
            name = member.display_name if member else str(uid)
            lines.append(f"**{i}.** {name} — **{rep} ⭐** ({rank_from_rep(rep)})")

        embed.description = (embed.description or "") + "\n".join(lines)
        return embed

    async def build_clan_top_embed(
        self,
        guild: nextcord.Guild,
        note: Optional[str] = None,
    ) -> nextcord.Embed:
        embed = nextcord.Embed(title="🏰 Топ кланов")

        if note:
            embed.description = f"> {note}"

        clan_stats = defaultdict(lambda: {"total_rep": 0, "members": []})

        for user_id, rep in self.db.all_users(guild.id):
            member = guild.get_member(user_id)
            if member is None:
                continue

            clans = get_member_clan_names(member)
            if not clans:
                continue

            rank_map = self._get_member_rank_map(guild, member)

            for clan_name in clans:
                if clan_name in HIDDEN_CLANS:
                    continue

                clan_stats[clan_name]["total_rep"] += rep
                clan_stats[clan_name]["members"].append(
                    (member, rep, rank_map.get(clan_name))
                )

        if not clan_stats:
            embed.description = ((embed.description + "\n\n") if embed.description else "") + "Пока нет данных по кланам."
            return embed

        sorted_clans = sorted(
            clan_stats.items(),
            key=lambda item: (item[1]["total_rep"], len(item[1]["members"])),
            reverse=True,
        )

        for place, (clan_name, data) in enumerate(sorted_clans[:10], start=1):
            members_sorted = sorted(
                data["members"],
                key=lambda row: (row[1], row[0].display_name.lower()),
                reverse=True,
            )

            top_members = members_sorted[:3]
            if top_members:
                lines = []
                for idx, (member, rep, clan_rank) in enumerate(top_members, start=1):
                    line = f"**{idx}.** {member.display_name} — **{rep} ⭐**"
                    if clan_rank:
                        line += f" · {clan_rank}"
                    line += chief_suffix_for_clan(member, clan_name)
                    lines.append(line)
                value = "\n".join(lines)
            else:
                value = "Нет участников"

            value += f"\n\n**Участников:** {len(data['members'])}"
            embed.add_field(
                name=f"#{place} {clan_name} — {data['total_rep']} ⭐",
                value=value,
                inline=False,
            )

        return embed

    async def build_pet_embed(
        self,
        guild: nextcord.Guild,
        owner_id: int,
        note: Optional[str] = None,
        feeding_page: bool = False,
    ) -> nextcord.Embed:
        member = guild.get_member(owner_id)
        owner_name = member.display_name if member else str(owner_id)
        pet_row = self.db.get_pet(guild.id, owner_id)
        current_rep = self.db.get_rep(guild.id, owner_id)
        embed = nextcord.Embed(title=f"🐾 Мой питомец — {owner_name}")

        lines: List[str] = []
        if note:
            lines.append(f"> {note}")
            lines.append("")

        if pet_row is None:
            lines.extend(
                [
                    "У тебя пока нет питомца.",
                    f"Купить питомца можно за **{PET_BUY_COST} ⭐**.",
                    "Одновременно можно иметь только одного питомца.",
                    "Кормить питомца можно **1 раз в день**.",
                    "Еда тратит твою репутацию и добавляет столько же очков прогресса.",
                    f"Когда питомец вырастает до **{PET_PROGRESS_MAX}/{PET_PROGRESS_MAX}**, его можно продать за blood.",
                    "Награда за продажу сейчас выдаётся администратором вручную по логу.",
                    f"Твоя текущая репутация: **{current_rep} ⭐**.",
                ]
            )
        else:
            pet_key, progress, last_feed_day = pet_row
            pet = PET_BY_KEY.get(pet_key)
            if pet is None:
                lines.append("Конфиг питомца не найден.")
            else:
                can_feed = progress < PET_PROGRESS_MAX and last_feed_day != day_key_local()
                sell_text = (
                    f"доступна — **{pet.reward_blood} blood**"
                    if progress >= PET_PROGRESS_MAX
                    else f"пока недоступна — нужно {PET_PROGRESS_MAX}/{PET_PROGRESS_MAX}"
                )
                feed_text = "доступно" if can_feed else "сегодня уже использовано"
                lines.extend(
                    [
                        f"**Питомец:** {pet.emoji} {pet.name}",
                        f"**Редкость:** {pet.rarity}",
                        f"**Прогресс:** {progress}/{PET_PROGRESS_MAX}",
                        f"**Продажа:** {sell_text}",
                        f"**Кормление сегодня:** {feed_text}",
                        f"**Твоя репутация:** {current_rep} ⭐",
                        "",
                        "**Еда**",
                        "• Трава — 1 ⭐",
                        "• Яблоко — 3 ⭐",
                        "• Мармеладки — 5 ⭐",
                        "• Омлетто — 10 ⭐",
                    ]
                )
                if feeding_page:
                    lines.extend(["", "Выбери еду кнопками ниже."])

        embed.description = "\n".join(lines)
        return embed

    def _pet_summary_line(self, guild_id: int, user_id: int) -> str:
        pet_row = self.db.get_pet(guild_id, user_id)
        if pet_row is None:
            return "Питомец отсутствует"
        pet_key, progress, _ = pet_row
        pet = PET_BY_KEY.get(pet_key)
        if pet is None:
            return "Питомец есть, но его конфиг не найден"
        return f"{pet.emoji} {pet.name} — {progress}/{PET_PROGRESS_MAX} ({pet.rarity})"

    @nextcord.slash_command(name="репутация", description="Профиль репутации и питомец.")
    async def reputation_slash(self, interaction: nextcord.Interaction, member: Optional[nextcord.Member] = None):
        if interaction.guild is None:
            return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)

        target = member or interaction.user
        view = ReputationMenuView(
            cog=self,
            guild_id=interaction.guild.id,
            profile_target_id=target.id,
            owner_id=interaction.user.id,
            page="profile",
        )
        embed = await self.build_profile_embed(
            guild=interaction.guild,
            user_id=target.id,
            viewer_id=interaction.user.id,
        )
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @nextcord.slash_command(name="репутацияадмин", description="Админ: изменить репутацию пользователю.")
    async def reputation_admin(self, interaction: nextcord.Interaction, member: nextcord.Member, delta: int):
        if interaction.guild is None:
            return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)
        if interaction.user.id != ADMIN_ID:
            return await interaction.response.send_message("Нет доступа.", ephemeral=True)

        self.db.admin_adjust_rep(interaction.guild.id, member.id, int(delta))
        new_rep = self.db.get_rep(interaction.guild.id, member.id)
        await interaction.response.send_message(
            f"✅ Репутация {member.mention} изменена на {delta}. Теперь: **{new_rep} ⭐**.",
            ephemeral=True,
        )

    @commands.Cog.listener()
    async def on_message(self, message: nextcord.Message):
        if not message.guild or message.author.bot:
            return

        if not message.reference or not message.reference.message_id:
            return

        if self.text_detector is None:
            return

        try:
            amount = self.text_detector.detect(message.content or "")
        except Exception:
            return

        if amount is None:
            return

        try:
            ref_msg = message.reference.resolved
            if ref_msg is None:
                ref_msg = await message.channel.fetch_message(message.reference.message_id)
        except Exception:
            return

        if not ref_msg or not ref_msg.author or ref_msg.author.bot:
            return

        voter_id = message.author.id
        target_id = ref_msg.author.id
        if voter_id == target_id:
            return

        ok, _reason = self.db.apply_text_vote(
            guild_id=message.guild.id,
            message_id=ref_msg.id,
            voter_id=voter_id,
            target_id=target_id,
            amount=amount,
        )

        try:
            await message.add_reaction("✅" if ok else "⛔")
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: nextcord.RawReactionActionEvent):
        if payload.guild_id is None or payload.user_id is None:
            return
        if payload.user_id == getattr(self.bot.user, "id", None):
            return

        vote = reaction_vote_from_emoji(str(payload.emoji))
        if vote is None:
            return

        guild = self.bot.get_guild(payload.guild_id)
        if guild is None:
            return

        channel = guild.get_channel(payload.channel_id)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(payload.channel_id)
            except Exception:
                return

        try:
            msg = await channel.fetch_message(payload.message_id)
        except Exception:
            return

        if not msg.author or msg.author.bot:
            return

        target_id = msg.author.id
        if target_id == payload.user_id:
            return

        self.db.apply_reaction_add(
            guild_id=payload.guild_id,
            message_id=payload.message_id,
            reactor_id=payload.user_id,
            target_id=target_id,
            amount=vote,
            emoji=str(payload.emoji),
        )

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: nextcord.RawReactionActionEvent):
        if payload.guild_id is None or payload.user_id is None:
            return
        vote = reaction_vote_from_emoji(str(payload.emoji))
        if vote is None:
            return
        self.db.apply_reaction_remove(
            guild_id=payload.guild_id,
            message_id=payload.message_id,
            reactor_id=payload.user_id,
            emoji=str(payload.emoji),
        )


def setup(bot: commands.Bot):
    bot.add_cog(ReputationCog(bot))