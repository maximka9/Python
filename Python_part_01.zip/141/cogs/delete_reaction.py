from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

import nextcord
from nextcord.ext import commands


class ReactionMute(commands.Cog):
    CATEGORY_ID = 1144656741884248134
    LOG_CHANNEL_ID = 1337500460709314661
    TIMEOUT_MINUTES = 1

    # Юникод-варианты, которые режем напрямую
    FORBIDDEN_UNICODE = {
        "🇷🇺",
        "🇺🇦",
        "🇿",
        "Z",
        "z",
        "🅉",
        "🆉",
    }

    # Точные имена кастомных эмодзи
    FORBIDDEN_CUSTOM_NAMES = {
        "z",
        "ru",
        "ua",
        "russia",
        "ukraine",
        "russian_flag",
        "ukrainian_flag",
        "flag_ru",
        "flag_ua",
        "ru_flag",
        "ua_flag",
    }

    # Подстроки в имени кастомного эмодзи
    FORBIDDEN_CUSTOM_SUBSTRINGS = {
        "flag_ru",
        "flag_ua",
        "ru_flag",
        "ua_flag",
        "russia",
        "ukraine",
        "россия",
        "украина",
        "zov",
    }

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def _get_channel_category_id(channel) -> Optional[int]:
        # У обычного текстового канала category_id есть сразу.
        # У веток (Thread) и постов форума часто category_id == None, категория у родителя.
        cid = getattr(channel, "category_id", None)
        if cid is not None:
            return cid
        parent = getattr(channel, "parent", None)
        if parent is not None:
            pcid = getattr(parent, "category_id", None)
            if pcid is not None:
                return pcid
        return None

    @classmethod
    def _classify_forbidden_emoji(cls, emoji: nextcord.PartialEmoji) -> Optional[str]:
        emoji_text = str(emoji).strip()

        if emoji_text in cls.FORBIDDEN_UNICODE:
            return f"Запрещённая реакция: {emoji_text}"

        # Иногда имя у юникод-эмодзи тоже заполнено
        name = (emoji.name or "").strip().lower()

        if name in cls.FORBIDDEN_CUSTOM_NAMES:
            return f"Запрещённая реакция: {emoji_text}"

        for token in cls.FORBIDDEN_CUSTOM_SUBSTRINGS:
            if token in name:
                return f"Запрещённая реакция: {emoji_text}"

        return None

    async def _send_log(
        self,
        guild: nextcord.Guild,
        member: nextcord.Member,
        channel,
        emoji_text: str,
        reason: str,
        punished: bool,
        removed: bool,
    ):
        log_channel = guild.get_channel(self.LOG_CHANNEL_ID)
        if log_channel is None:
            try:
                log_channel = await self.bot.fetch_channel(self.LOG_CHANNEL_ID)
            except Exception:
                return

        if not isinstance(log_channel, nextcord.abc.Messageable):
            return

        embed = nextcord.Embed(
            title="Удалена запрещённая реакция",
            color=nextcord.Color.red(),
            timestamp=datetime.now(timezone.utc),
        )
        embed.add_field(
            name="Пользователь",
            value=f"{member.mention} (`{member.id}`)",
            inline=False,
        )
        embed.add_field(
            name="Канал",
            value=getattr(channel, "mention", f"`{getattr(channel, 'id', 'неизвестно')}`"),
            inline=False,
        )
        embed.add_field(
            name="Реакция",
            value=emoji_text,
            inline=False,
        )
        embed.add_field(
            name="Удаление реакции",
            value="Да ✅" if removed else "Нет ⚠️",
            inline=False,
        )
        embed.add_field(
            name="Наказание",
            value="Мут на 1 минуту ✅" if punished else "Не удалось выдать мут ⚠️",
            inline=False,
        )
        embed.add_field(
            name="Причина",
            value=reason,
            inline=False,
        )

        try:
            await log_channel.send(embed=embed)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: nextcord.RawReactionActionEvent):
        if payload.guild_id is None:
            return

        if self.bot.user and payload.user_id == self.bot.user.id:
            return

        reason = self._classify_forbidden_emoji(payload.emoji)
        if reason is None:
            return

        guild = self.bot.get_guild(payload.guild_id)
        if guild is None:
            return

        channel = self.bot.get_channel(payload.channel_id)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(payload.channel_id)
            except Exception as e:
                print(f"[ReactionMute] Не удалось получить канал {payload.channel_id}: {type(e).__name__}: {e}")
                return

        category_id = self._get_channel_category_id(channel)
        if category_id != self.CATEGORY_ID:
            return

        member = payload.member
        if member is None:
            try:
                member = await guild.fetch_member(payload.user_id)
            except Exception as e:
                print(f"[ReactionMute] Не удалось получить участника {payload.user_id}: {type(e).__name__}: {e}")
                return

        if member.bot:
            return

        emoji_text = str(payload.emoji)
        removed = False
        punished = False

        me = guild.me
        if me is not None:
            perms = channel.permissions_for(me)
            if not perms.manage_messages:
                print(
                    "[ReactionMute] У бота нет права «Управлять сообщениями» в этом канале — "
                    "удалять чужие реакции нельзя (требуется Discord API)."
                )

        try:
            message = await channel.fetch_message(payload.message_id)
            await message.remove_reaction(payload.emoji, member)
            removed = True
        except Exception as e:
            print(
                f"[ReactionMute] Не удалось удалить реакцию {emoji_text} "
                f"у {member} в канале {getattr(channel, 'id', 'unknown')}: "
                f"{type(e).__name__}: {e}"
            )

        try:
            timeout_until = datetime.now(timezone.utc) + timedelta(minutes=self.TIMEOUT_MINUTES)
            await member.edit(timeout=timeout_until, reason=reason)
            punished = True
        except Exception as e:
            print(
                f"[ReactionMute] Не удалось выдать таймаут {member} "
                f"в guild {guild.id}: {type(e).__name__}: {e}"
            )

        await self._send_log(
            guild=guild,
            member=member,
            channel=channel,
            emoji_text=emoji_text,
            reason=reason,
            punished=punished,
            removed=removed,
        )


def setup(bot: commands.Bot):
    bot.add_cog(ReactionMute(bot))