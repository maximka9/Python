from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import nextcord
from nextcord import SelectOption, ui
from nextcord.ext import commands

from cogs.clan_membership import (
    CLAN_ROLE_ID_TO_NAME,
    HEAD_TO_CLAN_ROLE_IDS,
    HIDDEN_CLANS,
    all_visible_clan_names,
    get_member_clan_names,
)

DB_PATH = Path("data") / "reputation.sqlite3"
LOG_CHANNEL_ID = 1337500460709314661
ADMIN_ID = 428880831294078987
GUILD_IDS = [1144656738734329876]

# База рангов по кланам
CLAN_RANK_TEMPLATES: Dict[str, List[dict]] = {
    "ПТУ": [
        {"key": "ptu_1", "name": "Любитель", "emoji": "🔞", "sort_order": 10},
        {"key": "ptu_2", "name": "Не сдал Огэ", "emoji": "👶", "sort_order": 20},
        {"key": "ptu_3", "name": "Шнур абитуриент", "emoji": "🧒", "sort_order": 30},
        {"key": "ptu_4", "name": "Перваш", "emoji": "🫃", "sort_order": 40},
        {"key": "ptu_5", "name": "Работяга", "emoji": "🐜", "sort_order": 50},
        {"key": "ptu_6", "name": "Сын болгарки", "emoji": "👨‍🏭", "sort_order": 60},
        {"key": "ptu_7", "name": "Гл. Цеха", "emoji": "🦧", "sort_order": 70},
        {"key": "ptu_8", "name": "Абсолют ПТУ", "emoji": "🗽", "sort_order": 80},
    ],
    "ПЛП": [
        {"key": "plp_1", "name": "SSS-Spirt", "emoji": "✨", "sort_order": 100},
        {"key": "plp_2", "name": "A-Absinthe", "emoji": "🌿", "sort_order": 90},
        {"key": "plp_3", "name": "V-Vodka", "emoji": "❄️", "sort_order": 80},
        {"key": "plp_4", "name": "W-Whiskey", "emoji": "🥃", "sort_order": 70},
        {"key": "plp_5", "name": "R-Rum", "emoji": "🏴‍☠️", "sort_order": 60},
        {"key": "plp_6", "name": "J-Jaegermeister", "emoji": "🦌", "sort_order": 50},
        {"key": "plp_7", "name": "T-Tequila", "emoji": "🌵", "sort_order": 40},
        {"key": "plp_8", "name": "L-Liqueur", "emoji": "🍫", "sort_order": 30},
        {"key": "plp_9", "name": "C-Cider", "emoji": "🍎", "sort_order": 20},
        {"key": "plp_10", "name": "B-Beer", "emoji": "🍻", "sort_order": 10},
    ],
    "t2": [
        {"key": "t2_1", "name": "новичок", "emoji": "🍃", "sort_order": 10},
        {"key": "t2_2", "name": "НЕшкольник", "emoji": "🤓", "sort_order": 20},
        {"key": "t2_3", "name": "хацкер", "emoji": "🧑🏻‍💻", "sort_order": 30},
        {"key": "t2_4", "name": "безлимитище", "emoji": "♾️", "sort_order": 40},
    ],
    "Курага": [
        {"key": "kuraga_1", "name": "Kick", "emoji": "❌", "sort_order": 10},
        {"key": "kuraga_2", "name": "test", "emoji": "🔧", "sort_order": 20},
        {"key": "kuraga_3", "name": "newbie", "emoji": "🛠️", "sort_order": 30},
        {"key": "kuraga_4", "name": "Main", "emoji": "🌟", "sort_order": 40},
        {"key": "kuraga_5", "name": "Immortal", "emoji": "💀", "sort_order": 50},
        {"key": "kuraga_6", "name": "Dep", "emoji": "🔶", "sort_order": 60},
        {"key": "kuraga_7", "name": "Head", "emoji": "🟧", "sort_order": 70},
        {"key": "kuraga_8", "name": "Owner", "emoji": "👑", "sort_order": 80},
    ],
    "ОШХ": [
        {"key": "osh_1", "name": "Актив ОШХ", "emoji": "🌟", "sort_order": 10},
        {"key": "osh_2", "name": "Опора ОШХ", "emoji": "🪨", "sort_order": 20},
        {"key": "osh_3", "name": "Координатор", "emoji": "📡", "sort_order": 30},
        {"key": "osh_4", "name": "Заместитель штаба", "emoji": "🎖️", "sort_order": 40},
    ],
}


@dataclass(frozen=True)
class RankTemplate:
    key: str
    clan_name: str
    name: str
    emoji: str
    sort_order: int
    is_active: bool = True


def format_rank_text(name: str, emoji: str) -> str:
    name = (name or "").strip()
    emoji = (emoji or "").strip()
    return f"{name} {emoji}".strip()


def normalize_name(value: str) -> str:
    return "".join((value or "").strip().lower().split())


class ClanRankDB:
    def __init__(self, path: Path):
        self.path = path
        self._init_db()
        self.sync_templates()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path)
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA foreign_keys=ON;")
        return con

    def _table_exists(self, con: sqlite3.Connection, table_name: str) -> bool:
        cur = con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (table_name,),
        )
        return cur.fetchone() is not None

    def _user_rank_pk_columns(self, con: sqlite3.Connection) -> List[str]:
        if not self._table_exists(con, "user_clan_ranks"):
            return []

        cur = con.execute("PRAGMA table_info(user_clan_ranks)")
        rows = cur.fetchall()
        pk_rows = [(int(row[5]), str(row[1])) for row in rows if int(row[5]) > 0]
        pk_rows.sort(key=lambda item: item[0])
        return [name for _, name in pk_rows]

    def _create_user_ranks_table(self, con: sqlite3.Connection, table_name: str):
        con.execute(
            f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                clan_name TEXT NOT NULL,
                rank_key TEXT NOT NULL,
                issued_by INTEGER NOT NULL,
                issued_at TEXT NOT NULL,
                PRIMARY KEY (guild_id, user_id, clan_name),
                FOREIGN KEY (rank_key) REFERENCES clan_rank_templates(rank_key)
            )
            """
        )

    def _ensure_user_ranks_table(self, con: sqlite3.Connection):
        desired_pk = ["guild_id", "user_id", "clan_name"]

        if not self._table_exists(con, "user_clan_ranks"):
            self._create_user_ranks_table(con, "user_clan_ranks")
            return

        current_pk = self._user_rank_pk_columns(con)
        if current_pk == desired_pk:
            return

        if self._table_exists(con, "user_clan_ranks_new"):
            con.execute("DROP TABLE user_clan_ranks_new")

        self._create_user_ranks_table(con, "user_clan_ranks_new")

        con.execute(
            """
            INSERT OR REPLACE INTO user_clan_ranks_new(
                guild_id, user_id, clan_name, rank_key, issued_by, issued_at
            )
            SELECT guild_id, user_id, clan_name, rank_key, issued_by, issued_at
            FROM user_clan_ranks
            """
        )

        con.execute("DROP TABLE user_clan_ranks")
        con.execute("ALTER TABLE user_clan_ranks_new RENAME TO user_clan_ranks")

    def _init_db(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS clan_rank_templates (
                    rank_key TEXT PRIMARY KEY,
                    clan_name TEXT NOT NULL,
                    name TEXT NOT NULL,
                    emoji TEXT NOT NULL DEFAULT '',
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1
                )
                """
            )
            self._ensure_user_ranks_table(con)
            con.commit()

    def sync_templates(self):
        with self._connect() as con:
            for clan_name, ranks in CLAN_RANK_TEMPLATES.items():
                if clan_name in HIDDEN_CLANS:
                    continue

                for item in ranks:
                    con.execute(
                        """
                        INSERT INTO clan_rank_templates(rank_key, clan_name, name, emoji, sort_order, is_active)
                        VALUES(?, ?, ?, ?, ?, 1)
                        ON CONFLICT(rank_key) DO UPDATE SET
                            clan_name=excluded.clan_name,
                            name=excluded.name,
                            emoji=excluded.emoji,
                            sort_order=excluded.sort_order,
                            is_active=1
                        """,
                        (
                            item["key"],
                            clan_name,
                            item["name"],
                            item.get("emoji", ""),
                            int(item["sort_order"]),
                        ),
                    )
            con.commit()

    def get_templates_for_clan(self, clan_name: str) -> List[RankTemplate]:
        if clan_name in HIDDEN_CLANS:
            return []

        with self._connect() as con:
            cur = con.execute(
                """
                SELECT rank_key, clan_name, name, emoji, sort_order, is_active
                FROM clan_rank_templates
                WHERE clan_name=? AND is_active=1
                ORDER BY sort_order DESC, name COLLATE NOCASE ASC
                """,
                (clan_name,),
            )
            return [
                RankTemplate(
                    key=str(row[0]),
                    clan_name=str(row[1]),
                    name=str(row[2]),
                    emoji=str(row[3]),
                    sort_order=int(row[4]),
                    is_active=bool(row[5]),
                )
                for row in cur.fetchall()
            ]

    def find_template(self, value: str, clan_name: str) -> Optional[RankTemplate]:
        value_norm = (value or "").strip().lower()
        templates = self.get_templates_for_clan(clan_name)

        for index, tpl in enumerate(templates, start=1):
            candidates = {
                str(index),
                tpl.key.lower(),
                tpl.name.lower(),
                format_rank_text(tpl.name, tpl.emoji).lower(),
                f"{tpl.emoji} {tpl.name}".strip().lower(),
            }
            if value_norm in candidates:
                return tpl
        return None

    def get_user_rank_rows(self, guild_id: int, user_id: int):
        with self._connect() as con:
            cur = con.execute(
                """
                SELECT
                    u.clan_name,
                    u.rank_key,
                    u.issued_by,
                    u.issued_at,
                    COALESCE(t.name, u.rank_key) AS rank_name,
                    COALESCE(t.emoji, '') AS emoji,
                    COALESCE(t.sort_order, 0) AS sort_order
                FROM user_clan_ranks u
                LEFT JOIN clan_rank_templates t ON t.rank_key = u.rank_key
                WHERE u.guild_id=? AND u.user_id=?
                ORDER BY u.clan_name COLLATE NOCASE ASC, sort_order DESC, rank_name COLLATE NOCASE ASC
                """,
                (guild_id, user_id),
            )
            return cur.fetchall()

    def get_user_rank_row(self, guild_id: int, user_id: int, clan_name: Optional[str] = None):
        rows = self.get_user_rank_rows(guild_id, user_id)
        if clan_name is None:
            return rows[0] if rows else None

        clan_norm = normalize_name(clan_name)
        for row in rows:
            if normalize_name(str(row[0])) == clan_norm:
                return row
        return None

    def get_user_rank_text(
        self,
        guild_id: int,
        user_id: int,
        clan_name: Optional[str] = None,
    ) -> Optional[str]:
        if clan_name is not None:
            row = self.get_user_rank_row(guild_id, user_id, clan_name=clan_name)
            if not row:
                return None
            return format_rank_text(str(row[4]), str(row[5]))

        rows = self.get_user_rank_rows(guild_id, user_id)
        if not rows:
            return None

        texts = [
            format_rank_text(str(row[4]), str(row[5]))
            for row in rows
            if str(row[0]) not in HIDDEN_CLANS
        ]
        if not texts:
            return None
        if len(texts) == 1:
            return texts[0]
        return " / ".join(texts)

    def get_user_rank_map(self, guild_id: int, user_id: int) -> Dict[str, str]:
        result: Dict[str, str] = {}
        for row in self.get_user_rank_rows(guild_id, user_id):
            clan_name = str(row[0])
            if clan_name in HIDDEN_CLANS:
                continue
            result[clan_name] = format_rank_text(str(row[4]), str(row[5]))
        return result

    def assign_rank(
        self,
        guild_id: int,
        user_id: int,
        clan_name: str,
        rank_key: str,
        issued_by: int,
    ):
        issued_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._connect() as con:
            con.execute(
                """
                INSERT INTO user_clan_ranks(guild_id, user_id, clan_name, rank_key, issued_by, issued_at)
                VALUES(?, ?, ?, ?, ?, ?)
                ON CONFLICT(guild_id, user_id, clan_name) DO UPDATE SET
                    rank_key=excluded.rank_key,
                    issued_by=excluded.issued_by,
                    issued_at=excluded.issued_at
                """,
                (guild_id, user_id, clan_name, rank_key, issued_by, issued_at),
            )
            con.commit()

    def remove_rank(self, guild_id: int, user_id: int, clan_name: Optional[str] = None):
        with self._connect() as con:
            if clan_name is None:
                con.execute(
                    "DELETE FROM user_clan_ranks WHERE guild_id=? AND user_id=?",
                    (guild_id, user_id),
                )
            else:
                con.execute(
                    "DELETE FROM user_clan_ranks WHERE guild_id=? AND user_id=? AND clan_name=?",
                    (guild_id, user_id, clan_name),
                )
            con.commit()

    def remove_missing_clans(self, guild_id: int, user_id: int, actual_clans: List[str]):
        with self._connect() as con:
            if actual_clans:
                placeholders = ", ".join("?" for _ in actual_clans)
                params = [guild_id, user_id, *actual_clans]
                con.execute(
                    f"""
                    DELETE FROM user_clan_ranks
                    WHERE guild_id=? AND user_id=?
                      AND clan_name NOT IN ({placeholders})
                    """,
                    params,
                )
            else:
                con.execute(
                    "DELETE FROM user_clan_ranks WHERE guild_id=? AND user_id=?",
                    (guild_id, user_id),
                )
            con.commit()


def _embed_ranks_list(clan_name: str, templates: List[RankTemplate]) -> nextcord.Embed:
    lines = [
        f"**{idx}.** {format_rank_text(tpl.name, tpl.emoji)}"
        for idx, tpl in enumerate(templates, start=1)
    ]
    return nextcord.Embed(
        title=f"Ранги клана {clan_name}",
        description="\n".join(lines),
        color=nextcord.Color.blurple(),
    )


class ClanPickTemplateView(ui.View):
    """Список шаблонов рангов — выбор клана автора команды."""

    def __init__(self, cog: "ClanRankCog", invoker_id: int, clans: List[str]):
        super().__init__(timeout=180)
        self.cog = cog
        self.invoker_id = invoker_id
        opts = [SelectOption(label=c[:100], value=c) for c in clans[:25]]
        self._select = ui.Select(placeholder="Выберите клан", min_values=1, max_values=1, options=opts)
        self._select.callback = self._on_pick
        self.add_item(self._select)

    async def interaction_check(self, interaction: nextcord.Interaction) -> bool:
        if interaction.user.id != self.invoker_id:
            await interaction.response.send_message("Это меню вызвано не тобой.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            item.disabled = True

    async def _on_pick(self, interaction: nextcord.Interaction):
        clan = self._select.values[0]
        templates = self.cog.db.get_templates_for_clan(clan)
        if not templates:
            await interaction.response.send_message(
                f"Для клана **{clan}** пока нет настроенных рангов.",
                ephemeral=True,
            )
            return
        embed = _embed_ranks_list(clan, templates)
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(content=None, embed=embed, view=self)


def _rank_select_options(templates: List[RankTemplate]) -> List[SelectOption]:
    opts: List[SelectOption] = []
    for tpl in templates[:25]:
        label = format_rank_text(tpl.name, tpl.emoji)
        if len(label) > 100:
            label = label[:97] + "..."
        opts.append(SelectOption(label=label, value=tpl.key))
    return opts


class RankGrantPickView(ui.View):
    """Второй шаг: выбор ранга по ключу шаблона (после выбора клана)."""

    def __init__(self, cog: "ClanRankCog", invoker_id: int, target: nextcord.Member, clan_name: str):
        super().__init__(timeout=180)
        self.cog = cog
        self.invoker_id = invoker_id
        self.target = target
        self.clan_name = clan_name
        templates = cog.db.get_templates_for_clan(clan_name)
        opts = _rank_select_options(templates)
        self._rank_select = ui.Select(
            placeholder="Выберите ранг",
            min_values=1,
            max_values=1,
            options=opts,
        )
        self._rank_select.callback = self._on_rank_pick
        self.add_item(self._rank_select)

    async def interaction_check(self, interaction: nextcord.Interaction) -> bool:
        if interaction.user.id != self.invoker_id:
            await interaction.response.send_message("Это меню вызвано не тобой.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            item.disabled = True

    async def _on_rank_pick(self, interaction: nextcord.Interaction):
        rank_key = self._rank_select.values[0]
        for item in self.children:
            item.disabled = True
        await self.cog._finalize_grant_rank_by_key(interaction, self.target, self.clan_name, rank_key)


class ClanPickGrantView(ui.View):
    """Шаг 1: выбор клана; затем показывается RankGrantPickView."""

    def __init__(self, cog: "ClanRankCog", invoker_id: int, target: nextcord.Member, manageable: List[str]):
        super().__init__(timeout=180)
        self.cog = cog
        self.invoker_id = invoker_id
        self.target = target
        opts = [SelectOption(label=c[:100], value=c) for c in manageable[:25]]
        self._select = ui.Select(placeholder="Выберите клан", min_values=1, max_values=1, options=opts)
        self._select.callback = self._on_pick
        self.add_item(self._select)

    async def interaction_check(self, interaction: nextcord.Interaction) -> bool:
        if interaction.user.id != self.invoker_id:
            await interaction.response.send_message("Это меню вызвано не тобой.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            item.disabled = True

    async def _on_pick(self, interaction: nextcord.Interaction):
        clan = self._select.values[0]
        target = self.target

        if clan not in set(get_member_clan_names(target)):
            await interaction.response.send_message(
                f"{target.mention} не состоит в клане **{clan}**.",
                ephemeral=True,
            )
            return

        templates = self.cog.db.get_templates_for_clan(clan)
        if not templates:
            await interaction.response.send_message(
                f"Для клана **{clan}** пока нет настроенных рангов.",
                ephemeral=True,
            )
            return

        for item in self.children:
            item.disabled = True

        extra = f"\n_(В списке первые 25 из {len(templates)} рангов.)_" if len(templates) > 25 else ""
        rank_view = RankGrantPickView(self.cog, self.invoker_id, target, clan)
        await interaction.response.edit_message(
            content=f"Клан **{clan}**. Выбери ранг для {target.mention}:{extra}",
            embed=None,
            view=rank_view,
        )


class ClanPickRemoveView(ui.View):
    def __init__(self, cog: "ClanRankCog", invoker_id: int, target: nextcord.Member, manageable: List[str]):
        super().__init__(timeout=180)
        self.cog = cog
        self.invoker_id = invoker_id
        self.target = target
        opts = [SelectOption(label=c[:100], value=c) for c in manageable[:25]]
        self._select = ui.Select(placeholder="Выберите клан", min_values=1, max_values=1, options=opts)
        self._select.callback = self._on_pick
        self.add_item(self._select)

    async def interaction_check(self, interaction: nextcord.Interaction) -> bool:
        if interaction.user.id != self.invoker_id:
            await interaction.response.send_message("Это меню вызвано не тобой.", ephemeral=True)
            return False
        return True

    async def on_timeout(self) -> None:
        for item in self.children:
            item.disabled = True

    async def _on_pick(self, interaction: nextcord.Interaction):
        clan = self._select.values[0]
        for item in self.children:
            item.disabled = True
        await self.cog._finalize_remove_rank(interaction, self.target, clan)


class ClanRankCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.db = ClanRankDB(DB_PATH)

    def _all_visible_clans(self) -> List[str]:
        return all_visible_clan_names()

    def _resolve_clan_name(self, value: Optional[str]) -> Optional[str]:
        if not value:
            return None

        value_norm = normalize_name(value)
        for clan_name in self._all_visible_clans():
            if value_norm == normalize_name(clan_name):
                return clan_name
        return None

    def _get_member_clans(
        self,
        member: nextcord.Member,
        *,
        include_hidden: bool = False,
    ) -> List[str]:
        return get_member_clan_names(member, include_hidden=include_hidden)

    def _get_actor_managed_clans(self, actor: nextcord.Member) -> List[str]:
        if actor.id == ADMIN_ID:
            return self._all_visible_clans()

        actor_role_ids = {role.id for role in actor.roles}
        clans: List[str] = []

        for head_role_id, clan_role_id in HEAD_TO_CLAN_ROLE_IDS.items():
            if head_role_id not in actor_role_ids:
                continue
            clan_name = CLAN_ROLE_ID_TO_NAME.get(clan_role_id)
            if not clan_name or clan_name in HIDDEN_CLANS:
                continue
            if clan_name not in clans:
                clans.append(clan_name)

        return sorted(clans, key=lambda x: x.lower())

    def _actor_can_manage_clan(
        self,
        actor: nextcord.Member,
        target_clan_name: Optional[str],
    ) -> bool:
        if target_clan_name is None:
            return False
        if actor.id == ADMIN_ID:
            return True
        return target_clan_name in self._get_actor_managed_clans(actor)

    async def _send_log(self, guild: nextcord.Guild, text: str):
        channel = guild.get_channel(LOG_CHANNEL_ID)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(LOG_CHANNEL_ID)
            except Exception:
                return

        if not isinstance(channel, nextcord.abc.Messageable):
            return

        try:
            await channel.send(text)
        except Exception:
            pass

    def _cleanup_member_rank_state(
        self,
        guild: nextcord.Guild,
        member: nextcord.Member,
    ):
        actual_clans = self._get_member_clans(member, include_hidden=True)
        self.db.remove_missing_clans(guild.id, member.id, actual_clans)

    def get_user_rank_map(
        self,
        guild: nextcord.Guild,
        member: nextcord.Member,
    ) -> Dict[str, str]:
        self._cleanup_member_rank_state(guild, member)
        allowed_clans = set(self._get_member_clans(member))
        raw_map = self.db.get_user_rank_map(guild.id, member.id)

        return {
            clan_name: rank_text
            for clan_name, rank_text in raw_map.items()
            if clan_name in allowed_clans
        }

    def get_user_rank_text(
        self,
        guild: nextcord.Guild,
        member: nextcord.Member,
        clan_name: Optional[str] = None,
    ) -> Optional[str]:
        rank_map = self.get_user_rank_map(guild, member)

        if clan_name is not None:
            clan_name = self._resolve_clan_name(clan_name) or clan_name
            return rank_map.get(clan_name)

        if not rank_map:
            return None
        if len(rank_map) == 1:
            return next(iter(rank_map.values()))
        return " / ".join(rank_map[clan] for clan in sorted(rank_map.keys(), key=lambda x: x.lower()))

    def _grant_rank_pipeline_by_key(
        self,
        guild: nextcord.Guild,
        invoker: nextcord.Member,
        target: nextcord.Member,
        clan_name: str,
        rank_key: str,
    ) -> Tuple[bool, str, Optional[str]]:
        """Выдача по ключу шаблона (из Select)."""
        manageable = set(self._get_actor_managed_clans(invoker))
        if clan_name not in manageable:
            return False, "Нет прав на выбранный клан.", None

        if clan_name not in set(get_member_clan_names(target)):
            return False, f"{target.mention} не состоит в клане **{clan_name}**.", None

        template: Optional[RankTemplate] = None
        for t in self.db.get_templates_for_clan(clan_name):
            if t.key == rank_key:
                template = t
                break
        if template is None:
            return False, "Выбранный ранг недоступен для этого клана.", None

        self.db.assign_rank(
            guild_id=guild.id,
            user_id=target.id,
            clan_name=clan_name,
            rank_key=template.key,
            issued_by=invoker.id,
        )
        rank_text = format_rank_text(template.name, template.emoji)
        user_msg = f"✅ {target.mention} выдан клановый ранг **{rank_text}** в клане **{clan_name}**."
        log_msg = (
            f"🏷️ **{invoker.display_name}** выдал ранг **{rank_text}** "
            f"пользователю **{target.display_name}** в клане **{clan_name}**"
        )
        return True, user_msg, log_msg

    def _remove_rank_pipeline(
        self,
        guild: nextcord.Guild,
        invoker: nextcord.Member,
        target: nextcord.Member,
        clan_name: str,
    ) -> Tuple[bool, str, Optional[str]]:
        manageable = set(self._get_actor_managed_clans(invoker))
        if clan_name not in manageable:
            return False, "Нет прав на выбранный клан.", None

        if clan_name not in set(get_member_clan_names(target)):
            return False, f"{target.mention} не состоит в клане **{clan_name}**.", None

        current_rank = self.get_user_rank_text(guild, target, clan_name=clan_name)
        if current_rank is None:
            return False, f"У участника нет кланового ранга в клане **{clan_name}**.", None

        self.db.remove_rank(guild.id, target.id, clan_name=clan_name)
        user_msg = f"✅ У {target.mention} снят клановый ранг **{current_rank}** в клане **{clan_name}**."
        log_msg = (
            f"🗑️ **{invoker.display_name}** снял ранг **{current_rank}** "
            f"у пользователя **{target.display_name}** в клане **{clan_name}**"
        )
        return True, user_msg, log_msg

    async def _finalize_grant_rank_by_key(
        self,
        interaction: nextcord.Interaction,
        target: nextcord.Member,
        clan_name: str,
        rank_key: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        invoker = interaction.user
        if guild is None or not isinstance(invoker, nextcord.Member):
            await interaction.followup.send("Ошибка контекста.", ephemeral=True)
            return

        ok, msg, log_line = self._grant_rank_pipeline_by_key(guild, invoker, target, clan_name, rank_key)
        await interaction.followup.send(msg, ephemeral=True)
        if ok and log_line:
            await self._send_log(guild, log_line)

    async def _finalize_remove_rank(
        self,
        interaction: nextcord.Interaction,
        target: nextcord.Member,
        clan_name: str,
    ) -> None:
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        invoker = interaction.user
        if guild is None or not isinstance(invoker, nextcord.Member):
            await interaction.followup.send("Ошибка контекста.", ephemeral=True)
            return

        ok, msg, log_line = self._remove_rank_pipeline(guild, invoker, target, clan_name)
        await interaction.followup.send(msg, ephemeral=True)
        if ok and log_line:
            await self._send_log(guild, log_line)

    @nextcord.slash_command(
        name="реп",
        description="Клановые ранги",
        guild_ids=GUILD_IDS,
    )
    async def rep_group(self, interaction: nextcord.Interaction):
        await interaction.response.send_message(
            "Используй подкоманды: `/реп ранги`, `/реп ранг`, `/реп выдатьранг` (клан и ранг — списками), `/реп снятьранг`",
            ephemeral=True,
        )

    @rep_group.subcommand(name="ранги", description="Показать доступные клановые ранги")
    async def rep_ranks(self, interaction: nextcord.Interaction):
        if interaction.guild is None:
            return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)

        invoker = interaction.user
        if not isinstance(invoker, nextcord.Member):
            return await interaction.response.send_message("Не удалось определить участника.", ephemeral=True)

        my_clans = get_member_clan_names(invoker)
        if not my_clans:
            return await interaction.response.send_message(
                "У тебя не найден клан. Список рангов недоступен; выбрать клан вручную нельзя.",
                ephemeral=True,
            )

        if len(my_clans) == 1:
            c = my_clans[0]
            templates = self.db.get_templates_for_clan(c)
            if not templates:
                return await interaction.response.send_message(
                    f"Для клана **{c}** пока нет настроенных рангов.",
                    ephemeral=True,
                )
            embed = _embed_ranks_list(c, templates)
            return await interaction.response.send_message(embed=embed, ephemeral=True)

        view = ClanPickTemplateView(self, invoker.id, my_clans)
        await interaction.response.send_message(
            "Выбери клан (по твоим ролям на сервере):",
            view=view,
            ephemeral=True,
        )

    @rep_group.subcommand(name="ранг", description="Посмотреть клановые ранги участника")
    async def rep_rank(
        self,
        interaction: nextcord.Interaction,
        member: Optional[nextcord.Member] = None,
    ):
        if interaction.guild is None:
            return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)

        target = member or interaction.user
        if not isinstance(target, nextcord.Member):
            return await interaction.response.send_message("Не удалось определить участника.", ephemeral=True)

        clans = self._get_member_clans(target)
        if not clans:
            return await interaction.response.send_message(
                f"{target.mention} не состоит в клане.",
                ephemeral=True,
            )

        rank_map = self.get_user_rank_map(interaction.guild, target)

        lines = [
            f"**{target.display_name}**",
            f"Кланы: **{', '.join(clans)}**",
        ]

        if rank_map:
            lines.append("")
            lines.append("**Клановые ранги:**")
            for clan_name in sorted(rank_map.keys(), key=lambda x: x.lower()):
                lines.append(f"• **{clan_name}** — {rank_map[clan_name]}")

        await interaction.response.send_message("\n".join(lines), ephemeral=True)

    @rep_group.subcommand(name="выдатьранг", description="Выдать клановый ранг участнику (клан и ранг — в списках)")
    async def rep_grant_rank(self, interaction: nextcord.Interaction, member: nextcord.Member):
        if interaction.guild is None:
            return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)

        invoker = interaction.user
        if not isinstance(invoker, nextcord.Member):
            return await interaction.response.send_message("Не удалось определить участника.", ephemeral=True)

        manageable = self._get_actor_managed_clans(invoker)
        if not manageable:
            return await interaction.response.send_message(
                "У тебя не найден клан главы (или ты не админ), поэтому выдать ранг нельзя. Клан вручную указать нельзя.",
                ephemeral=True,
            )

        if len(manageable) > 1:
            view = ClanPickGrantView(self, invoker.id, member, manageable)
            await interaction.response.send_message(
                "Сначала выбери клан (твои управляемые кланы), затем — ранг из списка:",
                view=view,
                ephemeral=True,
            )
            return

        clan_name = manageable[0]
        if clan_name not in set(get_member_clan_names(member)):
            return await interaction.response.send_message(
                f"{member.mention} не состоит в клане **{clan_name}**.",
                ephemeral=True,
            )

        templates = self.db.get_templates_for_clan(clan_name)
        if not templates:
            return await interaction.response.send_message(
                f"Для клана **{clan_name}** пока нет настроенных рангов.",
                ephemeral=True,
            )

        tpls = templates
        extra = f"\n_(В списке первые 25 из {len(tpls)} рангов.)_" if len(tpls) > 25 else ""
        rank_view = RankGrantPickView(self, invoker.id, member, clan_name)
        await interaction.response.send_message(
            f"Клан **{clan_name}**. Выбери ранг для {member.mention}:{extra}",
            view=rank_view,
            ephemeral=True,
        )

    @rep_group.subcommand(name="снятьранг", description="Снять клановый ранг у участника")
    async def rep_remove_rank(self, interaction: nextcord.Interaction, member: nextcord.Member):
        if interaction.guild is None:
            return await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)

        invoker = interaction.user
        if not isinstance(invoker, nextcord.Member):
            return await interaction.response.send_message("Не удалось определить участника.", ephemeral=True)

        manageable = self._get_actor_managed_clans(invoker)
        if not manageable:
            return await interaction.response.send_message(
                "У тебя не найден клан главы (или ты не админ), поэтому снять ранг нельзя. Клан вручную указать нельзя.",
                ephemeral=True,
            )

        if len(manageable) > 1:
            view = ClanPickRemoveView(self, invoker.id, member, manageable)
            await interaction.response.send_message(
                "Выбери клан, в котором снимается ранг (твои управляемые кланы):",
                view=view,
                ephemeral=True,
            )
            return

        clan_name = manageable[0]
        ok, msg, log_line = self._remove_rank_pipeline(interaction.guild, invoker, member, clan_name)
        await interaction.response.send_message(msg, ephemeral=True)
        if ok and log_line:
            await self._send_log(interaction.guild, log_line)

    @commands.Cog.listener()
    async def on_member_update(self, before: nextcord.Member, after: nextcord.Member):
        before_clans = set(self._get_member_clans(before, include_hidden=True))
        after_clans = set(self._get_member_clans(after, include_hidden=True))

        lost_clans = before_clans - after_clans
        if not lost_clans:
            return

        for clan_name in lost_clans:
            self.db.remove_rank(after.guild.id, after.id, clan_name=clan_name)

    @commands.Cog.listener()
    async def on_member_remove(self, member: nextcord.Member):
        self.db.remove_rank(member.guild.id, member.id)


def setup(bot: commands.Bot):
    bot.add_cog(ClanRankCog(bot))