import nextcord
from nextcord.ui import Select, View, Button
from nextcord import Interaction
from nextcord.ext import commands

MODERATOR_ROLE = ["event-менеджер", "support", "DS Support"]
VOICE_CATEGORY_ID = 1373002617105678456  # Замените на ID вашей категории


def has_any_role(*role_names):
    async def predicate(ctx):
        if not ctx.guild:
            return False
        # Проверяем, есть ли у пользователя хотя бы одна из ролей
        return any(role.name in role_names for role in ctx.author.roles)
    return commands.check(predicate)






class EventSelect(Select):
    def __init__(self):
        options = [
            nextcord.SelectOption(label='Крокодил',emoji="🐊", description='Голосовой канал для игры', value='crocodile'),
            nextcord.SelectOption(label='Викторина',emoji="❓", description='Канал для вопросов', value='quiz'),
            nextcord.SelectOption(label='Караоке',emoji="🎤", description='Музыкальный канал', value='karaoke'),
            nextcord.SelectOption(label='Монополия', emoji="🎩", description="Канал для Монополии", value='monopoly',)

        ]
        super().__init__(
            placeholder="Выберите тип ивента...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: Interaction):
        selected_event = self.values[0]
        event_id = 1296157395935957023 #ID для роли спортивный
        event_name = {
            'crocodile': '🐊│ Крокодил',
            'quiz': '❓│ Викторина',
            'karaoke': '🎤│ Караоке',
            'monopoly': '🎩| Монополия'

        }.get(selected_event, 'Ивент')

        category = interaction.guild.get_channel(VOICE_CATEGORY_ID)
        if not category or not isinstance(category, nextcord.CategoryChannel):
            return await interaction.response.send_message("❌ Категория не найдена!", ephemeral=True)

        try:
            # Создаем канал с датой в названии
            channel_name_event = f"{event_name}"
            voice_channel_event = await category.create_voice_channel(name=channel_name_event)
            text_event_chanel = await voice_channel_event.send(f"<@&{event_id}> начался ивент {voice_channel_event.mention}")

            # Создаем кнопку для удаления
            async def delete_callback(interaction: Interaction):
                if MODERATOR_ROLE not in [role.name for role in interaction.user.roles]:
                    return await interaction.response.send_message(
                        "❌ У вас нет прав для удаления канала!",
                        ephemeral=True
                    )
                await voice_channel_event.delete()
                await interaction.response.send_message(
                    f"✅ Канал {channel_name_event} удалён!",
                    ephemeral=True
                )

            delete_button = Button(
                style=nextcord.ButtonStyle.danger,
                label="Удалить канал",
                emoji="🗑️"
            )
            delete_button.callback = delete_callback

            view = View()
            view.add_item(delete_button)

            await interaction.response.send_message(
                f"✅ Создан канал {voice_channel_event.mention}",
                view=view,
                ephemeral=True
            )

        except Exception as e:
            await interaction.response.send_message(
                f"❌ Ошибка: {str(e)}",
                ephemeral=True
            )


class EventManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @nextcord.slash_command(name='event', description="Создать голосовой канал для ивента")
    @has_any_role(*MODERATOR_ROLE)
    async def event_command(self, interaction: Interaction):

        view = View()
        view.add_item(EventSelect())

        await interaction.response.send_message(
            "🎮 Выберите тип ивента:",
            view=view,
            ephemeral=False
        )


def setup(bot):
    bot.add_cog(EventManager(bot))