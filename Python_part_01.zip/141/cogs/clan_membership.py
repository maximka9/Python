"""
Единая логика: какие кланы у участника (роли клана, глава, алиасы вроде PLP OLD).
Используется в resp.py и clan_ranks.py.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional, Set

import nextcord

# role_id главы -> role_id клана
HEAD_TO_CLAN_ROLE_IDS: Dict[int, int] = {
    1407063540132614386: 1407064359888359425,  # ОШХ
    1407040453207003146: 1407040431346290798,  # 414
    1459275022836437176: 1453513363886833704,  # Танкисты
    1332010040940433449: 1332009885910696006,  # Курага
    1406591987297030144: 1406594325676298240,  # t2
    1302761133895319552: 1302754241399488613,  # ПТУ
    1396584391324467260: 1301666317560053780,  # 141
    1355877745472831488: 1355877106034409783,  # ПЛП
    1477690821653434398: 1471167241448984709,  # Воркер
    1482013652545572915: 1482013193302966382,  # 139
}

# role_id клана -> отображаемое имя клана
CLAN_ROLE_ID_TO_NAME: Dict[int, str] = {
    1355877106034409783: "ПЛП",
    1332009885910696006: "Курага",
    1301666317560053780: "141",
    1302754241399488613: "ПТУ",
    1406594325676298240: "t2",
    1407040431346290798: "414",
    1407064359888359425: "ОШХ",
    1453513363886833704: "Танкисты",
    1471167241448984709: "Воркер",
    1482013193302966382: "139",
}

# Доп. роли → тот же клан, что и обычная роль (например PLP OLD → ПЛП).
# Можно задать в .env: PLP_OLD_ROLE_ID=...
ROLE_ALIASES_FOR_CLAN: Dict[int, str] = {}


def _env_int(name: str) -> Optional[int]:
    raw = os.getenv(name, "").strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


_plp_old = _env_int("PLP_OLD_ROLE_ID")
if _plp_old is not None:
    ROLE_ALIASES_FOR_CLAN[_plp_old] = "ПЛП"

HIDDEN_CLANS: Set[str] = {"141"}


def _add_unique(out: List[str], seen: Set[str], name: str, *, include_hidden: bool) -> None:
    if not name:
        return
    if not include_hidden and name in HIDDEN_CLANS:
        return
    if name in seen:
        return
    seen.add(name)
    out.append(name)


def get_member_clan_names(member: Optional[nextcord.Member], *, include_hidden: bool = False) -> List[str]:
    """
    Все кланы участника: обычные клановые роли, роль главы (как клан), алиасы (PLP OLD → ПЛП).
    Без дубликатов, отсортировано по имени.
    """
    if member is None:
        return []

    seen: Set[str] = set()
    out: List[str] = []
    role_ids = {r.id for r in member.roles}

    for rid, clan_name in CLAN_ROLE_ID_TO_NAME.items():
        if rid in role_ids:
            _add_unique(out, seen, clan_name, include_hidden=include_hidden)

    for head_rid, clan_rid in HEAD_TO_CLAN_ROLE_IDS.items():
        if head_rid not in role_ids:
            continue
        clan_name = CLAN_ROLE_ID_TO_NAME.get(clan_rid)
        if clan_name:
            _add_unique(out, seen, clan_name, include_hidden=include_hidden)

    for alias_rid, canon in ROLE_ALIASES_FOR_CLAN.items():
        if alias_rid in role_ids:
            _add_unique(out, seen, canon, include_hidden=include_hidden)

    return sorted(out, key=lambda x: x.lower())


def get_head_clan_names(member: Optional[nextcord.Member]) -> Set[str]:
    """В каких кланах пользователь — глава (по роли главы)."""
    if member is None:
        return set()
    role_ids = {r.id for r in member.roles}
    names: Set[str] = set()
    for head_rid, clan_rid in HEAD_TO_CLAN_ROLE_IDS.items():
        if head_rid in role_ids:
            n = CLAN_ROLE_ID_TO_NAME.get(clan_rid)
            if n:
                names.add(n)
    return names


def chief_suffix_for_clan(member: Optional[nextcord.Member], clan_name: str) -> str:
    """Доп. пометка для главы (не заменяет клановую роль)."""
    if member and clan_name in get_head_clan_names(member):
        return " · 👑"
    return ""


def all_visible_clan_names() -> List[str]:
    clans = {n for n in CLAN_ROLE_ID_TO_NAME.values() if n not in HIDDEN_CLANS}
    return sorted(clans, key=lambda x: x.lower())
