from __future__ import annotations

import os
import sqlite3
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import nextcord
from nextcord.ext import commands
from nextcord import Interaction, Embed, SelectOption
from nextcord.ui import View, Button, Select


# ================== НАСТРОЙКИ ==================
# Клановые роли (это и есть "клановые")
CLANS = {
    "ПЛП": 1355877106034409783,
    "Курага": 1332009885910696006,
    "141": 1301666317560053780,
    "ПТУ": 1302754241399488613,
    "t2": 1406594325676298240,
    "Pivo": 1406596830518706277,
    "Огузок": 1407034466429308989,
    "414": 1407040431346290798,
    "ОШХ": 1407064359888359425,
    "Танкисты": 1453513363886833704,
}

MEMBERS_PER_PAGE = 10

# куда слать ежедневный отчёт о доставке/недоставке
REPORT_CHANNEL_ID = 1337500460709314661

# БД для "лишних клановых ролей"
CLAN_DB_PATH = os.getenv("CLAN_DB_PATH", "data/clan_cleanup.db")

MIN_CLAN_ROLES = 3
COOLDOWN_DAYS = 3  # повторное DM-уведомление одному человеку не чаще чем раз в N дней

# custom_id для персистентного select в DM
CID_CLAN_PICK = "clan_cleanup:pick"
# ===============================================


# ==========================
# DB
# ==========================
class ClanCleanupDB:
    def __init__(self, path: str):
        self.path = path
        parent = os.path.dirname(self.path)
        if parent:
            os.makedirs(parent, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL;")
        con.execute("PRAGMA synchronous=NORMAL;")
        return con

    async def init(self) -> None:
        def _sync():
            con = self._connect()
            try:
                con.execute("""
                    CREATE TABLE IF NOT EXISTS reminders(
                        guild_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        last_sent_at TEXT NOT NULL,
                        PRIMARY KEY (guild_id, user_id)
                    );
                """)
                con.execute("""
                    CREATE TABLE IF NOT EXISTS pending(
                        message_id INTEGER PRIMARY KEY,
                        guild_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        role_ids TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        status TEXT NOT NULL DEFAULT 'open'
                    );
                """)
                con.execute("""
                    CREATE TABLE IF NOT EXISTS dm_log(
                        day TEXT NOT NULL,
                        guild_id INTEGER NOT NULL,
                        user_id INTEGER NOT NULL,
                        delivered INTEGER NOT NULL,
                        error TEXT,
                        PRIMARY KEY(day, guild_id, user_id)
                    );
                """)
                con.commit()
            finally:
                con.close()

        await asyncio.to_thread(_sync)

    async def should_send(self, guild_id: int, user_id: int, cooldown_days: int) -> bool:
        def _sync() -> bool:
            con = self._connect()
            try:
                row = con.execute(
                    "SELECT last_sent_at FROM reminders WHERE guild_id=? AND user_id=?",
                    (guild_id, user_id),
                ).fetchone()
                if not row:
                    return True
                last = datetime.fromisoformat(row["last_sent_at"])
                return datetime.utcnow() - last >= timedelta(days=cooldown_days)
            finally:
                con.close()

        return await asyncio.to_thread(_sync)

    async def mark_sent(self, guild_id: int, user_id: int) -> None:
        ts = datetime.utcnow().isoformat()

        def _sync():
            con = self._connect()
            try:
                con.execute(
                    "INSERT INTO reminders(guild_id, user_id, last_sent_at) VALUES(?, ?, ?) "
                    "ON CONFLICT(guild_id, user_id) DO UPDATE SET last_sent_at=excluded.last_sent_at",
                    (guild_id, user_id, ts),
                )
                con.commit()
            finally:
                con.close()

        await asyncio.to_thread(_sync)

    async def create_pending(self, message_id: int, guild_id: int, user_id: int, role_ids: List[int]) -> None:
        ts = datetime.utcnow().isoformat()
        role_ids_str = ",".join(str(x) for x in role_ids)

        def _sync():
            con = self._connect()
            try:
                con.execute(
                    "INSERT OR REPLACE INTO pending(message_id, guild_id, user_id, role_ids, created_at, status) "
                    "VALUES(?, ?, ?, ?, ?, 'open')",
                    (message_id, guild_id, user_id, role_ids_str, ts),
                )
                con.commit()
            finally:
                con.close()

        await asyncio.to_thread(_sync)

    async def get_pending(self, message_id: int) -> Optional[dict]:
        def _sync() -> Optional[dict]:
            con = self._connect()
            try:
                row = con.execute(
                    "SELECT message_id, guild_id, user_id, role_ids, status FROM pending WHERE message_id=?",
                    (message_id,),
                ).fetchone()
                return dict(row) if row else None
            finally:
                con.close()

        return await asyncio.to_thread(_sync)

    async def close_pending(self, message_id: int) -> None:
        def _sync():
            con = self._connect()
            try:
                con.execute("UPDATE pending SET status='closed' WHERE message_id=?", (message_id,))
                con.commit()
            finally:
                con.close()

        await asyncio.to_thread(_sync)

    async def log_dm(self, day: str, guild_id: int, user_id: int, delivered: int, error: str = "") -> None:
        def _sync():
            con = self._connect()
            try:
                con.execute(
                    "INSERT OR REPLACE INTO dm_log(day, guild_id, user_id, delivered, error) VALUES(?,?,?,?,?)",
                    (day, guild_id, user_id, int(delivered), (error or "")[:300]),
                )
                con.commit()
            finally:
                con.close()

        await asyncio.to_thread(_sync)


# ==========================
# Helpers
# ==========================
def _get_clan_role_ids_set() -> set[int]:
    return set(CLANS.values())


def _member_clan_roles(member: nextcord.Member) -> List[nextcord.Role]:
    clan_ids = _get_clan_role_ids_set()
    return [r for r in member.roles if r.id in clan_ids]


def _disable_view(view: nextcord.ui.View) -> nextcord.ui.View:
    for item in view.children:
        if isinstance(item, nextcord.ui.Button) or isinstance(item, nextcord.ui.Select):
            item.disabled = True
    return view


# ==========================
# Просмотр участников клана (твой функционал)
# ==========================
class ClanPaginator(View):
    def __init__(self, members: List[nextcord.Member], clan_name: str):
        super().__init__(timeout=120)
        self.members = members
        self.clan_name = clan_name
        self.current_page = 0
        self.total_pages = (len(members) - 1) // MEMBERS_PER_PAGE + 1

        self.prev_button = Button(label="⏮️ Назад", style=nextcord.ButtonStyle.primary)
        self.next_button = Button(label="⏭️ Вперёд", style=nextcord.ButtonStyle.primary)
        self.prev_button.callback = self.prev_page
        self.next_button.callback = self.next_page
        self.add_item(self.prev_button)
        self.add_item(self.next_button)

    def get_embed(self):
        start = self.current_page * MEMBERS_PER_PAGE
        end = start + MEMBERS_PER_PAGE
        page_members = self.members[start:end]

        embed = Embed(title=f"Состав клана: {self.clan_name}", color=nextcord.Color.blue())
        if page_members:
            embed.add_field(
                name=f"Участники ({len(self.members)} всего)",
                value="\n".join(f"{m.mention} — {m.name}" for m in page_members),
                inline=False
            )
        else:
            embed.add_field(name="Участники", value="– Нет участников", inline=False)

        embed.set_footer(text=f"Страница {self.current_page + 1} из {self.total_pages}")
        return embed

    async def update_message(self, interaction: Interaction):
        await interaction.response.edit_message(embed=self.get_embed(), view=self)

    async def prev_page(self, interaction: Interaction):
        if self.current_page > 0:
            self.current_page -= 1
            await self.update_message(interaction)

    async def next_page(self, interaction: Interaction):
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
            await self.update_message(interaction)


class ClanSelectMenu(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=60)
        self.bot = bot
        options = [SelectOption(label=clan) for clan in CLANS]
        self.select = Select(placeholder="Выберите клан", options=options)
        self.select.callback = self.select_callback
        self.add_item(self.select)

    async def select_callback(self, interaction: Interaction):
        await interaction.response.defer(ephemeral=True)
        clan_name = self.select.values[0]

        guild = interaction.guild
        if guild is None:
            await interaction.followup.send("Команда доступна только на сервере.", ephemeral=True)
            return

        role_id = CLANS.get(clan_name)
        role = guild.get_role(role_id) if role_id else None
        if not role:
            await interaction.followup.send("❌ Роль клана не найдена.", ephemeral=True)
            return

        # Используем кеш участников
        members = getattr(self.bot, "guild_clan_members_cache", {}).get(guild.id, {}).get(clan_name)
        if members:
            paginator = ClanPaginator(members, clan_name)
            await interaction.followup.send(embed=paginator.get_embed(), view=paginator, ephemeral=True)
            return

        # Если кеш пуст — fetch_members с прогрессом
        progress_msg = await interaction.followup.send(
            f"🔄 Получаем участников клана {clan_name}... 0 найдено", ephemeral=True
        )

        members = []
        counter = 0
        try:
            async for member in guild.fetch_members(limit=None):
                counter += 1
                if role in member.roles:
                    members.append(member)
                if counter % 50 == 0:
                    await progress_msg.edit(
                        content=f"🔄 Получаем участников клана {clan_name}... {len(members)} найдено из {counter} обработано"
                    )
        except Exception as e:
            await progress_msg.edit(content=f"❌ Ошибка при получении участников: {e}")
            return

        if not members:
            await progress_msg.edit(content="– Нет участников или не удалось получить список участников.")
            return

        # Сохраняем в кеш
        getattr(self.bot, "guild_clan_members_cache", {}).setdefault(guild.id, {})[clan_name] = members

        paginator = ClanPaginator(members, clan_name)
        await progress_msg.edit(content="✅ Участники загружены!", embed=paginator.get_embed(), view=paginator)


# ==========================
# UI для снятия лишней клановой роли
# ==========================
class ClanCleanupSelect(nextcord.ui.Select):
    def __init__(self):
        super().__init__(
            placeholder="Выберите клановую роль, которую нужно убрать",
            options=[nextcord.SelectOption(label="(загрузка...)", value="0")],
            min_values=1,
            max_values=1,
            custom_id=CID_CLAN_PICK,
        )

    async def callback(self, interaction: Interaction):
        cog: "ClanMemberCog" = interaction.client.get_cog("ClanMemberCog")  # type: ignore
        if not cog:
            return

        if interaction.guild is None:
            await interaction.response.send_message("Это действие доступно только на сервере.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        msg = interaction.message
        if msg is None:
            await interaction.followup.send("Не удалось получить сообщение.", ephemeral=True)
            return

        pending = await cog.db.get_pending(msg.id)
        if not pending or pending["status"] != "open":
            await interaction.followup.send("Эта заявка уже закрыта/не найдена.", ephemeral=True)
            return

        if interaction.user.id != int(pending["user_id"]):
            await interaction.followup.send("⛔ Это меню не для вас.", ephemeral=True)
            return

        role_id_to_remove = int(self.values[0])

        guild = interaction.guild
        member = guild.get_member(interaction.user.id)
        if member is None:
            try:
                member = await guild.fetch_member(interaction.user.id)
            except Exception:
                member = None

        role = guild.get_role(role_id_to_remove)
        if role is None:
            try:
                role = await guild.fetch_role(role_id_to_remove)
            except Exception:
                role = None

        if not member or not role:
            await interaction.followup.send("⚠️ Не удалось получить участника/роль.", ephemeral=True)
            return

        # Проверка прав бота
        me = guild.me
        if me is None:
            try:
                me = await guild.fetch_member(interaction.client.user.id)  # type: ignore
            except Exception:
                me = None

        if not me or not me.guild_permissions.manage_roles:
            await interaction.followup.send("⚠️ У бота нет Manage Roles.", ephemeral=True)
            return

        if role >= me.top_role:
            await interaction.followup.send("⚠️ Роль выше/равна роли бота (иерархия).", ephemeral=True)
            return

        # Снимаем роль (это попадёт в Audit Log)
        try:
            if role in member.roles:
                await member.remove_roles(
                    role,
                    reason="Auto clan cleanup: user had 3+ clan roles; user selected role to remove"
                )
        except nextcord.Forbidden:
            await interaction.followup.send("⚠️ Forbidden: не могу снять роль.", ephemeral=True)
            return
        except nextcord.HTTPException:
            await interaction.followup.send("⚠️ Ошибка Discord API при снятии роли.", ephemeral=True)
            return

        await cog.db.close_pending(msg.id)

        # Обновим сообщение
        try:
            emb = msg.embeds[0] if msg.embeds else nextcord.Embed(title="Клановые роли")
            emb.description = f"✅ Убрана роль: **{role.name}**.\nСпасибо!"
            await msg.edit(embed=emb, view=_disable_view(ClanCleanupView()))
        except Exception:
            pass

        await interaction.followup.send(f"✅ Убрала роль **{role.name}**.", ephemeral=True)


class ClanCleanupView(nextcord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.select = ClanCleanupSelect()
        self.add_item(self.select)


# ==========================
# COG
# ==========================
class ClanMemberCog(commands.Cog, name="ClanMemberCog"):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.db = ClanCleanupDB(CLAN_DB_PATH)

        self._ready = asyncio.Event()
        self._scan_done_once = False

        # регаем персистентное меню (для DM после рестартов)
        try:
            bot.add_view(ClanCleanupView())
        except Exception:
            pass

        bot.loop.create_task(self._startup())

    async def _startup(self):
        try:
            await self.db.init()
            await self.bot.wait_until_ready()
        finally:
            self._ready.set()

    async def wait_ready(self):
        await self._ready.wait()

    @commands.Cog.listener()
    async def on_ready(self):
        # чтобы не дублить при реконнектах
        if self._scan_done_once:
            return
        self._scan_done_once = True

        await self.wait_ready()

        # ждём кэш из main.py (он может заполняться долго)
        # 3 попытки по 10 сек — обычно хватает
        for _ in range(3):
            if self._cache_looks_ready():
                break
            await asyncio.sleep(10)

        # запускаем ежедневный скан "у кого 3+ клановых ролей"
        for guild in self.bot.guilds:
            await self._scan_guild_from_cache_and_dm(guild)

    def _cache_looks_ready(self) -> bool:
        # если хотя бы для одной гильдии есть непустой словарь — считаем что кэш готов
        cache = getattr(self.bot, "guild_clan_members_cache", None)
        if not isinstance(cache, dict) or not cache:
            return False
        for gid, data in cache.items():
            if isinstance(data, dict) and len(data) > 0:
                return True
        return False

    async def _scan_guild_from_cache_and_dm(self, guild: nextcord.Guild):
        day = datetime.utcnow().strftime("%Y-%m-%d")

        sent_ok: List[int] = []
        sent_fail: List[int] = []

        cache = getattr(self.bot, "guild_clan_members_cache", {}).get(guild.id, {})
        if not isinstance(cache, dict) or not cache:
            # кэша нет — не делаем тяжёлый fetch_members автоматически
            return

        # собираем: user_id -> set(role_id)
        by_member: Dict[int, set[int]] = {}
        for clan_name, members in cache.items():
            role_id = CLANS.get(clan_name)
            if not role_id:
                continue
            if not isinstance(members, list):
                continue
            for m in members:
                by_member.setdefault(m.id, set()).add(role_id)

        # всем, у кого >=3 клановых ролей
        for user_id, roles_set in by_member.items():
            if len(roles_set) < MIN_CLAN_ROLES:
                continue

            # антиспам
            if not await self.db.should_send(guild.id, user_id, COOLDOWN_DAYS):
                continue

            member = guild.get_member(user_id)
            if member is None:
                continue

            role_ids_list = sorted(list(roles_set))

            options: List[nextcord.SelectOption] = []
            for rid in role_ids_list:
                r = guild.get_role(rid)
                if r:
                    options.append(nextcord.SelectOption(label=r.name, value=str(rid)))

            if not options:
                continue

            embed = nextcord.Embed(
                title="⚠️ Слишком много клановых ролей",
                description=(
                    f"У тебя сейчас **{len(role_ids_list)}** клановые роли.\n"
                    f"Нужно убрать одну из них.\n\n"
                    f"Выбери роль, которую нужно снять:"
                ),
                color=nextcord.Color.orange(),
            )

            view = ClanCleanupView()
            # подменяем options у select (custom_id остаётся тем же — персистентность сохраняется)
            view.select.options = options  # type: ignore

            try:
                dm_msg = await member.send(embed=embed, view=view)
            except Exception as e:
                sent_fail.append(user_id)
                await self.db.log_dm(day, guild.id, user_id, delivered=0, error=type(e).__name__)
                continue

            await self.db.create_pending(dm_msg.id, guild.id, user_id, role_ids_list)
            await self.db.mark_sent(guild.id, user_id)
            sent_ok.append(user_id)
            await self.db.log_dm(day, guild.id, user_id, delivered=1, error="")

        # отчёт в канал (одним сообщением)
        await self._send_report(guild, day, sent_ok, sent_fail)

    async def _send_report(self, guild: nextcord.Guild, day: str, ok: List[int], fail: List[int]):
        # если никому не отправляли и никому не фейлилось — можно не спамить
        if not ok and not fail:
            return

        ch = guild.get_channel(REPORT_CHANNEL_ID)
        if ch is None:
            try:
                ch = await guild.fetch_channel(REPORT_CHANNEL_ID)
            except Exception:
                return

        text = (
            f"🧹 **Клан-чистка (DM) — {day}**\n"
            f"✅ Доставлено: **{len(ok)}**\n"
            f"❌ Не доставлено: **{len(fail)}**"
        )

        if fail:
            # чтобы не пинговать тонну людей, список ограничим
            shown = fail[:25]
            text += "\n\n**Не доставлено (первые 25):**\n" + "\n".join(f"`{uid}`" for uid in shown)
            if len(fail) > 25:
                text += f"\n…и ещё {len(fail) - 25}"

        try:
            await ch.send(text)
        except Exception:
            pass

    # --------- Slash команды ---------

    @nextcord.slash_command(description="Вывести участников клана")
    async def clan_members(self, interaction: Interaction):
        await interaction.response.send_message("Выберите клан:", view=ClanSelectMenu(self.bot), ephemeral=True)

    @nextcord.slash_command(description="Если у вас 3+ клановых ролей — выбрать какую убрать (если ЛС закрыты)")
    async def clan_fix(self, interaction: Interaction):
        if interaction.guild is None or not isinstance(interaction.user, nextcord.Member):
            await interaction.response.send_message("Команда доступна только на сервере.", ephemeral=True)
            return

        member = interaction.user
        clan_roles = _member_clan_roles(member)
        if len(clan_roles) < MIN_CLAN_ROLES:
            await interaction.response.send_message("✅ У вас нет лишних клановых ролей.", ephemeral=True)
            return

        # быстро отвечаем (без defer) — это безопаснее для interaction
        options = [nextcord.SelectOption(label=r.name, value=str(r.id)) for r in clan_roles]

        embed = nextcord.Embed(
            title="Убрать клановую роль",
            description=f"У вас сейчас {len(clan_roles)} клановых ролей. Выберите одну, которую нужно снять.",
            color=nextcord.Color.orange(),
        )

        view = ClanCleanupView()
        view.select.options = options  # type: ignore

        # здесь pending и БД не обязательны, но удобно, чтобы логика была одна
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


# ----------------------
# setup
# ----------------------
def setup(bot: commands.Bot):
    bot.add_cog(ClanMemberCog(bot))