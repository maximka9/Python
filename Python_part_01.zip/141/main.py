import nextcord
from nextcord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()

intents = nextcord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True
intents.messages = True
intents.reactions = True

bot = commands.Bot(command_prefix="!", intents=intents)
bot.guild_clan_members_cache = {}  # оставляем

initial_extensions = [
    'cogs.event_manager',
    'cogs.close_manager',
    'cogs.report',
    'cogs.kiwkiform',
    'cogs.room_manager',
    'cogs.clan',
    'cogs.VoiceStats',
    'cogs.clan_member',
    'cogs.unban',
    'cogs.rules',
    'cogs.role',
    'cogs.dota',
    'cogs.clan_role',
    'cogs.deleterole',
    'cogs.predl',
    'cogs.exc',
    'cogs.piclans',
    'cogs.giveaway',
    'cogs.demorgan',
    'cogs.resp',
    'cogs.pubg',
    'cogs.event_quiz',
    'cogs.clan_ranks',
    'cogs.delete_reaction'
]

@bot.event
async def on_ready():
    print(f'✅ Бот {bot.user} успешно запущен!')
    print(f'ID бота: {bot.user.id}')
    print(f'Серверов: {len(bot.guilds)}')

    try:
        synced = await bot.sync_application_commands()
        if synced is not None:
            print(f"🔁 Синхронизировано {len(synced)} слэш-команд.")
        else:
            print("🔁 Синхронизация слэш-команд выполнена, но возвращаемое значение отсутствует.")
    except Exception as e:
        print(f"❌ Ошибка при синхронизации: {e}")

def load_cogs():
    for extension in initial_extensions:
        try:
            bot.load_extension(extension)
            print(f'🔧 Cog "{extension}" успешно загружен')
        except Exception as e:
            print(f'❌ Не удалось загрузить {extension}: {type(e).__name__} - {e}')

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    await ctx.send(f'⚠️ Ошибка: {str(error)}', delete_after=15)

if __name__ == '__main__':
    load_cogs()
    bot.run(os.getenv('TOKEN'))
