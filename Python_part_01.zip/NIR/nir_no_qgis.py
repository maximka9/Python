"""
Скрипт для тестирования маршрутизации БЕЗ QGIS.
Показывает прогресс выполнения и время каждого этапа.

Запуск: python nir_no_qgis.py
"""

import os
import time
import math
from collections import Counter
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import geopandas as gpd
import srtm
import osmnx as ox
from shapely.geometry import box, LineString, Point
import networkx as nx
import requests
from io import BytesIO

# Для прогресс-бара (установите: pip install tqdm)
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False
    print("⚠️ tqdm не установлен. Установите: pip install tqdm")

# Для анализа изображений (установите: pip install pillow)
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("⚠️ Pillow не установлен. Установите: pip install pillow")

# ============== КОНФИГУРАЦИЯ ==============
# Физические параметры
MG = 16.66667       # масса * g / нормирующий коэффициент
NU = 0.06           # коэффициент сопротивления качению
MIN_DESCENT_COEFF = 0.02  # минимальный коэффициент при спуске (чтобы вес не был нулевым)
MAX_GRADIENT = 0.30       # максимальный учитываемый уклон (30% — очень крутой)

START_COORDS = (53.183055, 50.075712)  # (latitude, longitude)
END_COORDS = (53.195144, 50.124155)    # (latitude, longitude)

BUFFER = 0.003  # Уменьшен для ускорения (был 0.005)
GREEN_BUFFER = 0.0005

# Настройки загрузки зелёных зон
LOAD_GREEN_AREAS = False   # Загружать зелёные зоны?
SKIP_IF_SLOW = False      # Пропускать если область большая?
CACHE_GREEN_AREAS = False  # Кэшировать зелёные зоны на диск?

# Настройки анализа зелени по космоснимкам
USE_SATELLITE_GREEN = True    # Использовать космоснимки вместо OSM?
SATELLITE_ZOOM = 20           # Уровень зума (19 = ~0.3м/пиксель, тайлы ~38м)
ROAD_BUFFER_METERS = 10       # Буфер от дороги в метрах (коридор для анализа, 10м = 20м общий коридор)
CACHE_SATELLITE = True        # Кэшировать тайлы на диск?
CACHE_TILE_ANALYSIS = True    # Кэшировать результаты анализа тайлов?
ANALYZE_CORRIDOR = True       # Анализировать только коридор вокруг дороги (по требованию научрука)
TILE_DOWNLOAD_THREADS = 8     # Количество потоков для параллельной загрузки тайлов (ускоряет в 4-8 раз)

# TMS источники (спутниковые снимки)
TMS_SERVERS = {
    'google': 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
    'esri': 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
}
TMS_SERVER = 'google'  # Google обычно лучше для зелени

GREEN_COEFFICIENTS = {
    'in_park': 0.7,
    'near_trees': 0.85,
    'near_green': 0.9,
    'no_green': 1.0,
}

SURFACE_COEFFICIENTS = {
    'asphalt': 0.9, 'concrete': 1.1, 'concrete:plates': 1.3,
    'paved': 1.2, 'paving_stones': 1.4, 'sett': 1.5,
    'compacted': 1.5, 'fine_gravel': 1.7, 'gravel': 2.0,
    'unpaved': 2.5, 'dirt': 3.0, 'ground': 3.0,
    'sand': 3.5, 'grass': 4.0,
}

HIGHWAY_COEFFICIENTS = {
    'cycleway': 0.3, 'path': 0.5, 'footway': 1.0,
    'residential': 1.0, 'living_street': 1.0, 'pedestrian': 1.0,
    'service': 1.1, 'unclassified': 1.1, 'track': 1.2,
    'tertiary': 1.2, 'tertiary_link': 1.2, 'secondary': 1.3,
    'secondary_link': 1.3, 'primary': 1.4, 'primary_link': 1.4,
    'steps': 10.0, 'construction': 100.0
}

DEFAULT_COEFFICIENT = 1.0
# ==========================================


class Timer:
    """Простой таймер для измерения времени выполнения"""
    def __init__(self):
        self.times = {}
        self.start_time = None
        self.total_start = time.time()
    
    def start(self, name):
        self.start_time = time.time()
        self.current_name = name
        print(f"\n⏱️  [{name}] Начало...")
    
    def stop(self):
        elapsed = time.time() - self.start_time
        self.times[self.current_name] = elapsed
        print(f"✅ [{self.current_name}] Завершено за {elapsed:.2f} сек")
        return elapsed
    
    def summary(self):
        total = time.time() - self.total_start
        print("\n" + "="*60)
        print("⏱️  ВРЕМЯ ВЫПОЛНЕНИЯ")
        print("="*60)
        for name, t in self.times.items():
            pct = (t / total) * 100
            bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
            print(f"   {name:30} {t:6.2f}с  {bar} {pct:5.1f}%")
        print("-"*60)
        print(f"   {'ВСЕГО':30} {total:6.2f}с")
        return total


timer = Timer()


def get_cache_path(bbox, cache_type="green"):
    """Генерирует путь к файлу кэша на основе bbox"""
    bounds = bbox.bounds
    cache_key = f"{cache_type}_{bounds[0]:.4f}_{bounds[1]:.4f}_{bounds[2]:.4f}_{bounds[3]:.4f}"
    cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, f"{cache_key}.pkl")


def load_from_cache(cache_path):
    """Загружает данные из кэша"""
    import pickle
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'rb') as f:
                data = pickle.load(f)
            return data
        except:
            return None
    return None


def save_to_cache(cache_path, data):
    """Сохраняет данные в кэш"""
    import pickle
    try:
        with open(cache_path, 'wb') as f:
            pickle.dump(data, f)
        return True
    except:
        return False


# ============== ФУНКЦИИ ДЛЯ АНАЛИЗА КОСМОСНИМКОВ ==============

def lat_lon_to_tile(lat, lon, zoom):
    """Конвертация координат в номер тайла TMS"""
    lat_rad = math.radians(lat)
    n = 2 ** zoom
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lat_lon(x, y, zoom):
    """Конвертация номера тайла в координаты (верхний левый угол)"""
    n = 2 ** zoom
    lon = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
    lat = math.degrees(lat_rad)
    return lat, lon


def get_tile_bounds(x, y, zoom):
    """Получить границы тайла в координатах"""
    lat1, lon1 = tile_to_lat_lon(x, y, zoom)
    lat2, lon2 = tile_to_lat_lon(x + 1, y + 1, zoom)
    return (lon1, lat2, lon2, lat1)  # (min_lon, min_lat, max_lon, max_lat)


def download_tile(x, y, zoom, server='esri'):
    """Скачивает тайл с TMS сервера"""
    if not PIL_AVAILABLE:
        return None
    
    url = TMS_SERVERS.get(server, TMS_SERVERS['esri'])
    url = url.format(x=x, y=y, z=zoom)
    
    # Проверяем кэш тайлов
    if CACHE_SATELLITE:
        cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache", "tiles")
        os.makedirs(cache_dir, exist_ok=True)
        cache_file = os.path.join(cache_dir, f"{server}_{zoom}_{x}_{y}.jpg")
        
        if os.path.exists(cache_file):
            try:
                return Image.open(cache_file)
            except:
                pass
    
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            img = Image.open(BytesIO(response.content))
            
            # Сохраняем в кэш
            if CACHE_SATELLITE:
                try:
                    img.save(cache_file, 'JPEG')
                except:
                    pass
            
            return img
    except Exception as e:
        pass
    
    return None


def analyze_green_in_image(img, mask=None, return_details=False):
    """
    Анализирует процент зелени на изображении.
    УЛУЧШЕНО: Различает ДЕРЕВЬЯ (тёмно-зелёные) и ТРАВУ (светло-зелёные).
    
    Использует:
    - NDI = (G - R) / (G + R) — индекс зелени
    - Яркость для разделения деревьев/травы
    
    Args:
        img: PIL Image
        mask: опциональная маска (numpy array)
        return_details: если True, возвращает dict с деталями
    
    Returns: 
        Если return_details=False: общий процент зелени (0-100)
        Если return_details=True: dict {'trees': %, 'grass': %, 'total': %}
    """
    if img is None:
        if return_details:
            return {'trees': 0.0, 'grass': 0.0, 'total': 0.0}
        return 0.0
    
    # Конвертируем в RGB если нужно
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    # Получаем массив пикселей
    pixels = np.array(img, dtype=np.float32)
    r, g, b = pixels[:,:,0], pixels[:,:,1], pixels[:,:,2]
    
    # Normalized Green-Red Difference Index
    sum_rg = r + g + 0.001  # избегаем деления на 0
    ndi = (g - r) / sum_rg
    
    # Excess Green Index
    exg = g - (r + b) / 2.0
    
    # Яркость
    brightness = (r + g + b) / 3.0
    
    # Насыщенность зелёного (насколько зелёный выделяется)
    max_rgb = np.maximum(np.maximum(r, g), b)
    min_rgb = np.minimum(np.minimum(r, g), b)
    saturation = (max_rgb - min_rgb) / (max_rgb + 0.001)
    
    # === БАЗОВЫЕ КРИТЕРИИ ЗЕЛЕНИ (ОСЛАБЛЕНЫ) ===
    base_green = (
        (ndi > 0.01) &          # Зелёный доминирует над красным (было 0.02)
        (exg > 1) &             # Excess green (было 2)
        (g > r) &               # Зелёный больше красного
        (g > 30) &              # Достаточно зелёного канала (было 35)
        (brightness > 5) &      # Не слишком тёмное (было 10)
        (brightness < 250)      # Не пересвечено
    )
    
    # === ДЕРЕВЬЯ: тёмно-зелёные, насыщенные (ОСЛАБЛЕНО) ===
    trees_mask = base_green & (
        (brightness < 120) |    # Тёмные области (было 100)
        ((brightness < 160) & (ndi > 0.05) & (saturation > 0.1))  # Средние но зелёные (было 140, 0.08, 0.15)
    )
    
    # === ТРАВА: светло-зелёная (ОСЛАБЛЕНО) ===
    grass_mask = base_green & ~trees_mask & (
        (brightness >= 60) &    # Светлее чем деревья (было 80)
        (brightness < 220) &    # Но не слишком светлые (было 200)
        (ndi > 0.01)            # Всё ещё зелёные (было 0.03)
    )
    
    # Применяем пространственную маску (коридор вокруг дороги)
    if mask is not None:
        mask_arr = np.array(mask)
        mask_pixels = (mask_arr > 0).sum()  # ИСПРАВЛЕНО: количество пикселей, а не сумма значений!
        if mask_pixels == 0:
            if return_details:
                return {'trees': 0.0, 'grass': 0.0, 'total': 0.0}
            return 0.0
        trees_mask = trees_mask & (mask_arr > 0)
        grass_mask = grass_mask & (mask_arr > 0)
        total_pixels = float(mask_pixels)
    else:
        total_pixels = float(pixels.shape[0] * pixels.shape[1])
    
    if total_pixels == 0:
        if return_details:
            return {'trees': 0.0, 'grass': 0.0, 'total': 0.0}
        return 0.0
    
    trees_pct = (float(trees_mask.sum()) / total_pixels) * 100
    grass_pct = (float(grass_mask.sum()) / total_pixels) * 100
    total_pct = trees_pct + grass_pct
    
    if return_details:
        return {'trees': trees_pct, 'grass': grass_pct, 'total': total_pct}
    
    return total_pct


# Кэш для результатов анализа тайлов
_tile_green_cache = {}
_tile_images_cache = {}  # Кэш загруженных изображений


def get_tiles_for_bbox(bbox, zoom):
    """Получает список тайлов, покрывающих bbox"""
    bounds = bbox.bounds
    min_lon, min_lat, max_lon, max_lat = bounds
    
    x1, y1 = lat_lon_to_tile(max_lat, min_lon, zoom)
    x2, y2 = lat_lon_to_tile(min_lat, max_lon, zoom)
    
    tiles = []
    for x in range(x1, x2 + 1):
        for y in range(y1, y2 + 1):
            tiles.append((x, y, zoom))
    
    return tiles


def create_corridor_mask(edge_geom, tile_bounds, img_size, buffer_meters=ROAD_BUFFER_METERS):
    """
    Создаёт маску коридора вокруг дороги для анализа только релевантных пикселей.
    ИСПРАВЛЕНО: правильный расчёт ширины с ограничением.
    """
    from PIL import Image, ImageDraw
    
    min_lon, min_lat, max_lon, max_lat = tile_bounds
    width, height = img_size
    
    # Конвертация координат в пиксели
    def coord_to_pixel(lon, lat):
        px = int((lon - min_lon) / (max_lon - min_lon) * width)
        py = int((max_lat - lat) / (max_lat - min_lat) * height)
        return (px, py)
    
    # Создаём маску
    mask = Image.new('L', (width, height), 0)
    draw = ImageDraw.Draw(mask)
    
    if edge_geom.geom_type == 'LineString':
        coords = list(edge_geom.coords)
        if len(coords) >= 2:
            pixels = [coord_to_pixel(lon, lat) for lon, lat in coords]
            
            # Ширина тайла в метрах (на широте ~53°)
            lat_center = (min_lat + max_lat) / 2
            meters_per_deg_lon = 111000 * np.cos(np.radians(lat_center))
            tile_width_meters = (max_lon - min_lon) * meters_per_deg_lon
            tile_height_meters = (max_lat - min_lat) * 111000
            
            # Размер пикселя в метрах
            if tile_width_meters > 0 and tile_height_meters > 0:
                meters_per_pixel_x = tile_width_meters / width
                meters_per_pixel_y = tile_height_meters / height
                meters_per_pixel = max(meters_per_pixel_x, meters_per_pixel_y)
                
                # Ширина коридора в пикселях (40м = 20м с каждой стороны)
                line_width_pixels = int((buffer_meters * 2) / meters_per_pixel)
                
                # Ограничиваем разумными значениями: минимум 5, максимум 1/3 тайла
                line_width_pixels = max(5, min(line_width_pixels, min(width, height) // 3))
            else:
                line_width_pixels = 20  # Fallback
            
            # Рисуем линию
            for i in range(len(pixels) - 1):
                draw.line([pixels[i], pixels[i+1]], fill=255, width=line_width_pixels)
    
    return np.array(mask)


def calculate_green_satellite_batch(edges_gdf, zoom=SATELLITE_ZOOM, buffer_meters=ROAD_BUFFER_METERS):
    """
    Пакетный расчёт зелени для всех рёбер через космоснимки.
    
    УЛУЧШЕНО (по требованиям научрука):
    1. Zoom 19 для мелких тайлов (~38м)
    2. Анализ КОРИДОРА вокруг дороги (не всего тайла)
    3. Разделение на ДЕРЕВЬЯ и ТРАВУ (разные бонусы)
    4. Деревья дают больший бонус чем трава
    """
    timer.start("Анализ зелени (космоснимки)")
    
    if not PIL_AVAILABLE:
        print("   ⚠️ Pillow не установлен, пропускаем анализ космоснимков")
        edges_gdf['green_percent'] = 0.0
        edges_gdf['trees_percent'] = 0.0
        edges_gdf['grass_percent'] = 0.0
        edges_gdf['green_coeff'] = GREEN_COEFFICIENTS['no_green']
        edges_gdf['green_type'] = 'none'
        timer.stop()
        return edges_gdf
    
    buffer_deg = buffer_meters / 111000.0
    
    # Собираем все нужные тайлы
    all_tiles = set()
    edge_tiles = {}
    
    print(f"   📡 Параметры: zoom={zoom} (~{256 * 156543.03 / (2**zoom):.0f}м/тайл), буфер={buffer_meters}м")
    print(f"   🛣️ Режим: {'КОРИДОР вокруг дороги' if ANALYZE_CORRIDOR else 'весь тайл'}")
    
    for idx, row in edges_gdf.iterrows():
        geom = row.geometry
        if geom is None:
            continue
        
        bounds = geom.bounds
        x1, y1 = lat_lon_to_tile(bounds[3] + buffer_deg, bounds[0] - buffer_deg, zoom)
        x2, y2 = lat_lon_to_tile(bounds[1] - buffer_deg, bounds[2] + buffer_deg, zoom)
        
        tiles = []
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                tiles.append((x, y))
                all_tiles.add((x, y))
        edge_tiles[idx] = tiles
    
    print(f"   📥 Загрузка {len(all_tiles)} тайлов...")
    
    # Загружаем все тайлы в память
    tile_images = {}
    tiles_list = list(all_tiles)
    
    # Проверяем кэш
    cache_path = None
    edge_results_cache = {}
    if CACHE_TILE_ANALYSIS:
        bounds = edges_gdf.total_bounds
        cache_key = f"corridor_v2_{zoom}_{buffer_meters}_{bounds[0]:.4f}_{bounds[1]:.4f}_{bounds[2]:.4f}_{bounds[3]:.4f}"
        cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")
        os.makedirs(cache_dir, exist_ok=True)
        cache_path = os.path.join(cache_dir, f"{cache_key}.pkl")
        cached = load_from_cache(cache_path)
        if cached is not None:
            edge_results_cache = cached
            print(f"   💾 Результаты загружены из кэша ({len(edge_results_cache)} рёбер)")
    
    # Если всё в кэше - пропускаем загрузку тайлов
    if len(edge_results_cache) == len(edges_gdf):
        print(f"   ✅ Все результаты в кэше, пропускаем загрузку тайлов")
    else:
        # Параллельная загрузка тайлов (ускоряет в 4-8 раз)
        print(f"   ⚡ Параллельная загрузка ({TILE_DOWNLOAD_THREADS} потоков)...")
        debug_saved = False
        
        def download_tile_wrapper(tile_xy):
            x, y = tile_xy
            img = download_tile(x, y, zoom, TMS_SERVER)
            return (x, y), img
        
        # Загружаем параллельно
        with ThreadPoolExecutor(max_workers=TILE_DOWNLOAD_THREADS) as executor:
            futures = {executor.submit(download_tile_wrapper, (x, y)): (x, y) for x, y in tiles_list}
            
            if TQDM_AVAILABLE:
                iterator = tqdm(as_completed(futures), total=len(futures), desc="   Загрузка тайлов")
            else:
                iterator = as_completed(futures)
            
            for future in iterator:
                try:
                    (x, y), img = future.result()
                    if img is not None:
                        tile_images[(x, y)] = img
                        
                        # DEBUG: сохраняем первый тайл
                        if not debug_saved:
                            debug_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache", "debug_tile.jpg")
                            try:
                                img.save(debug_path, "JPEG")
                                pixels = np.array(img, dtype=np.float32)
                                r, g, b = pixels[:,:,0], pixels[:,:,1], pixels[:,:,2]
                                print(f"\n   🔍 DEBUG: {debug_path}")
                                print(f"      RGB: R={r.mean():.0f}, G={g.mean():.0f}, B={b.mean():.0f}")
                                debug_saved = True
                            except:
                                pass
                except Exception as e:
                    pass  # Пропускаем ошибки загрузки
        
        print(f"   ✅ Загружено: {len(tile_images)} тайлов")
    
    # Анализируем каждое ребро
    print(f"   🌿 Анализ коридоров для {len(edges_gdf)} рёбер...")
    
    trees_list = []
    grass_list = []
    total_list = []
    
    edge_indices = list(edges_gdf.index)
    iterator = tqdm(edge_indices, desc="   Анализ рёбер") if TQDM_AVAILABLE else edge_indices
    
    debug_count = 0
    debug_max = 5  # Показываем статистику для первых 5 рёбер
    
    for idx in iterator:
        # Проверяем кэш
        if idx in edge_results_cache:
            result = edge_results_cache[idx]
            trees_list.append(result['trees'])
            grass_list.append(result['grass'])
            total_list.append(result['total'])
            continue
        
        row = edges_gdf.loc[idx]
        geom = row.geometry
        
        if idx not in edge_tiles or geom is None:
            trees_list.append(0.0)
            grass_list.append(0.0)
            total_list.append(0.0)
            continue
        
        # Собираем результаты со всех тайлов ребра
        edge_trees = []
        edge_grass = []
        edge_total = []
        mask_sizes = []
        
        for tx, ty in edge_tiles[idx]:
            if (tx, ty) not in tile_images:
                continue
            
            img = tile_images[(tx, ty)]
            tile_bounds = get_tile_bounds(tx, ty, zoom)
            
            if ANALYZE_CORRIDOR:
                # Создаём маску коридора
                mask = create_corridor_mask(geom, tile_bounds, img.size, buffer_meters)
                # ИСПРАВЛЕНО: считаем количество пикселей, а не сумму значений!
                mask_size = (mask > 0).sum()  # Количество ненулевых пикселей
                mask_sizes.append(mask_size)
                
                if mask_size == 0:
                    continue
                
                # Отладка для первых рёбер
                if debug_count < debug_max:
                    pixels_in_mask = mask_size
                    total_pixels = mask.size
                    print(f"\n   🔍 DEBUG ребро #{idx}: маска={pixels_in_mask}/{total_pixels} пикселей ({pixels_in_mask/total_pixels*100:.1f}%)")
                
                result = analyze_green_in_image(img, mask=mask, return_details=True)
            else:
                # Анализируем весь тайл
                result = analyze_green_in_image(img, return_details=True)
            
            edge_trees.append(result['trees'])
            edge_grass.append(result['grass'])
            edge_total.append(result['total'])
            
            # Отладка для первых рёбер
            if debug_count < debug_max and ANALYZE_CORRIDOR:
                print(f"      Тайл ({tx},{ty}): деревья={result['trees']:.1f}%, трава={result['grass']:.1f}%, всего={result['total']:.1f}%")
        
        if debug_count < debug_max and ANALYZE_CORRIDOR:
            if mask_sizes:
                avg_mask = np.mean(mask_sizes)
                print(f"      Средний размер маски: {avg_mask:.0f} пикселей")
            debug_count += 1
        
        # Усредняем по тайлам
        trees_pct = np.mean(edge_trees) if edge_trees else 0.0
        grass_pct = np.mean(edge_grass) if edge_grass else 0.0
        total_pct = np.mean(edge_total) if edge_total else 0.0
        
        trees_list.append(trees_pct)
        grass_list.append(grass_pct)
        total_list.append(total_pct)
        
        # Сохраняем в кэш
        edge_results_cache[idx] = {'trees': trees_pct, 'grass': grass_pct, 'total': total_pct}
    
    # Сохраняем кэш
    if CACHE_TILE_ANALYSIS and cache_path:
        save_to_cache(cache_path, edge_results_cache)
        print(f"   💾 Результаты сохранены в кэш")
    
    # Записываем результаты
    edges_gdf['trees_percent'] = trees_list
    edges_gdf['grass_percent'] = grass_list
    edges_gdf['green_percent'] = total_list
    
    # === НОВАЯ ФОРМУЛА КОЭФФИЦИЕНТА ===
    # По требованию научрука: деревья важнее травы!
    # Деревья дают больший бонус (тень), трава — меньший (прохлада)
    trees_pct = edges_gdf['trees_percent'].values
    grass_pct = edges_gdf['grass_percent'].values
    total_pct = edges_gdf['green_percent'].values
    
    # Базовая точка: 10% общей зелени = нейтрально (1.0)
    # Штраф за отсутствие зелени
    penalty = np.maximum(0, (10 - total_pct) / 100)  # 0% → +0.1
    
    # Бонусы (деревья в 2 раза важнее травы!)
    trees_bonus = trees_pct / 100 * 0.6    # до -60% за деревья
    grass_bonus = grass_pct / 100 * 0.25   # до -25% за траву
    
    edges_gdf['green_coeff'] = np.clip(1.0 + penalty - trees_bonus - grass_bonus, 0.3, 1.2)
    
    # Результаты:
    # 0% зелени → 1.1 (штраф +10%)
    # 10% трава → 0.975 (-2.5%)
    # 10% деревья → 0.94 (-6%)
    # 50% деревья → 0.7 (-30%)
    # 100% деревья → 0.4 (-60%)
    
    # Категоризация
    def categorize_green(row):
        if row['trees_percent'] >= 15:
            return 'trees'
        elif row['trees_percent'] + row['grass_percent'] >= 25:
            return 'park'
        elif row['grass_percent'] >= 10:
            return 'grass'
        elif row['trees_percent'] + row['grass_percent'] >= 3:
            return 'sparse'
        else:
            return 'none'
    
    edges_gdf['green_type'] = edges_gdf.apply(categorize_green, axis=1)
    
    # Статистика
    avg_trees = edges_gdf['trees_percent'].mean()
    avg_grass = edges_gdf['grass_percent'].mean()
    avg_total = edges_gdf['green_percent'].mean()
    max_trees = edges_gdf['trees_percent'].max()
    
    print(f"\n   📊 СТАТИСТИКА ЗЕЛЕНИ В КОРИДОРЕ ({buffer_meters}м):")
    print(f"      🌳 Деревья: средн. {avg_trees:.1f}%, макс. {max_trees:.1f}%")
    print(f"      🌿 Трава:   средн. {avg_grass:.1f}%")
    print(f"      📈 Всего:   средн. {avg_total:.1f}%")
    
    type_stats = edges_gdf['green_type'].value_counts()
    print(f"      📋 Категории: {dict(type_stats)}")
    
    timer.stop()
    return edges_gdf


# ============== КОНЕЦ ФУНКЦИЙ КОСМОСНИМКОВ ==============


def init_environment():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cache_dir = os.path.join(script_dir, "osmnx_cache")
    os.makedirs(cache_dir, exist_ok=True)
    ox.settings.cache_folder = cache_dir
    ox.settings.useful_tags_way += ['surface']
    return script_dir


def init_srtm():
    timer.start("Инициализация SRTM")
    elevation_data = srtm.get_data()
    test = elevation_data.get_elevation(START_COORDS[0], START_COORDS[1])
    if test:
        print(f"   Высота в точке старта: {test} м")
    timer.stop()
    return elevation_data


def create_bbox(start, end, buffer):
    min_lat = min(start[0], end[0]) - buffer
    min_lon = min(start[1], end[1]) - buffer
    max_lat = max(start[0], end[0]) + buffer
    max_lon = max(start[1], end[1]) + buffer
    return box(min_lon, min_lat, max_lon, max_lat)


def load_graph(bbox):
    timer.start("Загрузка дорог OSM")
    custom_filter = (
        '["highway"~"construction|cycleway|footway|living_street|path|pedestrian|platform|'
        'primary|primary_link|residential|secondary|secondary_link|service|steps|tertiary|'
        'tertiary_link|track|unclassified"]'
    )
    G = ox.graph_from_polygon(bbox, custom_filter=custom_filter, simplify=False, retain_all=True)
    print(f"   Узлов: {G.number_of_nodes()}, Рёбер: {G.number_of_edges()}")
    timer.stop()
    return G


def load_green_areas(bbox, skip_if_slow=True, use_cache=True):
    """
    Загрузка зелёных зон из OSM через Overpass API.
    С кэшированием, retry и fallback на ox.features_from_bbox при ошибках.
    """
    timer.start("Загрузка зелёных зон")
    
    # Проверяем кэш
    if use_cache and CACHE_GREEN_AREAS:
        cache_path = get_cache_path(bbox, "green")
        cached = load_from_cache(cache_path)
        if cached is not None:
            print(f"   💾 Загружено из кэша: {sum(len(v) for v in cached.values())} объектов")
            timer.stop()
            return cached
    
    green_geometries = {'parks': [], 'forests': [], 'trees': [], 'grass': []}
    bounds = bbox.bounds
    north, south, east, west = bounds[3], bounds[1], bounds[2], bounds[0]
    
    success = False
    
    # Попытка 1: Быстрый Overpass API запрос
    try:
        import requests
        from shapely.geometry import Polygon
        
        overpass_servers = [
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
        ]
        
        query = f"""
        [out:json][timeout:60];
        (
          way["leisure"="park"]({south},{west},{north},{east});
          relation["leisure"="park"]({south},{west},{north},{east});
          way["leisure"="garden"]({south},{west},{north},{east});
        );
        out geom;
        """
        
        for server in overpass_servers:
            try:
                print(f"   📡 Запрос парков ({server.split('/')[2]})...")
                response = requests.get(server, params={'data': query}, timeout=60)
                
                if response.status_code == 200:
                    data = response.json()
                    elements = data.get('elements', [])
                    
                    for elem in elements:
                        if elem.get('type') == 'way' and 'geometry' in elem:
                            coords = [(p['lon'], p['lat']) for p in elem['geometry']]
                            if len(coords) >= 3:
                                try:
                                    poly = Polygon(coords)
                                    if poly.is_valid:
                                        green_geometries['parks'].append(poly)
                                except:
                                    pass
                    
                    print(f"   ✅ Парки: {len(green_geometries['parks'])}")
                    success = True
                    break
                else:
                    print(f"   ⚠️ Ошибка {response.status_code}, пробуем другой сервер...")
                    time.sleep(1)
                    
            except requests.exceptions.Timeout:
                print(f"   ⚠️ Таймаут, пробуем другой сервер...")
                continue
            except Exception as e:
                print(f"   ⚠️ Ошибка: {e}")
                continue
                
    except Exception as e:
        print(f"   ⚠️ Ошибка Overpass: {e}")
    
    # Попытка 2: Fallback на OSMnx
    if not success and len(green_geometries['parks']) == 0:
        print("   🔄 Fallback: загрузка через OSMnx...")
        try:
            tags = {'leisure': ['park', 'garden']}
            parks = ox.features_from_bbox(bbox=(north, south, east, west), tags=tags)
            if len(parks) > 0:
                green_geometries['parks'] = [g.intersection(bbox) for g in parks.geometry if g.intersects(bbox)]
                print(f"   ✅ Парки (OSMnx): {len(green_geometries['parks'])}")
        except Exception as e:
            print(f"   ⚠️ OSMnx тоже не сработал: {e}")
    
    total = sum(len(v) for v in green_geometries.values())
    print(f"   Всего объектов: {total}")
    
    # Сохраняем в кэш
    if use_cache and CACHE_GREEN_AREAS and total > 0:
        cache_path = get_cache_path(bbox, "green")
        if save_to_cache(cache_path, green_geometries):
            print(f"   💾 Сохранено в кэш")
    
    timer.stop()
    return green_geometries


def calculate_green_with_sjoin(edges_gdf, green_geometries):
    """Быстрый расчёт озеленения через spatial join"""
    green_priority = {'park': 0, 'forest': 1, 'trees': 2, 'grass': 3}
    green_coeff_map = {
        'park': GREEN_COEFFICIENTS['in_park'],
        'forest': GREEN_COEFFICIENTS['in_park'],
        'trees': GREEN_COEFFICIENTS['near_trees'],
        'grass': GREEN_COEFFICIENTS['near_green'],
    }
    
    green_rows = []
    type_mapping = {'parks': 'park', 'forests': 'forest', 'trees': 'trees', 'grass': 'grass'}
    
    for key, green_type in type_mapping.items():
        for geom in green_geometries.get(key, []):
            if geom is not None and geom.is_valid:
                green_rows.append({'geometry': geom, 'green_type': green_type})
    
    if not green_rows:
        edges_gdf['green_type'] = 'none'
        edges_gdf['green_coeff'] = GREEN_COEFFICIENTS['no_green']
        return edges_gdf
    
    green_gdf = gpd.GeoDataFrame(green_rows, crs="EPSG:4326")
    
    edges_buffered = edges_gdf.copy()
    # Подавляем warning о CRS - для небольших буферов в градусах это допустимо
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        edges_buffered['geometry'] = edges_gdf.geometry.buffer(GREEN_BUFFER)
    edges_buffered['edge_idx'] = range(len(edges_buffered))
    
    joined = gpd.sjoin(edges_buffered[['geometry', 'edge_idx']], green_gdf, how='left', predicate='intersects')
    joined['priority'] = joined['green_type'].map(green_priority).fillna(999)
    
    # Фильтруем только строки с реальными пересечениями (не NaN)
    valid_joins = joined[joined['green_type'].notna()]
    
    if len(valid_joins) > 0:
        best_green = valid_joins.loc[valid_joins.groupby('edge_idx')['priority'].idxmin()]
        green_dict = dict(zip(best_green['edge_idx'], best_green['green_type']))
    else:
        green_dict = {}
    
    edges_gdf['green_type'] = [green_dict.get(i, 'none') for i in range(len(edges_gdf))]
    edges_gdf['green_coeff'] = edges_gdf['green_type'].map(
        lambda x: green_coeff_map.get(x, GREEN_COEFFICIENTS['no_green'])
    )
    
    return edges_gdf


def get_first_value(val):
    if isinstance(val, list):
        return val[0] if val else None
    return val


def calculate_weights_vectorized(edges_gdf, elevation_data, green_geometries):
    timer.start("Расчёт весов рёбер")
    
    elevation_cache = {}
    
    def get_elevation_cached(lon, lat):
        key = (round(lon, 5), round(lat, 5))
        if key not in elevation_cache:
            height = elevation_data.get_elevation(key[1], key[0])
            elevation_cache[key] = height if height is not None else 0
        return elevation_cache[key]
    
    # Расчёт высот с прогресс-баром
    print("   Расчёт высот...")
    if TQDM_AVAILABLE:
        elevation_diffs = []
        for geom in tqdm(edges_gdf.geometry, desc="   Высоты", unit="ребро"):
            start = get_elevation_cached(geom.coords[0][0], geom.coords[0][1])
            end = get_elevation_cached(geom.coords[-1][0], geom.coords[-1][1])
            elevation_diffs.append(end - start)
        edges_gdf['elevation_diff'] = elevation_diffs
    else:
        edges_gdf['elevation_diff'] = edges_gdf.geometry.apply(
            lambda g: get_elevation_cached(g.coords[-1][0], g.coords[-1][1]) - 
                      get_elevation_cached(g.coords[0][0], g.coords[0][1])
        )
    
    # Расчёт озеленения
    print("   Расчёт озеленения...")
    if USE_SATELLITE_GREEN and PIL_AVAILABLE:
        # Новый метод: анализ космоснимков
        edges_gdf = calculate_green_satellite_batch(edges_gdf)
    else:
        # Старый метод: OSM данные
        edges_gdf = calculate_green_with_sjoin(edges_gdf, green_geometries)
    
    # Коэффициенты
    edges_gdf['surface_key'] = edges_gdf['surface'].apply(get_first_value) if 'surface' in edges_gdf.columns else None
    edges_gdf['highway_key'] = edges_gdf['highway'].apply(get_first_value) if 'highway' in edges_gdf.columns else None
    edges_gdf['surface_coeff'] = edges_gdf['surface_key'].map(SURFACE_COEFFICIENTS).fillna(DEFAULT_COEFFICIENT)
    edges_gdf['highway_coeff'] = edges_gdf['highway_key'].map(HIGHWAY_COEFFICIENTS).fillna(DEFAULT_COEFFICIENT)
    
    # Веса
    length = edges_gdf['length'].values
    elev_diff = edges_gdf['elevation_diff'].values
    surface_coeff = edges_gdf['surface_coeff'].values
    highway_coeff = edges_gdf['highway_coeff'].values
    green_coeff = edges_gdf['green_coeff'].values
    
    # Расчёт градиента (уклона) — физически более точный подход
    # gradient = elevation_diff / length (например, 0.1 = 10% уклон)
    gradient = np.where(length > 0, elev_diff / length, 0)
    gradient = np.clip(gradient, -MAX_GRADIENT, MAX_GRADIENT)  # ограничиваем экстремальные значения
    
    # Сохраняем градиент для анализа
    edges_gdf['gradient'] = gradient
    edges_gdf['gradient_percent'] = gradient * 100
    
    # Физическая формула: W = m*g*L*(μ + sin(θ)) ≈ m*g*L*(μ + gradient) для малых углов
    # При подъёме: коэффициент = NU + gradient (больше работы)
    # При спуске: коэффициент = NU - |gradient| (меньше работы, но минимум MIN_DESCENT_COEFF)
    # При gradient=0: коэффициент = NU, base_weight = MG * NU * length (как было раньше!)
    effective_coeff = np.where(
        gradient >= 0,
        NU + gradient,                              # подъём
        np.maximum(NU - np.abs(gradient), MIN_DESCENT_COEFF)  # спуск (но не меньше минимума)
    )
    
    base_weight = MG * length * effective_coeff
    
    edges_gdf['weight_full'] = np.maximum(base_weight * surface_coeff * highway_coeff, 0)
    edges_gdf['weight_elevation_only'] = np.maximum(base_weight, 0)
    edges_gdf['weight_green'] = np.maximum(base_weight * surface_coeff * highway_coeff * green_coeff, 0)
    
    # Статистика
    green_edges = (edges_gdf['green_type'] != 'none').sum()
    avg_gradient = np.abs(gradient).mean() * 100
    max_gradient_val = np.abs(gradient).max() * 100
    uphill_count = (gradient > 0.01).sum()
    downhill_count = (gradient < -0.01).sum()
    
    print(f"   📈 Уклоны: средний {avg_gradient:.1f}%, макс {max_gradient_val:.1f}%")
    print(f"   ⬆️ Подъёмов: {uphill_count} | ⬇️ Спусков: {downhill_count}")
    print(f"   🌳 Озеленённых рёбер: {green_edges} из {len(edges_gdf)} ({100*green_edges/len(edges_gdf):.1f}%)")
    
    timer.stop()
    return edges_gdf


def apply_weights_to_graph(G, edges_gdf):
    timer.start("Применение весов к графу")
    
    edges_gdf = edges_gdf.reset_index()
    weight_cols = ['weight_full', 'weight_elevation_only', 'weight_green', 
                   'green_coeff', 'green_type', 'gradient',
                   'trees_percent', 'grass_percent', 'green_percent']
    
    # Проверяем какие колонки есть
    available_cols = [c for c in weight_cols if c in edges_gdf.columns]
    weight_dict = edges_gdf.set_index(['u', 'v', 'key'])[available_cols].to_dict('index')
    
    for u, v, key, data in G.edges(keys=True, data=True):
        weights = weight_dict.get((u, v, key), {})
        data['weight_full'] = weights.get('weight_full', data.get('length', 1))
        data['weight_elevation_only'] = weights.get('weight_elevation_only', data.get('length', 1))
        data['weight_green'] = weights.get('weight_green', data.get('length', 1))
        data['green_coeff'] = weights.get('green_coeff', 1.0)
        data['green_type'] = weights.get('green_type', 'none')
        data['gradient'] = weights.get('gradient', 0.0)
        # Новые поля для деревьев и травы
        data['trees_percent'] = weights.get('trees_percent', 0.0)
        data['grass_percent'] = weights.get('grass_percent', 0.0)
        data['green_percent'] = weights.get('green_percent', 0.0)
    
    timer.stop()
    return G


def find_route(G, start_coords, end_coords, weight_key):
    start_node = ox.distance.nearest_nodes(G, X=start_coords[1], Y=start_coords[0])
    end_node = ox.distance.nearest_nodes(G, X=end_coords[1], Y=end_coords[0])
    try:
        route = nx.shortest_path(G, source=start_node, target=end_node, weight=weight_key)
        return route, start_node, end_node
    except nx.NetworkXNoPath:
        return None, start_node, end_node


def calculate_route_cost(G, route, weight_key):
    if route is None:
        return 0
    return sum(G.edges[route[i], route[i+1], 0][weight_key] for i in range(len(route) - 1))


def calculate_route_length(G, route):
    if route is None:
        return 0
    return sum(G.edges[route[i], route[i+1], 0].get('length', 0) for i in range(len(route) - 1))


def calculate_route_green_stats(G, route):
    """
    Расчёт статистики озеленения маршрута.
    УЛУЧШЕНО: возвращает отдельно деревья и траву.
    """
    if route is None:
        return {'none': 0}, 0, 0, 0
    
    green_counter = Counter()
    total_trees_weighted = 0
    total_grass_weighted = 0
    total_green_length = 0
    total_length = 0
    
    for i in range(len(route) - 1):
        data = G.edges[route[i], route[i + 1], 0]
        green_type = data.get('green_type', 'none')
        length = data.get('length', 0)
        trees_pct = data.get('trees_percent', 0.0)
        grass_pct = data.get('grass_percent', 0.0)
        
        green_counter[green_type] += 1
        total_length += length
        
        # Взвешенное среднее по длине
        total_trees_weighted += trees_pct * length
        total_grass_weighted += grass_pct * length
        
        if green_type != 'none':
            total_green_length += length
    
    green_percent = (total_green_length / total_length * 100) if total_length > 0 else 0
    avg_trees = (total_trees_weighted / total_length) if total_length > 0 else 0
    avg_grass = (total_grass_weighted / total_length) if total_length > 0 else 0
    
    return dict(green_counter), green_percent, avg_trees, avg_grass


def count_attributes_in_route(G, route):
    surface_counter = Counter()
    highway_counter = Counter()
    
    if route is None:
        return surface_counter, highway_counter
    
    for i in range(len(route) - 1):
        data = G.edges[route[i], route[i + 1], 0]
        surface = get_first_value(data.get('surface', 'N/A')) or 'N/A'
        highway = get_first_value(data.get('highway', 'N/A')) or 'N/A'
        surface_counter[surface] += 1
        highway_counter[highway] += 1
    
    return surface_counter, highway_counter


def calculate_route_elevation_stats(G, route):
    """Расчёт статистики уклонов маршрута"""
    if route is None:
        return 0, 0, 0, 0
    
    total_climb = 0  # суммарный набор высоты
    total_descent = 0  # суммарный спуск
    max_gradient = 0  # максимальный уклон
    gradients = []
    
    for i in range(len(route) - 1):
        data = G.edges[route[i], route[i + 1], 0]
        gradient = data.get('gradient', 0)
        length = data.get('length', 0)
        gradients.append(abs(gradient))
        
        if gradient > 0:
            total_climb += gradient * length  # приблизительный набор высоты
        else:
            total_descent += abs(gradient) * length
        
        if abs(gradient) > max_gradient:
            max_gradient = abs(gradient)
    
    avg_gradient = sum(gradients) / len(gradients) if gradients else 0
    return total_climb, total_descent, max_gradient * 100, avg_gradient * 100


def print_route_comparison(name, G, route, cost_full, green_percent, trees_pct=0, grass_pct=0):
    if route is None:
        print(f"\n❌ {name}: маршрут не найден")
        return
        
    length = calculate_route_length(G, route)
    surface_counter, highway_counter = count_attributes_in_route(G, route)
    green_stats, _, _, _ = calculate_route_green_stats(G, route)
    climb, descent, max_grad, avg_grad = calculate_route_elevation_stats(G, route)
    
    print(f"\n📍 {name}")
    print(f"   Длина: {length:.0f} м | Стоимость: {cost_full:.1f} | Рёбер: {len(route)-1}")
    print(f"   📈 Набор: {climb:.0f}м | Спуск: {descent:.0f}м | Макс уклон: {max_grad:.1f}%")
    print(f"   🌳 Озеленение: {green_percent:.1f}% (🌲 деревья: {trees_pct:.1f}%, 🌿 трава: {grass_pct:.1f}%)")
    print(f"   📋 Категории: {green_stats}")
    print(f"   🛤️ Покрытия: {dict(surface_counter.most_common(3))}")


# ==================== MAIN ====================
if __name__ == "__main__":
    print("="*60)
    print("🚴 ТЕСТИРОВАНИЕ МАРШРУТИЗАЦИИ (без QGIS)")
    print("="*60)
    
    # Инициализация
    script_dir = init_environment()
    elevation_data = init_srtm()
    
    # Загрузка данных
    bbox = create_bbox(START_COORDS, END_COORDS, BUFFER)
    G = load_graph(bbox)
    
    if USE_SATELLITE_GREEN and PIL_AVAILABLE:
        print("\n🛰️ Используется анализ космоснимков для оценки зелени")
        green_geometries = {'parks': [], 'forests': [], 'trees': [], 'grass': []}
    elif LOAD_GREEN_AREAS:
        green_geometries = load_green_areas(bbox, skip_if_slow=SKIP_IF_SLOW)
    else:
        print("\n⏭️ Загрузка зелёных зон отключена (LOAD_GREEN_AREAS=False)")
        green_geometries = {'parks': [], 'forests': [], 'trees': [], 'grass': []}
    
    # Преобразование и расчёт весов
    timer.start("Преобразование графа")
    edges = ox.graph_to_gdfs(G, nodes=False, edges=True)
    edges = edges.explode(index_parts=False)
    print(f"   Всего рёбер: {len(edges)}")
    timer.stop()
    
    edges = calculate_weights_vectorized(edges, elevation_data, green_geometries)
    G = apply_weights_to_graph(G, edges)
    
    # Поиск маршрутов (только нужные)
    timer.start("Поиск маршрутов")
    route_full, start_node, end_node = find_route(G, START_COORDS, END_COORDS, 'weight_full')
    route_green, _, _ = find_route(G, START_COORDS, END_COORDS, 'weight_green')
    print(f"   Старт: {start_node} | Финиш: {end_node}")
    timer.stop()
    
    # Расчёт метрик
    cost_full = calculate_route_cost(G, route_full, 'weight_full')
    cost_green = calculate_route_cost(G, route_green, 'weight_full')
    
    # Статистика зелени (теперь с деревьями и травой!)
    _, green_pct_full, trees_full, grass_full = calculate_route_green_stats(G, route_full)
    _, green_pct_green, trees_green, grass_green = calculate_route_green_stats(G, route_green)
    
    # Вывод результатов
    print("\n" + "="*60)
    print("📊 СРАВНЕНИЕ МАРШРУТОВ")
    print("="*60)
    
    print_route_comparison("🟢 Полный вес", G, route_full, cost_full, green_pct_full, trees_full, grass_full)
    print_route_comparison("🌳 С озеленением", G, route_green, cost_green, green_pct_green, trees_green, grass_green)
    
    # Анализ
    if cost_full > 0:
        print("\n" + "-"*60)
        print("💡 АНАЛИЗ ВЫГОДЫ")
        print("-"*60)
        print(f"   vs 'с озеленением': {((cost_green - cost_full) / cost_full) * 100:+.1f}% энергии")
    
    # Итоговое время
    timer.summary()
    
    print("\n✅ Тестирование завершено!")
