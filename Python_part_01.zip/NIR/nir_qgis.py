import os
import math
from collections import Counter
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO
import numpy as np
import geopandas as gpd
import srtm
import osmnx as ox
from shapely.geometry import box, Point
from shapely.ops import unary_union
import networkx as nx
import requests
from qgis.core import (QgsVectorLayer, QgsField, QgsFeature, QgsGeometry, 
                       QgsProject, QgsPointXY, QgsRasterLayer, QgsCoordinateReferenceSystem)
from PyQt5.QtCore import QVariant

# Для анализа изображений
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("⚠️ Pillow не установлен. Установите: pip install pillow")

# ============== КОНФИГУРАЦИЯ ==============
# Физические параметры велосипедиста
MG = 16.66667       # масса * g / нормирующий коэффициент  
NU = 0.06           # коэффициент сопротивления качению
MIN_DESCENT_COEFF = 0.02  # минимальный коэффициент при спуске
MAX_GRADIENT = 0.30       # максимальный учитываемый уклон (30%)

# Координаты начальной и конечной точек
START_COORDS = (53.186243, 50.088031)  # (latitude, longitude)
END_COORDS = (53.195334,50.124063)    # (latitude, longitude)

# Буфер вокруг маршрута для загрузки дорог
BUFFER = 0.003  # Уменьшен для ускорения (был 0.005)

# Радиус поиска зелёных зон от дороги (в градусах, ~50м)
GREEN_BUFFER = 0.0005

# Коэффициенты озеленения (чем меньше - тем лучше для жары)
GREEN_COEFFICIENTS = {
    'in_park': 0.7,        # Дорога проходит через парк
    'near_trees': 0.85,    # Рядом с деревьями (в тени)
    'near_green': 0.9,     # Рядом с газоном/зеленью
    'no_green': 1.0,       # Нет озеленения
}

# Словарь коэффициентов для типов покрытий
SURFACE_COEFFICIENTS = {
    'asphalt': 0.9,
    'concrete': 1.1,
    'concrete:plates': 1.3,
    'paved': 1.2,
    'paving_stones': 1.4,
    'sett': 1.5,
    'compacted': 1.5,
    'fine_gravel': 1.7,
    'gravel': 2.0,
    'unpaved': 2.5,
    'dirt': 3.0,
    'ground': 3.0,
    'sand': 3.5,
    'grass': 4.0,
}

# Коэффициенты для типа дороги
HIGHWAY_COEFFICIENTS = {
    'cycleway': 0.3,
    'path': 0.5,
    'footway': 1.0,
    'residential': 1.0,
    'living_street': 1.0,
    'pedestrian': 1.0,
    'service': 1.1,
    'unclassified': 1.1,
    'track': 1.2,
    'tertiary': 1.2,
    'tertiary_link': 1.2,
    'secondary': 1.3,
    'secondary_link': 1.3,
    'primary': 1.4,
    'primary_link': 1.4,
    'steps': 10.0,
    'construction': 100.0
}

DEFAULT_COEFFICIENT = 1.0

# Настройки кэширования
CACHE_GREEN_AREAS = True  # Кэшировать зелёные зоны на диск?

# Настройки анализа зелени по космоснимкам
USE_SATELLITE_GREEN = True    # Использовать космоснимки вместо OSM?
SATELLITE_ZOOM = 20           # Уровень зума (20 = ~0.15м/пиксель, тайлы ~19м) - увеличен для большей детализации
ROAD_BUFFER_METERS = 10       # Буфер от дороги в метрах (коридор для анализа, 10м = 20м общий коридор)
CACHE_SATELLITE = True        # Кэшировать тайлы на диск?
CACHE_TILE_ANALYSIS = True    # Кэшировать результаты анализа тайлов?
FORCE_RECALCULATE = False      # Пересчитать (игнорировать кэш)?
ANALYZE_CORRIDOR = True       # Анализировать только коридор вокруг дороги (по требованию научрука)
CREATE_VEGETATION_LAYER = True  # Создавать слой растительности? (медленно при zoom=20, можно включить для проверки)
TILE_DOWNLOAD_THREADS = 6     # Количество потоков для параллельной загрузки тайлов (меньше для QGIS)

# TMS источники (спутниковые снимки)
TMS_SERVERS = {
    'google': 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
    'esri': 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
}
TMS_SERVER = 'google'  # Google обычно лучше для зелени
# ==========================================


def get_cache_path(bbox, cache_type="green"):
    """Генерирует путь к файлу кэша на основе bbox"""
    bounds = bbox.bounds
    cache_key = f"{cache_type}_{bounds[0]:.4f}_{bounds[1]:.4f}_{bounds[2]:.4f}_{bounds[3]:.4f}"
    cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, f"{cache_key}.pkl")


def load_from_cache(cache_path):
    """Загружает данные из кэша"""
    import pickle
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'rb') as f:
                data = pickle.load(f)
            return data
        except:
            return None
    return None


def save_to_cache(cache_path, data):
    """Сохраняет данные в кэш"""
    import pickle
    try:
        with open(cache_path, 'wb') as f:
            pickle.dump(data, f)
        return True
    except:
        return False


# ============== ФУНКЦИИ ДЛЯ АНАЛИЗА КОСМОСНИМКОВ ==============

def lat_lon_to_tile(lat, lon, zoom):
    """Конвертация координат в номер тайла TMS"""
    lat_rad = math.radians(lat)
    n = 2 ** zoom
    x = int((lon + 180.0) / 360.0 * n)
    y = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lat_lon(x, y, zoom):
    """Конвертация номера тайла в координаты (верхний левый угол)"""
    n = 2 ** zoom
    lon = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
    lat = math.degrees(lat_rad)
    return lat, lon


def get_tile_bounds(x, y, zoom):
    """Получить границы тайла в координатах"""
    lat1, lon1 = tile_to_lat_lon(x, y, zoom)
    lat2, lon2 = tile_to_lat_lon(x + 1, y + 1, zoom)
    return (lon1, lat2, lon2, lat1)  # (min_lon, min_lat, max_lon, max_lat)


def download_tile(x, y, zoom, server='google'):
    """Скачивает тайл с TMS сервера"""
    if not PIL_AVAILABLE:
        return None
    
    url = TMS_SERVERS.get(server, TMS_SERVERS['google'])
    url = url.format(x=x, y=y, z=zoom)
    
    # Проверяем кэш тайлов
    if CACHE_SATELLITE:
        cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache", "tiles")
        os.makedirs(cache_dir, exist_ok=True)
        cache_file = os.path.join(cache_dir, f"{server}_{zoom}_{x}_{y}.jpg")
        
        if os.path.exists(cache_file):
            try:
                return Image.open(cache_file)
            except:
                pass
    
    try:
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code == 200:
            img = Image.open(BytesIO(response.content))
            
            # Сохраняем в кэш
            if CACHE_SATELLITE:
                try:
                    img.save(cache_file, 'JPEG')
                except:
                    pass
            
            return img
    except Exception as e:
        pass
    
    return None


def analyze_green_in_image(img, mask=None, return_details=False):
    """
    Анализирует процент зелени на изображении.
    УЛУЧШЕНО: Различает ДЕРЕВЬЯ (тёмно-зелёные) и ТРАВУ (светло-зелёные).
    
    Args:
        img: PIL Image
        mask: опциональная маска (numpy array)
        return_details: если True, возвращает dict с деталями
    
    Returns: 
        Если return_details=False: общий процент зелени (0-100)
        Если return_details=True: dict {'trees': %, 'grass': %, 'total': %}
    """
    if img is None:
        if return_details:
            return {'trees': 0.0, 'grass': 0.0, 'total': 0.0}
        return 0.0
    
    # Конвертируем в RGB если нужно
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    # Получаем массив пикселей
    pixels = np.array(img, dtype=np.float32)
    r, g, b = pixels[:,:,0], pixels[:,:,1], pixels[:,:,2]
    
    # Normalized Green-Red Difference Index
    sum_rg = r + g + 0.001  # избегаем деления на 0
    ndi = (g - r) / sum_rg
    
    # Excess Green Index
    exg = g - (r + b) / 2.0
    
    # Яркость
    brightness = (r + g + b) / 3.0
    
    # Насыщенность зелёного
    max_rgb = np.maximum(np.maximum(r, g), b)
    min_rgb = np.minimum(np.minimum(r, g), b)
    saturation = (max_rgb - min_rgb) / (max_rgb + 0.001)
    
    # === БАЗОВЫЕ КРИТЕРИИ ЗЕЛЕНИ (ОСЛАБЛЕНЫ) ===
    base_green = (
        (ndi > 0.01) &          # Зелёный доминирует над красным (было 0.02)
        (exg > 1) &             # Excess green (было 2)
        (g > r) &               # Зелёный больше красного
        (g > 30) &              # Достаточно зелёного канала (было 35)
        (brightness > 5) &      # Не слишком тёмное (было 10)
        (brightness < 250)      # Не пересвечено
    )
    
    # === ДЕРЕВЬЯ: тёмно-зелёные, насыщенные (ОСЛАБЛЕНО) ===
    trees_mask = base_green & (
        (brightness < 120) |    # Тёмные области (было 100)
        ((brightness < 160) & (ndi > 0.05) & (saturation > 0.1))  # Средние но зелёные (было 140, 0.08, 0.15)
    )
    
    # === ТРАВА: светло-зелёная (ОСЛАБЛЕНО) ===
    grass_mask = base_green & ~trees_mask & (
        (brightness >= 60) &    # Светлее чем деревья (было 80)
        (brightness < 220) &    # Но не слишком светлые (было 200)
        (ndi > 0.01)            # Всё ещё зелёные (было 0.03)
    )
    
    # Применяем пространственную маску (коридор вокруг дороги)
    if mask is not None:
        mask_arr = np.array(mask)
        mask_pixels = (mask_arr > 0).sum()  # ИСПРАВЛЕНО: количество пикселей, а не сумма значений!
        if mask_pixels == 0:
            if return_details:
                return {'trees': 0.0, 'grass': 0.0, 'total': 0.0}
            return 0.0
        trees_mask = trees_mask & (mask_arr > 0)
        grass_mask = grass_mask & (mask_arr > 0)
        total_pixels = float(mask_pixels)
    else:
        total_pixels = float(pixels.shape[0] * pixels.shape[1])
    
    if total_pixels == 0:
        if return_details:
            return {'trees': 0.0, 'grass': 0.0, 'total': 0.0}
        return 0.0
    
    trees_pct = (float(trees_mask.sum()) / total_pixels) * 100
    grass_pct = (float(grass_mask.sum()) / total_pixels) * 100
    total_pct = trees_pct + grass_pct
    
    if return_details:
        return {'trees': trees_pct, 'grass': grass_pct, 'total': total_pct}
    
    return total_pct


def create_corridor_mask(edge_geom, tile_bounds, img_size, buffer_meters=ROAD_BUFFER_METERS):
    """
    Создаёт маску коридора вокруг дороги для анализа только релевантных пикселей.
    ИСПРАВЛЕНО: правильный расчёт ширины с ограничением.
    """
    from PIL import Image, ImageDraw
    
    min_lon, min_lat, max_lon, max_lat = tile_bounds
    width, height = img_size
    
    def coord_to_pixel(lon, lat):
        px = int((lon - min_lon) / (max_lon - min_lon) * width)
        py = int((max_lat - lat) / (max_lat - min_lat) * height)
        return (px, py)
    
    mask = Image.new('L', (width, height), 0)
    draw = ImageDraw.Draw(mask)
    
    if edge_geom.geom_type == 'LineString':
        coords = list(edge_geom.coords)
        if len(coords) >= 2:
            pixels = [coord_to_pixel(lon, lat) for lon, lat in coords]
            
            # Ширина тайла в метрах (на широте ~53°)
            lat_center = (min_lat + max_lat) / 2
            meters_per_deg_lon = 111000 * np.cos(np.radians(lat_center))
            tile_width_meters = (max_lon - min_lon) * meters_per_deg_lon
            tile_height_meters = (max_lat - min_lat) * 111000
            
            # Размер пикселя в метрах
            if tile_width_meters > 0 and tile_height_meters > 0:
                meters_per_pixel_x = tile_width_meters / width
                meters_per_pixel_y = tile_height_meters / height
                meters_per_pixel = max(meters_per_pixel_x, meters_per_pixel_y)
                
                # Ширина коридора в пикселях (40м = 20м с каждой стороны)
                line_width_pixels = int((buffer_meters * 2) / meters_per_pixel)
                
                # Ограничиваем разумными значениями: минимум 5, максимум 1/3 тайла
                line_width_pixels = max(5, min(line_width_pixels, min(width, height) // 3))
            else:
                line_width_pixels = 20  # Fallback
            
            # Рисуем линию
            for i in range(len(pixels) - 1):
                draw.line([pixels[i], pixels[i+1]], fill=255, width=line_width_pixels)
    
    return np.array(mask)


def calculate_green_satellite_batch(edges_gdf, zoom=SATELLITE_ZOOM, buffer_meters=ROAD_BUFFER_METERS):
    """
    Пакетный расчёт зелени для всех рёбер через космоснимки.
    
    УЛУЧШЕНО (по требованиям научрука):
    1. Zoom 19 для мелких тайлов (~38м)
    2. Анализ КОРИДОРА вокруг дороги (не всего тайла)
    3. Разделение на ДЕРЕВЬЯ и ТРАВУ (разные бонусы)
    """
    print("🛰️ Анализ зелени (космоснимки)...")
    
    if not PIL_AVAILABLE:
        print("   ⚠️ Pillow не установлен")
        edges_gdf['green_percent'] = 0.0
        edges_gdf['trees_percent'] = 0.0
        edges_gdf['grass_percent'] = 0.0
        edges_gdf['green_coeff'] = GREEN_COEFFICIENTS['no_green']
        edges_gdf['green_type'] = 'none'
        return edges_gdf
    
    buffer_deg = buffer_meters / 111000.0
    
    # Собираем все нужные тайлы
    all_tiles = set()
    edge_tiles = {}
    
    print(f"   📡 Параметры: zoom={zoom} (~{256 * 156543.03 / (2**zoom):.0f}м/тайл), буфер={buffer_meters}м")
    print(f"   🛣️ Режим: {'КОРИДОР вокруг дороги' if ANALYZE_CORRIDOR else 'весь тайл'}")
    
    for idx, row in edges_gdf.iterrows():
        geom = row.geometry
        if geom is None:
            continue
        
        bounds = geom.bounds
        x1, y1 = lat_lon_to_tile(bounds[3] + buffer_deg, bounds[0] - buffer_deg, zoom)
        x2, y2 = lat_lon_to_tile(bounds[1] - buffer_deg, bounds[2] + buffer_deg, zoom)
        
        tiles = []
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                tiles.append((x, y))
                all_tiles.add((x, y))
        edge_tiles[idx] = tiles
    
    print(f"   📥 Загрузка {len(all_tiles)} тайлов...")
    
    # Загружаем все тайлы
    tile_images = {}
    tiles_list = list(all_tiles)
    
    # Проверяем кэш результатов
    cache_path = None
    edge_results_cache = {}
    if CACHE_TILE_ANALYSIS:
        bounds = edges_gdf.total_bounds
        cache_key = f"corridor_v2_{zoom}_{buffer_meters}_{bounds[0]:.4f}_{bounds[1]:.4f}_{bounds[2]:.4f}_{bounds[3]:.4f}"
        cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")
        os.makedirs(cache_dir, exist_ok=True)
        cache_path = os.path.join(cache_dir, f"{cache_key}.pkl")
        if not FORCE_RECALCULATE:
            cached = load_from_cache(cache_path)
            if cached is not None:
                edge_results_cache = cached
                print(f"   💾 Результаты загружены из кэша ({len(edge_results_cache)} рёбер)")
        else:
            print(f"   ⚠️ FORCE_RECALCULATE=True, пересчитываем...")
    
    # Если всё в кэше - пропускаем загрузку
    if len(edge_results_cache) == len(edges_gdf):
        print(f"   ✅ Все результаты в кэше")
    else:
        # Параллельная загрузка тайлов (ускоряет в 4-6 раз)
        print(f"   ⚡ Параллельная загрузка ({TILE_DOWNLOAD_THREADS} потоков)...")
        debug_saved = False
        
        def download_tile_wrapper(tile_xy):
            x, y = tile_xy
            img = download_tile(x, y, zoom, TMS_SERVER)
            return (x, y), img
        
        # Загружаем параллельно
        with ThreadPoolExecutor(max_workers=TILE_DOWNLOAD_THREADS) as executor:
            futures = {executor.submit(download_tile_wrapper, (x, y)): (x, y) for x, y in tiles_list}
            completed = 0
            
            for future in as_completed(futures):
                completed += 1
                if completed % 500 == 0:
                    print(f"   Загружено {completed}/{len(tiles_list)} тайлов...")
                
                try:
                    (x, y), img = future.result()
                    if img is not None:
                        tile_images[(x, y)] = img
                        
                        # DEBUG: сохраняем первый тайл
                        if not debug_saved:
                            debug_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache", "debug_tile.jpg")
                            try:
                                img.save(debug_path, "JPEG")
                                pixels = np.array(img, dtype=np.float32)
                                print(f"   🔍 DEBUG: {debug_path}")
                                print(f"      RGB: R={pixels[:,:,0].mean():.0f}, G={pixels[:,:,1].mean():.0f}, B={pixels[:,:,2].mean():.0f}")
                                debug_saved = True
                            except:
                                pass
                except Exception as e:
                    pass  # Пропускаем ошибки загрузки
        
        print(f"   ✅ Загружено: {len(tile_images)} тайлов")
    
    # Анализируем каждое ребро
    print(f"   🌿 Анализ коридоров для {len(edges_gdf)} рёбер...")
    
    trees_list = []
    grass_list = []
    total_list = []
    
    edge_indices = list(edges_gdf.index)
    for i, idx in enumerate(edge_indices):
        if (i + 1) % 500 == 0:
            print(f"   Обработано {i + 1}/{len(edge_indices)} рёбер...")
        
        # Проверяем кэш
        if idx in edge_results_cache:
            result = edge_results_cache[idx]
            trees_list.append(result['trees'])
            grass_list.append(result['grass'])
            total_list.append(result['total'])
            continue
        
        row = edges_gdf.loc[idx]
        geom = row.geometry
        
        if idx not in edge_tiles or geom is None:
            trees_list.append(0.0)
            grass_list.append(0.0)
            total_list.append(0.0)
            continue
        
        # Собираем результаты со всех тайлов
        edge_trees = []
        edge_grass = []
        edge_total = []
        
        for tx, ty in edge_tiles[idx]:
            if (tx, ty) not in tile_images:
                continue
            
            img = tile_images[(tx, ty)]
            tile_bounds = get_tile_bounds(tx, ty, zoom)
            
            if ANALYZE_CORRIDOR:
                mask = create_corridor_mask(geom, tile_bounds, img.size, buffer_meters)
                if (mask > 0).sum() == 0:  # ИСПРАВЛЕНО: считаем пиксели, а не сумму значений
                    continue
                result = analyze_green_in_image(img, mask=mask, return_details=True)
            else:
                result = analyze_green_in_image(img, return_details=True)
            
            edge_trees.append(result['trees'])
            edge_grass.append(result['grass'])
            edge_total.append(result['total'])
        
        trees_pct = np.mean(edge_trees) if edge_trees else 0.0
        grass_pct = np.mean(edge_grass) if edge_grass else 0.0
        total_pct = np.mean(edge_total) if edge_total else 0.0
        
        trees_list.append(trees_pct)
        grass_list.append(grass_pct)
        total_list.append(total_pct)
        
        edge_results_cache[idx] = {'trees': trees_pct, 'grass': grass_pct, 'total': total_pct}
    
    # Сохраняем кэш
    if CACHE_TILE_ANALYSIS and cache_path:
        save_to_cache(cache_path, edge_results_cache)
        print(f"   💾 Результаты сохранены в кэш")
    
    # Записываем результаты
    edges_gdf['trees_percent'] = trees_list
    edges_gdf['grass_percent'] = grass_list
    edges_gdf['green_percent'] = total_list
    
    # === НОВАЯ ФОРМУЛА: деревья важнее травы! ===
    trees_pct = edges_gdf['trees_percent'].values
    grass_pct = edges_gdf['grass_percent'].values
    total_pct = edges_gdf['green_percent'].values
    
    penalty = np.maximum(0, (10 - total_pct) / 100)
    trees_bonus = trees_pct / 100 * 0.6
    grass_bonus = grass_pct / 100 * 0.25
    
    edges_gdf['green_coeff'] = np.clip(1.0 + penalty - trees_bonus - grass_bonus, 0.3, 1.2)
    
    # Категоризация
    def categorize_green(row):
        if row['trees_percent'] >= 15:
            return 'trees'
        elif row['trees_percent'] + row['grass_percent'] >= 25:
            return 'park'
        elif row['grass_percent'] >= 10:
            return 'grass'
        elif row['trees_percent'] + row['grass_percent'] >= 3:
            return 'sparse'
        else:
            return 'none'
    
    edges_gdf['green_type'] = edges_gdf.apply(categorize_green, axis=1)
    
    # Статистика
    avg_trees = edges_gdf['trees_percent'].mean()
    avg_grass = edges_gdf['grass_percent'].mean()
    max_trees = edges_gdf['trees_percent'].max()
    
    print(f"\n   📊 СТАТИСТИКА ЗЕЛЕНИ В КОРИДОРЕ ({buffer_meters}м):")
    print(f"      🌳 Деревья: средн. {avg_trees:.1f}%, макс. {max_trees:.1f}%")
    print(f"      🌿 Трава:   средн. {avg_grass:.1f}%")
    
    type_stats = edges_gdf['green_type'].value_counts()
    print(f"      📋 Категории: {dict(type_stats)}")
    
    return edges_gdf


# ============== КОНЕЦ ФУНКЦИЙ КОСМОСНИМКОВ ==============


def init_environment():
    """Инициализация окружения и кэша"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cache_dir = os.path.join(script_dir, "osmnx_cache")
    os.makedirs(cache_dir, exist_ok=True)
    ox.settings.cache_folder = cache_dir
    ox.settings.useful_tags_way += ['surface']
    return script_dir


def init_srtm():
    """Инициализация SRTM с тестом"""
    print("🗺️ Инициализация SRTM...")
    elevation_data = srtm.get_data()
    
    test_elevation = elevation_data.get_elevation(START_COORDS[0], START_COORDS[1])
    if test_elevation is None:
        print("⚠️ ВНИМАНИЕ: SRTM не возвращает данные!")
    else:
        print(f"✅ SRTM работает. Высота в точке старта: {test_elevation} м")
    
    return elevation_data


def create_bbox(start, end, buffer):
    """Создание bounding box для загрузки данных"""
    min_lat = min(start[0], end[0]) - buffer
    min_lon = min(start[1], end[1]) - buffer
    max_lat = max(start[0], end[0]) + buffer
    max_lon = max(start[1], end[1]) + buffer
    return box(min_lon, min_lat, max_lon, max_lat)


def load_graph(bbox):
    """Загрузка графа дорог из OSM"""
    print("🌐 Загрузка данных OSM (дороги)...")
    custom_filter = (
        '["highway"~"construction|cycleway|footway|living_street|path|pedestrian|platform|'
        'primary|primary_link|residential|secondary|secondary_link|service|steps|tertiary|'
        'tertiary_link|track|unclassified"]'
    )
    
    G = ox.graph_from_polygon(
        bbox,
        custom_filter=custom_filter,
        simplify=False,
        retain_all=True
    )
    print(f"✅ Загружено {G.number_of_nodes()} узлов и {G.number_of_edges()} рёбер")
    return G


def load_green_areas(bbox, use_cache=True):
    """
    Загрузка зелёных зон из OSM через прямой Overpass API запрос.
    С кэшированием, retry и fallback на ox.features_from_bbox при ошибках.
    """
    print("🌳 Загрузка данных о зелёных насаждениях...")
    
    # Проверяем кэш
    if use_cache and CACHE_GREEN_AREAS:
        cache_path = get_cache_path(bbox, "green")
        cached = load_from_cache(cache_path)
        if cached is not None:
            print(f"   💾 Загружено из кэша: {sum(len(v) for v in cached.values())} объектов")
            return cached
    
    green_geometries = {'parks': [], 'forests': [], 'trees': [], 'grass': []}
    bounds = bbox.bounds
    north, south, east, west = bounds[3], bounds[1], bounds[2], bounds[0]
    
    success = False
    
    # Попытка 1: Быстрый Overpass API запрос
    try:
        import requests
        from shapely.geometry import Polygon
        import time
        
        # Пробуем разные серверы Overpass
        overpass_servers = [
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
        ]
        
        query = f"""
        [out:json][timeout:60];
        (
          way["leisure"="park"]({south},{west},{north},{east});
          relation["leisure"="park"]({south},{west},{north},{east});
          way["leisure"="garden"]({south},{west},{north},{east});
        );
        out geom;
        """
        
        for server in overpass_servers:
            try:
                print(f"   📡 Запрос парков ({server.split('/')[2]})...")
                response = requests.get(server, params={'data': query}, timeout=60)
                
                if response.status_code == 200:
                    data = response.json()
                    elements = data.get('elements', [])
                    
                    for elem in elements:
                        if elem.get('type') == 'way' and 'geometry' in elem:
                            coords = [(p['lon'], p['lat']) for p in elem['geometry']]
                            if len(coords) >= 3:
                                try:
                                    poly = Polygon(coords)
                                    if poly.is_valid:
                                        green_geometries['parks'].append(poly)
                                except:
                                    pass
                    
                    print(f"   ✅ Парки: {len(green_geometries['parks'])}")
                    success = True
                    break
                else:
                    print(f"   ⚠️ Ошибка {response.status_code}, пробуем другой сервер...")
                    time.sleep(1)
                    
            except requests.exceptions.Timeout:
                print(f"   ⚠️ Таймаут, пробуем другой сервер...")
                continue
            except Exception as e:
                print(f"   ⚠️ Ошибка: {e}")
                continue
                
    except Exception as e:
        print(f"   ⚠️ Ошибка Overpass: {e}")
    
    # Попытка 2: Fallback на OSMnx (медленнее, но надёжнее)
    if not success and len(green_geometries['parks']) == 0:
        print("   🔄 Fallback: загрузка через OSMnx...")
        try:
            tags = {'leisure': ['park', 'garden']}
            parks = ox.features_from_bbox(bbox=(north, south, east, west), tags=tags)
            if len(parks) > 0:
                green_geometries['parks'] = [g.intersection(bbox) for g in parks.geometry if g.intersects(bbox)]
                print(f"   ✅ Парки (OSMnx): {len(green_geometries['parks'])}")
        except Exception as e:
            print(f"   ⚠️ OSMnx тоже не сработал: {e}")
    
    total = sum(len(v) for v in green_geometries.values())
    print(f"✅ Всего зелёных объектов: {total}")
    
    # Сохраняем в кэш
    if use_cache and CACHE_GREEN_AREAS and total > 0:
        cache_path = get_cache_path(bbox, "green")
        if save_to_cache(cache_path, green_geometries):
            print(f"   💾 Сохранено в кэш")
    
    return green_geometries


def calculate_green_with_sjoin(edges_gdf, green_geometries):
    """
    БЫСТРЫЙ расчёт озеленения через spatial join.
    Работает за секунды вместо минут!
    """
    print("🌿 Расчёт озеленённости (spatial join)...")
    
    # Приоритет типов зелени (чем меньше индекс - тем лучше)
    green_priority = {'park': 0, 'forest': 1, 'trees': 2, 'grass': 3}
    green_coeff_map = {
        'park': GREEN_COEFFICIENTS['in_park'],
        'forest': GREEN_COEFFICIENTS['in_park'],
        'trees': GREEN_COEFFICIENTS['near_trees'],
        'grass': GREEN_COEFFICIENTS['near_green'],
    }
    
    # Собираем все зелёные объекты в один GeoDataFrame
    green_rows = []
    type_mapping = {
        'parks': 'park',
        'forests': 'forest', 
        'trees': 'trees',
        'grass': 'grass'
    }
    
    for key, green_type in type_mapping.items():
        geoms = green_geometries.get(key, [])
        for geom in geoms:
            if geom is not None and geom.is_valid:
                green_rows.append({'geometry': geom, 'green_type': green_type})
    
    if not green_rows:
        print("   ⚠️ Зелёных объектов не найдено")
        edges_gdf['green_type'] = 'none'
        edges_gdf['green_coeff'] = GREEN_COEFFICIENTS['no_green']
        return edges_gdf
    
    green_gdf = gpd.GeoDataFrame(green_rows, crs="EPSG:4326")
    print(f"   📊 Всего зелёных объектов: {len(green_gdf)}")
    
    # Создаём буфер вокруг рёбер для поиска близких объектов
    edges_buffered = edges_gdf.copy()
    # Подавляем warning о CRS - для небольших буферов в градусах это допустимо
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        edges_buffered['geometry'] = edges_gdf.geometry.buffer(GREEN_BUFFER)
    edges_buffered['edge_idx'] = range(len(edges_buffered))
    
    # Spatial join - находит пересечения за секунды!
    joined = gpd.sjoin(edges_buffered[['geometry', 'edge_idx']], green_gdf, how='left', predicate='intersects')
    joined['priority'] = joined['green_type'].map(green_priority).fillna(999)
    
    # Фильтруем только строки с реальными пересечениями (не NaN)
    valid_joins = joined[joined['green_type'].notna()]
    
    if len(valid_joins) > 0:
        best_green = valid_joins.loc[valid_joins.groupby('edge_idx')['priority'].idxmin()]
        green_dict = dict(zip(best_green['edge_idx'], best_green['green_type']))
    else:
        green_dict = {}
    
    # Применяем к исходному DataFrame
    edges_gdf['green_type'] = [green_dict.get(i, 'none') for i in range(len(edges_gdf))]
    edges_gdf['green_coeff'] = edges_gdf['green_type'].map(
        lambda x: green_coeff_map.get(x, GREEN_COEFFICIENTS['no_green'])
    )
    
    # Статистика
    stats = edges_gdf['green_type'].value_counts()
    print(f"   ✅ Результат: {dict(stats)}")
    
    return edges_gdf


def get_first_value(val):
    """Извлекает первое значение из списка или возвращает само значение"""
    if isinstance(val, list):
        return val[0] if val else None
    return val


def calculate_weights_vectorized(edges_gdf, elevation_data, green_geometries):
    """Векторизованный расчёт весов для всех рёбер"""
    print("⚙️ Расчёт весов рёбер...")
    
    # Кэш для высот
    elevation_cache = {}
    
    def get_elevation_cached(lon, lat):
        key = (round(lon, 5), round(lat, 5))
        if key not in elevation_cache:
            height = elevation_data.get_elevation(key[1], key[0])
            elevation_cache[key] = height if height is not None else 0
        return elevation_cache[key]
    
    # Расчёт разницы высот
    def calc_elev_diff(geom):
        start = get_elevation_cached(geom.coords[0][0], geom.coords[0][1])
        end = get_elevation_cached(geom.coords[-1][0], geom.coords[-1][1])
        return end - start
    
    edges_gdf['elevation_diff'] = edges_gdf.geometry.apply(calc_elev_diff)
    
    # Расчёт озеленения
    if USE_SATELLITE_GREEN and PIL_AVAILABLE:
        # Новый метод: анализ космоснимков
        edges_gdf = calculate_green_satellite_batch(edges_gdf)
    else:
        # Старый метод: OSM данные
        edges_gdf = calculate_green_with_sjoin(edges_gdf, green_geometries)
    
    # Извлечение коэффициентов (векторизовано)
    edges_gdf['surface_key'] = edges_gdf['surface'].apply(get_first_value) if 'surface' in edges_gdf.columns else None
    edges_gdf['highway_key'] = edges_gdf['highway'].apply(get_first_value) if 'highway' in edges_gdf.columns else None
    
    edges_gdf['surface_coeff'] = edges_gdf['surface_key'].map(SURFACE_COEFFICIENTS).fillna(DEFAULT_COEFFICIENT)
    edges_gdf['highway_coeff'] = edges_gdf['highway_key'].map(HIGHWAY_COEFFICIENTS).fillna(DEFAULT_COEFFICIENT)
    
    # Векторизованный расчёт весов с использованием numpy
    length = edges_gdf['length'].values
    elev_diff = edges_gdf['elevation_diff'].values
    surface_coeff = edges_gdf['surface_coeff'].values
    highway_coeff = edges_gdf['highway_coeff'].values
    green_coeff = edges_gdf['green_coeff'].values
    
    # Расчёт градиента (уклона) — физически более точный подход
    gradient = np.where(length > 0, elev_diff / length, 0)
    gradient = np.clip(gradient, -MAX_GRADIENT, MAX_GRADIENT)
    
    edges_gdf['gradient'] = gradient
    edges_gdf['gradient_percent'] = gradient * 100
    
    # Физическая формула: W = m*g*L*(μ + gradient) для подъёма
    effective_coeff = np.where(
        gradient >= 0,
        NU + gradient,
        np.maximum(NU - np.abs(gradient), MIN_DESCENT_COEFF)
    )
    
    base_weight = MG * length * effective_coeff
    
    # Веса для разных критериев
    edges_gdf['weight_full'] = np.maximum(base_weight * surface_coeff * highway_coeff, 0)
    edges_gdf['weight_elevation_only'] = np.maximum(base_weight, 0)
    edges_gdf['weight_green'] = np.maximum(base_weight * surface_coeff * highway_coeff * green_coeff, 0)
    
    # Статистика
    avg_gradient = np.abs(gradient).mean() * 100
    max_gradient_val = np.abs(gradient).max() * 100
    green_edges = (edges_gdf['green_type'] != 'none').sum()
    print(f"📈 Уклоны: средний {avg_gradient:.1f}%, макс {max_gradient_val:.1f}%")
    print(f"🌳 Озеленённых рёбер: {green_edges} из {len(edges_gdf)} ({100*green_edges/len(edges_gdf):.1f}%)")
    
    return edges_gdf


def apply_weights_to_graph(G, edges_gdf):
    """Применение весов к графу"""
    edges_gdf = edges_gdf.reset_index()
    weight_cols = ['weight_full', 'weight_elevation_only', 'weight_green', 
                   'green_coeff', 'green_type', 'gradient',
                   'trees_percent', 'grass_percent', 'green_percent']
    
    available_cols = [c for c in weight_cols if c in edges_gdf.columns]
    weight_dict = edges_gdf.set_index(['u', 'v', 'key'])[available_cols].to_dict('index')
    
    for u, v, key, data in G.edges(keys=True, data=True):
        weights = weight_dict.get((u, v, key), {})
        data['weight_full'] = weights.get('weight_full', data.get('length', 1))
        data['weight_elevation_only'] = weights.get('weight_elevation_only', data.get('length', 1))
        data['weight_green'] = weights.get('weight_green', data.get('length', 1))
        data['green_coeff'] = weights.get('green_coeff', 1.0)
        data['green_type'] = weights.get('green_type', 'none')
        data['gradient'] = weights.get('gradient', 0.0)
        data['trees_percent'] = weights.get('trees_percent', 0.0)
        data['grass_percent'] = weights.get('grass_percent', 0.0)
        data['green_percent'] = weights.get('green_percent', 0.0)
    
    return G


def find_route(G, start_coords, end_coords, weight_key):
    """Поиск маршрута с обработкой ошибок"""
    start_node = ox.distance.nearest_nodes(G, X=start_coords[1], Y=start_coords[0])
    end_node = ox.distance.nearest_nodes(G, X=end_coords[1], Y=end_coords[0])
    
    try:
        route = nx.shortest_path(G, source=start_node, target=end_node, weight=weight_key)
        return route, start_node, end_node
    except nx.NetworkXNoPath:
        print(f"❌ Маршрут не найден по весу '{weight_key}'")
        return None, start_node, end_node


def calculate_route_cost(G, route, weight_key):
    """Расчёт стоимости маршрута"""
    if route is None:
        return 0
    return sum(G.edges[route[i], route[i+1], 0][weight_key] for i in range(len(route) - 1))


def calculate_route_length(G, route):
    """Расчёт длины маршрута в метрах"""
    if route is None:
        return 0
    return sum(G.edges[route[i], route[i+1], 0].get('length', 0) for i in range(len(route) - 1))


def calculate_route_green_stats(G, route):
    """
    Расчёт статистики озеленения маршрута.
    УЛУЧШЕНО: возвращает отдельно деревья и траву.
    """
    if route is None:
        return {'none': 0}, 0, 0, 0
    
    green_counter = Counter()
    total_trees_weighted = 0
    total_grass_weighted = 0
    total_green_length = 0
    total_length = 0
    
    for i in range(len(route) - 1):
        data = G.edges[route[i], route[i + 1], 0]
        green_type = data.get('green_type', 'none')
        length = data.get('length', 0)
        trees_pct = data.get('trees_percent', 0.0)
        grass_pct = data.get('grass_percent', 0.0)
        
        green_counter[green_type] += 1
        total_length += length
        
        total_trees_weighted += trees_pct * length
        total_grass_weighted += grass_pct * length
        
        if green_type != 'none':
            total_green_length += length
    
    green_percent = (total_green_length / total_length * 100) if total_length > 0 else 0
    avg_trees = (total_trees_weighted / total_length) if total_length > 0 else 0
    avg_grass = (total_grass_weighted / total_length) if total_length > 0 else 0
    
    return dict(green_counter), green_percent, avg_trees, avg_grass


def count_attributes_in_route(G, route):
    """Подсчёт типов покрытий и дорог в маршруте"""
    surface_counter = Counter()
    highway_counter = Counter()
    
    if route is None:
        return surface_counter, highway_counter
    
    for i in range(len(route) - 1):
        data = G.edges[route[i], route[i + 1], 0]
        
        surface = get_first_value(data.get('surface', 'N/A')) or 'N/A'
        highway = get_first_value(data.get('highway', 'N/A')) or 'N/A'
        
        surface_counter[surface] += 1
        highway_counter[highway] += 1
    
    return surface_counter, highway_counter


def calculate_route_elevation_stats(G, route):
    """Расчёт статистики уклонов маршрута"""
    if route is None:
        return 0, 0, 0, 0
    
    total_climb = 0
    total_descent = 0
    max_gradient = 0
    gradients = []
    
    for i in range(len(route) - 1):
        data = G.edges[route[i], route[i + 1], 0]
        gradient = data.get('gradient', 0)
        length = data.get('length', 0)
        gradients.append(abs(gradient))
        
        if gradient > 0:
            total_climb += gradient * length
        else:
            total_descent += abs(gradient) * length
        
        if abs(gradient) > max_gradient:
            max_gradient = abs(gradient)
    
    avg_gradient = sum(gradients) / len(gradients) if gradients else 0
    return total_climb, total_descent, max_gradient * 100, avg_gradient * 100


def add_satellite_layer():
    """Добавляет слой спутниковых снимков в QGIS для визуальной проверки"""
    # Google Satellite
    if TMS_SERVER == 'google':
        url = "type=xyz&url=https://mt1.google.com/vt/lyrs%3Ds%26x%3D{x}%26y%3D{y}%26z%3D{z}&zmax=20&zmin=0"
    else:
        url = "type=xyz&url=https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}&zmax=20&zmin=0"
    
    layer = QgsRasterLayer(url, "Спутниковые снимки", "wms")
    if layer.isValid():
        QgsProject.instance().addMapLayer(layer)
        # Перемещаем вниз
        root = QgsProject.instance().layerTreeRoot()
        node = root.findLayer(layer.id())
        if node:
            clone = node.clone()
            root.insertChildNode(-1, clone)
            root.removeChildNode(node)
        return layer
    return None


def create_route_layer(G, route, layer_name, cost=None, length=None, green_percent=None):
    """Создание QGIS-слоя из маршрута с дополнительными атрибутами"""
    if route is None:
        return None
        
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", layer_name, "memory")
    provider = layer.dataProvider()
    
    provider.addAttributes([
        QgsField("length_m", QVariant.Double),
        QgsField("cost", QVariant.Double),
        QgsField("nodes", QVariant.Int),
        QgsField("green_pct", QVariant.Double)
    ])
    layer.updateFields()
    
    coords = [(G.nodes[node]['x'], G.nodes[node]['y']) for node in route]
    line = QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in coords])
    
    feature = QgsFeature()
    feature.setGeometry(line)
    feature.setAttributes([length or 0, cost or 0, len(route), green_percent or 0])
    provider.addFeature(feature)
    layer.updateExtents()
    
    return layer


def create_edge_layer(edges_gdf, layer_name):
    """Создание QGIS-слоя из всех рёбер (оптимизированная версия)"""
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", layer_name, "memory")
    provider = layer.dataProvider()
    
    # Выбираем только нужные колонки
    cols_to_export = ['length', 'weight_full', 'weight_green', 'elevation_diff', 
                      'highway', 'surface', 'green_type', 'green_coeff']
    cols_available = [c for c in cols_to_export if c in edges_gdf.columns]
    
    provider.addAttributes([QgsField(col, QVariant.String) for col in cols_available])
    layer.updateFields()
    
    # Batch добавление фичей (быстрее чем по одной)
    features = []
    for _, row in edges_gdf.iterrows():
        feature = QgsFeature()
        feature.setGeometry(QgsGeometry.fromWkt(row['geometry'].wkt))
        feature.setAttributes([str(row.get(col, '')) for col in cols_available])
        features.append(feature)
    
    provider.addFeatures(features)
    layer.updateExtents()
    return layer


def create_green_layer(green_geometries, layer_name):
    """Создание QGIS-слоя для визуализации зелёных зон (OSM)"""
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", layer_name, "memory")
    provider = layer.dataProvider()
    
    provider.addAttributes([QgsField("type", QVariant.String)])
    layer.updateFields()
    
    features = []
    for green_type, geometries in green_geometries.items():
        for geom in geometries:
            try:
                feature = QgsFeature()
                feature.setGeometry(QgsGeometry.fromWkt(geom.wkt))
                feature.setAttributes([green_type])
                features.append(feature)
            except:
                pass  # Пропускаем невалидные геометрии
    
    provider.addFeatures(features)
    layer.updateExtents()
    return layer


def load_vegetation_from_osm(bbox):
    """
    Загрузка растительности из OSM: парки, леса, деревья, газоны.
    Возвращает GeoDataFrame с полигонами.
    """
    from shapely.geometry import Polygon
    
    print("🌲 Загрузка растительности из OSM...")
    
    bounds = bbox.bounds
    north, south, east, west = bounds[3], bounds[1], bounds[2], bounds[0]
    
    vegetation = []
    
    # Расширенный запрос к Overpass API — все виды растительности
    query = f"""
    [out:json][timeout:90];
    (
      // Парки и сады
      way["leisure"="park"]({south},{west},{north},{east});
      way["leisure"="garden"]({south},{west},{north},{east});
      relation["leisure"="park"]({south},{west},{north},{east});
      
      // Леса и рощи
      way["landuse"="forest"]({south},{west},{north},{east});
      way["natural"="wood"]({south},{west},{north},{east});
      relation["landuse"="forest"]({south},{west},{north},{east});
      relation["natural"="wood"]({south},{west},{north},{east});
      
      // Газоны и зелёные зоны
      way["landuse"="grass"]({south},{west},{north},{east});
      way["landuse"="meadow"]({south},{west},{north},{east});
      way["landuse"="village_green"]({south},{west},{north},{east});
      way["landuse"="greenfield"]({south},{west},{north},{east});
      way["natural"="grassland"]({south},{west},{north},{east});
      way["natural"="scrub"]({south},{west},{north},{east});
      
      // Кладбища (обычно зелёные)
      way["landuse"="cemetery"]({south},{west},{north},{east});
      
      // Стадионы и спортплощадки (газон)
      way["leisure"="pitch"]({south},{west},{north},{east});
      way["leisure"="golf_course"]({south},{west},{north},{east});
      
      // Аллеи и зелёные зоны
      way["landuse"="allotments"]({south},{west},{north},{east});
      way["landuse"="orchard"]({south},{west},{north},{east});
      way["landuse"="vineyard"]({south},{west},{north},{east});
      
      // Природные зоны
      way["boundary"="national_park"]({south},{west},{north},{east});
      way["leisure"="nature_reserve"]({south},{west},{north},{east});
    );
    out geom;
    """
    
    overpass_servers = [
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
    ]
    
    for server in overpass_servers:
        try:
            print(f"   📡 Запрос ({server.split('/')[2]})...")
            response = requests.get(server, params={'data': query}, timeout=60)
            
            if response.status_code == 200:
                data = response.json()
                elements = data.get('elements', [])
                
                for elem in elements:
                    if elem.get('type') == 'way' and 'geometry' in elem:
                        coords = [(p['lon'], p['lat']) for p in elem['geometry']]
                        if len(coords) >= 3:
                            try:
                                poly = Polygon(coords)
                                if poly.is_valid and poly.area > 0:
                                    tags = elem.get('tags', {})
                                    veg_type = (tags.get('leisure') or 
                                               tags.get('landuse') or 
                                               tags.get('natural') or 'unknown')
                                    vegetation.append({
                                        'geometry': poly,
                                        'type': veg_type,
                                        'name': tags.get('name', '')
                                    })
                            except:
                                pass
                
                print(f"   ✅ Загружено {len(vegetation)} объектов растительности")
                break
            else:
                print(f"   ⚠️ Ошибка {response.status_code}, пробуем другой сервер...")
                
        except Exception as e:
            print(f"   ⚠️ Ошибка: {e}")
            continue
    
    return vegetation


def create_vegetation_layer_osm(bbox, layer_name="🌲 Растительность (OSM)"):
    """Создание QGIS-слоя с растительностью из OSM"""
    from qgis.core import QgsSymbol, QgsCategorizedSymbolRenderer, QgsRendererCategory
    from PyQt5.QtGui import QColor
    
    vegetation = load_vegetation_from_osm(bbox)
    
    if not vegetation:
        print("   ⚠️ Растительность не найдена")
        return None
    
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", layer_name, "memory")
    provider = layer.dataProvider()
    
    provider.addAttributes([
        QgsField("type", QVariant.String),
        QgsField("name", QVariant.String)
    ])
    layer.updateFields()
    
    features = []
    for item in vegetation:
        try:
            feature = QgsFeature()
            feature.setGeometry(QgsGeometry.fromWkt(item['geometry'].wkt))
            feature.setAttributes([item['type'], item['name']])
            features.append(feature)
        except:
            pass
    
    provider.addFeatures(features)
    layer.updateExtents()
    
    # Категоризированная стилизация по типу
    categories = []
    
    # Цвета для разных типов растительности
    type_colors = {
        'park': (144, 238, 144, 150),       # lightgreen
        'garden': (60, 179, 113, 150),      # mediumseagreen
        'grass': (154, 205, 50, 120),       # yellowgreen
        'meadow': (124, 252, 0, 120),       # lawngreen
        'village_green': (144, 238, 144, 130),
        'greenfield': (173, 255, 47, 100),
        'grassland': (154, 205, 50, 120),
        'scrub': (107, 142, 35, 150),       # olivedrab
        'forest': (34, 139, 34, 180),       # forestgreen
        'wood': (0, 100, 0, 180),           # darkgreen
        'cemetery': (85, 107, 47, 120),     # darkolivegreen
        'pitch': (50, 205, 50, 100),        # limegreen
        'golf_course': (0, 128, 0, 100),
        'allotments': (128, 128, 0, 120),
        'orchard': (107, 142, 35, 130),
        'vineyard': (85, 107, 47, 130),
        'national_park': (34, 139, 34, 100),
        'nature_reserve': (0, 100, 0, 100),
    }
    
    type_names = {
        'park': 'Парки', 'garden': 'Сады', 'grass': 'Газоны',
        'meadow': 'Луга', 'village_green': 'Скверы', 'greenfield': 'Зелёные зоны',
        'grassland': 'Травяные', 'scrub': 'Кустарники', 'forest': 'Леса',
        'wood': 'Рощи', 'cemetery': 'Кладбища', 'pitch': 'Стадионы',
        'golf_course': 'Гольф', 'allotments': 'Огороды', 'orchard': 'Сады плод.',
        'vineyard': 'Виноградники', 'national_park': 'Нац. парки',
        'nature_reserve': 'Заповедники'
    }
    
    for veg_type, color in type_colors.items():
        symbol = QgsSymbol.defaultSymbol(layer.geometryType())
        symbol.setColor(QColor(*color))
        name = type_names.get(veg_type, veg_type)
        categories.append(QgsRendererCategory(veg_type, symbol, name))
    
    renderer = QgsCategorizedSymbolRenderer('type', categories)
    layer.setRenderer(renderer)
    
    return layer


def create_vegetation_layer_satellite(bbox, zoom=SATELLITE_ZOOM, layer_name="🌲 Растительность (спутник)"):
    """
    Создание QGIS-слоя с растительностью на основе анализа спутниковых снимков.
    Использует тот же алгоритм что и 'Озеленение дорог' для проверки.
    """
    from shapely.geometry import box as shapely_box
    from PyQt5.QtGui import QColor
    from qgis.core import QgsSymbol, QgsRendererRange, QgsGraduatedSymbolRenderer
    
    print("🛰️ Создание слоя растительности из спутника...")
    
    if not PIL_AVAILABLE:
        print("   ⚠️ Pillow не установлен")
        return None
    
    bounds = bbox.bounds
    min_lon, min_lat, max_lon, max_lat = bounds
    
    # Получаем все тайлы для области
    x1, y1 = lat_lon_to_tile(max_lat, min_lon, zoom)
    x2, y2 = lat_lon_to_tile(min_lat, max_lon, zoom)
    
    tiles = []
    for x in range(x1, x2 + 1):
        for y in range(y1, y2 + 1):
            tiles.append((x, y))
    
    print(f"   📡 Анализ {len(tiles)} тайлов...")
    
    # Анализируем каждый тайл и создаём полигон с % зелени
    tile_data = []
    for i, (x, y) in enumerate(tiles):
        if (i + 1) % 30 == 0:
            print(f"   Обработано {i + 1}/{len(tiles)} тайлов...")
        
        img = download_tile(x, y, zoom, TMS_SERVER)
        if img is None:
            continue
        
        green_pct = analyze_green_in_image(img)
        tile_bounds = get_tile_bounds(x, y, zoom)  # (min_lon, min_lat, max_lon, max_lat)
        
        tile_data.append({
            'geometry': shapely_box(tile_bounds[0], tile_bounds[1], tile_bounds[2], tile_bounds[3]),
            'green_pct': green_pct
        })
    
    print(f"   ✅ Проанализировано {len(tile_data)} тайлов")
    
    # Создаём QGIS слой
    layer = QgsVectorLayer("Polygon?crs=EPSG:4326", layer_name, "memory")
    provider = layer.dataProvider()
    
    provider.addAttributes([
        QgsField("green_pct", QVariant.Double),
        QgsField("category", QVariant.String)
    ])
    layer.updateFields()
    
    features = []
    for item in tile_data:
        try:
            feature = QgsFeature()
            feature.setGeometry(QgsGeometry.fromWkt(item['geometry'].wkt))
            
            # Категоризация
            pct = item['green_pct']
            if pct >= 25:
                cat = 'Много зелени (25%+)'
            elif pct >= 10:
                cat = 'Средне (10-25%)'
            elif pct >= 3:
                cat = 'Мало (3-10%)'
            else:
                cat = 'Нет зелени (<3%)'
            
            feature.setAttributes([pct, cat])
            features.append(feature)
        except:
            pass
    
    provider.addFeatures(features)
    layer.updateExtents()
    
    # Градиентная стилизация по проценту зелени
    ranges = []
    
    # 0-3%: прозрачный/серый
    symbol0 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol0.setColor(QColor(200, 200, 200, 50))
    ranges.append(QgsRendererRange(0, 3, symbol0, "< 3% (нет)"))
    
    # 3-10%: светло-зелёный
    symbol1 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol1.setColor(QColor(200, 255, 200, 100))
    ranges.append(QgsRendererRange(3, 10, symbol1, "3-10% (мало)"))
    
    # 10-25%: зелёный
    symbol2 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol2.setColor(QColor(100, 200, 100, 130))
    ranges.append(QgsRendererRange(10, 25, symbol2, "10-25% (средне)"))
    
    # 25%+: тёмно-зелёный
    symbol3 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol3.setColor(QColor(34, 139, 34, 160))
    ranges.append(QgsRendererRange(25, 100, symbol3, "25%+ (много)"))
    
    renderer = QgsGraduatedSymbolRenderer('green_pct', ranges)
    layer.setRenderer(renderer)
    
    # Статистика
    green_tiles = sum(1 for t in tile_data if t['green_pct'] >= 3)
    avg_green = sum(t['green_pct'] for t in tile_data) / len(tile_data) if tile_data else 0
    print(f"   📊 Тайлов с зеленью: {green_tiles}/{len(tile_data)}, средний %: {avg_green:.1f}%")
    
    return layer


def create_green_edges_layer(edges_gdf, layer_name="🌿 Озеленение дорог"):
    """Создание QGIS-слоя с процентом зелени на рёбрах (для космоснимков)"""
    from qgis.core import QgsSymbol, QgsRendererRange, QgsGraduatedSymbolRenderer
    from PyQt5.QtGui import QColor
    
    layer = QgsVectorLayer("LineString?crs=EPSG:4326", layer_name, "memory")
    provider = layer.dataProvider()
    
    provider.addAttributes([
        QgsField("green_pct", QVariant.Double),
        QgsField("green_type", QVariant.String),
        QgsField("length", QVariant.Double)
    ])
    layer.updateFields()
    
    features = []
    for idx, row in edges_gdf.iterrows():
        try:
            feature = QgsFeature()
            feature.setGeometry(QgsGeometry.fromWkt(row.geometry.wkt))
            feature.setAttributes([
                float(row.get('green_percent', 0)),
                str(row.get('green_type', 'none')),
                float(row.get('length', 0))
            ])
            features.append(feature)
        except:
            pass
    
    provider.addFeatures(features)
    layer.updateExtents()
    
    # Градиентная стилизация по проценту зелени
    ranges = []
    
    # 0-3%: серый (нет зелени)
    symbol0 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol0.setColor(QColor(150, 150, 150))
    symbol0.setWidth(0.3)
    ranges.append(QgsRendererRange(0, 3, symbol0, "0-3% (нет)"))
    
    # 3-10%: светло-зелёный
    symbol1 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol1.setColor(QColor(180, 230, 180))
    symbol1.setWidth(0.5)
    ranges.append(QgsRendererRange(3, 10, symbol1, "3-10% (мало)"))
    
    # 10-25%: зелёный
    symbol2 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol2.setColor(QColor(100, 200, 100))
    symbol2.setWidth(0.7)
    ranges.append(QgsRendererRange(10, 25, symbol2, "10-25% (деревья)"))
    
    # 25%+: тёмно-зелёный
    symbol3 = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol3.setColor(QColor(34, 139, 34))
    symbol3.setWidth(1.0)
    ranges.append(QgsRendererRange(25, 100, symbol3, "25%+ (парк)"))
    
    renderer = QgsGraduatedSymbolRenderer('green_pct', ranges)
    layer.setRenderer(renderer)
    
    return layer


def print_route_comparison(name, G, route, cost_full, green_percent, trees_pct=0, grass_pct=0):
    """Вывод информации о маршруте"""
    if route is None:
        print(f"\n❌ {name}: маршрут не найден")
        return
        
    length = calculate_route_length(G, route)
    surface_counter, highway_counter = count_attributes_in_route(G, route)
    green_stats, _, _, _ = calculate_route_green_stats(G, route)
    climb, descent, max_grad, avg_grad = calculate_route_elevation_stats(G, route)
    
    print(f"\n📍 {name}")
    print(f"   Длина: {length:.0f} м | Стоимость: {cost_full:.1f} | Рёбер: {len(route)-1}")
    print(f"   📈 Набор: {climb:.0f}м | Спуск: {descent:.0f}м | Макс уклон: {max_grad:.1f}%")
    print(f"   🌳 Озеленение: {green_percent:.1f}% (🌲 деревья: {trees_pct:.1f}%, 🌿 трава: {grass_pct:.1f}%)")
    print(f"   📋 Категории: {green_stats}")
    print(f"   🛤️ Покрытия: {dict(surface_counter.most_common(3))}")


# ==================== MAIN ====================
if __name__ == "__main__" or True:  # True для запуска в QGIS
    
    # Инициализация
    script_dir = init_environment()
    elevation_data = init_srtm()
    
    # Загрузка данных
    bbox = create_bbox(START_COORDS, END_COORDS, BUFFER)
    G = load_graph(bbox)
    
    # Загрузка зелёных зон
    if USE_SATELLITE_GREEN and PIL_AVAILABLE:
        print("\n🛰️ Используется анализ космоснимков для оценки зелени")
        green_geometries = {'parks': [], 'forests': [], 'trees': [], 'grass': []}
    else:
        green_geometries = load_green_areas(bbox)
    
    # Преобразуем граф в GeoDataFrame и рассчитываем веса
    edges = ox.graph_to_gdfs(G, nodes=False, edges=True)
    edges = edges.explode(index_parts=False)
    edges = calculate_weights_vectorized(edges, elevation_data, green_geometries)
    
    # Применяем веса к графу
    G = apply_weights_to_graph(G, edges)
    
    print(edges[['length', 'elevation_diff', 'green_type', 'green_coeff']].head(5))
    
    # Поиск маршрутов (только нужные)
    print("\n🔍 Поиск маршрутов...")
    route_full, start_node, end_node = find_route(G, START_COORDS, END_COORDS, 'weight_full')
    route_green, _, _ = find_route(G, START_COORDS, END_COORDS, 'weight_green')
    
    print(f"   Старт: узел {start_node} | Финиш: узел {end_node}")
    
    # Расчёт стоимостей
    cost_full = calculate_route_cost(G, route_full, 'weight_full')
    cost_green = calculate_route_cost(G, route_green, 'weight_full')
    
    # Расчёт озеленения для каждого маршрута (теперь с деревьями и травой!)
    _, green_pct_full, trees_full, grass_full = calculate_route_green_stats(G, route_full)
    _, green_pct_green, trees_green, grass_green = calculate_route_green_stats(G, route_green)
    
    # Сравнение маршрутов
    print("\n" + "="*60)
    print("📊 СРАВНЕНИЕ МАРШРУТОВ")
    print("="*60)
    
    print_route_comparison("🟢 Полный вес (рельеф + покрытие)", G, route_full, cost_full, green_pct_full, trees_full, grass_full)
    print_route_comparison("🌳 Полный вес + озеленение (для жары)", G, route_green, cost_green, green_pct_green, trees_green, grass_green)
    
    # Анализ выгоды
    print("\n" + "-"*60)
    print("💡 АНАЛИЗ ВЫГОДЫ")
    print("-"*60)
    
    if cost_full > 0:
        print(f"   vs 'с озеленением': {((cost_green - cost_full) / cost_full) * 100:+.1f}% энергии")
    
    if green_pct_full > 0:
        print(f"\n   🌳 Озеленение 'полный вес': {green_pct_full:.1f}%")
        print(f"   🌳 Озеленение 'с озеленением': {green_pct_green:.1f}% ({green_pct_green - green_pct_full:+.1f}%)")
    
    # Создание слоёв QGIS
    print("\n🗂️ Создание слоёв QGIS...")
    
    # Спутниковый слой НЕ создаётся автоматически (добавьте вручную в QGIS если нужно)
    # Чтобы включить: раскомментируйте строки ниже
    # if USE_SATELLITE_GREEN:
    #     sat_layer = add_satellite_layer()
    #     if sat_layer:
    #         print("   ✅ Добавлен слой спутниковых снимков")
    
    # Выбираем слой зелени в зависимости от метода
    if USE_SATELLITE_GREEN and PIL_AVAILABLE:
        green_layer = create_green_edges_layer(edges, "🌿 Озеленение дорог (спутник)")
    else:
        green_layer = create_green_layer(green_geometries, "🌿 Зелёные зоны (OSM)")
    
    # Создаём слой растительности из СПУТНИКА (опционально, медленно при zoom=20)
    vegetation_layer = None
    if CREATE_VEGETATION_LAYER:
        vegetation_layer = create_vegetation_layer_satellite(bbox, SATELLITE_ZOOM, "🌲 Растительность (спутник)")
    
    layers = [
        create_route_layer(G, route_full, "🟢 Маршрут (полный вес)", 
                          cost_full, calculate_route_length(G, route_full), green_pct_full),
        create_route_layer(G, route_green, "🌳 Маршрут (с озеленением)", 
                          cost_green, calculate_route_length(G, route_green), green_pct_green),
        green_layer,
    ]
    
    # Добавляем слой растительности только если создан
    if vegetation_layer:
        layers.append(vegetation_layer)
    
    for layer in layers:
        if layer:
            QgsProject.instance().addMapLayer(layer)
    
    print("✅ Готово!")
