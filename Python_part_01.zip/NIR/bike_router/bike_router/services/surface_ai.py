"""Final experimental AI module for concrete OSM ``surface`` recovery.

The module predicts concrete OSM surface values such as ``asphalt`` or
``paving_stones`` and derives routing-oriented groups afterwards. It is kept
outside the routing path: generated predictions are exported for analysis and
future integration, but the live graph is not mutated.
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import re
import subprocess
from collections.abc import Callable, Iterable, Sequence
from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import geopandas as gpd
import joblib
import networkx as nx
import numpy as np
import osmnx as ox
import pandas as pd
from shapely.geometry import box
from shapely.ops import unary_union

_log_surface_ai = logging.getLogger(__name__)
from sklearn.base import BaseEstimator, ClassifierMixin, TransformerMixin
from sklearn.calibration import CalibratedClassifierCV
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from ..config import Settings
from .area_graph_cache import (
    area_precache_content_fingerprint,
    area_precache_directory_id,
    graph_base_path,
    graph_green_path,
    load_graphml_path,
    parse_precache_polygon,
    precache_area_dir,
)
from .graph import GraphBuilder
from .surface_ml import (
    OSM_TAG_COLUMNS,
    SATELLITE_FEATURES,
    SURFACE_GROUP_MAP,
    SURFACE_GROUPS,
    _first_osm_value,
    _geometry_feature_row,
    _import_pyplot,
    _json_safe,
    _utm_crs_for,
    dedupe_dataframe_by_edge_id,
    filter_edges_to_polygon,
    limit_edges_for_experiment,
    no_progress,
    progress_iter,
)

ProgressFactory = Callable[[Iterable[Any], str, int | None], Iterable[Any]]


CONCRETE_SURFACE_VALUES: tuple[str, ...] = (
    "asphalt",
    "concrete",
    "paved",
    "concrete:plates",
    "paving_stones",
    "sett",
    "cobblestone",
    "bricks",
    "compacted",
    "fine_gravel",
    "gravel",
    "pebblestone",
    "unpaved",
    "ground",
    "dirt",
    "earth",
    "sand",
    "grass",
    "mud",
)

SUPPORTED_SURFACE_VALUES: tuple[str, ...] = CONCRETE_SURFACE_VALUES + (
    "unknown",
    "rare_other",
)

AI_OSM_FEATURES: tuple[str, ...] = (
    "highway",
    "service",
    "tracktype",
    "smoothness",
    "bicycle",
    "foot",
    "access",
    "lit",
    "oneway",
    "maxspeed",
    "lanes",
    "bridge",
    "tunnel",
    "junction",
    "area",
)

AI_GEOMETRY_FEATURES: tuple[str, ...] = (
    "edge_length_m",
    "edge_bearing_deg",
    "edge_sinuosity",
    "edge_num_points",
    "edge_bbox_width_m",
    "edge_bbox_height_m",
    "distance_to_polygon_center_m",
)

AI_SATELLITE_FEATURES: tuple[str, ...] = SATELLITE_FEATURES

SPATIAL_PRIOR_FEATURES: tuple[str, ...] = (
    "distance_to_polygon_center_m",
    "distance_to_polygon_centroid_x",
    "distance_to_polygon_centroid_y",
    "edge_centroid_lat",
    "edge_centroid_lon",
    "tile_x",
    "tile_y",
)

NEIGHBOR_FEATURES: tuple[str, ...] = (
    "neighbor_1hop_count",
    "neighbor_2hop_count",
    "neighbor_1hop_known_surface_share",
    "neighbor_2hop_known_surface_share",
    "neighbor_1hop_paved_good_share",
    "neighbor_1hop_paved_rough_share",
    "neighbor_1hop_unpaved_soft_share",
    "neighbor_2hop_paved_good_share",
    "neighbor_2hop_paved_rough_share",
    "neighbor_2hop_unpaved_soft_share",
    "neighbor_1hop_same_highway_share",
    "neighbor_2hop_same_highway_share",
    "neighbor_1hop_mean_length_m",
    "neighbor_2hop_mean_length_m",
    "neighbor_1hop_highway_residential_share",
    "neighbor_1hop_highway_footway_share",
    "neighbor_1hop_highway_service_share",
    "neighbor_1hop_highway_path_or_track_share",
)

CONCRETE_AI_LABEL_MAP: dict[str, str] = {
    "asphalt": "asphalt",
    "paving_stones": "paving_stones",
    "concrete": "concrete",
    "unpaved": "unpaved",
    "ground": "ground",
    "paved": "other_paved",
    "concrete:plates": "other_paved",
    "sett": "other_paved",
    "cobblestone": "other_paved",
    "bricks": "other_paved",
    "compacted": "other_unpaved",
    "fine_gravel": "other_unpaved",
    "gravel": "other_unpaved",
    "pebblestone": "other_unpaved",
    "dirt": "other_unpaved",
    "earth": "other_unpaved",
    "sand": "other_unpaved",
    "grass": "other_unpaved",
    "mud": "other_unpaved",
}

CONCRETE_COMPACT_LABELS: tuple[str, ...] = (
    "asphalt",
    "paving_stones",
    "unpaved",
    "ground",
    "concrete",
    "other_paved",
    "other_unpaved",
)

DANGEROUS_UPGRADE_SEVERITY: dict[str, float] = {
    "paved_rough": 1.0,
    "unpaved_hard": 2.0,
    "unpaved_soft": 3.0,
    "rough_or_unpaved": 2.5,
}

REQUIRED_PROBA_SURFACES: tuple[str, ...] = (
    "asphalt",
    "concrete",
    "paved",
    "paving_stones",
    "sett",
    "compacted",
    "fine_gravel",
    "gravel",
    "ground",
    "dirt",
    "sand",
    "grass",
    "unknown",
)

BAD_SURFACES: tuple[str, ...] = (
    "unpaved",
    "ground",
    "dirt",
    "earth",
    "sand",
    "grass",
    "mud",
)

SURFACE_COLORS: dict[str, str] = {
    "asphalt": "#1f78b4",
    "concrete": "#6baed6",
    "paved": "#756bb1",
    "concrete:plates": "#9e9ac8",
    "paving_stones": "#7b3294",
    "sett": "#c2a5cf",
    "cobblestone": "#9970ab",
    "bricks": "#b35806",
    "compacted": "#fdb863",
    "fine_gravel": "#e08214",
    "gravel": "#d95f0e",
    "pebblestone": "#fe9929",
    "unpaved": "#a63603",
    "ground": "#8c510a",
    "dirt": "#6b3d1f",
    "earth": "#5d4037",
    "sand": "#dfc27d",
    "grass": "#1b9e77",
    "mud": "#4d2c19",
    "rare_other": "#525252",
    "unknown": "#969696",
}

GROUP_COLORS: dict[str, str] = {
    "paved_good": "#0B4F9C",
    "paved_rough": "#7B3294",
    "unpaved_hard": "#E08214",
    "unpaved_soft": "#8C2D04",
    "unknown": "#8A8A8A",
}

# Backward-compatible hook for old candidate aliases.
_GROUP_MODEL_CANDIDATE_ALIASES: dict[str, str] = {}


def _normalize_group_model_candidates(names: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(_GROUP_MODEL_CANDIDATE_ALIASES.get(n, n) for n in names)


def _env_str(name: str, default: str) -> str:
    return os.getenv(name, default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return int(default)


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return float(default)


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return bool(default)
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _split_csv(raw: str) -> tuple[str, ...]:
    return tuple(x.strip() for x in raw.split(",") if x.strip())


@dataclass(frozen=True)
class SurfaceAIConfig:
    enabled: bool = False
    mode: str = "experiment"
    target: str = "concrete"
    min_class_count: int = 50
    model_candidates: tuple[str, ...] = (
        "always_majority",
        "highway_heuristic",
        "osm_only_rf",
        "satellite_only_rf",
        "combined_rf",
        "combined_rf_balanced",
        "combined_rf_without_spatial_prior",
        "combined_rf_balanced_without_spatial_prior",
        "combined_rf_with_neighbors",
    )
    group_model_candidates: tuple[str, ...] = (
        "group_direct_always_majority",
        "group_direct_highway_heuristic",
        "group_direct_osm_only_rf",
        "group_direct_satellite_only_rf",
        "group_direct_combined_rf",
        "group_direct_combined_rf_balanced",
        "group_direct_combined_rf_calibrated",
        "group_direct_combined_rf_without_spatial_prior",
        "group_direct_combined_rf_balanced_without_spatial_prior",
        "group_direct_combined_rf_neighbor_features",
        "group_direct_combined_rf_class_weight_manual",
        "group_direct_combined_rf_paved_rough_oversampled",
        "group_direct_combined_rf_threshold_tuned",
    )
    concrete_target_mode: str = "compact"
    group_target_mode: str = "3class_unpaved_hard_to_soft"
    train_direct_group_model: bool = True
    selection_metric: str = "macro_f1_safe"
    group_selection_metric: str = "macro_f1_safe_rough_aware"
    dangerous_error_penalty: float = 0.50
    min_bad_surface_recall: float = 0.50
    min_paved_rough_recall: float = 0.25
    paved_rough_recall_weight: float = 0.25
    unpaved_soft_recall_weight: float = 0.25
    group_class_weight_mode: str = "balanced_manual"
    group_class_weight_paved_good: float = 1.0
    group_class_weight_paved_rough: float = 4.0
    group_class_weight_unpaved_soft: float = 3.0
    # Включает post-hoc правило топ-1 только у кандидата ``*threshold_tuned*`` (см. ``_tuned_group_top_fields``).
    group_threshold_tuning: bool = True
    paved_rough_min_proba: float = 0.30
    unpaved_soft_min_proba: float = 0.35
    calibration_enabled: bool = True
    calibration_method: str = "sigmoid"
    calibration_share: float = 0.10
    calibration_min_class_count: int = 20
    enable_spatial_prior: bool = True
    run_spatial_prior_ablation: bool = True
    use_neighbor_features: bool = True
    neighbor_hops: int = 2
    neighbor_use_prediction_pass2: bool = True
    graph_source_priority: tuple[str, ...] = (
        "area_precache",
        "tiles_coverage_graph",
        "osmnx_fallback",
    )
    strict_area_precache: bool = False
    use_tile_coverage_polygon: bool = True
    tile_usage_report: bool = True
    use_green_cache_features: bool = True
    use_tile_green_mask_features: bool = True
    max_dangerous_upgrade_rate_effective: float = 0.10
    max_calibration_ece: float = 0.08
    train_area_mode: str = "tile_coverage"
    predict_area_mode: str = "precache_polygon"
    train_on_all_tile_edges: bool = True
    predict_only_inside_polygon: bool = True
    train_graph_source_priority: tuple[str, ...] = (
        "tile_coverage_graph",
        "area_precache",
        "osmnx_fallback",
    )
    predict_graph_source_priority: tuple[str, ...] = (
        "area_precache",
        "tile_coverage_graph",
        "osmnx_fallback",
    )
    osmnx_retain_all: bool = True
    osmnx_truncate_by_edge: bool = True
    osmnx_simplify: bool = True
    osmnx_network_type: str = "all"
    osmnx_custom_filter: str = ""
    holdout_predict_polygon_known_share: float = 0.20
    tile_edge_match_mode: str = "samples_and_buffer"
    edge_tile_buffer_m: float = 10.0
    compact_output: bool = True
    output_mode: str = "compact"
    max_output_files: int = 20
    compact_cleanup: bool = True
    save_heavy_artifacts: bool = False
    compact_allowed_extensions: tuple[str, ...] = (".csv", ".xlsx", ".png")
    save_full_predictions_geojson: bool = False
    run_holdout_leakage_checks: bool = True
    holdout_split_mode: str = "grouped_geometry_or_way"
    holdout_large_grid_m: float = 1000.0
    mask_holdout_labels_for_neighbors: bool = True
    prevent_directed_edge_leakage: bool = True
    use_satellite_features: bool = False
    sample_step_m: float = 7.0
    pixel_window: int = 5
    tms_server: str = ""
    tile_zoom: int = 20
    tiles_dir: str = ""
    spatial_grid_m: float = 300.0
    test_share: float = 0.20
    random_state: int = 42
    rf_n_estimators: int = 300
    rf_class_weight: str = "balanced_subsample"
    min_confidence: float = 0.65
    conf_high: float = 0.85
    conf_medium: float = 0.65
    enable_safety_policy: bool = True
    paved_good_min_confidence: float = 0.90
    bad_surface_min_confidence: float = 0.60
    min_margin: float = 0.15
    out_dir: str = "./data/experiments/surface_ai"
    min_known_edges: int = 100
    max_tile_cache_items: int = 512
    # Повторный пропуск шагов [2–5] при совпадении отпечатка (см. ``surface_ai_edges_cache_*``).
    reuse_edges_cache: bool = False
    # Явная запись parquet-кэша рёбер (по умолчанию выкл.: не трогаем ``data/cache/*``).
    edges_cache_write: bool = False
    # Доп. корень **только для чтения** (первым в списке). Пусто → см. ``surface_ai_edges_cache_read_roots``.
    edges_cache_dir: str = ""
    # Авто-параллелизм без CLI: тайлы по процессам; кандидаты моделей при |candidates| >= порога.
    auto_parallel: bool = True
    model_outer_parallel_min_candidates: int = 3

    @classmethod
    def from_env(cls) -> SurfaceAIConfig:
        """Load Surface AI settings from ``SURFACE_AI_*`` environment variables."""
        base = cls()
        updates: dict[str, Any] = {
            "enabled": _env_bool("SURFACE_AI_ENABLED", base.enabled),
            "mode": _env_str("SURFACE_AI_MODE", base.mode),
            "target": _env_str("SURFACE_AI_TARGET", base.target),
            "min_class_count": _env_int("SURFACE_AI_MIN_CLASS_COUNT", base.min_class_count),
            "selection_metric": _env_str("SURFACE_AI_SELECTION_METRIC", base.selection_metric),
            "group_selection_metric": _env_str(
                "SURFACE_AI_GROUP_SELECTION_METRIC", base.group_selection_metric
            ),
            "dangerous_error_penalty": _env_float(
                "SURFACE_AI_DANGEROUS_ERROR_PENALTY", base.dangerous_error_penalty
            ),
            "min_bad_surface_recall": _env_float(
                "SURFACE_AI_MIN_BAD_SURFACE_RECALL", base.min_bad_surface_recall
            ),
            "min_paved_rough_recall": _env_float(
                "SURFACE_AI_MIN_PAVED_ROUGH_RECALL", base.min_paved_rough_recall
            ),
            "paved_rough_recall_weight": _env_float(
                "SURFACE_AI_PAVED_ROUGH_RECALL_WEIGHT", base.paved_rough_recall_weight
            ),
            "unpaved_soft_recall_weight": _env_float(
                "SURFACE_AI_UNPAVED_SOFT_RECALL_WEIGHT", base.unpaved_soft_recall_weight
            ),
            "group_class_weight_mode": _env_str(
                "SURFACE_AI_GROUP_CLASS_WEIGHT_MODE", base.group_class_weight_mode
            ),
            "group_class_weight_paved_good": _env_float(
                "SURFACE_AI_GROUP_CLASS_WEIGHT_PAVED_GOOD", base.group_class_weight_paved_good
            ),
            "group_class_weight_paved_rough": _env_float(
                "SURFACE_AI_GROUP_CLASS_WEIGHT_PAVED_ROUGH", base.group_class_weight_paved_rough
            ),
            "group_class_weight_unpaved_soft": _env_float(
                "SURFACE_AI_GROUP_CLASS_WEIGHT_UNPAVED_SOFT", base.group_class_weight_unpaved_soft
            ),
            "group_threshold_tuning": _env_bool(
                "SURFACE_AI_GROUP_THRESHOLD_TUNING", base.group_threshold_tuning
            ),
            "paved_rough_min_proba": _env_float(
                "SURFACE_AI_PAVED_ROUGH_MIN_PROBA", base.paved_rough_min_proba
            ),
            "unpaved_soft_min_proba": _env_float(
                "SURFACE_AI_UNPAVED_SOFT_MIN_PROBA", base.unpaved_soft_min_proba
            ),
            "concrete_target_mode": _env_str(
                "SURFACE_AI_CONCRETE_TARGET_MODE", base.concrete_target_mode
            ),
            "group_target_mode": _env_str("SURFACE_AI_GROUP_TARGET_MODE", base.group_target_mode),
            "train_direct_group_model": _env_bool(
                "SURFACE_AI_TRAIN_DIRECT_GROUP_MODEL", base.train_direct_group_model
            ),
            "calibration_enabled": _env_bool(
                "SURFACE_AI_CALIBRATION_ENABLED", base.calibration_enabled
            ),
            "calibration_method": _env_str(
                "SURFACE_AI_CALIBRATION_METHOD", base.calibration_method
            ),
            "calibration_share": _env_float("SURFACE_AI_CALIBRATION_SHARE", base.calibration_share),
            "calibration_min_class_count": _env_int(
                "SURFACE_AI_CALIBRATION_MIN_CLASS_COUNT", base.calibration_min_class_count
            ),
            "enable_spatial_prior": _env_bool(
                "SURFACE_AI_ENABLE_SPATIAL_PRIOR", base.enable_spatial_prior
            ),
            "run_spatial_prior_ablation": _env_bool(
                "SURFACE_AI_RUN_SPATIAL_PRIOR_ABLATION", base.run_spatial_prior_ablation
            ),
            "use_neighbor_features": _env_bool(
                "SURFACE_AI_USE_NEIGHBOR_FEATURES", base.use_neighbor_features
            ),
            "neighbor_hops": _env_int("SURFACE_AI_NEIGHBOR_HOPS", base.neighbor_hops),
            "neighbor_use_prediction_pass2": _env_bool(
                "SURFACE_AI_NEIGHBOR_USE_PREDICTION_PASS2", base.neighbor_use_prediction_pass2
            ),
            "strict_area_precache": _env_bool(
                "SURFACE_AI_STRICT_AREA_PRECACHE", base.strict_area_precache
            ),
            "use_tile_coverage_polygon": _env_bool(
                "SURFACE_AI_USE_TILE_COVERAGE_POLYGON", base.use_tile_coverage_polygon
            ),
            "tile_usage_report": _env_bool("SURFACE_AI_TILE_USAGE_REPORT", base.tile_usage_report),
            "use_green_cache_features": _env_bool(
                "SURFACE_AI_USE_GREEN_CACHE_FEATURES", base.use_green_cache_features
            ),
            "use_tile_green_mask_features": _env_bool(
                "SURFACE_AI_USE_TILE_GREEN_MASK_FEATURES", base.use_tile_green_mask_features
            ),
            "max_dangerous_upgrade_rate_effective": _env_float(
                "SURFACE_AI_MAX_DANGEROUS_UPGRADE_RATE_EFFECTIVE",
                base.max_dangerous_upgrade_rate_effective,
            ),
            "max_calibration_ece": _env_float(
                "SURFACE_AI_MAX_CALIBRATION_ECE", base.max_calibration_ece
            ),
            "train_area_mode": _env_str("SURFACE_AI_TRAIN_AREA_MODE", base.train_area_mode),
            "predict_area_mode": _env_str("SURFACE_AI_PREDICT_AREA_MODE", base.predict_area_mode),
            "train_on_all_tile_edges": _env_bool(
                "SURFACE_AI_TRAIN_ON_ALL_TILE_EDGES", base.train_on_all_tile_edges
            ),
            "predict_only_inside_polygon": _env_bool(
                "SURFACE_AI_PREDICT_ONLY_INSIDE_POLYGON", base.predict_only_inside_polygon
            ),
            "osmnx_retain_all": _env_bool("SURFACE_AI_OSMNX_RETAIN_ALL", base.osmnx_retain_all),
            "osmnx_truncate_by_edge": _env_bool(
                "SURFACE_AI_OSMNX_TRUNCATE_BY_EDGE", base.osmnx_truncate_by_edge
            ),
            "osmnx_simplify": _env_bool("SURFACE_AI_OSMNX_SIMPLIFY", base.osmnx_simplify),
            "osmnx_network_type": _env_str(
                "SURFACE_AI_OSMNX_NETWORK_TYPE", base.osmnx_network_type
            ),
            "osmnx_custom_filter": _env_str(
                "SURFACE_AI_OSMNX_CUSTOM_FILTER", base.osmnx_custom_filter
            ),
            "holdout_predict_polygon_known_share": _env_float(
                "SURFACE_AI_HOLDOUT_PREDICT_POLYGON_KNOWN_SHARE",
                base.holdout_predict_polygon_known_share,
            ),
            "tile_edge_match_mode": _env_str(
                "SURFACE_AI_TILE_EDGE_MATCH_MODE", base.tile_edge_match_mode
            ),
            "edge_tile_buffer_m": _env_float(
                "SURFACE_AI_EDGE_TILE_BUFFER_M", base.edge_tile_buffer_m
            ),
            "compact_output": _env_bool("SURFACE_AI_COMPACT_OUTPUT", base.compact_output),
            "output_mode": _env_str("SURFACE_AI_OUTPUT_MODE", base.output_mode),
            "max_output_files": _env_int("SURFACE_AI_MAX_OUTPUT_FILES", base.max_output_files),
            "compact_cleanup": _env_bool("SURFACE_AI_COMPACT_CLEANUP", base.compact_cleanup),
            "save_heavy_artifacts": _env_bool(
                "SURFACE_AI_SAVE_HEAVY_ARTIFACTS", base.save_heavy_artifacts
            ),
            "save_full_predictions_geojson": _env_bool(
                "SURFACE_AI_SAVE_FULL_PREDICTIONS_GEOJSON", base.save_full_predictions_geojson
            ),
            "run_holdout_leakage_checks": _env_bool(
                "SURFACE_AI_RUN_HOLDOUT_LEAKAGE_CHECKS", base.run_holdout_leakage_checks
            ),
            "holdout_split_mode": _env_str(
                "SURFACE_AI_HOLDOUT_SPLIT_MODE", base.holdout_split_mode
            ),
            "holdout_large_grid_m": _env_float(
                "SURFACE_AI_HOLDOUT_LARGE_GRID_M", base.holdout_large_grid_m
            ),
            "mask_holdout_labels_for_neighbors": _env_bool(
                "SURFACE_AI_MASK_HOLDOUT_LABELS_FOR_NEIGHBORS",
                base.mask_holdout_labels_for_neighbors,
            ),
            "prevent_directed_edge_leakage": _env_bool(
                "SURFACE_AI_PREVENT_DIRECTED_EDGE_LEAKAGE", base.prevent_directed_edge_leakage
            ),
            "use_satellite_features": _env_bool(
                "SURFACE_AI_USE_SATELLITE_FEATURES", base.use_satellite_features
            ),
            "sample_step_m": _env_float("SURFACE_AI_SAMPLE_STEP_M", base.sample_step_m),
            "pixel_window": _env_int("SURFACE_AI_PIXEL_WINDOW", base.pixel_window),
            "tms_server": _env_str("SURFACE_AI_TMS_SERVER", base.tms_server),
            "tile_zoom": _env_int("SURFACE_AI_TILE_ZOOM", base.tile_zoom),
            "tiles_dir": _env_str("SURFACE_AI_TILES_DIR", base.tiles_dir),
            "spatial_grid_m": _env_float("SURFACE_AI_SPATIAL_GRID_M", base.spatial_grid_m),
            "test_share": _env_float("SURFACE_AI_TEST_SHARE", base.test_share),
            "random_state": _env_int("SURFACE_AI_RANDOM_STATE", base.random_state),
            "rf_n_estimators": _env_int("SURFACE_AI_RF_N_ESTIMATORS", base.rf_n_estimators),
            "rf_class_weight": _env_str("SURFACE_AI_RF_CLASS_WEIGHT", base.rf_class_weight),
            "min_confidence": _env_float("SURFACE_AI_MIN_CONFIDENCE", base.min_confidence),
            "conf_high": _env_float("SURFACE_AI_CONF_HIGH", base.conf_high),
            "conf_medium": _env_float("SURFACE_AI_CONF_MEDIUM", base.conf_medium),
            "enable_safety_policy": _env_bool(
                "SURFACE_AI_ENABLE_SAFETY_POLICY", base.enable_safety_policy
            ),
            "paved_good_min_confidence": _env_float(
                "SURFACE_AI_PAVED_GOOD_MIN_CONFIDENCE", base.paved_good_min_confidence
            ),
            "bad_surface_min_confidence": _env_float(
                "SURFACE_AI_BAD_SURFACE_MIN_CONFIDENCE", base.bad_surface_min_confidence
            ),
            "min_margin": _env_float("SURFACE_AI_MIN_MARGIN", base.min_margin),
            "out_dir": _env_str("SURFACE_AI_OUT_DIR", base.out_dir),
            "min_known_edges": _env_int("SURFACE_AI_MIN_KNOWN_EDGES", base.min_known_edges),
            "max_tile_cache_items": _env_int(
                "SURFACE_AI_MAX_TILE_CACHE_ITEMS", base.max_tile_cache_items
            ),
            "reuse_edges_cache": _env_bool("SURFACE_AI_REUSE_EDGES_CACHE", base.reuse_edges_cache),
            "edges_cache_write": _env_bool("SURFACE_AI_EDGES_CACHE_WRITE", base.edges_cache_write),
            "edges_cache_dir": os.getenv(
                "SURFACE_AI_EDGES_CACHE_DIR", base.edges_cache_dir
            ).strip(),
            "auto_parallel": _env_bool("SURFACE_AI_AUTO_PARALLEL", base.auto_parallel),
            "model_outer_parallel_min_candidates": _env_int(
                "SURFACE_AI_MODEL_OUTER_PARALLEL_MIN_CANDIDATES",
                base.model_outer_parallel_min_candidates,
            ),
        }
        if os.getenv("SURFACE_AI_MODEL_CANDIDATES"):
            updates["model_candidates"] = _split_csv(os.getenv("SURFACE_AI_MODEL_CANDIDATES", ""))
        if os.getenv("SURFACE_AI_GROUP_MODEL_CANDIDATES"):
            updates["group_model_candidates"] = _normalize_group_model_candidates(
                _split_csv(os.getenv("SURFACE_AI_GROUP_MODEL_CANDIDATES", ""))
            )
        if os.getenv("SURFACE_AI_GRAPH_SOURCE_PRIORITY"):
            updates["graph_source_priority"] = _split_csv(
                os.getenv("SURFACE_AI_GRAPH_SOURCE_PRIORITY", "")
            )
        if os.getenv("SURFACE_AI_TRAIN_GRAPH_SOURCE_PRIORITY"):
            updates["train_graph_source_priority"] = _split_csv(
                os.getenv("SURFACE_AI_TRAIN_GRAPH_SOURCE_PRIORITY", "")
            )
        if os.getenv("SURFACE_AI_PREDICT_GRAPH_SOURCE_PRIORITY"):
            updates["predict_graph_source_priority"] = _split_csv(
                os.getenv("SURFACE_AI_PREDICT_GRAPH_SOURCE_PRIORITY", "")
            )
        if os.getenv("SURFACE_AI_COMPACT_ALLOWED_EXTENSIONS"):
            updates["compact_allowed_extensions"] = _split_csv(
                os.getenv("SURFACE_AI_COMPACT_ALLOWED_EXTENSIONS", "")
            )
        return replace(base, **updates)


@dataclass
class SurfaceAIArtifacts:
    output_dir: Path
    dataset_csv: Path
    predictions_csv: Path
    predictions_geojson: Path
    baseline_csv: Path
    baseline_xlsx: Path
    baseline_png: Path
    metrics_json: Path
    model_joblib: Path
    model_card_json: Path
    report_txt: Path
    surface_map_png: Path
    confidence_map_png: Path
    unknown_predictions_map_png: Path
    errors_map_png: Path
    confusion_matrix_concrete_png: Path
    confusion_matrix_group_png: Path
    feature_importance_png: Path
    confusion_matrix_concrete_compact_png: Path
    confusion_matrix_concrete_legacy_png: Path
    confusion_matrix_group_direct_png: Path
    group_direct_model_joblib: Path
    group_direct_model_card_json: Path
    group_direct_metrics_json: Path
    calibration_curve_concrete_png: Path
    calibration_curve_group_direct_png: Path
    reliability_table_concrete_csv: Path
    reliability_table_group_direct_csv: Path
    dangerous_errors_map_raw_png: Path
    dangerous_errors_map_effective_png: Path
    dangerous_errors_csv: Path
    spatial_prior_ablation_txt: Path
    tile_usage_csv: Path
    tile_usage_map_png: Path
    neighbor_feature_importance_png: Path
    train_polygon_geojson: Path
    predict_polygon_geojson: Path
    tile_coverage_polygon_geojson: Path
    train_edges_geojson: Path
    predict_edges_geojson: Path
    dataset_all_tile_edges_csv: Path
    predictions_inside_polygon_csv: Path
    predictions_inside_polygon_geojson: Path
    tile_usage_map_train_png: Path
    tile_usage_map_predict_png: Path
    train_vs_predict_report_txt: Path
    dangerous_errors_global_test_csv: Path
    dangerous_errors_predict_holdout_csv: Path
    dangerous_errors_global_test_raw_png: Path
    dangerous_errors_global_test_effective_png: Path
    dangerous_errors_predict_holdout_raw_png: Path
    dangerous_errors_predict_holdout_effective_png: Path
    unknown_risk_map_png: Path
    run_summary_csv: Path
    runtime_predictions_csv: Path


def normalize_surface_value(raw: Any) -> str | None:
    value = _first_osm_value(raw)
    if value is None:
        return None
    s = str(value).strip().lower()
    if not s or s in {"none", "null", "nan", "unknown", "no"}:
        return None
    if s == "yes":
        return "paved"

    s = s.replace("\\", "/")
    parts = [p.strip() for p in re.split(r"[;|,/]", s) if p.strip()]
    if not parts:
        parts = [s]

    aliases = {
        "cement": "concrete",
        "concrete_slabs": "concrete:plates",
        "concrete:plate": "concrete:plates",
        "cobblestone:flattened": "cobblestone",
        "paving_stones:30": "paving_stones",
        "paving_stones:20": "paving_stones",
        "fine_gravel;gravel": "fine_gravel",
        "grass_paver": "grass",
        "woodchips": "ground",
        "soil": "earth",
    }
    for part in parts:
        part = aliases.get(part, part)
        if part.startswith("paving_stones:"):
            part = "paving_stones"
        elif part.startswith("sett:"):
            part = "sett"
        elif part.startswith("cobblestone:"):
            part = "cobblestone"
        elif part.startswith("concrete:") and part != "concrete:plates":
            part = "concrete"
        if part in CONCRETE_SURFACE_VALUES:
            return part
    first = aliases.get(parts[0], parts[0])
    return first if first in CONCRETE_SURFACE_VALUES else None


def _surface_values_from_edge_row(row: Any) -> tuple[str | None, str | None]:
    """Return ``(raw_surface, normalized_surface)`` from raw or derived graph columns.

    Some cached graph variants keep ``surface_osm_raw``/``surface_osm_norm`` but do
    not expose the original ``surface`` tag after GraphML round-tripping. The ML
    dataset must treat those columns as the same OSM truth, otherwise all known
    surfaces can be silently marked unknown.
    """
    raw_candidates = (
        getattr(row, "surface", None),
        getattr(row, "surface_osm_raw", None),
        getattr(row, "surface_raw", None),
    )
    norm_candidates = (
        getattr(row, "surface_osm_norm", None),
        getattr(row, "surface_norm", None),
        getattr(row, "surface_true_concrete", None),
    )

    raw_surface: str | None = None
    for value in raw_candidates:
        first = _first_osm_value(value)
        if first is not None and str(first).strip().lower() not in {"", "none", "null", "nan"}:
            raw_surface = str(first)
            break

    surface_norm = normalize_surface_value(raw_surface)
    if surface_norm is None:
        for value in norm_candidates:
            surface_norm = normalize_surface_value(value)
            if surface_norm is not None:
                break
    if raw_surface is None and surface_norm is not None:
        raw_surface = surface_norm
    return raw_surface, surface_norm


def surface_to_group(surface: Any) -> str:
    s = normalize_surface_value(surface) if surface not in (None, "rare_other") else surface
    if s == "rare_other":
        return "unknown"
    return SURFACE_GROUP_MAP.get(str(s or ""), "unknown")


def normalize_surface_to_concrete_ai_label(surface_norm: Any) -> str | None:
    surface = normalize_surface_value(surface_norm)
    if surface is None:
        return None
    return CONCRETE_AI_LABEL_MAP.get(surface)


def normalize_group_target(group: Any, mode: str = "3class_unpaved_hard_to_soft") -> str:
    g = str(group or "unknown")
    if mode == "4class_original":
        return g if g in SURFACE_GROUPS else "unknown"
    if mode == "3class_rough_or_unpaved":
        if g in {"unpaved_hard", "unpaved_soft"}:
            return "rough_or_unpaved"
        if g in {"paved_good", "paved_rough"}:
            return g
        return "unknown"
    if g == "unpaved_hard":
        return "unpaved_soft"
    if g in {"paved_good", "paved_rough", "unpaved_soft"}:
        return g
    return "unknown"


def group_target_labels(mode: str) -> tuple[str, ...]:
    if mode == "4class_original":
        return SURFACE_GROUPS
    if mode == "3class_rough_or_unpaved":
        return ("paved_good", "paved_rough", "rough_or_unpaved")
    return ("paved_good", "paved_rough", "unpaved_soft")


def is_dangerous_upgrade(true_group: str, pred_group: str) -> bool:
    return (
        str(true_group) in {"paved_rough", "unpaved_hard", "unpaved_soft", "rough_or_unpaved"}
        and str(pred_group) == "paved_good"
    )


def train_label_to_surface(label: Any) -> str:
    s = str(label or "unknown")
    if s in CONCRETE_SURFACE_VALUES or s in CONCRETE_COMPACT_LABELS:
        return s
    if s.startswith("rare_other_"):
        return "rare_other"
    return "unknown"


def train_label_to_group(label: Any) -> str:
    s = str(label or "unknown")
    if s in {"paved_good", "paved_rough", "unpaved_hard", "unpaved_soft", "rough_or_unpaved"}:
        return s
    if s in {"other_paved"}:
        return "paved_rough"
    if s in {"other_unpaved"}:
        return "unpaved_soft"
    if s.startswith("rare_other_"):
        return s.replace("rare_other_", "", 1) or "unknown"
    return surface_to_group(s)


def label_to_group_or_direct(label: Any) -> str:
    return train_label_to_group(label)


def proba_column_for_surface(surface: str) -> str:
    clean = re.sub(r"[^0-9a-zA-Z_]+", "_", surface).strip("_")
    return f"proba_{clean}"


def predict_surface_by_highway_heuristic(edge_attrs: dict) -> str:
    highway = str(edge_attrs.get("highway") or "").strip().lower()
    tracktype = str(edge_attrs.get("tracktype") or "").strip().lower()

    if highway in {"primary", "secondary", "tertiary", "residential", "living_street"}:
        return "asphalt"
    if highway in {"cycleway"}:
        return "asphalt"
    if highway in {"footway", "pedestrian"}:
        return "paving_stones"
    if highway == "service":
        return "asphalt"
    if highway == "track":
        if tracktype in {"grade1"}:
            return "compacted"
        if tracktype in {"grade2", "grade3"}:
            return "gravel"
        return "ground"
    if highway == "path":
        return "ground"
    if highway == "steps":
        return "concrete"
    return "unknown"


def _norm_feature(value: Any) -> str | None:
    v = _first_osm_value(value)
    if v is None:
        return None
    s = str(v).strip().lower()
    if not s or s in {"nan", "none", "null"}:
        return None
    return s


def _geometry_features_with_center(
    row: Any,
    projected_geom: Any,
    center_projected: Any,
) -> dict[str, Any]:
    item = _geometry_feature_row(row, projected_geom)
    try:
        item["distance_to_polygon_center_m"] = float(
            projected_geom.centroid.distance(center_projected)
        )
    except Exception:
        item["distance_to_polygon_center_m"] = float("nan")
    return item


def _short_hash(value: str) -> str:
    return hashlib.sha1(value.encode("utf-8", errors="ignore")).hexdigest()[:16]


def _rounded_geometry_hash(geometry: Any, precision: int = 6) -> str:
    if geometry is None:
        return "none"
    try:
        coords = []
        for x, y in list(geometry.coords):
            coords.append((round(float(x), precision), round(float(y), precision)))
        forward = "|".join(f"{x:.{precision}f},{y:.{precision}f}" for x, y in coords)
        backward = "|".join(f"{x:.{precision}f},{y:.{precision}f}" for x, y in reversed(coords))
        return _short_hash(min(forward, backward))
    except Exception:
        return _short_hash(getattr(geometry, "wkt", str(geometry)))


def build_osm_geometry_dataset(
    edges_gdf: gpd.GeoDataFrame,
    polygon: Any,
    *,
    progress: ProgressFactory = no_progress,
) -> pd.DataFrame:
    for col in AI_OSM_FEATURES:
        if col not in edges_gdf.columns:
            edges_gdf[col] = None
    projected_crs = _utm_crs_for(edges_gdf)
    projected = edges_gdf.to_crs(projected_crs)
    center = gpd.GeoSeries([polygon.centroid], crs="EPSG:4326").to_crs(projected_crs).iloc[0]

    rows: list[dict[str, Any]] = []
    iterator = zip(edges_gdf.itertuples(index=False), projected.geometry.values)
    for row, projected_geom in progress(
        iterator,
        "[3/8] OSM/geometry features",
        total=len(edges_gdf),
    ):
        surface_raw, surface_norm = _surface_values_from_edge_row(row)
        true_group = surface_to_group(surface_norm)
        item: dict[str, Any] = {
            "edge_id": row.edge_id,
            "u": str(row.u),
            "v": str(row.v),
            "key": str(row.key),
            "length_m": float(getattr(row, "length_m", np.nan)),
            "surface_raw": surface_raw,
            "surface_norm": surface_norm or "unknown",
            "surface_osm_raw": surface_raw,
            "surface_osm_norm": surface_norm or "unknown",
            "surface_true_concrete": surface_norm or "unknown",
            "surface_true_concrete_legacy": surface_norm or "unknown",
            "surface_true_concrete_compact": normalize_surface_to_concrete_ai_label(surface_norm)
            or "unknown",
            "surface_true_group": true_group,
            "surface_group_true": true_group,
            "is_surface_known": bool(surface_norm in CONCRETE_SURFACE_VALUES),
            "geometry_wkt": row.geometry.wkt if row.geometry is not None else None,
            "geometry_hash_rounded": _rounded_geometry_hash(row.geometry),
            "osm_way_id": _first_osm_value(getattr(row, "osmid", None)),
            "inside_train_area": bool(getattr(row, "inside_train_area", False)),
            "inside_predict_area": bool(getattr(row, "inside_predict_area", False)),
            "surface_ai_edge_source": getattr(row, "surface_ai_edge_source", None),
        }
        uv = sorted([str(row.u), str(row.v)])
        item["undirected_edge_key"] = f"{uv[0]}:{uv[1]}:{item['geometry_hash_rounded']}"
        for col in AI_OSM_FEATURES:
            item[col] = _norm_feature(getattr(row, col, None))
        item.update(_geometry_features_with_center(row, projected_geom, center))
        rows.append(item)
    return pd.DataFrame(rows)


def _surface_train_label(
    surface: str, frequent: set[str], *, mode: str = "legacy_full"
) -> tuple[str, bool]:
    if mode == "compact":
        label = normalize_surface_to_concrete_ai_label(surface)
        if label:
            return label, False
        return "unknown", False
    if surface in frequent:
        return surface, False
    group = surface_to_group(surface)
    if group in SURFACE_GROUPS:
        return f"rare_other_{group}", True
    return "rare_other", True


def add_train_labels(
    dataset: pd.DataFrame,
    *,
    min_class_count: int,
    concrete_target_mode: str = "compact",
    group_target_mode: str = "3class_unpaved_hard_to_soft",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    df = dataset.copy()
    known = df[df["is_surface_known"]]
    counts = known["surface_true_concrete"].value_counts().sort_index()
    frequent = {str(k) for k, v in counts.items() if int(v) >= int(min_class_count)}
    train_labels: list[str] = []
    legacy_labels: list[str] = []
    group_direct: list[str] = []
    rare_flags: list[bool] = []
    for _, row in df.iterrows():
        surface = str(row.get("surface_true_concrete") or "unknown")
        group = str(row.get("surface_true_group") or "unknown")
        if not bool(row.get("is_surface_known")) or surface == "unknown":
            train_labels.append("unknown")
            legacy_labels.append("unknown")
            group_direct.append("unknown")
            rare_flags.append(False)
            continue
        label, is_rare = _surface_train_label(surface, frequent, mode=concrete_target_mode)
        legacy_label, legacy_is_rare = _surface_train_label(surface, frequent, mode="legacy_full")
        train_labels.append(label)
        legacy_labels.append(legacy_label)
        group_direct.append(normalize_group_target(group, group_target_mode))
        rare_flags.append(is_rare)
    df["surface_train_label"] = train_labels
    df["surface_train_label_legacy"] = legacy_labels
    df["surface_group_direct_label"] = group_direct
    df["surface_is_rare_class"] = rare_flags
    meta = {
        "surface_counts": {str(k): int(v) for k, v in counts.items()},
        "frequent_surface_classes": sorted(frequent),
        "rare_surface_classes": sorted(set(counts.index.astype(str)) - frequent),
        "min_class_count": int(min_class_count),
        "concrete_target_mode": concrete_target_mode,
        "group_target_mode": group_target_mode,
        "concrete_compact_labels": list(CONCRETE_COMPACT_LABELS),
        "group_direct_labels": list(group_target_labels(group_target_mode)),
    }
    return df, meta


def build_surface_ai_dataset(
    edges_gdf: gpd.GeoDataFrame,
    settings: Settings,
    config: SurfaceAIConfig,
    polygon: Any,
    *,
    progress: ProgressFactory = no_progress,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    osm_df = build_osm_geometry_dataset(edges_gdf, polygon, progress=progress)
    if config.use_satellite_features:
        ml_config = _surface_ml_config_from_ai(config)
        from .surface_ai_mp import parallel_extract_tile_features_for_edges

        tile_df = parallel_extract_tile_features_for_edges(
            edges_gdf,
            settings,
            config,
            ml_config,
            progress=progress,
        )
    else:
        rows = []
        for edge_id in osm_df["edge_id"].astype(str):
            item = {"edge_id": edge_id, "tile_missing": True, "tile_samples_count": 0}
            for col in AI_SATELLITE_FEATURES:
                item[col] = np.nan
            item["tile_missing_share"] = 1.0
            item["sampled_pixel_count"] = 0
            rows.append(item)
        tile_df = pd.DataFrame(rows)
    # GeoJSON/JSON round-trip и read_json могут дать edge_id как float — merge требует один тип.
    osm_df = osm_df.copy()
    tile_df = tile_df.copy()
    osm_df["edge_id"] = osm_df["edge_id"].map(lambda x: "" if pd.isna(x) else str(x).strip())
    tile_df["edge_id"] = tile_df["edge_id"].map(lambda x: "" if pd.isna(x) else str(x).strip())
    osm_df = dedupe_dataframe_by_edge_id(osm_df, keep="first", name="osm_df (surface_ai)")
    tile_df = dedupe_dataframe_by_edge_id(tile_df, keep="last", name="tile_df (surface_ai)")
    dataset = osm_df.merge(tile_df, on="edge_id", how="left", validate="one_to_one")
    for col in AI_SATELLITE_FEATURES:
        if col not in dataset.columns:
            dataset[col] = np.nan
    dataset, label_meta = add_train_labels(
        dataset,
        min_class_count=config.min_class_count,
        concrete_target_mode=config.concrete_target_mode,
        group_target_mode=config.group_target_mode,
    )
    return dataset, label_meta


def add_neighbor_features(dataset: pd.DataFrame) -> pd.DataFrame:
    """Add 1/2-hop graph-neighbor features without using test labels.

    For edges in the test fold, known-surface shares use only non-test OSM labels,
    preventing target leakage from adjacent test edges.
    """
    df = dataset.copy()
    edge_ids = df["edge_id"].astype(str).tolist()
    edge_set = set(edge_ids)
    node_edges: dict[str, set[str]] = {}
    for edge_id, u, v in zip(edge_ids, df["u"].astype(str), df["v"].astype(str)):
        node_edges.setdefault(u, set()).add(edge_id)
        node_edges.setdefault(v, set()).add(edge_id)
    edge_neighbors: dict[str, set[str]] = {}
    for edge_id, u, v in zip(edge_ids, df["u"].astype(str), df["v"].astype(str)):
        n = (node_edges.get(u, set()) | node_edges.get(v, set())) - {edge_id}
        edge_neighbors[edge_id] = n
    lookup = df.set_index("edge_id", drop=False)
    allowed_known = lookup["is_surface_known"].astype(bool) & ~lookup.get(
        "surface_ai_split", pd.Series("", index=lookup.index)
    ).isin({"test", "predict_holdout"})

    def summarize(
        edge_id: str, neigh_ids: set[str], hop: int, base_highway: str
    ) -> dict[str, float]:
        out: dict[str, float] = {}
        ids = [n for n in neigh_ids if n in edge_set]
        sub = lookup.loc[ids] if ids else lookup.iloc[0:0]
        out[f"neighbor_{hop}hop_count"] = float(len(ids))
        if sub.empty:
            for key in (
                "known_surface_share",
                "paved_good_share",
                "paved_rough_share",
                "unpaved_soft_share",
                "same_highway_share",
                "mean_length_m",
            ):
                out[f"neighbor_{hop}hop_{key}"] = 0.0
            if hop == 1:
                for key in ("residential", "footway", "service", "path_or_track"):
                    out[f"neighbor_1hop_highway_{key}_share"] = 0.0
            return out
        known_mask = allowed_known.reindex(sub.index).fillna(False)
        known = sub[known_mask]
        denom = max(1, len(sub))
        out[f"neighbor_{hop}hop_known_surface_share"] = float(len(known) / denom)
        groups = known["surface_true_group"].map(
            lambda g: normalize_group_target(g, "3class_unpaved_hard_to_soft")
        )
        for group in ("paved_good", "paved_rough", "unpaved_soft"):
            out[f"neighbor_{hop}hop_{group}_share"] = float(
                (groups == group).sum() / max(1, len(known))
            )
        hws = sub["highway"].astype(str)
        out[f"neighbor_{hop}hop_same_highway_share"] = (
            float((hws == base_highway).mean()) if len(hws) else 0.0
        )
        out[f"neighbor_{hop}hop_mean_length_m"] = (
            float(pd.to_numeric(sub["length_m"], errors="coerce").mean()) if len(sub) else 0.0
        )
        if hop == 1:
            out["neighbor_1hop_highway_residential_share"] = (
                float((hws == "residential").mean()) if len(hws) else 0.0
            )
            out["neighbor_1hop_highway_footway_share"] = (
                float((hws == "footway").mean()) if len(hws) else 0.0
            )
            out["neighbor_1hop_highway_service_share"] = (
                float((hws == "service").mean()) if len(hws) else 0.0
            )
            out["neighbor_1hop_highway_path_or_track_share"] = (
                float(hws.isin(["path", "track"]).mean()) if len(hws) else 0.0
            )
        return out

    rows: list[dict[str, float]] = []
    for edge_id, base_highway in zip(edge_ids, df["highway"].astype(str)):
        hop1 = edge_neighbors.get(edge_id, set())
        hop2: set[str] = set()
        for n in hop1:
            hop2.update(edge_neighbors.get(n, set()))
        hop2.discard(edge_id)
        hop2 -= hop1
        item = {"edge_id": edge_id}
        item.update(summarize(edge_id, hop1, 1, base_highway))
        item.update(summarize(edge_id, hop2, 2, base_highway))
        rows.append(item)
    neigh = pd.DataFrame(rows)
    out = df.merge(neigh, on="edge_id", how="left", validate="one_to_one")
    for col in NEIGHBOR_FEATURES:
        if col not in out.columns:
            out[col] = 0.0
        out[col] = pd.to_numeric(out[col], errors="coerce").fillna(0.0)
    return out


def _surface_ml_config_from_ai(config: SurfaceAIConfig) -> Any:
    from .surface_ml import SurfaceMLConfig

    return SurfaceMLConfig(
        sample_step_m=config.sample_step_m,
        pixel_window=config.pixel_window,
        min_confidence=config.min_confidence,
        paved_good_min_confidence=config.paved_good_min_confidence,
        spatial_grid_m=config.spatial_grid_m,
        test_share=config.test_share,
        random_state=config.random_state,
        min_known_edges=config.min_known_edges,
        n_estimators=config.rf_n_estimators,
        max_tile_cache_items=config.max_tile_cache_items,
    )


def spatial_train_test_split(
    dataset: pd.DataFrame,
    edges_gdf: gpd.GeoDataFrame,
    config: SurfaceAIConfig,
) -> pd.Series:
    candidate_mask = dataset.get("is_train_candidate", dataset["is_surface_known"]).astype(bool)
    known = dataset[candidate_mask].copy()
    if len(known) < int(config.min_known_edges):
        inside_train = dataset.get(
            "inside_train_area", pd.Series(False, index=dataset.index)
        ).astype(bool)
        has_tiles = dataset.get("has_tile_features", pd.Series(False, index=dataset.index)).astype(
            bool
        )
        surface_known = dataset.get(
            "is_surface_known", pd.Series(False, index=dataset.index)
        ).astype(bool)
        diagnostics = {
            "total_edges": int(len(dataset)),
            "inside_train_area": int(inside_train.sum()),
            "has_tile_features": int(has_tiles.sum()),
            "known_surface_edges": int(surface_known.sum()),
            "known_inside_train_area": int((inside_train & surface_known).sum()),
            "known_with_tile_features": int((surface_known & has_tiles).sum()),
            "known_inside_train_with_tile_features": int(
                (inside_train & surface_known & has_tiles).sum()
            ),
        }
        raise ValueError(
            f"Not enough known train-candidate surface edges for training: found {len(known)}. "
            f"Need at least {config.min_known_edges}. Diagnostics: {diagnostics}"
        )
    if known["surface_train_label"].nunique() < 2:
        raise ValueError("Need at least two concrete surface classes for training")

    edge_lookup_df = edges_gdf.copy()
    edge_lookup_df["edge_id"] = edge_lookup_df["edge_id"].map(
        lambda x: "" if pd.isna(x) else str(x).strip()
    )
    edge_lookup = edge_lookup_df.drop_duplicates("edge_id", keep="first").set_index("edge_id")
    known_edges = edge_lookup.loc[known["edge_id"].astype(str)].reset_index()
    projected = known_edges.to_crs(_utm_crs_for(known_edges))
    cent = projected.geometry.centroid
    grid = max(1.0, float(config.spatial_grid_m))
    cells = pd.Series(
        [
            f"{int(math.floor(x / grid))}:{int(math.floor(y / grid))}"
            for x, y in zip(cent.x, cent.y)
        ],
        index=known.index,
    )
    unique_cells = np.array(sorted(cells.unique()))
    if len(unique_cells) < 2:
        raise ValueError("Not enough spatial cells for spatial train/test split")
    rng = np.random.default_rng(int(config.random_state))
    rng.shuffle(unique_cells)
    test_n = max(1, int(round(len(unique_cells) * float(config.test_share))))
    cal_n = (
        int(round(len(unique_cells) * float(config.calibration_share)))
        if config.calibration_enabled
        else 0
    )
    test_n = min(test_n, len(unique_cells) - 1)
    cal_n = min(max(0, cal_n), max(0, len(unique_cells) - test_n - 1))
    test_cells = set(unique_cells[:test_n])
    calibration_cells = set(unique_cells[test_n : test_n + cal_n])

    # Keep every learnable label represented in train if possible.
    labels = set(known["surface_train_label"].astype(str))
    for label in sorted(labels):
        holdout_cells = test_cells | calibration_cells
        train_labels = set(known.loc[~cells.isin(holdout_cells), "surface_train_label"].astype(str))
        if label in train_labels:
            continue
        label_cells = [
            c
            for c in cells[known["surface_train_label"].astype(str) == label].unique()
            if c in holdout_cells
        ]
        if label_cells:
            c = label_cells[0]
            if c in test_cells:
                test_cells.remove(c)
            else:
                calibration_cells.discard(c)

    split = pd.Series("unknown", index=dataset.index, dtype=object)
    split.loc[known.index[~cells.isin(test_cells | calibration_cells).to_numpy()]] = "train"
    split.loc[known.index[cells.isin(calibration_cells).to_numpy()]] = "calibration"
    split.loc[known.index[cells.isin(test_cells).to_numpy()]] = "test"
    holdout_share = max(0.0, float(config.holdout_predict_polygon_known_share))
    if holdout_share > 0 and "inside_predict_area" in dataset.columns:
        train_inside = known.index[
            (split.loc[known.index] == "train").to_numpy()
            & dataset.loc[known.index, "inside_predict_area"].astype(bool).to_numpy()
        ]
        if len(train_inside) > 1:
            rng = np.random.default_rng(int(config.random_state) + 17)
            mode = str(config.holdout_split_mode or "grouped_geometry_or_way")
            if mode in {"grouped_geometry", "grouped_osm_way", "grouped_geometry_or_way"}:
                if mode == "grouped_osm_way" and "osm_way_id" in dataset.columns:
                    groups = dataset.loc[train_inside, "osm_way_id"].fillna("").astype(str)
                elif mode == "grouped_geometry_or_way":
                    way = (
                        dataset.loc[train_inside, "osm_way_id"].fillna("").astype(str)
                        if "osm_way_id" in dataset.columns
                        else pd.Series("", index=train_inside)
                    )
                    geom = dataset.loc[train_inside, "geometry_hash_rounded"].fillna("").astype(str)
                    undirected = (
                        dataset.loc[train_inside, "undirected_edge_key"].fillna("").astype(str)
                    )
                    groups = way.where(
                        way.str.len() > 0, undirected.where(undirected.str.len() > 0, geom)
                    )
                else:
                    groups = (
                        dataset.loc[train_inside, "geometry_hash_rounded"].fillna("").astype(str)
                    )
                unique_groups = np.array(sorted(groups.unique()))
                rng.shuffle(unique_groups)
                group_target = max(1, int(round(len(unique_groups) * holdout_share)))
                chosen_groups = set(unique_groups[:group_target])
                chosen = groups[groups.isin(chosen_groups)].index.to_numpy()
            else:
                holdout_n = int(round(len(train_inside) * holdout_share))
                chosen = (
                    rng.choice(np.array(train_inside), size=max(1, holdout_n), replace=False)
                    if holdout_n > 0
                    else np.array([])
                )
            if len(chosen):
                split.loc[chosen] = "predict_holdout"
                if (
                    bool(config.prevent_directed_edge_leakage)
                    and "undirected_edge_key" in dataset.columns
                ):
                    keys = set(dataset.loc[chosen, "undirected_edge_key"].dropna().astype(str))
                    peer_idx = known.index[
                        dataset.loc[known.index, "undirected_edge_key"]
                        .astype(str)
                        .isin(keys)
                        .to_numpy()
                    ]
                    split.loc[peer_idx] = "predict_holdout"
    if (split == "train").sum() == 0 or (split == "test").sum() == 0:
        raise ValueError("Spatial split produced an empty train or test partition")
    return split


def spatial_train_cal_test_split(
    dataset: pd.DataFrame,
    edges_gdf: gpd.GeoDataFrame,
    config: SurfaceAIConfig,
) -> pd.Series:
    return spatial_train_test_split(dataset, edges_gdf, config)


def _features_for_model(
    dataset: pd.DataFrame,
    feature_set: str,
    *,
    config: SurfaceAIConfig | None = None,
) -> tuple[pd.DataFrame, list[str], list[str]]:
    geometry_cols = list(AI_GEOMETRY_FEATURES)
    if (
        feature_set.endswith("_without_spatial_prior")
        or feature_set == "combined_without_spatial_prior"
    ):
        geometry_cols = [c for c in geometry_cols if c not in SPATIAL_PRIOR_FEATURES]
    if feature_set == "osm":
        cat_cols = list(AI_OSM_FEATURES)
        num_cols: list[str] = []
    elif feature_set == "satellite":
        cat_cols = []
        num_cols = list(AI_SATELLITE_FEATURES)
    elif feature_set in {"combined", "combined_without_spatial_prior"}:
        cat_cols = list(AI_OSM_FEATURES)
        num_cols = geometry_cols + list(AI_SATELLITE_FEATURES)
    elif feature_set in {
        "combined_with_neighbors",
        "combined_with_neighbors_without_spatial_prior",
    }:
        cat_cols = list(AI_OSM_FEATURES)
        num_cols = geometry_cols + list(AI_SATELLITE_FEATURES) + list(NEIGHBOR_FEATURES)
    elif feature_set == "osm_geometry":
        cat_cols = list(AI_OSM_FEATURES)
        num_cols = geometry_cols
    else:
        cat_cols = []
        num_cols = []
    if config is not None and not config.use_satellite_features:
        drop_sat = set(AI_SATELLITE_FEATURES)
        num_cols = [c for c in num_cols if c not in drop_sat]
    cols = cat_cols + num_cols
    X = dataset.reindex(columns=cols).copy()
    for col in cat_cols:
        X[col] = X[col].where(X[col].notna(), None)
    for col in num_cols:
        X[col] = pd.to_numeric(X[col], errors="coerce")
    return X, cat_cols, num_cols


def _numeric_columns_with_signal(X: pd.DataFrame, num_cols: Sequence[str]) -> list[str]:
    """Числовые признаки, в которых есть хотя бы одно не-NaN значение (иначе median-imputer шумит предупреждениями)."""
    if X.empty or len(X) == 0:
        return list(num_cols)
    out: list[str] = []
    for c in num_cols:
        if c not in X.columns:
            continue
        if pd.to_numeric(X[c], errors="coerce").notna().any():
            out.append(c)
    return out


class ConstantFeatureTransformer(BaseEstimator, TransformerMixin):
    """Single constant feature for candidates whose requested feature set is empty."""

    def fit(self, X: Any, y: Any = None) -> ConstantFeatureTransformer:
        return self

    def transform(self, X: Any) -> np.ndarray:
        return np.ones((len(X), 1), dtype=float)

    def get_feature_names_out(self, input_features: Any = None) -> np.ndarray:
        return np.array(["constant_no_available_features"], dtype=object)


def _build_preprocessor(cat_cols: Sequence[str], num_cols: Sequence[str]) -> Any:
    transformers = []
    if cat_cols:
        transformers.append(
            (
                "cat",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="constant", fill_value="__missing__")),
                        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
                    ]
                ),
                list(cat_cols),
            )
        )
    if num_cols:
        transformers.append(
            (
                "num",
                Pipeline(steps=[("imputer", SimpleImputer(strategy="median"))]),
                list(num_cols),
            )
        )
    if not transformers:
        return ConstantFeatureTransformer()
    return ColumnTransformer(
        transformers=transformers, remainder="drop", verbose_feature_names_out=True
    )


def _rf(
    config: SurfaceAIConfig,
    *,
    class_weight: str | None,
    n_jobs: int = -1,
) -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=int(config.rf_n_estimators),
        random_state=int(config.random_state),
        class_weight=class_weight,
        n_jobs=int(n_jobs),
        min_samples_leaf=2,
    )


def _manual_group_class_weight(config: SurfaceAIConfig) -> dict[str, float]:
    """Веса только для меток ``group_target_labels(group_target_mode)`` (без лишних ключей для sklearn)."""
    labels = group_target_labels(config.group_target_mode)
    by_label = {
        "paved_good": float(config.group_class_weight_paved_good),
        "paved_rough": float(config.group_class_weight_paved_rough),
        "unpaved_soft": float(config.group_class_weight_unpaved_soft),
        "unpaved_hard": float(config.group_class_weight_unpaved_soft),
        "rough_or_unpaved": float(config.group_class_weight_unpaved_soft),
    }
    out: dict[str, float] = {}
    for lab in labels:
        if lab in by_label:
            out[lab] = by_label[lab]
        else:
            out[lab] = 1.0
    return out


def _build_pipeline(
    candidate: str,
    feature_set: str,
    config: SurfaceAIConfig,
    *,
    sklearn_n_jobs: int = -1,
    fit_frame: pd.DataFrame | None = None,
) -> Pipeline:
    if fit_frame is not None and len(fit_frame):
        X_schema, cat_cols, num_cols = _features_for_model(fit_frame, feature_set, config=config)
        num_cols = _numeric_columns_with_signal(X_schema, num_cols)
    else:
        _, cat_cols, num_cols = _features_for_model(pd.DataFrame(), feature_set, config=config)
    preprocessor = _build_preprocessor(cat_cols, num_cols)
    nj = int(sklearn_n_jobs)
    if candidate == "combined_hist_gradient_boosting":
        model: Any = HistGradientBoostingClassifier(random_state=int(config.random_state))
    elif candidate == "combined_logistic_regression":
        model = LogisticRegression(max_iter=1000, class_weight="balanced", n_jobs=nj)
    else:
        cw: Any = None
        if candidate in {
            "combined_rf_balanced",
            "combined_balanced_random_forest",
            "combined_rf_balanced_without_spatial_prior",
            "group_direct_combined_rf_balanced",
            "group_direct_combined_rf_balanced_without_spatial_prior",
        }:
            cw = config.rf_class_weight or "balanced_subsample"
        if candidate in {
            "group_direct_combined_rf_class_weight_manual",
            "group_direct_combined_rf_paved_rough_weighted",
            "group_direct_combined_rf_paved_rough_oversampled",
            "group_direct_combined_rf_threshold_tuned",
        }:
            cw = _manual_group_class_weight(config)
        model = _rf(config, class_weight=cw, n_jobs=nj)
    return Pipeline(steps=[("preprocess", preprocessor), ("model", model)])


class HighwayHeuristicClassifier(BaseEstimator, ClassifierMixin):
    def __init__(
        self, train_label_classes: Sequence[str], frequent_surfaces: Sequence[str]
    ) -> None:
        self.classes_ = np.array(sorted(set(train_label_classes)))
        self.frequent_surfaces_ = set(frequent_surfaces)

    def fit(self, X: pd.DataFrame, y: Sequence[str]) -> HighwayHeuristicClassifier:
        self.classes_ = np.array(sorted(set(y)))
        return self

    def _to_label(self, surface: str) -> str:
        if surface in self.frequent_surfaces_:
            return surface
        group = surface_to_group(surface)
        label = f"rare_other_{group}" if group in SURFACE_GROUPS else "rare_other"
        return label if label in set(self.classes_) else "unknown"

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        labels = []
        for _, row in X.iterrows():
            surface = predict_surface_by_highway_heuristic(row.to_dict())
            labels.append(self._to_label(surface))
        return np.array(labels, dtype=object)

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        pred = self.predict(X)
        proba = np.zeros((len(pred), len(self.classes_)), dtype=float)
        lookup = {c: i for i, c in enumerate(self.classes_)}
        for i, label in enumerate(pred):
            j = lookup.get(label)
            if j is not None:
                proba[i, j] = 1.0
        return proba


class GroupHighwayHeuristicClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, group_mode: str = "3class_unpaved_hard_to_soft") -> None:
        self.group_mode = group_mode
        self.classes_ = np.array(group_target_labels(group_mode))

    def fit(self, X: pd.DataFrame, y: Sequence[str]) -> GroupHighwayHeuristicClassifier:
        self.classes_ = np.array(sorted(set(str(v) for v in y)))
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        labels = []
        for _, row in X.iterrows():
            surface = predict_surface_by_highway_heuristic(row.to_dict())
            labels.append(normalize_group_target(surface_to_group(surface), self.group_mode))
        return np.array(labels, dtype=object)

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        pred = self.predict(X)
        proba = np.zeros((len(pred), len(self.classes_)), dtype=float)
        lookup = {c: i for i, c in enumerate(self.classes_)}
        for i, label in enumerate(pred):
            j = lookup.get(label)
            if j is not None:
                proba[i, j] = 1.0
        return proba


def _candidate_feature_set(candidate: str) -> str:
    key = candidate.replace("group_direct_", "")
    if key == "osm_only_rf":
        return "osm"
    if key == "satellite_only_rf":
        return "satellite"
    if key in {
        "combined_rf",
        "combined_rf_balanced",
        "combined_balanced_random_forest",
        "combined_hist_gradient_boosting",
        "combined_logistic_regression",
        "combined_rf_calibrated",
    }:
        return "combined"
    if key in {"combined_rf_without_spatial_prior", "combined_rf_balanced_without_spatial_prior"}:
        return "combined_without_spatial_prior"
    if key in {
        "combined_rf_with_neighbors",
        "combined_with_neighbors",
        "combined_rf_neighbor_features",
    }:
        return "combined_with_neighbors"
    if key in {
        "combined_rf_class_weight_manual",
        "combined_rf_paved_rough_weighted",
        "combined_rf_paved_rough_oversampled",
        "combined_rf_threshold_tuned",
    }:
        return "combined"
    if key == "highway_heuristic":
        return "osm"
    return "none"


def _candidate_display(candidate: str) -> tuple[str, str]:
    mapping = {
        "always_majority": ("Always majority", "none"),
        "highway_heuristic": ("Highway heuristic", "highway only"),
        "osm_only_rf": ("OSM-only RF", "OSM tags"),
        "satellite_only_rf": ("Satellite-only RF", "satellite stats"),
        "combined_rf": ("Combined RF", "OSM + geometry + satellite"),
        "combined_rf_balanced": ("Combined balanced RF", "OSM + geometry + satellite"),
        "combined_balanced_random_forest": ("Combined balanced RF", "OSM + geometry + satellite"),
        "combined_hist_gradient_boosting": (
            "Combined HistGradientBoosting",
            "OSM + geometry + satellite",
        ),
        "combined_logistic_regression": (
            "Combined logistic regression",
            "OSM + geometry + satellite",
        ),
        "combined_rf_without_spatial_prior": (
            "Combined RF without spatial prior",
            "OSM + geometry + satellite - spatial prior",
        ),
        "combined_rf_balanced_without_spatial_prior": (
            "Combined balanced RF without spatial prior",
            "OSM + geometry + satellite - spatial prior",
        ),
        "combined_rf_with_neighbors": (
            "Combined RF + neighbor features",
            "OSM + geometry + satellite + neighbors",
        ),
        "combined_rf_neighbor_features": (
            "Combined RF + neighbor features",
            "OSM + geometry + satellite + neighbors",
        ),
        "group_direct_always_majority": ("Group direct always majority", "none"),
        "group_direct_highway_heuristic": ("Group direct highway heuristic", "highway only"),
        "group_direct_osm_only_rf": ("Group direct OSM-only RF", "OSM tags"),
        "group_direct_satellite_only_rf": ("Group direct satellite-only RF", "satellite stats"),
        "group_direct_combined_rf": ("Group direct Combined RF", "OSM + geometry + satellite"),
        "group_direct_combined_rf_balanced": (
            "Group direct Combined balanced RF",
            "OSM + geometry + satellite",
        ),
        "group_direct_combined_rf_calibrated": (
            "Group direct Combined calibrated RF",
            "OSM + geometry + satellite",
        ),
        "group_direct_combined_rf_without_spatial_prior": (
            "Group direct Combined RF without spatial prior",
            "OSM + geometry + satellite - spatial prior",
        ),
        "group_direct_combined_rf_balanced_without_spatial_prior": (
            "Group direct Combined balanced RF without spatial prior",
            "OSM + geometry + satellite - spatial prior",
        ),
        "group_direct_combined_rf_neighbor_features": (
            "Group direct RF + neighbor features",
            "OSM + geometry + satellite + neighbors",
        ),
        "group_direct_combined_rf_with_neighbors": (
            "Group direct RF + neighbor features",
            "OSM + geometry + satellite + neighbors",
        ),
        "group_direct_combined_rf_class_weight_manual": (
            "Group direct RF manual rough weights",
            "OSM + geometry + satellite",
        ),
        "group_direct_combined_rf_paved_rough_weighted": (
            "Group direct RF manual weights (paved_rough emphasis)",
            "OSM + geometry + satellite; same RF weights as class_weight_manual until real oversampling exists",
        ),
        "group_direct_combined_rf_paved_rough_oversampled": (
            "Group direct RF paved_rough oversampled",
            "OSM + geometry + satellite; implemented as manual class weights",
        ),
        "group_direct_combined_rf_threshold_tuned": (
            "Group direct RF + post-hoc group thresholds",
            "OSM + geometry + satellite",
        ),
    }
    return mapping.get(candidate, (candidate, _candidate_feature_set(candidate)))


def _metrics_for_predictions(
    y_true: Sequence[str],
    y_pred: Sequence[str],
    *,
    labels: Sequence[str],
    target: str,
) -> dict[str, Any]:
    labels = list(labels)
    report = classification_report(
        y_true,
        y_pred,
        labels=labels,
        zero_division=0,
        output_dict=True,
    )
    true_groups = pd.Series(y_true).map(train_label_to_group)
    pred_groups = pd.Series(y_pred).map(train_label_to_group)
    bad_mask = true_groups.isin({"unpaved_hard", "unpaved_soft"})
    recall_bad = (
        float((pred_groups[bad_mask].isin({"unpaved_hard", "unpaved_soft"})).mean())
        if bad_mask.any()
        else 0.0
    )
    unpaved_soft_mask = true_groups == "unpaved_soft"
    recall_unpaved_soft = (
        float((pred_groups[unpaved_soft_mask] == "unpaved_soft").mean())
        if unpaved_soft_mask.any()
        else 0.0
    )
    return {
        "target": target,
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "recall_bad_surface": recall_bad,
        "recall_unpaved_soft": recall_unpaved_soft,
        "recall_asphalt": float(report.get("asphalt", {}).get("recall", 0.0)),
        "recall_concrete": float(report.get("concrete", {}).get("recall", 0.0)),
        "recall_paving_stones": float(report.get("paving_stones", {}).get("recall", 0.0)),
        "classification_report": report,
        "confusion_matrix_labels": labels,
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).astype(int).tolist(),
    }


def _group_metrics_for_predictions(y_true: Sequence[str], y_pred: Sequence[str]) -> dict[str, Any]:
    ytg = pd.Series(y_true).map(train_label_to_group).tolist()
    ypg = pd.Series(y_pred).map(train_label_to_group).tolist()
    labels = list(SURFACE_GROUPS)
    if "rough_or_unpaved" in set(ytg) | set(ypg):
        labels = ["paved_good", "paved_rough", "rough_or_unpaved"]
    report = classification_report(ytg, ypg, labels=labels, zero_division=0, output_dict=True)
    bad_mask = pd.Series(ytg).isin({"unpaved_hard", "unpaved_soft", "rough_or_unpaved"})
    pred_bad = pd.Series(ypg).isin({"unpaved_hard", "unpaved_soft", "rough_or_unpaved"})
    true_s = pd.Series(ytg)
    pred_s = pd.Series(ypg)
    rough_mask = true_s == "paved_rough"
    rough_to_good = rough_mask & (pred_s == "paved_good")
    good_mask = true_s == "paved_good"
    good_to_rough = good_mask & (pred_s == "paved_rough")
    return {
        "target": "group",
        "accuracy": float(accuracy_score(ytg, ypg)),
        "balanced_accuracy": float(balanced_accuracy_score(ytg, ypg)),
        "macro_f1": float(f1_score(ytg, ypg, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(ytg, ypg, average="weighted", zero_division=0)),
        "recall_bad_surface": float(pred_bad[bad_mask].mean()) if bad_mask.any() else 0.0,
        "recall_unpaved_soft": float(report.get("unpaved_soft", {}).get("recall", 0.0)),
        "recall_paved_rough": float(report.get("paved_rough", {}).get("recall", 0.0)),
        "precision_paved_rough": float(report.get("paved_rough", {}).get("precision", 0.0)),
        "f1_paved_rough": float(report.get("paved_rough", {}).get("f1-score", 0.0)),
        "paved_rough_to_paved_good_count": int(rough_to_good.sum()),
        "paved_rough_to_paved_good_rate": float(rough_to_good.mean()) if rough_mask.any() else 0.0,
        "paved_good_to_paved_rough_count": int(good_to_rough.sum()),
        "paved_good_to_paved_rough_rate": float(good_to_rough.mean()) if good_mask.any() else 0.0,
        "classification_report": report,
        "confusion_matrix_labels": labels,
        "confusion_matrix": confusion_matrix(ytg, ypg, labels=labels).astype(int).tolist(),
    }


def dangerous_upgrade_metrics(
    true_groups: Sequence[str],
    raw_pred_groups: Sequence[str],
    effective_pred_groups: Sequence[str] | None = None,
    lengths_m: Sequence[float] | None = None,
) -> dict[str, Any]:
    true = pd.Series(list(true_groups), dtype=object).fillna("unknown").astype(str)
    raw = pd.Series(list(raw_pred_groups), dtype=object).fillna("unknown").astype(str)
    effective = (
        pd.Series(list(effective_pred_groups), dtype=object).fillna("unknown").astype(str)
        if effective_pred_groups is not None
        else raw
    )
    lengths = (
        pd.Series(list(lengths_m), dtype=float)
        if lengths_m is not None
        else pd.Series(np.ones(len(true)), dtype=float)
    )
    non_good = true.isin({"paved_rough", "unpaved_hard", "unpaved_soft", "rough_or_unpaved"})

    def block(pred: pd.Series, suffix: str) -> dict[str, Any]:
        mask = pd.Series([is_dangerous_upgrade(t, p) for t, p in zip(true, pred)])
        by_class = {g: int(mask[true == g].sum()) for g in sorted(true[non_good].unique())}
        rate_by = {
            g: float(mask[true == g].mean()) if int((true == g).sum()) else 0.0
            for g in sorted(true[non_good].unique())
        }
        sev = true.map(lambda g: DANGEROUS_UPGRADE_SEVERITY.get(str(g), 0.0))
        return {
            f"dangerous_upgrade_count_{suffix}": int(mask.sum()),
            f"dangerous_upgrade_rate_{suffix}_all": float(mask.mean()) if len(mask) else 0.0,
            f"dangerous_upgrade_rate_{suffix}_among_non_good": float(mask[non_good].mean())
            if non_good.any()
            else 0.0,
            f"dangerous_upgrade_count_by_true_class_{suffix}": by_class,
            f"dangerous_upgrade_rate_by_true_class_{suffix}": rate_by,
            f"dangerous_upgrade_length_m_{suffix}": float(lengths[mask].sum()),
            f"dangerous_upgrade_length_share_{suffix}": float(
                lengths[mask].sum() / max(1e-9, lengths.sum())
            ),
            f"dangerous_upgrade_weighted_score_{suffix}": float((sev[mask]).sum()),
        }

    out = {}
    out.update(block(raw, "raw"))
    out.update(block(effective, "effective"))
    # Flat aliases used by baseline tables.
    out["dangerous_upgrade_rate_raw"] = out["dangerous_upgrade_rate_raw_among_non_good"]
    out["dangerous_upgrade_rate_effective"] = out["dangerous_upgrade_rate_effective_among_non_good"]
    out["dangerous_upgrade_count_raw"] = out["dangerous_upgrade_count_raw"]
    out["dangerous_upgrade_count_effective"] = out["dangerous_upgrade_count_effective"]
    out["dangerous_upgrade_length_m_effective"] = out["dangerous_upgrade_length_m_effective"]
    return out


def macro_f1_safe(metrics: dict[str, Any], config: SurfaceAIConfig) -> float:
    return float(metrics.get("macro_f1", 0.0)) - float(config.dangerous_error_penalty) * float(
        metrics.get("dangerous_upgrade_rate_effective", 0.0)
    )


def macro_f1_safe_rough_aware(metrics: dict[str, Any], config: SurfaceAIConfig) -> float:
    return (
        float(metrics.get("macro_f1", 0.0))
        + float(config.unpaved_soft_recall_weight) * float(metrics.get("recall_unpaved_soft", 0.0))
        + float(config.paved_rough_recall_weight) * float(metrics.get("recall_paved_rough", 0.0))
        - float(config.dangerous_error_penalty)
        * float(metrics.get("dangerous_upgrade_rate_effective", 0.0))
    )


def train_evaluate_models(
    dataset: pd.DataFrame,
    config: SurfaceAIConfig,
    label_meta: dict[str, Any],
    *,
    progress: ProgressFactory = no_progress,
) -> tuple[dict[str, Any], pd.DataFrame, pd.DataFrame]:
    train = dataset[dataset["surface_ai_split"] == "train"].copy()
    test = dataset[dataset["surface_ai_split"] == "test"].copy()
    y_train = train["surface_train_label"].astype(str)
    y_test = test["surface_train_label"].astype(str)
    labels = sorted(set(y_train) | set(y_test))
    frequent = label_meta.get("frequent_surface_classes", [])
    models: dict[str, Any] = {}
    rows: list[dict[str, Any]] = []
    group_rows: list[dict[str, Any]] = []
    test_predictions: dict[str, list[str]] = {}

    candidates = list(dict.fromkeys(config.model_candidates))
    for candidate in progress(candidates, "[5/8] Train/evaluate models", total=len(candidates)):
        display, features_label = _candidate_display(candidate)
        feature_set = _candidate_feature_set(candidate)
        if candidate == "always_majority":
            model: Any = DummyClassifier(strategy="most_frequent")
            X_train = pd.DataFrame({"constant": np.ones(len(train))})
            X_test = pd.DataFrame({"constant": np.ones(len(test))})
        elif candidate == "highway_heuristic":
            model = HighwayHeuristicClassifier(labels, frequent)
            X_train, _, _ = _features_for_model(train, "osm", config=config)
            X_test, _, _ = _features_for_model(test, "osm", config=config)
        else:
            model = _build_pipeline(candidate, feature_set, config, fit_frame=train)
            X_train, _, _ = _features_for_model(train, feature_set, config=config)
            X_test, _, _ = _features_for_model(test, feature_set, config=config)
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        pred = [str(x) for x in pred]
        test_predictions[candidate] = pred
        concrete_metrics = _metrics_for_predictions(
            y_test.tolist(),
            pred,
            labels=labels,
            target="surface_concrete",
        )
        group_metrics = _group_metrics_for_predictions(y_test.tolist(), pred)
        row = {
            "model_key": candidate,
            "model": display,
            "target": "concrete surface",
            "features": features_label,
            "accuracy": concrete_metrics["accuracy"],
            "balanced_accuracy": concrete_metrics["balanced_accuracy"],
            "macro_f1": concrete_metrics["macro_f1"],
            "weighted_f1": concrete_metrics["weighted_f1"],
            "recall_bad_surface": concrete_metrics["recall_bad_surface"],
            "recall_unpaved_soft": concrete_metrics["recall_unpaved_soft"],
            "recall_asphalt": concrete_metrics["recall_asphalt"],
            "recall_concrete": concrete_metrics["recall_concrete"],
            "recall_paving_stones": concrete_metrics["recall_paving_stones"],
        }
        rows.append(row)
        group_rows.append(
            {
                "model_key": candidate,
                "model": display,
                "target": "group",
                "features": features_label,
                "accuracy": group_metrics["accuracy"],
                "balanced_accuracy": group_metrics["balanced_accuracy"],
                "macro_f1": group_metrics["macro_f1"],
                "weighted_f1": group_metrics["weighted_f1"],
                "recall_bad_surface": concrete_metrics["recall_bad_surface"],
                "recall_unpaved_soft": group_metrics["recall_unpaved_soft"],
                "recall_asphalt": np.nan,
                "recall_concrete": np.nan,
                "recall_paving_stones": np.nan,
            }
        )
        models[candidate] = {
            "model": model,
            "feature_set": feature_set,
            "concrete_metrics": concrete_metrics,
            "group_metrics": group_metrics,
            "test_pred": pred,
        }

    baseline_table = pd.DataFrame(rows + group_rows)
    selected = select_best_model(models, baseline_table, config)
    models["_selected"] = selected
    return models, baseline_table, pd.DataFrame(rows)


def select_best_model(
    models: dict[str, Any],
    baseline_table: pd.DataFrame,
    config: SurfaceAIConfig,
) -> dict[str, Any]:
    concrete = baseline_table[baseline_table["target"] == "concrete surface"].copy()
    eligible = concrete[
        concrete["recall_bad_surface"] >= float(config.min_bad_surface_recall)
    ].copy()
    safety_applied = True
    if eligible.empty:
        eligible = concrete
        safety_applied = False
    metric = config.selection_metric if config.selection_metric in eligible.columns else "macro_f1"
    eligible = eligible.sort_values(
        by=[metric, "balanced_accuracy", "recall_bad_surface"],
        ascending=[False, False, False],
    )
    best_key = str(eligible.iloc[0]["model_key"])
    return {
        "model_key": best_key,
        "model_name": str(eligible.iloc[0]["model"]),
        "selected_by": metric,
        "safety_recall_threshold": float(config.min_bad_surface_recall),
        "safety_recall_threshold_satisfied": bool(safety_applied),
        "metrics": models[best_key]["concrete_metrics"],
        "group_metrics": models[best_key]["group_metrics"],
    }


def _effective_group_for_metrics(
    pred_group: str, confidence: float, margin: float, config: SurfaceAIConfig
) -> str:
    if margin < float(config.min_margin):
        return "unknown"
    if confidence < float(config.min_confidence):
        return "unknown"
    if pred_group == "paved_good" and confidence < float(config.paved_good_min_confidence):
        return "paved_rough"
    return pred_group


def _task_candidate_kind(candidate: str) -> str:
    key = candidate.replace("group_direct_", "")
    if key == "always_majority":
        return "always_majority"
    if key == "highway_heuristic":
        return "highway_heuristic"
    return "model"


def _fit_candidate_model(
    candidate: str,
    feature_set: str,
    target: str,
    train: pd.DataFrame,
    calibration: pd.DataFrame,
    config: SurfaceAIConfig,
    labels: Sequence[str],
    label_meta: dict[str, Any],
    *,
    sklearn_n_jobs: int = -1,
) -> tuple[Any, pd.DataFrame]:
    train_fit = pd.concat([train, calibration], axis=0) if not calibration.empty else train
    y_train = train[
        "surface_group_direct_label" if target == "group_direct" else "surface_train_label"
    ].astype(str)
    y_train_fit = train_fit[
        "surface_group_direct_label" if target == "group_direct" else "surface_train_label"
    ].astype(str)
    kind = _task_candidate_kind(candidate)
    if kind == "always_majority":
        model: Any = DummyClassifier(strategy="most_frequent")
        X_train_fit = pd.DataFrame({"constant": np.ones(len(train_fit))}, index=train_fit.index)
        model.fit(X_train_fit, y_train_fit)
        return model, X_train_fit
    if kind == "highway_heuristic":
        if target == "group_direct":
            model = GroupHighwayHeuristicClassifier(config.group_target_mode)
        else:
            model = HighwayHeuristicClassifier(
                labels, label_meta.get("frequent_surface_classes", [])
            )
        X_train_fit, _, _ = _features_for_model(train_fit, "osm", config=config)
        model.fit(X_train_fit, y_train_fit)
        return model, X_train_fit

    calibrate = (
        "calibrated" in candidate
        and config.calibration_enabled
        and config.calibration_method != "none"
        and not calibration.empty
    )
    base = _build_pipeline(
        candidate.replace("_calibrated", ""),
        feature_set,
        config,
        sklearn_n_jobs=sklearn_n_jobs,
        fit_frame=train_fit,
    )
    if calibrate:
        X_train, _, _ = _features_for_model(train, feature_set, config=config)
        base.fit(X_train, y_train)
        X_cal, _, _ = _features_for_model(calibration, feature_set, config=config)
        y_cal = calibration[
            "surface_group_direct_label" if target == "group_direct" else "surface_train_label"
        ].astype(str)
        if y_cal.nunique() >= 2 and len(y_cal) >= int(config.calibration_min_class_count):
            try:
                calibrated = CalibratedClassifierCV(
                    estimator=base,
                    method=config.calibration_method,
                    cv="prefit",
                )
                calibrated.fit(X_cal, y_cal)
                return calibrated, X_train
            except Exception:
                pass
        return base, X_train
    X_train_fit, _, _ = _features_for_model(train_fit, feature_set, config=config)
    base.fit(X_train_fit, y_train_fit)
    return base, X_train_fit


def _proba_top_fields(
    proba: pd.DataFrame,
) -> tuple[list[str], list[float], list[str], list[float], list[float]]:
    labels: list[str] = []
    conf: list[float] = []
    labels2: list[str] = []
    conf2: list[float] = []
    margins: list[float] = []
    for _, row in proba.iterrows():
        ordered = row.sort_values(ascending=False)
        top1 = str(ordered.index[0]) if len(ordered) else "unknown"
        c1 = float(ordered.iloc[0]) if len(ordered) else 0.0
        top2 = str(ordered.index[1]) if len(ordered) > 1 else "unknown"
        c2 = float(ordered.iloc[1]) if len(ordered) > 1 else 0.0
        labels.append(top1)
        conf.append(c1)
        labels2.append(top2)
        conf2.append(c2)
        margins.append(c1 - c2)
    return labels, conf, labels2, conf2, margins


def _tuned_group_top_fields(
    proba: pd.DataFrame,
    config: SurfaceAIConfig,
    *,
    candidate: str,
) -> tuple[list[str], list[float], list[str], list[float], list[float]]:
    pred, conf, top2, top2_conf, margin = _proba_top_fields(proba)
    # Иначе все group-direct кандидаты получают один post-processing — сравнение моделей искажается.
    if "threshold_tuned" not in candidate or not config.group_threshold_tuning:
        return pred, conf, top2, top2_conf, margin
    tuned: list[str] = []
    tuned_conf: list[float] = []
    tuned_top2: list[str] = []
    tuned_top2_conf: list[float] = []
    tuned_margin: list[float] = []
    for idx, row in proba.iterrows():
        ordered = row.sort_values(ascending=False)
        chosen = str(ordered.index[0]) if len(ordered) else "unknown"
        if chosen == "paved_good":
            rough_p = float(row.get("paved_rough", 0.0))
            soft_p = float(row.get("unpaved_soft", 0.0))
            top_p = float(ordered.iloc[0]) if len(ordered) else 0.0
            if soft_p >= float(config.unpaved_soft_min_proba) and (top_p - soft_p) <= 0.50:
                chosen = "unpaved_soft"
            elif rough_p >= float(config.paved_rough_min_proba) and (top_p - rough_p) <= 0.50:
                chosen = "paved_rough"
        c = float(row.get(chosen, 0.0))
        others = row.drop(labels=[chosen], errors="ignore").sort_values(ascending=False)
        second = str(others.index[0]) if len(others) else "unknown"
        c2 = float(others.iloc[0]) if len(others) else 0.0
        tuned.append(chosen)
        tuned_conf.append(c)
        tuned_top2.append(second)
        tuned_top2_conf.append(c2)
        tuned_margin.append(c - c2)
    return tuned, tuned_conf, tuned_top2, tuned_top2_conf, tuned_margin


def evaluate_task_model(
    *,
    candidate: str,
    model: Any,
    feature_set: str,
    target: str,
    test: pd.DataFrame,
    labels: Sequence[str],
    config: SurfaceAIConfig,
) -> tuple[dict[str, Any], pd.DataFrame]:
    if _task_candidate_kind(candidate) == "always_majority":
        X_test = pd.DataFrame({"constant": np.ones(len(test))}, index=test.index)
    else:
        X_test, _, _ = _features_for_model(
            test,
            feature_set if feature_set != "none" else "osm",
            config=config,
        )
    proba = _predict_model_proba(model, X_test, labels)
    if target == "group_direct":
        pred, conf, _, _, margin = _tuned_group_top_fields(proba, config, candidate=candidate)
    else:
        pred, conf, _, _, margin = _proba_top_fields(proba)
    if target == "group_direct":
        y_true = test["surface_group_direct_label"].astype(str).tolist()
        true_groups = y_true
        pred_groups = pred
        group_metrics = _group_metrics_for_predictions(y_true, pred)
        metrics = dict(group_metrics)
        metrics["target"] = "group_direct"
        report_labels = list(labels)
    else:
        y_true = test["surface_train_label"].astype(str).tolist()
        true_groups = [train_label_to_group(x) for x in y_true]
        pred_groups = [train_label_to_group(x) for x in pred]
        metrics = _metrics_for_predictions(y_true, pred, labels=labels, target="concrete_compact")
        report_labels = list(labels)
    effective_groups = [
        _effective_group_for_metrics(pg, c, m, config)
        for pg, c, m in zip(pred_groups, conf, margin)
    ]
    metrics.update(
        dangerous_upgrade_metrics(
            true_groups,
            pred_groups,
            effective_groups,
            test["length_m"].astype(float).tolist(),
        )
    )
    rough_effective_mask = [
        t == "paved_rough" and p == "paved_good" for t, p in zip(true_groups, effective_groups)
    ]
    lengths = pd.to_numeric(test["length_m"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    rough_true_count = sum(1 for t in true_groups if t == "paved_rough")
    metrics["rough_upgrade_rate_effective"] = (
        float(sum(rough_effective_mask) / rough_true_count) if rough_true_count else 0.0
    )
    metrics["rough_upgrade_length_m_effective"] = (
        float(lengths[np.asarray(rough_effective_mask, dtype=bool)].sum()) if len(lengths) else 0.0
    )
    metrics["macro_f1_safe"] = macro_f1_safe(metrics, config)
    metrics["macro_f1_safe_rough_aware"] = macro_f1_safe_rough_aware(metrics, config)
    metrics["confusion_matrix_labels"] = report_labels if target != "group_direct" else list(labels)
    details = pd.DataFrame(
        {
            "edge_id": test["edge_id"].astype(str).values,
            "y_true": y_true,
            "y_pred": pred,
            "pred_confidence": conf,
            "pred_margin": margin,
            "true_group": true_groups,
            "pred_group": pred_groups,
            "effective_group": effective_groups,
        },
        index=test.index,
    )
    return metrics, details


def train_evaluate_task_models(
    dataset: pd.DataFrame,
    config: SurfaceAIConfig,
    label_meta: dict[str, Any],
    *,
    target: str,
    candidates: Sequence[str],
    progress: ProgressFactory = no_progress,
) -> tuple[dict[str, Any], pd.DataFrame]:
    train = dataset[dataset["surface_ai_split"] == "train"].copy()
    calibration = dataset[dataset["surface_ai_split"] == "calibration"].copy()
    test = dataset[dataset["surface_ai_split"] == "test"].copy()
    target_col = "surface_group_direct_label" if target == "group_direct" else "surface_train_label"
    labels = sorted(set(train[target_col].astype(str)) | set(test[target_col].astype(str)))
    models: dict[str, Any] = {}
    rows: list[dict[str, Any]] = []
    cand_list = list(dict.fromkeys(candidates))
    workers = 1
    if bool(config.auto_parallel) and len(cand_list) >= int(
        config.model_outer_parallel_min_candidates
    ):
        from bike_router.tools._parallel_utils import auto_worker_count

        workers = max(
            1,
            min(auto_worker_count(len(cand_list), memory_heavy=False), len(cand_list)),
        )
    use_outer_mp = workers > 1
    if use_outer_mp:
        import shutil
        import tempfile
        import time as _time
        from concurrent.futures import ProcessPoolExecutor

        from .surface_ai_mp import train_surface_ai_candidate_worker

        tmpdir = tempfile.mkdtemp(prefix="surface_ai_cand_")
        try:
            cfg_path = Path(tmpdir) / "cfg.joblib"
            lm_path = Path(tmpdir) / "lm.joblib"
            tr_path = Path(tmpdir) / "train.parquet"
            cal_path = Path(tmpdir) / "cal.parquet"
            te_path = Path(tmpdir) / "test.parquet"
            models_dir = Path(tmpdir) / "models"
            models_dir.mkdir(parents=True, exist_ok=True)
            joblib.dump(config, cfg_path)
            joblib.dump(label_meta, lm_path)
            train.to_parquet(tr_path, index=False)
            cal_df = calibration.reindex(columns=train.columns)
            cal_df.to_parquet(cal_path, index=False)
            test.to_parquet(te_path, index=False)
            payloads = [
                {
                    "config_path": str(cfg_path),
                    "label_meta_path": str(lm_path),
                    "train_path": str(tr_path),
                    "calibration_path": str(cal_path),
                    "test_path": str(te_path),
                    "candidate": c,
                    "target": target,
                    "sklearn_n_jobs": 1,
                    "models_dir": str(models_dir),
                }
                for c in cand_list
            ]
            t0 = _time.perf_counter()
            _log_surface_ai.info(
                "Surface AI %s: параллельное обучение кандидатов=%d workers=%d",
                target,
                len(cand_list),
                workers,
            )
            with ProcessPoolExecutor(max_workers=workers) as ex:
                outs = list(ex.map(train_surface_ai_candidate_worker, payloads))
            for item in outs:
                c = str(item["candidate"])
                models[c] = {
                    "model": joblib.load(item["model_path"]),
                    "feature_set": item["feature_set"],
                    "metrics": item["metrics"],
                    "details": pd.read_parquet(item["details_path"]),
                    "labels": item["labels"],
                    "target": item["target"],
                }
                rows.append(item["row"])
            _log_surface_ai.info(
                "Surface AI %s: кандидаты готовы за %.1fs",
                target,
                _time.perf_counter() - t0,
            )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
    else:
        for candidate in progress(
            cand_list, f"[5/8] Train/evaluate {target}", total=len(cand_list)
        ):
            display, features_label = _candidate_display(candidate)
            feature_set = _candidate_feature_set(candidate)
            model, _ = _fit_candidate_model(
                candidate,
                feature_set,
                target,
                train,
                calibration,
                config,
                labels,
                label_meta,
                sklearn_n_jobs=-1,
            )
            metrics, details = evaluate_task_model(
                candidate=candidate,
                model=model,
                feature_set=feature_set,
                target=target,
                test=test,
                labels=labels,
                config=config,
            )
            rows.append(
                {
                    "model_key": candidate,
                    "model": display,
                    "target": target,
                    "features": features_label,
                    "accuracy": metrics.get("accuracy", 0.0),
                    "balanced_accuracy": metrics.get("balanced_accuracy", 0.0),
                    "macro_f1": metrics.get("macro_f1", 0.0),
                    "weighted_f1": metrics.get("weighted_f1", 0.0),
                    "macro_f1_safe": metrics.get("macro_f1_safe", 0.0),
                    "macro_f1_safe_rough_aware": metrics.get("macro_f1_safe_rough_aware", 0.0),
                    "recall_bad_surface": metrics.get("recall_bad_surface", 0.0),
                    "recall_unpaved_soft": metrics.get("recall_unpaved_soft", 0.0),
                    "recall_paved_rough": metrics.get("recall_paved_rough", np.nan),
                    "precision_paved_rough": metrics.get("precision_paved_rough", np.nan),
                    "f1_paved_rough": metrics.get("f1_paved_rough", np.nan),
                    "paved_rough_to_paved_good_count": metrics.get(
                        "paved_rough_to_paved_good_count", 0
                    ),
                    "paved_rough_to_paved_good_rate": metrics.get(
                        "paved_rough_to_paved_good_rate", 0.0
                    ),
                    "rough_upgrade_rate_effective": metrics.get(
                        "rough_upgrade_rate_effective", 0.0
                    ),
                    "rough_upgrade_length_m_effective": metrics.get(
                        "rough_upgrade_length_m_effective", 0.0
                    ),
                    "recall_asphalt": metrics.get("recall_asphalt", np.nan),
                    "recall_concrete": metrics.get("recall_concrete", np.nan),
                    "recall_paving_stones": metrics.get("recall_paving_stones", np.nan),
                    "dangerous_upgrade_rate_raw": metrics.get("dangerous_upgrade_rate_raw", 0.0),
                    "dangerous_upgrade_rate_effective": metrics.get(
                        "dangerous_upgrade_rate_effective", 0.0
                    ),
                    "dangerous_upgrade_count_raw": metrics.get("dangerous_upgrade_count_raw", 0),
                    "dangerous_upgrade_count_effective": metrics.get(
                        "dangerous_upgrade_count_effective", 0
                    ),
                    "dangerous_upgrade_length_m_effective": metrics.get(
                        "dangerous_upgrade_length_m_effective", 0.0
                    ),
                }
            )
            models[candidate] = {
                "model": model,
                "feature_set": feature_set,
                "metrics": metrics,
                "details": details,
                "labels": labels,
                "target": target,
            }
    table = pd.DataFrame(rows)
    return models, table


def select_model_for_target(
    models: dict[str, Any], table: pd.DataFrame, config: SurfaceAIConfig, *, target: str
) -> dict[str, Any]:
    if table.empty:
        raise ValueError(f"No models evaluated for {target}")
    if target == "group_direct":
        metric = (
            config.group_selection_metric
            if config.group_selection_metric in table.columns
            else "macro_f1_safe_rough_aware"
        )
        ranked = table.copy()
        selected_by = metric
        if metric == "macro_f1_safe_rough_aware":
            ranked = ranked.sort_values(
                by=[
                    metric,
                    "dangerous_upgrade_rate_effective",
                    "recall_paved_rough",
                    "recall_unpaved_soft",
                ],
                ascending=[False, True, False, False],
            )
        else:
            ranked = ranked.sort_values(
                by=[
                    "dangerous_upgrade_rate_effective",
                    "macro_f1",
                    "recall_bad_surface",
                    "recall_unpaved_soft",
                ],
                ascending=[True, False, False, False],
            )
    else:
        metric = config.selection_metric
        if metric not in table.columns:
            metric = "macro_f1"
        eligible = table[table["recall_bad_surface"] >= float(config.min_bad_surface_recall)]
        ranked = eligible if not eligible.empty else table
        ranked = ranked.sort_values(
            by=[metric, "balanced_accuracy", "recall_bad_surface"],
            ascending=[False, False, False],
        )
        selected_by = metric
    row = ranked.iloc[0]
    key = str(row["model_key"])
    return {
        "model_key": key,
        "model_name": str(row["model"]),
        "selected_by": selected_by,
        "metrics": models[key]["metrics"],
        "labels": models[key]["labels"],
        "target": target,
        "warnings": [
            "WARNING: no group_direct model satisfies paved_rough recall threshold. paved_rough should not be trusted for routing yet."
        ]
        if target == "group_direct"
        and float(table.get("recall_paved_rough", pd.Series([0.0])).max())
        < float(config.min_paved_rough_recall)
        else [],
    }


def reliability_table_from_proba(
    y_true: Sequence[str], proba: pd.DataFrame, *, n_bins: int = 10
) -> tuple[pd.DataFrame, dict[str, float]]:
    pred = proba.idxmax(axis=1).astype(str)
    conf = proba.max(axis=1).astype(float)
    correct = (pd.Series(list(y_true), index=proba.index).astype(str) == pred).astype(float)
    rows = []
    ece = 0.0
    mce = 0.0
    for i in range(n_bins):
        lo = i / n_bins
        hi = (i + 1) / n_bins
        mask = (conf >= lo) & (conf <= hi if i == n_bins - 1 else conf < hi)
        if mask.any():
            avg_conf = float(conf[mask].mean())
            acc = float(correct[mask].mean())
            gap = abs(avg_conf - acc)
            share = float(mask.mean())
            ece += share * gap
            mce = max(mce, gap)
            count = int(mask.sum())
        else:
            avg_conf = acc = gap = share = 0.0
            count = 0
        rows.append(
            {
                "bin_low": lo,
                "bin_high": hi,
                "count": count,
                "share": share,
                "avg_confidence": avg_conf,
                "accuracy": acc,
                "gap": gap,
            }
        )
    brier = float(np.mean((conf - correct) ** 2)) if len(conf) else 0.0
    metrics = {
        "ece_top_label": float(ece),
        "mce_top_label": float(mce),
        "brier_top_label": brier,
        "mean_confidence_correct": float(conf[correct == 1].mean())
        if (correct == 1).any()
        else 0.0,
        "mean_confidence_incorrect": float(conf[correct == 0].mean())
        if (correct == 0).any()
        else 0.0,
    }
    return pd.DataFrame(rows), metrics


def plot_calibration_curve(reliability: pd.DataFrame, path: Path, *, title: str) -> None:
    plt = _import_pyplot()
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.plot([0, 1], [0, 1], color="#666666", linestyle="--", linewidth=1)
    if not reliability.empty:
        ax.plot(reliability["avg_confidence"], reliability["accuracy"], marker="o", color="#1f78b4")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Mean predicted confidence")
    ax.set_ylabel("Empirical accuracy")
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def calibration_artifacts_for_selected(
    dataset: pd.DataFrame,
    selected: dict[str, Any],
    models: dict[str, Any],
    artifacts: SurfaceAIArtifacts,
    config: SurfaceAIConfig,
    *,
    target: str,
) -> dict[str, Any]:
    key = selected["model_key"]
    entry = models[key]
    test = dataset[dataset["surface_ai_split"] == "test"].copy()
    target_col = "surface_group_direct_label" if target == "group_direct" else "surface_train_label"
    if _task_candidate_kind(key) == "always_majority":
        X = pd.DataFrame({"constant": np.ones(len(test))}, index=test.index)
    else:
        X, _, _ = _features_for_model(
            test,
            entry["feature_set"] if entry["feature_set"] != "none" else "osm",
            config=config,
        )
    proba_model = entry.get("calibrated_model") or entry["model"]
    proba = _predict_model_proba(proba_model, X, entry["labels"])
    table, metrics = reliability_table_from_proba(test[target_col].astype(str).tolist(), proba)
    if target == "group_direct":
        table.to_csv(artifacts.reliability_table_group_direct_csv, index=False, encoding="utf-8")
        plot_calibration_curve(
            table, artifacts.calibration_curve_group_direct_png, title="Group direct calibration"
        )
    else:
        table.to_csv(artifacts.reliability_table_concrete_csv, index=False, encoding="utf-8")
        plot_calibration_curve(
            table, artifacts.calibration_curve_concrete_png, title="Concrete compact calibration"
        )
    return metrics


def evaluate_selected_on_split(
    dataset: pd.DataFrame,
    selected: dict[str, Any],
    models: dict[str, Any],
    config: SurfaceAIConfig,
    *,
    target: str,
    split_name: str,
) -> dict[str, Any]:
    subset = dataset[dataset["surface_ai_split"] == split_name].copy()
    if subset.empty:
        return {"split": split_name, "target": target, "edge_count": 0}
    key = selected["model_key"]
    entry = models[key]
    model = entry.get("calibrated_model") or entry["model"]
    metrics, _ = evaluate_task_model(
        candidate=key,
        model=model,
        feature_set=entry["feature_set"],
        target=target,
        test=subset,
        labels=entry["labels"],
        config=config,
    )
    metrics["split"] = split_name
    metrics["edge_count"] = int(len(subset))
    return metrics


def apply_posthoc_calibration_to_selected(
    dataset: pd.DataFrame,
    selected: dict[str, Any],
    models: dict[str, Any],
    config: SurfaceAIConfig,
    *,
    target: str,
) -> bool:
    if not config.calibration_enabled or config.calibration_method == "none":
        selected["calibrated"] = False
        return False
    key = selected["model_key"]
    if _task_candidate_kind(key) != "model":
        selected["calibrated"] = False
        return False
    entry = models[key]
    if (
        isinstance(entry.get("model"), CalibratedClassifierCV)
        or entry.get("calibrated_model") is not None
    ):
        selected["calibrated"] = True
        selected["calibration_method"] = config.calibration_method
        return True

    train = dataset[dataset["surface_ai_split"] == "train"].copy()
    calibration = dataset[dataset["surface_ai_split"] == "calibration"].copy()
    if calibration.empty:
        selected["calibrated"] = False
        return False
    target_col = "surface_group_direct_label" if target == "group_direct" else "surface_train_label"
    y_train = train[target_col].astype(str)
    y_cal = calibration[target_col].astype(str)
    labels = set(entry.get("labels") or [])
    if y_cal.nunique() < 2 or len(y_cal) < int(config.calibration_min_class_count):
        selected["calibrated"] = False
        return False
    if labels and not labels.issubset(set(y_cal.unique())):
        selected["calibrated"] = False
        return False

    feature_set = entry["feature_set"]
    base_key = key.replace("_calibrated", "")
    base = _build_pipeline(base_key, feature_set, config, fit_frame=train)
    X_train, _, _ = _features_for_model(train, feature_set, config=config)
    X_cal, _, _ = _features_for_model(calibration, feature_set, config=config)
    try:
        base.fit(X_train, y_train)
        calibrated = CalibratedClassifierCV(
            estimator=base,
            method=config.calibration_method,
            cv="prefit",
        )
        calibrated.fit(X_cal, y_cal)
    except Exception:
        selected["calibrated"] = False
        return False
    entry["calibrated_model"] = calibrated
    entry["calibrated"] = True
    selected["calibrated"] = True
    selected["calibration_method"] = config.calibration_method
    return True


def _predict_model_proba(model: Any, X: pd.DataFrame, classes: Sequence[str]) -> pd.DataFrame:
    classes = list(classes)
    if hasattr(model, "predict_proba"):
        raw = model.predict_proba(X)
        model_classes = [str(c) for c in getattr(model, "classes_", classes)]
        out = pd.DataFrame(0.0, index=X.index, columns=classes)
        for i, cls in enumerate(model_classes):
            if cls in out.columns:
                out[cls] = raw[:, i]
        return out
    pred = [str(x) for x in model.predict(X)]
    out = pd.DataFrame(0.0, index=X.index, columns=classes)
    for i, cls in enumerate(pred):
        if cls in out.columns:
            out.loc[X.index[i], cls] = 1.0
    return out


def _has_features(
    row: pd.Series, feature_set: str, *, config: SurfaceAIConfig | None = None
) -> bool:
    _, cat_cols, num_cols = _features_for_model(pd.DataFrame(), feature_set, config=config)
    for col in cat_cols:
        if _norm_feature(row.get(col)):
            return True
    for col in num_cols:
        v = pd.to_numeric(row.get(col), errors="coerce")
        if pd.notna(v):
            return True
    return False


def apply_safety_policy(
    *,
    is_surface_known: bool,
    true_surface: str,
    pred_label: str,
    confidence: float,
    margin: float,
    has_features: bool,
    config: SurfaceAIConfig,
) -> tuple[str, str, str]:
    pred_surface = train_label_to_surface(pred_label)
    pred_group = train_label_to_group(pred_label)
    if is_surface_known and true_surface != "unknown":
        return true_surface, surface_to_group(true_surface), "osm"
    if not has_features:
        return "unknown", "unknown", "default_no_features"
    if not config.enable_safety_policy:
        if confidence >= config.min_confidence:
            return pred_surface, pred_group, "ml"
        return "unknown", "unknown", "default_low_confidence"
    if margin < float(config.min_margin):
        return "unknown", "unknown", "ml_ambiguous"
    if confidence < float(config.min_confidence):
        return "unknown", "unknown", "default_low_confidence"
    if pred_surface in BAD_SURFACES and confidence >= float(config.bad_surface_min_confidence):
        return pred_surface, pred_group, "ml"
    if pred_group == "paved_good" and confidence < float(config.paved_good_min_confidence):
        return "paved", "paved_rough", "ml"
    if pred_surface == "rare_other":
        return "unknown", pred_group, "ml"
    return pred_surface, pred_group, "ml"


def _predict_entry_proba_for_all(
    dataset: pd.DataFrame,
    entry: dict[str, Any],
    model_key: str,
    config: SurfaceAIConfig,
    *,
    calibrated: bool = False,
) -> pd.DataFrame:
    if _task_candidate_kind(model_key) == "always_majority":
        X = pd.DataFrame({"constant": np.ones(len(dataset))}, index=dataset.index)
    else:
        X, _, _ = _features_for_model(
            dataset,
            entry["feature_set"] if entry["feature_set"] != "none" else "osm",
            config=config,
        )
    model = (
        entry.get("calibrated_model")
        if calibrated and entry.get("calibrated_model") is not None
        else entry["model"]
    )
    return _predict_model_proba(model, X, entry["labels"])


def confidence_bucket(conf: float, config: SurfaceAIConfig) -> str:
    if conf >= float(config.conf_high):
        return "high"
    if conf >= float(config.conf_medium):
        return "medium"
    return "low"


def predict_all_edges(
    dataset: pd.DataFrame,
    concrete_models: dict[str, Any],
    group_models: dict[str, Any],
    config: SurfaceAIConfig,
    *,
    progress: ProgressFactory = no_progress,
) -> pd.DataFrame:
    concrete_selected = concrete_models["_selected"]
    concrete_key = concrete_selected["model_key"]
    concrete_entry = concrete_models[concrete_key]
    group_selected = group_models["_selected"]
    group_key = group_selected["model_key"]
    group_entry = group_models[group_key]

    for _ in progress(range(1), "[6/8] Predict surfaces/groups", total=1):
        concrete_proba_raw = _predict_entry_proba_for_all(
            dataset, concrete_entry, concrete_key, config
        )
        concrete_proba = _predict_entry_proba_for_all(
            dataset, concrete_entry, concrete_key, config, calibrated=True
        )
        group_proba_raw = _predict_entry_proba_for_all(dataset, group_entry, group_key, config)
        group_proba = _predict_entry_proba_for_all(
            dataset, group_entry, group_key, config, calibrated=True
        )

    concrete_pred_raw, concrete_conf_raw, _, _, concrete_margin_raw = _proba_top_fields(
        concrete_proba_raw
    )
    concrete_pred, concrete_conf, concrete_top2, concrete_top2_conf, concrete_margin = (
        _proba_top_fields(concrete_proba)
    )
    group_pred_raw, group_conf_raw, _, _, group_margin_raw = _tuned_group_top_fields(
        group_proba_raw, config, candidate=group_key
    )
    group_pred, group_conf, group_top2, group_top2_conf, group_margin = _tuned_group_top_fields(
        group_proba, config, candidate=group_key
    )

    out = dataset.copy()
    out["surface_pred_label"] = concrete_pred
    out["surface_pred_label_raw"] = concrete_pred_raw
    out["surface_pred_concrete_compact"] = [train_label_to_surface(x) for x in concrete_pred]
    out["surface_pred_concrete"] = out["surface_pred_concrete_compact"]
    out["surface_pred"] = out["surface_pred_concrete_compact"]
    out["surface_pred_group_derived_from_concrete"] = [
        train_label_to_group(x) for x in concrete_pred
    ]
    out["surface_pred_group_direct"] = group_pred
    out["surface_pred_group_direct_raw"] = group_pred_raw
    out["surface_pred_group"] = out["surface_pred_group_direct"]
    out["surface_group_pred"] = out["surface_pred_group_direct"]
    out["surface_pred_confidence_raw"] = concrete_conf_raw
    out["surface_pred_confidence_calibrated"] = concrete_conf
    out["surface_pred_confidence"] = group_conf
    out["surface_pred_top2"] = [train_label_to_surface(x) for x in concrete_top2]
    out["surface_pred_top2_confidence"] = concrete_top2_conf
    out["surface_pred_margin_raw"] = concrete_margin_raw
    out["surface_pred_margin_calibrated"] = concrete_margin
    out["surface_pred_margin"] = group_margin
    out["surface_pred_group_direct_confidence_raw"] = group_conf_raw
    out["surface_pred_group_direct_confidence_calibrated"] = group_conf
    out["surface_pred_group_direct_margin_raw"] = group_margin_raw
    out["surface_pred_group_direct_margin_calibrated"] = group_margin

    for surface in sorted(
        set(concrete_proba.columns) | set(REQUIRED_PROBA_SURFACES) | set(CONCRETE_COMPACT_LABELS)
    ):
        col = proba_column_for_surface(train_label_to_surface(surface))
        if col not in out.columns:
            out[col] = 0.0
    for label in concrete_proba.columns:
        surface = train_label_to_surface(str(label))
        col = proba_column_for_surface(surface)
        out[col] = out[col].to_numpy(dtype=float) + concrete_proba[label].to_numpy(dtype=float)
    if "proba_unknown" not in out.columns:
        out["proba_unknown"] = 0.0

    raw_eff: list[str] = []
    cal_eff: list[str] = []
    sources: list[str] = []
    concrete_effective: list[str] = []
    for idx, row in out.iterrows():
        known = bool(row.get("is_surface_known"))
        true_group = normalize_group_target(row.get("surface_true_group"), config.group_target_mode)
        pred_group = str(row.get("surface_pred_group_direct") or "unknown")
        conf = float(row.get("surface_pred_group_direct_confidence_calibrated") or 0.0)
        margin = float(row.get("surface_pred_group_direct_margin_calibrated") or 0.0)
        has_features = _has_features(row, group_entry["feature_set"], config=config)
        if known:
            eff_group = true_group
            source = "osm"
        elif not has_features:
            eff_group = "unknown"
            source = "default_no_features"
        elif margin < float(config.min_margin):
            eff_group = "unknown"
            source = "ml_ambiguous"
        elif conf < float(config.min_confidence):
            eff_group = "unknown"
            source = "default_low_confidence"
        else:
            eff_group = _effective_group_for_metrics(pred_group, conf, margin, config)
            source = "ml"
        raw_pred_group = str(row.get("surface_pred_group_direct_raw") or "unknown")
        raw_eff.append(raw_pred_group if not known else true_group)
        cal_eff.append(eff_group)
        sources.append(source)
        concrete_effective.append(
            str(
                row.get("surface_true_concrete")
                if known
                else row.get("surface_pred_concrete_compact")
            )
        )
    out["surface_source"] = sources
    out["surface_effective_for_routing"] = concrete_effective
    out["surface_effective_group_for_routing_raw"] = raw_eff
    out["surface_effective_group_for_routing_calibrated"] = cal_eff
    out["surface_effective_group_for_routing"] = cal_eff
    true_direct = out["surface_group_direct_label"].astype(str)
    out["dangerous_upgrade_raw"] = [
        is_dangerous_upgrade(t, p)
        for t, p in zip(true_direct, out["surface_effective_group_for_routing_raw"].astype(str))
    ]
    out["dangerous_upgrade_effective"] = [
        is_dangerous_upgrade(t, p)
        for t, p in zip(
            true_direct, out["surface_effective_group_for_routing_calibrated"].astype(str)
        )
    ]
    out["dangerous_upgrade_severity"] = [
        DANGEROUS_UPGRADE_SEVERITY.get(str(t), 0.0) if bool(flag) else 0.0
        for t, flag in zip(true_direct, out["dangerous_upgrade_effective"])
    ]
    out["confidence_bucket_raw"] = [
        confidence_bucket(float(x), config) for x in out["surface_pred_group_direct_confidence_raw"]
    ]
    out["confidence_bucket_calibrated"] = [
        confidence_bucket(float(x), config)
        for x in out["surface_pred_group_direct_confidence_calibrated"]
    ]
    out["tile_id_samples"] = ""
    out["tile_green_mask_available"] = False
    out["edge_green_cache_available"] = False
    return out


def dataset_summary(dataset: pd.DataFrame) -> dict[str, Any]:
    total = int(len(dataset))
    known = int(dataset["is_surface_known"].sum()) if total else 0
    return {
        "total_edges": total,
        "known_surface_edges": known,
        "unknown_surface_edges": total - known,
        "unknown_share": float((total - known) / total) if total else 0.0,
        "train_edges_total": int(
            dataset.get("inside_train_area", pd.Series(False, index=dataset.index))
            .astype(bool)
            .sum()
        ),
        "train_edges_with_tile_features": int(
            (
                dataset.get("inside_train_area", pd.Series(False, index=dataset.index)).astype(bool)
                & dataset.get("has_tile_features", pd.Series(False, index=dataset.index)).astype(
                    bool
                )
            ).sum()
        ),
        "train_known_surface_edges": int(
            dataset.get("is_train_candidate", pd.Series(False, index=dataset.index))
            .astype(bool)
            .sum()
        ),
        "train_known_surface_edges_with_tile_features": int(
            (
                dataset.get("inside_train_area", pd.Series(False, index=dataset.index)).astype(bool)
                & dataset["is_surface_known"].astype(bool)
                & dataset.get("has_tile_features", pd.Series(False, index=dataset.index)).astype(
                    bool
                )
            ).sum()
        ),
        "train_known_surface_edges_osm_fallback": int(
            dataset.get("is_train_candidate_osm_fallback", pd.Series(False, index=dataset.index))
            .astype(bool)
            .sum()
        ),
        "train_unknown_surface_edges": int(
            (
                dataset.get("inside_train_area", pd.Series(False, index=dataset.index)).astype(bool)
                & ~dataset["is_surface_known"].astype(bool)
            ).sum()
        ),
        "predict_edges_inside_polygon": int(
            dataset.get("inside_predict_area", pd.Series(False, index=dataset.index))
            .astype(bool)
            .sum()
        ),
        "predict_unknown_surface_edges_inside_polygon": int(
            dataset.get("is_prediction_candidate", pd.Series(False, index=dataset.index))
            .astype(bool)
            .sum()
        ),
        "surface_norm_distribution": dataset["surface_true_concrete"]
        .value_counts(dropna=False)
        .to_dict(),
        "surface_train_label_distribution": dataset.loc[
            dataset["is_surface_known"], "surface_train_label"
        ]
        .value_counts(dropna=False)
        .to_dict(),
        "surface_group_distribution": dataset["surface_true_group"]
        .value_counts(dropna=False)
        .to_dict(),
        "highway_distribution": dataset["highway"].value_counts(dropna=False).head(50).to_dict(),
    }


def experiment_output_dir(
    settings: Settings, config: SurfaceAIConfig, output_dir: Path | None
) -> Path:
    if output_dir is not None:
        out = Path(output_dir)
    else:
        stamp = datetime.now().strftime("surface_ai_%Y%m%d_%H%M%S")
        raw = (config.out_dir or "").strip()
        if raw:
            base = Path(raw)
            if not base.is_absolute():
                base = Path.cwd() / base
            out = base.parent / stamp if base.name == "surface_ai" else base / stamp
        else:
            out = Path(settings.base_dir) / "experiments" / stamp
    out.mkdir(parents=True, exist_ok=True)
    return out


def artifact_paths(output_dir: Path) -> SurfaceAIArtifacts:
    return SurfaceAIArtifacts(
        output_dir=output_dir,
        dataset_csv=output_dir / "surface_ai_dataset.csv",
        predictions_csv=output_dir / "surface_ai_predictions.csv",
        predictions_geojson=output_dir / "surface_ai_predictions.geojson",
        baseline_csv=output_dir / "02_surface_ai_baseline_table.csv",
        baseline_xlsx=output_dir / "01_surface_ai_results.xlsx",
        baseline_png=output_dir / "09_surface_ai_baseline_table.png",
        metrics_json=output_dir / "surface_ai_metrics.json",
        model_joblib=output_dir / "surface_ai_model.joblib",
        model_card_json=output_dir / "surface_ai_model_card.json",
        report_txt=output_dir / "surface_ai_report.txt",
        surface_map_png=output_dir / "10_surface_ai_surface_map.png",
        confidence_map_png=output_dir / "12_surface_ai_confidence_map.png",
        unknown_predictions_map_png=output_dir / "11_surface_ai_unknown_risk_map.png",
        errors_map_png=output_dir / "20_surface_ai_errors_map.png",
        confusion_matrix_concrete_png=output_dir / "surface_ai_confusion_matrix_concrete.png",
        confusion_matrix_group_png=output_dir / "surface_ai_confusion_matrix_group.png",
        feature_importance_png=output_dir / "16_surface_ai_feature_importance.png",
        confusion_matrix_concrete_compact_png=output_dir
        / "14_surface_ai_confusion_matrix_concrete_compact.png",
        confusion_matrix_concrete_legacy_png=output_dir
        / "surface_ai_confusion_matrix_concrete_legacy.png",
        confusion_matrix_group_direct_png=output_dir
        / "15_surface_ai_confusion_matrix_group_direct.png",
        group_direct_model_joblib=output_dir / "surface_ai_group_direct_model.joblib",
        group_direct_model_card_json=output_dir / "surface_ai_group_direct_model_card.json",
        group_direct_metrics_json=output_dir / "surface_ai_group_direct_metrics.json",
        calibration_curve_concrete_png=output_dir / "surface_ai_calibration_curve_concrete.png",
        calibration_curve_group_direct_png=output_dir
        / "17_surface_ai_calibration_curve_group_direct.png",
        reliability_table_concrete_csv=output_dir / "surface_ai_reliability_table_concrete.csv",
        reliability_table_group_direct_csv=output_dir
        / "07_surface_ai_reliability_table_group_direct.csv",
        dangerous_errors_map_raw_png=output_dir / "surface_ai_dangerous_errors_map_raw.png",
        dangerous_errors_map_effective_png=output_dir
        / "surface_ai_dangerous_errors_map_effective.png",
        dangerous_errors_csv=output_dir / "surface_ai_dangerous_errors.csv",
        spatial_prior_ablation_txt=output_dir / "surface_ai_spatial_prior_ablation.txt",
        tile_usage_csv=output_dir / "04_surface_ai_tile_usage.csv",
        tile_usage_map_png=output_dir / "13_surface_ai_tile_usage_map.png",
        neighbor_feature_importance_png=output_dir / "surface_ai_neighbor_feature_importance.png",
        train_polygon_geojson=output_dir / "surface_ai_train_polygon.geojson",
        predict_polygon_geojson=output_dir / "surface_ai_predict_polygon.geojson",
        tile_coverage_polygon_geojson=output_dir / "surface_ai_tile_coverage_polygon.geojson",
        train_edges_geojson=output_dir / "surface_ai_train_edges.geojson",
        predict_edges_geojson=output_dir / "surface_ai_predict_edges.geojson",
        dataset_all_tile_edges_csv=output_dir / "surface_ai_dataset_all_tile_edges.csv",
        predictions_inside_polygon_csv=output_dir / "03_surface_ai_predictions_inside_polygon.csv",
        predictions_inside_polygon_geojson=output_dir
        / "surface_ai_predictions_inside_polygon.geojson",
        tile_usage_map_train_png=output_dir / "surface_ai_tile_usage_map_train.png",
        tile_usage_map_predict_png=output_dir / "surface_ai_tile_usage_map_predict.png",
        train_vs_predict_report_txt=output_dir / "surface_ai_train_vs_predict_report.txt",
        dangerous_errors_global_test_csv=output_dir
        / "05_surface_ai_dangerous_errors_global_test.csv",
        dangerous_errors_predict_holdout_csv=output_dir
        / "06_surface_ai_dangerous_errors_predict_holdout.csv",
        dangerous_errors_global_test_raw_png=output_dir
        / "surface_ai_dangerous_errors_global_test_raw.png",
        dangerous_errors_global_test_effective_png=output_dir
        / "18_surface_ai_dangerous_errors_global_test_effective.png",
        dangerous_errors_predict_holdout_raw_png=output_dir
        / "surface_ai_dangerous_errors_predict_holdout_raw.png",
        dangerous_errors_predict_holdout_effective_png=output_dir
        / "19_surface_ai_dangerous_errors_predict_holdout_effective.png",
        unknown_risk_map_png=output_dir / "11_surface_ai_unknown_risk_map.png",
        run_summary_csv=output_dir / "08_surface_ai_run_summary.csv",
        runtime_predictions_csv=output_dir / "runtime_predictions.csv",
    )


def write_runtime_router_predictions_from_experiment(
    predictions_inside: pd.DataFrame,
    predict_edges: gpd.GeoDataFrame,
    *,
    settings: Settings,
    group_selected: dict[str, Any],
    artifacts: SurfaceAIArtifacts,
    precache_polygon: Any,
) -> None:
    """Пишет CSV в формате ``SurfacePredictionStore`` (каталог эксперимента + cache по Settings)."""

    from .surface_prediction_store import (
        SurfacePredictionStore,
        _first_osm_scalar,
        compute_runtime_routing_graph_hash,
        write_runtime_predictions_csv,
    )
    from .surface_prediction_store import (
        _norm_group as _runtime_norm_group,
    )
    from .surface_prediction_store import (
        _rounded_geometry_hash as _runtime_geom_hash,
    )
    from .surface_resolve import ml_group_to_profile_surface

    if predictions_inside.empty:
        _log_surface_ai.warning("runtime_predictions: пустой predictions_inside — пропуск записи")
        return

    pe = predict_edges.copy()
    if "edge_id" not in pe.columns and all(c in pe.columns for c in ("u", "v", "key")):
        pe["edge_id"] = (
            pd.to_numeric(pe["u"], errors="coerce").fillna(-1).astype(int).astype(str)
            + "_"
            + pd.to_numeric(pe["v"], errors="coerce").fillna(-1).astype(int).astype(str)
            + "_"
            + pd.to_numeric(pe["key"], errors="coerce").fillna(0).astype(int).astype(str)
        )
    if "edge_id" not in pe.columns:
        _log_surface_ai.warning("runtime_predictions: у predict_edges нет edge_id — пропуск")
        return

    pe_geo = pe[["edge_id", "geometry"]].drop_duplicates(subset=["edge_id"], keep="first")
    merged = predictions_inside.merge(pe_geo, on="edge_id", how="left")

    try:
        if precache_polygon is not None:
            area_fp = hashlib.sha256(
                getattr(precache_polygon, "wkt", str(precache_polygon)).encode("utf-8")
            ).hexdigest()[:24]
        else:
            area_fp = ""
    except Exception:
        area_fp = ""

    graph_hash = compute_runtime_routing_graph_hash(pe)
    ts = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    gkey = str(group_selected.get("model_key") or "")

    rows: list[dict[str, Any]] = []
    for _, row in merged.iterrows():
        geom = row.get("geometry")
        if geom is not None and not bool(getattr(geom, "is_empty", False)):
            gh_r = _runtime_geom_hash(geom)
        else:
            gh_r = ""

        u, v, k = row.get("u"), row.get("v"), row.get("key", 0)
        try:
            und = SurfacePredictionStore._undirected_key(
                int(float(u)), int(float(v)), int(float(k))
            )
        except Exception:
            und = ""
        try:
            uvkey = f"{int(float(u))}_{int(float(v))}_{int(float(k))}"
        except Exception:
            uvkey = str(row.get("edge_id") or "")

        raw_grp = str(
            row.get("surface_pred_group") or row.get("surface_pred_group_direct") or "unknown"
        )
        grp = _runtime_norm_group(raw_grp)

        ow = row.get("osmid")
        if ow is None:
            ow = row.get("osm_way_id")
        try:
            osm_scalar = _first_osm_scalar(ow)
            osm_way_id = int(float(str(osm_scalar).split(".")[0])) if osm_scalar is not None else ""
        except Exception:
            osm_way_id = ""

        dangerous = bool(row.get("dangerous_upgrade_effective", False))
        safe_flag = "false" if dangerous else "true"
        eff_ml = ml_group_to_profile_surface(grp)

        rows.append(
            {
                "edge_id": str(row["edge_id"]).strip(),
                "uvkey": uvkey,
                "osm_way_id": osm_way_id,
                "geometry_hash_rounded": gh_r,
                "undirected_edge_key": und,
                "surface_pred_group": grp,
                "surface_pred_concrete": str(row.get("surface_pred_concrete") or "")
                or str(row.get("surface_pred_concrete_compact") or ""),
                "surface_pred_confidence": float(row.get("surface_pred_confidence") or 0.0),
                "surface_pred_margin": float(row.get("surface_pred_margin") or 0.0),
                "surface_effective_ml": eff_ml,
                "surface_ml_safe": safe_flag,
                "surface_ml_reject_reason": "",
                "model_key": gkey,
                "model_target": "group_direct",
                "artifact_created_at": ts,
                "artifact_id": artifacts.output_dir.name,
                "area_fingerprint": area_fp,
                "graph_fingerprint": graph_hash,
            }
        )

    rt_df = pd.DataFrame(rows)
    write_runtime_predictions_csv(rt_df, artifacts.runtime_predictions_csv)
    cache_path = settings.surface_ai_runtime_predictions_resolved_path
    write_runtime_predictions_csv(rt_df, cache_path)
    _log_surface_ai.info(
        "runtime_predictions: записано %d строк в %s и %s",
        len(rt_df),
        artifacts.runtime_predictions_csv,
        cache_path,
    )


def write_dataset_csv(dataset: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    dataset.to_csv(path, index=False, encoding="utf-8")


def is_compact_output(config: SurfaceAIConfig) -> bool:
    mode = str(config.output_mode or "").lower()
    if mode in {"compact", "full"}:
        return mode == "compact"
    return bool(config.compact_output)


def save_heavy_artifacts(config: SurfaceAIConfig) -> bool:
    mode = str(config.output_mode or "").lower()
    if mode == "full":
        return True
    if mode == "compact":
        return False
    return bool(config.save_heavy_artifacts)


def prediction_columns(predictions: pd.DataFrame) -> list[str]:
    required = [
        "edge_id",
        "u",
        "v",
        "key",
        "length_m",
        "highway",
        "surface_osm_raw",
        "surface_osm_norm",
        "surface_true_concrete",
        "surface_true_group",
        "surface_true",
        "inside_train_area",
        "inside_predict_area",
        "has_tile_features",
        "is_train_candidate",
        "is_prediction_candidate",
        "is_surface_known",
        "surface_train_label",
        "surface_pred_concrete",
        "surface_pred_concrete_compact",
        "surface_pred_group_derived_from_concrete",
        "surface_pred_group_direct",
        "surface_pred_group_direct_confidence_raw",
        "surface_pred_group_direct_confidence_calibrated",
        "surface_pred_group",
        "surface_group_pred",
        "surface_pred_confidence_raw",
        "surface_pred_confidence_calibrated",
        "surface_pred_confidence",
        "surface_pred_top2",
        "surface_pred_top2_confidence",
        "surface_pred_margin_raw",
        "surface_pred_margin_calibrated",
        "surface_pred_margin",
        "surface_source",
    ]
    required.extend(proba_column_for_surface(s) for s in REQUIRED_PROBA_SURFACES)
    required.extend(
        [
            "surface_is_rare_class",
            "surface_effective_for_routing",
            "surface_effective_group_for_routing_raw",
            "surface_effective_group_for_routing_calibrated",
            "surface_effective_group_for_routing",
            "dangerous_upgrade_raw",
            "dangerous_upgrade_effective",
            "dangerous_upgrade_severity",
            "confidence_bucket_raw",
            "confidence_bucket_calibrated",
            "neighbor_1hop_count",
            "neighbor_2hop_count",
            "neighbor_1hop_known_surface_share",
            "neighbor_1hop_paved_good_share",
            "neighbor_1hop_paved_rough_share",
            "neighbor_1hop_unpaved_soft_share",
            "neighbor_2hop_paved_good_share",
            "neighbor_2hop_paved_rough_share",
            "neighbor_2hop_unpaved_soft_share",
            "tile_id_samples",
            "tile_samples_count",
            "tile_missing_share",
            "tile_green_mask_available",
            "edge_green_cache_available",
            "sampled_pixel_count",
            "rgb_mean_r",
            "rgb_mean_g",
            "rgb_mean_b",
            "brightness_mean",
            "saturation_mean",
            "texture_std",
            "geometry_wkt",
        ]
    )
    cols = [c for c in required if c in predictions.columns]
    extra = [c for c in predictions.columns if c not in cols and c != "geometry"]
    return cols + extra


def write_predictions_csv(predictions: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    predictions[prediction_columns(predictions)].to_csv(path, index=False, encoding="utf-8")


def write_predictions_geojson(
    predictions: pd.DataFrame, edges_gdf: gpd.GeoDataFrame, path: Path
) -> None:
    base = edges_gdf[["edge_id", "geometry"]].copy()
    prediction_ids = (
        set(predictions["edge_id"].astype(str)) if "edge_id" in predictions.columns else set()
    )
    if predictions.empty:
        base = base.iloc[0:0]
    elif prediction_ids:
        base = base[base["edge_id"].astype(str).isin(prediction_ids)]
    gdf = base.merge(
        predictions.drop(columns=["geometry"], errors="ignore"), on="edge_id", how="left"
    )
    gdf = gpd.GeoDataFrame(gdf, geometry="geometry", crs="EPSG:4326")
    path.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(path, driver="GeoJSON")


def write_edges_geojson(edges_gdf: gpd.GeoDataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    gdf = edges_gdf.copy()
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326", allow_override=True)
    else:
        gdf = gdf.to_crs("EPSG:4326")
    gdf.to_file(path, driver="GeoJSON")


def write_baseline_tables(baseline_table: pd.DataFrame, artifacts: SurfaceAIArtifacts) -> None:
    baseline_table.to_csv(artifacts.baseline_csv, index=False, encoding="utf-8")
    plot_baseline_table_png(baseline_table, artifacts.baseline_png)


def _flat_dict_frame(data: dict[str, Any]) -> pd.DataFrame:
    rows = []
    for key, value in (data or {}).items():
        if isinstance(value, (dict, list, tuple)):
            value = json.dumps(_json_safe(value), ensure_ascii=False)
        rows.append({"key": key, "value": value})
    return pd.DataFrame(rows)


def write_results_workbook(
    artifacts: SurfaceAIArtifacts,
    *,
    baseline_table: pd.DataFrame,
    summary: dict[str, Any],
    area_meta: dict[str, Any],
    tile_coverage: dict[str, Any],
    selected: dict[str, Any],
    group_selected: dict[str, Any],
    holdout_metrics: dict[str, Any],
    calibration_metrics: dict[str, Any],
    dangerous_metrics: dict[str, Any],
    predictions_inside: pd.DataFrame | None = None,
    dangerous_global: pd.DataFrame | None = None,
    dangerous_holdout: pd.DataFrame | None = None,
    run_config: dict[str, Any] | None = None,
    artifact_manifest: pd.DataFrame | None = None,
) -> None:
    with pd.ExcelWriter(artifacts.baseline_xlsx, engine="openpyxl") as writer:
        _flat_dict_frame(summary).to_excel(writer, sheet_name="summary", index=False)
        baseline_table.to_excel(writer, sheet_name="baseline", index=False)
        _flat_dict_frame({"selected_model": selected}).to_excel(
            writer, sheet_name="selected_model", index=False
        )
        _flat_dict_frame({"group_direct": group_selected}).to_excel(
            writer, sheet_name="group_direct", index=False
        )
        _flat_dict_frame({"concrete_compact": selected}).to_excel(
            writer, sheet_name="concrete_compact", index=False
        )
        if predictions_inside is not None:
            predictions_inside.head(5000).to_excel(
                writer, sheet_name="predict_inside_polygon", index=False
            )
        _flat_dict_frame(tile_coverage).to_excel(
            writer, sheet_name="tile_usage_summary", index=False
        )
        danger_summary = dict(dangerous_metrics)
        danger_summary["global_test_rows"] = (
            int(len(dangerous_global)) if dangerous_global is not None else 0
        )
        danger_summary["predict_holdout_rows"] = (
            int(len(dangerous_holdout)) if dangerous_holdout is not None else 0
        )
        _flat_dict_frame(danger_summary).to_excel(
            writer, sheet_name="dangerous_errors_summary", index=False
        )
        _flat_dict_frame(
            calibration_metrics.get("group_direct", calibration_metrics)
            if isinstance(calibration_metrics, dict)
            else {}
        ).to_excel(writer, sheet_name="calibration_group_direct", index=False)
        _flat_dict_frame(holdout_metrics).to_excel(writer, sheet_name="holdout_checks", index=False)
        _flat_dict_frame(run_config or {}).to_excel(writer, sheet_name="run_config", index=False)
        if artifact_manifest is not None:
            artifact_manifest.to_excel(writer, sheet_name="artifact_manifest", index=False)
        # Compatibility/detail sheets.
        baseline_table[baseline_table["target"].astype(str).str.contains("concrete")].to_excel(
            writer, sheet_name="models_concrete", index=False
        )
        baseline_table[baseline_table["target"].astype(str).str.contains("group")].to_excel(
            writer, sheet_name="models_group", index=False
        )
        _flat_dict_frame(area_meta).to_excel(writer, sheet_name="areas", index=False)


def plot_baseline_table_png(baseline_table: pd.DataFrame, path: Path) -> None:
    plt = _import_pyplot()
    cols = [
        "model",
        "target",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "weighted_f1",
        "recall_bad_surface",
        "recall_unpaved_soft",
        "dangerous_upgrade_rate_effective",
        "dangerous_upgrade_count_effective",
    ]
    df = baseline_table[[c for c in cols if c in baseline_table.columns]].copy()
    for col in cols[2:]:
        df[col] = df[col].map(lambda x: "" if pd.isna(x) else f"{float(x):.3f}")
    fig_h = max(4.0, 0.42 * len(df) + 1.0)
    fig, ax = plt.subplots(figsize=(15, fig_h))
    ax.axis("off")
    tbl = ax.table(cellText=df.values, colLabels=df.columns, loc="center", cellLoc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8)
    tbl.scale(1.0, 1.35)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def compact_experiment_outputs(artifacts: SurfaceAIArtifacts, config: SurfaceAIConfig) -> None:
    if not config.compact_output:
        return
    ordered_keep = [
        artifacts.dataset_all_tile_edges_csv.name,
        artifacts.predictions_inside_polygon_csv.name,
        artifacts.predictions_inside_polygon_geojson.name,
        artifacts.baseline_xlsx.name,
        artifacts.metrics_json.name,
        artifacts.model_joblib.name,
        artifacts.group_direct_model_joblib.name,
        artifacts.model_card_json.name,
        artifacts.report_txt.name,
        artifacts.surface_map_png.name,
        artifacts.confidence_map_png.name,
        artifacts.unknown_predictions_map_png.name,
        artifacts.errors_map_png.name,
        artifacts.dangerous_errors_map_raw_png.name,
        artifacts.dangerous_errors_map_effective_png.name,
        artifacts.tile_usage_csv.name,
        artifacts.tile_usage_map_png.name,
        artifacts.train_polygon_geojson.name,
        artifacts.predict_polygon_geojson.name,
        artifacts.tile_coverage_polygon_geojson.name,
    ]
    # If the limit is reduced later, prefer keeping machine-readable core files.
    if int(config.max_output_files) > 0 and len(ordered_keep) > int(config.max_output_files):
        keep = set(ordered_keep[: int(config.max_output_files)])
    else:
        keep = set(ordered_keep)
    for path in artifacts.output_dir.iterdir():
        if path.is_file() and path.name not in keep:
            try:
                path.unlink()
            except OSError:
                pass


def artifact_manifest(output_dir: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(output_dir.iterdir(), key=lambda p: p.name):
        if not path.is_file():
            continue
        rows.append(
            {
                "filename": path.name,
                "type": path.suffix.lower().lstrip("."),
                "description": "Surface AI experiment artifact",
                "created": datetime.fromtimestamp(path.stat().st_mtime).isoformat(
                    timespec="seconds"
                ),
                "rows_if_table": "",
            }
        )
    return pd.DataFrame(rows)


def expected_compact_manifest(artifacts: SurfaceAIArtifacts) -> pd.DataFrame:
    files = [
        (
            artifacts.baseline_xlsx,
            "xlsx",
            "Main workbook with summary, metrics, configuration, and manifest",
        ),
        (artifacts.baseline_csv, "csv", "Model baseline table"),
        (
            artifacts.predictions_inside_polygon_csv,
            "csv",
            "Unknown surface predictions inside predict polygon",
        ),
        (artifacts.tile_usage_csv, "csv", "Tile usage by train/predict areas"),
        (
            artifacts.dangerous_errors_global_test_csv,
            "csv",
            "Dangerous errors on global known test split",
        ),
        (
            artifacts.dangerous_errors_predict_holdout_csv,
            "csv",
            "Dangerous errors on predict-polygon holdout split",
        ),
        (artifacts.reliability_table_group_direct_csv, "csv", "Group-direct reliability table"),
        (artifacts.run_summary_csv, "csv", "One-row run and safety summary"),
        (artifacts.baseline_png, "png", "Baseline model table image"),
        (artifacts.surface_map_png, "png", "Predicted surface map"),
        (artifacts.unknown_risk_map_png, "png", "Unknown prediction risk map"),
        (artifacts.confidence_map_png, "png", "Prediction confidence map"),
        (artifacts.tile_usage_map_png, "png", "Tile usage map"),
        (
            artifacts.confusion_matrix_concrete_compact_png,
            "png",
            "Concrete compact confusion matrix",
        ),
        (artifacts.confusion_matrix_group_direct_png, "png", "Group-direct confusion matrix"),
        (artifacts.feature_importance_png, "png", "Feature importance"),
        (artifacts.calibration_curve_group_direct_png, "png", "Group-direct calibration curve"),
        (
            artifacts.dangerous_errors_global_test_effective_png,
            "png",
            "Effective dangerous upgrades on global test",
        ),
        (
            artifacts.dangerous_errors_predict_holdout_effective_png,
            "png",
            "Effective dangerous upgrades on predict holdout",
        ),
        (artifacts.errors_map_png, "png", "Known test error map"),
    ]
    return pd.DataFrame(
        [
            {
                "filename": p.name,
                "type": typ,
                "description": desc,
                "created": "",
                "rows_if_table": "",
            }
            for p, typ, desc in files
        ]
    )


def current_git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=Path(__file__).resolve().parents[1],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


def polygon_hash(polygon: Any) -> str:
    return _short_hash(getattr(polygon, "wkt", str(polygon)))


def graph_fingerprint(edges: gpd.GeoDataFrame) -> dict[str, Any]:
    if edges is None or edges.empty:
        return {"edges_count": 0, "nodes_count": 0, "graph_hash": "empty"}
    u = edges.get("u", pd.Series([], dtype=object)).astype(str)
    v = edges.get("v", pd.Series([], dtype=object)).astype(str)
    payload = "|".join(
        sorted(edges.get("edge_id", pd.Series([], dtype=object)).astype(str).head(10000).tolist())
    )
    return {
        "edges_count": int(len(edges)),
        "nodes_count": int(len(set(u) | set(v))),
        "graph_hash": _short_hash(payload),
    }


def safety_decision_summary(
    config: SurfaceAIConfig,
    group_selected: dict[str, Any],
    calibration_metrics: dict[str, Any],
    warnings: dict[str, bool],
) -> dict[str, Any]:
    metrics = group_selected.get("metrics", {})
    ece = float((calibration_metrics or {}).get("ece_top_label", 1.0))
    experimental = (
        float(metrics.get("dangerous_upgrade_rate_effective", 1.0))
        <= float(config.max_dangerous_upgrade_rate_effective)
        and float(metrics.get("recall_bad_surface", 0.0)) >= float(config.min_bad_surface_recall)
        and ece <= float(config.max_calibration_ece)
    )
    main = (
        experimental
        and float(metrics.get("recall_paved_rough", 0.0)) >= float(config.min_paved_rough_recall)
        and not bool(warnings.get("warning_predict_holdout_suspiciously_high", False))
    )
    reasons = [
        f"group_direct dangerous_upgrade_rate_effective = {metrics.get('dangerous_upgrade_rate_effective', 'disabled')}",
        f"group_direct recall_bad_surface = {metrics.get('recall_bad_surface', 'disabled')}",
        f"group_direct ece_top_label = {ece}",
        f"paved_rough recall = {metrics.get('recall_paved_rough', 'disabled')}",
    ]
    return {
        "safe_to_use_for_main_routing": bool(main),
        "safe_to_use_for_experimental_routing": bool(experimental),
        "reasons": reasons,
    }


def build_warning_flags(
    config: SurfaceAIConfig,
    selected: dict[str, Any],
    group_selected: dict[str, Any],
    holdout_metrics: dict[str, Any],
    dangerous_global_rows: int,
    dangerous_global_expected: int,
    output_file_count: int,
) -> dict[str, bool]:
    global_macro = float(group_selected.get("metrics", {}).get("macro_f1", 0.0))
    holdout_macro = float((holdout_metrics.get("group_direct") or {}).get("macro_f1", 0.0))
    return {
        "warning_paved_rough_low_recall": float(
            group_selected.get("metrics", {}).get("recall_paved_rough", 0.0)
        )
        < float(config.min_paved_rough_recall),
        "warning_dangerous_map_empty_but_metrics_nonzero": int(dangerous_global_expected) > 0
        and int(dangerous_global_rows) == 0,
        "warning_predict_holdout_suspiciously_high": (holdout_macro - global_macro) > 0.20,
        "warning_neighbor_features_need_leakage_check": bool(
            config.use_neighbor_features and not config.run_holdout_leakage_checks
        ),
        "warning_safety_threshold_disabled": any(
            v is None
            for v in [
                config.min_bad_surface_recall,
                config.max_dangerous_upgrade_rate_effective,
                config.max_calibration_ece,
                config.min_paved_rough_recall,
            ]
        ),
        "warning_compact_output_limit_exceeded": is_compact_output(config)
        and int(output_file_count) > int(config.max_output_files),
        "warning_train_graph_not_saved": is_compact_output(config)
        and not save_heavy_artifacts(config),
    }


def write_run_summary_csv(path: Path, summary: dict[str, Any]) -> None:
    pd.DataFrame([_json_safe(summary)]).to_csv(path, index=False, encoding="utf-8")


def _plot_lines_by_column(
    edges_gdf: gpd.GeoDataFrame,
    predictions: pd.DataFrame,
    *,
    value_col: str,
    color_map: dict[str, str],
    path: Path,
    only_mask: pd.Series | None = None,
    title: str = "",
) -> None:
    plt = _import_pyplot()
    gdf = edges_gdf[["edge_id", "geometry"]].merge(
        predictions[["edge_id", value_col]],
        on="edge_id",
        how="left",
    )
    if only_mask is not None:
        allowed = set(predictions.loc[only_mask, "edge_id"].astype(str))
        gdf = gdf[gdf["edge_id"].astype(str).isin(allowed)]
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_axis_off()
    if title:
        ax.set_title(title)
    if gdf.empty:
        ax.text(0.5, 0.5, "No edges", ha="center", va="center", transform=ax.transAxes)
    else:
        for value, color in color_map.items():
            subset = gdf[gdf[value_col] == value]
            if subset.empty:
                continue
            subset.plot(ax=ax, color=color, linewidth=1.3, alpha=0.9, label=value)
        rest = gdf[~gdf[value_col].isin(color_map.keys())]
        if not rest.empty:
            rest.plot(ax=ax, color="#969696", linewidth=0.8, alpha=0.7, label="other")
        ax.legend(loc="lower left", fontsize=7, frameon=True)
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=220, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)


def plot_surface_maps(
    predictions: pd.DataFrame,
    edges_gdf: gpd.GeoDataFrame,
    artifacts: SurfaceAIArtifacts,
    config: SurfaceAIConfig,
) -> None:
    _plot_lines_by_column(
        edges_gdf,
        predictions,
        value_col="surface_pred_group",
        color_map=GROUP_COLORS,
        path=artifacts.surface_map_png,
        title="Predicted surface group",
    )
    plot_unknown_risk_map(predictions, edges_gdf, artifacts.unknown_risk_map_png, config)
    plot_confidence_map(predictions, edges_gdf, artifacts.confidence_map_png, config)
    plot_errors_map(predictions, edges_gdf, artifacts.errors_map_png)


def plot_confidence_map(
    predictions: pd.DataFrame, edges_gdf: gpd.GeoDataFrame, path: Path, config: SurfaceAIConfig
) -> None:
    plt = _import_pyplot()
    gdf = edges_gdf[["edge_id", "geometry"]].merge(
        predictions[["edge_id", "is_surface_known", "surface_source", "surface_pred_confidence"]],
        on="edge_id",
        how="left",
    )

    def bucket(row: pd.Series) -> str:
        if bool(row.get("is_surface_known")):
            return "osm_known"
        src = str(row.get("surface_source") or "")
        if src.startswith("default") or src in {"unknown", "ml_ambiguous"}:
            return "default"
        c = float(row.get("surface_pred_confidence") or 0.0)
        if c >= config.conf_high:
            return "high"
        if c >= config.conf_medium:
            return "medium"
        return "low"

    gdf["confidence_bucket"] = gdf.apply(bucket, axis=1)
    colors = {
        "high": "#1a9850",
        "medium": "#fee08b",
        "low": "#d73027",
        "default": "#969696",
        "osm_known": "#2b2b2b",
    }
    widths = {"osm_known": 0.6, "default": 0.8, "low": 1.2, "medium": 1.2, "high": 1.2}
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_axis_off()
    for key, color in colors.items():
        subset = gdf[gdf["confidence_bucket"] == key]
        if subset.empty:
            continue
        subset.plot(ax=ax, color=color, linewidth=widths[key], alpha=0.85, label=key)
    ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=220, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)


def plot_unknown_risk_map(
    predictions: pd.DataFrame, edges_gdf: gpd.GeoDataFrame, path: Path, config: SurfaceAIConfig
) -> None:
    pred_cols = [
        "edge_id",
        "is_surface_known",
        "surface_pred_group_direct",
        "surface_source",
        "surface_pred_group_direct_confidence_calibrated",
    ]
    gdf = edges_gdf[["edge_id", "geometry"]].merge(
        predictions[[c for c in pred_cols if c in predictions.columns]],
        on="edge_id",
        how="inner",
    )
    if "is_surface_known" in gdf.columns:
        gdf = gdf[~gdf["is_surface_known"].astype(bool)]

    def risk(row: pd.Series) -> str:
        src = str(row.get("surface_source") or "")
        group = str(row.get("surface_pred_group_direct") or "unknown")
        conf = float(row.get("surface_pred_group_direct_confidence_calibrated") or 0.0)
        if src == "ml_ambiguous":
            return "ml_ambiguous"
        if src == "default_low_confidence":
            return "default_low_confidence"
        if group == "paved_good" and conf < float(config.conf_medium):
            return "low_conf_paved_good"
        if group == "paved_good" and conf < float(config.conf_high):
            return "medium_conf_paved_good"
        return "other"

    gdf["unknown_risk"] = gdf.apply(risk, axis=1) if not gdf.empty else []
    colors = {
        "low_conf_paved_good": "#d73027",
        "medium_conf_paved_good": "#fee08b",
        "ml_ambiguous": "#fc8d59",
        "default_low_confidence": "#969696",
    }
    plt = _import_pyplot()
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_axis_off()
    ax.set_title("Unknown surface predictions requiring caution")
    plotted = False
    for key, color in colors.items():
        subset = gdf[gdf["unknown_risk"] == key]
        if subset.empty:
            continue
        subset.plot(ax=ax, color=color, linewidth=1.4, alpha=0.9, label=key)
        plotted = True
    if not plotted:
        ax.text(
            0.5,
            0.5,
            "No unknown prediction risk flags",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
    else:
        ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=220, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)


def plot_errors_map(predictions: pd.DataFrame, edges_gdf: gpd.GeoDataFrame, path: Path) -> None:
    err_mask = (predictions["surface_ai_split"] == "test") & (
        predictions["surface_group_direct_label"].astype(str)
        != predictions["surface_pred_group_direct"].astype(str)
    )
    plt = _import_pyplot()
    gdf = edges_gdf[["edge_id", "geometry"]].merge(
        predictions[["edge_id"]],
        on="edge_id",
        how="inner",
    )
    error_ids = set(predictions.loc[err_mask, "edge_id"].astype(str))
    gdf = gdf[gdf["edge_id"].astype(str).isin(error_ids)]
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_axis_off()
    if gdf.empty:
        ax.text(0.5, 0.5, "No test errors", ha="center", va="center", transform=ax.transAxes)
    else:
        gdf.plot(ax=ax, color="#d73027", linewidth=1.8, alpha=0.95)
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=220, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)


def plot_dangerous_errors_map(
    predictions: pd.DataFrame,
    edges_gdf: gpd.GeoDataFrame,
    path: Path,
    *,
    mode: str,
) -> None:
    col = "dangerous_upgrade_raw" if mode == "raw" else "dangerous_upgrade_effective"
    mask = (predictions["surface_ai_split"] == "test") & predictions[col].astype(bool)
    gdf = edges_gdf[["edge_id", "geometry"]].merge(
        predictions[["edge_id", "surface_group_direct_label", "length_m", col]],
        on="edge_id",
        how="inner",
    )
    ids = set(predictions.loc[mask, "edge_id"].astype(str))
    gdf = gdf[gdf["edge_id"].astype(str).isin(ids)]
    plt = _import_pyplot()
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_axis_off()
    colors = {
        "paved_rough": "#fdae61",
        "unpaved_soft": "#d73027",
        "unpaved_hard": "#7f0000",
        "rough_or_unpaved": "#d73027",
    }
    if gdf.empty:
        ax.text(
            0.5,
            0.5,
            f"No dangerous upgrades ({mode})",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
    else:
        for group, color in colors.items():
            subset = gdf[gdf["surface_group_direct_label"] == group]
            if subset.empty:
                continue
            subset.plot(
                ax=ax, color=color, linewidth=2.0, alpha=0.9, label=f"{group} -> paved_good"
            )
        total_len = float(pd.to_numeric(gdf["length_m"], errors="coerce").sum())
        ax.text(
            0.01,
            0.99,
            f"Dangerous upgrades after safety policy: {len(gdf)} edges / {total_len:.0f} m",
            transform=ax.transAxes,
            ha="left",
            va="top",
            bbox={"facecolor": "white", "alpha": 0.8, "edgecolor": "none"},
        )
        ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=220, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)


def write_dangerous_errors_csv(predictions: pd.DataFrame, path: Path) -> None:
    mask = (predictions["surface_ai_split"] == "test") & (
        predictions["dangerous_upgrade_raw"].astype(bool)
        | predictions["dangerous_upgrade_effective"].astype(bool)
    )
    cols = [
        "edge_id",
        "u",
        "v",
        "key",
        "length_m",
        "highway",
        "surface_true_group",
        "surface_group_direct_label",
        "surface_pred_group_direct",
        "surface_effective_group_for_routing_calibrated",
        "dangerous_upgrade_raw",
        "dangerous_upgrade_effective",
        "dangerous_upgrade_severity",
        "surface_pred_group_direct_confidence_calibrated",
        "geometry_wkt",
    ]
    predictions.loc[mask, [c for c in cols if c in predictions.columns]].to_csv(
        path, index=False, encoding="utf-8"
    )


def dangerous_errors_for_split(
    predictions: pd.DataFrame, split_name: str, config: SurfaceAIConfig
) -> pd.DataFrame:
    split = predictions[
        (predictions["surface_ai_split"].astype(str) == split_name)
        & predictions["is_surface_known"].astype(bool)
    ].copy()
    if split.empty:
        return pd.DataFrame(
            columns=[
                "edge_id",
                "u",
                "v",
                "key",
                "split",
                "true_group",
                "pred_group_raw",
                "pred_group_effective",
                "dangerous_upgrade_raw",
                "dangerous_upgrade_effective",
                "dangerous_upgrade_severity",
                "length_m",
                "confidence",
                "margin",
                "highway",
                "surface_osm_raw",
                "geometry_wkt",
            ]
        )
    true_group = split["surface_group_direct_label"].astype(str)
    raw_group = split.get(
        "surface_pred_group_direct_raw", split.get("surface_pred_group_direct")
    ).astype(str)
    pred_group = split.get("surface_pred_group_direct", raw_group).astype(str)
    conf = pd.to_numeric(
        split.get("surface_pred_group_direct_confidence_calibrated"), errors="coerce"
    ).fillna(0.0)
    margin = pd.to_numeric(
        split.get("surface_pred_group_direct_margin_calibrated"), errors="coerce"
    ).fillna(0.0)
    effective_group = pd.Series(
        [
            _effective_group_for_metrics(p, c, m, config)
            for p, c, m in zip(pred_group.tolist(), conf.tolist(), margin.tolist())
        ],
        index=split.index,
    )
    dangerous_raw = pd.Series(
        [is_dangerous_upgrade(t, p) for t, p in zip(true_group.tolist(), raw_group.tolist())],
        index=split.index,
    )
    dangerous_effective = pd.Series(
        [is_dangerous_upgrade(t, p) for t, p in zip(true_group.tolist(), effective_group.tolist())],
        index=split.index,
    )
    rows = pd.DataFrame(
        {
            "edge_id": split["edge_id"].astype(str),
            "u": split.get("u"),
            "v": split.get("v"),
            "key": split.get("key"),
            "split": split_name,
            "true_group": true_group,
            "pred_group_raw": raw_group,
            "pred_group_effective": effective_group,
            "dangerous_upgrade_raw": dangerous_raw,
            "dangerous_upgrade_effective": dangerous_effective,
            "dangerous_upgrade_severity": [
                DANGEROUS_UPGRADE_SEVERITY.get(str(t), 0.0) if bool(e) else 0.0
                for t, e in zip(true_group.tolist(), dangerous_effective.tolist())
            ],
            "length_m": pd.to_numeric(split.get("length_m"), errors="coerce").fillna(0.0),
            "confidence": conf,
            "margin": margin,
            "highway": split.get("highway"),
            "surface_osm_raw": split.get("surface_osm_raw"),
            "geometry_wkt": split.get("geometry_wkt"),
        }
    )
    return rows[rows["dangerous_upgrade_raw"] | rows["dangerous_upgrade_effective"]].copy()


def write_dangerous_errors_split_csv(
    predictions: pd.DataFrame, path: Path, *, split_name: str, config: SurfaceAIConfig
) -> pd.DataFrame:
    df = dangerous_errors_for_split(predictions, split_name, config)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")
    return df


def plot_dangerous_errors_split_map(
    dangerous_df: pd.DataFrame,
    edges_gdf: gpd.GeoDataFrame,
    path: Path,
    *,
    split_name: str,
    mode: str,
    expected_count: int = 0,
) -> None:
    flag_col = "dangerous_upgrade_raw" if mode == "raw" else "dangerous_upgrade_effective"
    rows = dangerous_df[
        dangerous_df.get(flag_col, pd.Series(False, index=dangerous_df.index)).astype(bool)
    ].copy()
    if int(expected_count) > 0 and rows.empty:
        raise RuntimeError(
            f"Dangerous error map mismatch: metrics count > 0 but map source has 0 rows for {split_name}/{mode}."
        )
    gdf = edges_gdf[["edge_id", "geometry"]].merge(rows, on="edge_id", how="inner")
    plt = _import_pyplot()
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_axis_off()
    ax.set_title(f"Dangerous upgrades on {split_name.replace('_', ' ')}, {mode} predictions")
    colors = {
        "paved_rough": "#fdae61",
        "unpaved_soft": "#d73027",
        "unpaved_hard": "#7f0000",
        "rough_or_unpaved": "#d73027",
    }
    if gdf.empty:
        ax.text(
            0.5,
            0.5,
            f"No dangerous upgrades on {split_name}",
            ha="center",
            va="center",
            transform=ax.transAxes,
        )
    else:
        for group, color in colors.items():
            subset = gdf[gdf["true_group"] == group]
            if subset.empty:
                continue
            subset.plot(
                ax=ax, color=color, linewidth=2.0, alpha=0.9, label=f"{group} -> paved_good"
            )
        total_len = float(pd.to_numeric(gdf["length_m"], errors="coerce").sum())
        ax.text(
            0.01,
            0.99,
            f"Dangerous upgrades on {split_name}: {len(gdf)} edges / {total_len:.0f} m",
            transform=ax.transAxes,
            ha="left",
            va="top",
            bbox={"facecolor": "white", "alpha": 0.8, "edgecolor": "none"},
        )
        ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout(pad=0)
    fig.savefig(path, dpi=220, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)


def _tile_to_lat_lon(x: int, y: int, z: int) -> tuple[float, float]:
    n = 2**z
    lon = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
    return math.degrees(lat_rad), lon


def _tile_bounds_geom(x: int, y: int, z: int) -> Any:
    lat1, lon1 = _tile_to_lat_lon(x, y, z)
    lat2, lon2 = _tile_to_lat_lon(x + 1, y + 1, z)
    return box(lon1, lat2, lon2, lat1)


def count_cached_tile_images(tiles_dir: Path | str) -> int:
    tiles_dir = Path(tiles_dir)
    if not tiles_dir.exists():
        return 0
    suffixes = {".jpg", ".jpeg", ".png", ".webp"}
    return sum(1 for p in tiles_dir.iterdir() if p.is_file() and p.suffix.lower() in suffixes)


def scan_cached_tiles(
    tiles_dir: Path | str,
    tms_server: str,
    z: int,
    precache_polygon: Any = None,
) -> gpd.GeoDataFrame:
    tiles_dir = Path(tiles_dir)
    rows = []
    pat = re.compile(
        rf"^{re.escape(tms_server)}_{int(z)}_(\d+)_(\d+)\.(jpg|jpeg|png|webp)$", re.IGNORECASE
    )
    for path in tiles_dir.glob(f"{tms_server}_{int(z)}_*_*.*"):
        m = pat.match(path.name)
        if not m:
            continue
        x = int(m.group(1))
        y = int(m.group(2))
        geom = _tile_bounds_geom(x, y, int(z))
        rows.append(
            {
                "tile_id": f"{tms_server}_{int(z)}_{x}_{y}",
                "server": tms_server,
                "z": int(z),
                "x": x,
                "y": y,
                "path": str(path),
                "geometry": geom,
                "footprint_wgs84": geom.wkt,
            }
        )
    gdf = gpd.GeoDataFrame(rows, geometry="geometry", crs="EPSG:4326")
    if not gdf.empty:
        gdf["footprint_area_m2"] = gdf.to_crs(_utm_crs_for(gdf)).geometry.area.astype(float).values
    else:
        gdf["footprint_area_m2"] = []
    if precache_polygon is not None:
        gdf["inside_precache_polygon"] = (
            gdf.geometry.intersects(precache_polygon) if not gdf.empty else []
        )
    elif "inside_precache_polygon" not in gdf.columns:
        gdf["inside_precache_polygon"] = False if not gdf.empty else []
    return gdf


def _polygon_area_km2(polygon: Any) -> float:
    if polygon is None or polygon.is_empty:
        return 0.0
    gdf = gpd.GeoDataFrame({"name": ["area"]}, geometry=[polygon], crs="EPSG:4326")
    return float(gdf.to_crs(_utm_crs_for(gdf)).geometry.area.iloc[0] / 1_000_000.0)


def _write_polygon_geojson(path: Path, polygon: Any, name: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    gdf = gpd.GeoDataFrame({"name": [name]}, geometry=[polygon], crs="EPSG:4326")
    gdf.to_file(path, driver="GeoJSON")


def tile_coverage_polygon_from_tiles(tiles_gdf: gpd.GeoDataFrame, fallback_polygon: Any) -> Any:
    if tiles_gdf.empty:
        return fallback_polygon
    return unary_union(list(tiles_gdf.geometry.values))


def _area_polygon_from_mode(mode: str, tile_coverage_polygon: Any, precache_polygon: Any) -> Any:
    mode = str(mode or "precache_polygon")
    if mode == "tile_coverage":
        return tile_coverage_polygon
    if mode == "tile_coverage_intersect_precache_polygon":
        return tile_coverage_polygon.intersection(precache_polygon)
    if mode == "tile_coverage_union_precache_polygon":
        return tile_coverage_polygon.union(precache_polygon)
    return precache_polygon


def _load_edges_from_osmnx_polygon(
    polygon: Any,
    settings: Settings,
    config: SurfaceAIConfig,
    *,
    source: str,
) -> tuple[gpd.GeoDataFrame, dict[str, Any]]:
    ox.settings.cache_folder = settings.osmnx_cache_dir
    ox.settings.use_cache = True
    for tag in OSM_TAG_COLUMNS + ("smoothness",):
        if tag not in ox.settings.useful_tags_way:
            ox.settings.useful_tags_way += [tag]
    kwargs: dict[str, Any] = {
        "simplify": bool(config.osmnx_simplify),
        "retain_all": bool(config.osmnx_retain_all),
        "truncate_by_edge": bool(config.osmnx_truncate_by_edge),
    }
    custom_filter = str(config.osmnx_custom_filter or "").strip()
    if custom_filter:
        kwargs["custom_filter"] = custom_filter
    else:
        kwargs["network_type"] = str(config.osmnx_network_type or "all")
    graph = ox.graph_from_polygon(polygon, **kwargs)
    if not isinstance(graph, nx.MultiDiGraph):
        graph = nx.MultiDiGraph(graph)
    return GraphBuilder.to_geodataframe(graph), {
        "graph_source": source,
        "graph_path": None,
        "osmnx_retain_all": bool(config.osmnx_retain_all),
        "osmnx_truncate_by_edge": bool(config.osmnx_truncate_by_edge),
        "osmnx_simplify": bool(config.osmnx_simplify),
        "osmnx_network_type": str(config.osmnx_network_type or "all"),
        "osmnx_custom_filter": custom_filter,
    }


def load_edges_for_surface_ai_polygon(
    settings: Settings,
    config: SurfaceAIConfig,
    polygon: Any,
    *,
    priority: Sequence[str],
    scope: str,
) -> tuple[gpd.GeoDataFrame, dict[str, Any]]:
    """Load edges for one Surface AI area using a scoped source priority."""
    meta: dict[str, Any] = {
        "precache_polygon_bounds_lonlat": tuple(float(x) for x in polygon.bounds),
        "graph_source": None,
        "graph_path": None,
        "graph_source_priority": list(priority),
        "graph_fallback_reasons": [],
        "graph_scope": scope,
    }
    priorities = tuple(priority or ("area_precache", "tiles_coverage_graph", "osmnx_fallback"))

    for source in priorities:
        if source == "tile_coverage_graph":
            try:
                edges, osm_meta = _load_edges_from_osmnx_polygon(
                    polygon,
                    settings,
                    config,
                    source="tile_coverage_graph"
                    if scope == "train"
                    else "tile_coverage_graph_predict",
                )
                meta.update(osm_meta)
                return edges, meta
            except Exception as exc:
                meta["graph_fallback_reasons"].append(f"tile_coverage_graph_failed:{exc}")
                continue
        if source == "area_precache":
            loaded = False
            for label, path in (
                ("graph_base", graph_base_path(settings)),
                ("graph_green", graph_green_path(settings)),
            ):
                if not path.exists():
                    meta["graph_fallback_reasons"].append(f"area_precache_{label}_missing")
                    continue
                graph = load_graphml_path(path)
                if graph is None:
                    meta["graph_fallback_reasons"].append(f"area_precache_{label}_load_failed")
                    continue
                meta["graph_source"] = "area_precache_graphml"
                meta["graph_path"] = str(path)
                return GraphBuilder.to_geodataframe(graph), meta
            if config.strict_area_precache and not loaded:
                raise FileNotFoundError(
                    "Surface AI strict area precache is enabled, but graph_base.graphml/graph_green.graphml were not usable"
                )
            continue
        if source == "osmnx_fallback":
            try:
                edges, osm_meta = _load_edges_from_osmnx_polygon(
                    polygon,
                    settings,
                    config,
                    source="osmnx_overpass_fallback",
                )
                meta.update(osm_meta)
                return edges, meta
            except Exception as exc:
                meta["graph_fallback_reasons"].append(f"osmnx_fallback_failed:{exc}")
                continue
        meta["graph_fallback_reasons"].append(f"unknown_graph_source:{source}")

    raise ValueError(
        f"No usable Surface AI graph source for {scope}: {priorities}; reasons={meta['graph_fallback_reasons']}"
    )


def load_edges_for_surface_ai_area(
    settings: Settings, config: SurfaceAIConfig
) -> tuple[gpd.GeoDataFrame, dict[str, Any]]:
    if not settings.has_precache_area_polygon:
        raise ValueError("PRECACHE_AREA_POLYGON_WKT is empty or not a polygon")
    return load_edges_for_surface_ai_polygon(
        settings,
        config,
        parse_precache_polygon(settings),
        priority=config.graph_source_priority,
        scope="legacy",
    )


def build_train_predict_polygons(
    settings: Settings,
    config: SurfaceAIConfig,
    tiles_gdf: gpd.GeoDataFrame,
) -> tuple[Any, Any, Any, dict[str, Any]]:
    precache_polygon = parse_precache_polygon(settings)
    tile_coverage_polygon = tile_coverage_polygon_from_tiles(tiles_gdf, precache_polygon)
    train_polygon = _area_polygon_from_mode(
        config.train_area_mode, tile_coverage_polygon, precache_polygon
    )
    predict_polygon = _area_polygon_from_mode(
        config.predict_area_mode, tile_coverage_polygon, precache_polygon
    )
    meta = {
        "train_area_mode": config.train_area_mode,
        "predict_area_mode": config.predict_area_mode,
        "tile_coverage_area_km2": _polygon_area_km2(tile_coverage_polygon),
        "precache_polygon_area_km2": _polygon_area_km2(precache_polygon),
        "train_polygon_area_km2": _polygon_area_km2(train_polygon),
        "predict_polygon_area_km2": _polygon_area_km2(predict_polygon),
    }
    return train_polygon, predict_polygon, tile_coverage_polygon, meta


def _edge_inside_polygon_flags(edges_gdf: gpd.GeoDataFrame, polygon: Any) -> pd.Series:
    if edges_gdf.empty:
        return pd.Series([], dtype=bool)
    gdf = (
        edges_gdf.to_crs("EPSG:4326")
        if edges_gdf.crs
        else edges_gdf.set_crs("EPSG:4326", allow_override=True)
    )
    return gdf.geometry.intersects(polygon)


def combine_train_predict_edges(
    train_edges: gpd.GeoDataFrame,
    predict_edges: gpd.GeoDataFrame,
    train_polygon: Any,
    predict_polygon: Any,
) -> gpd.GeoDataFrame:
    train = train_edges.copy()
    predict = predict_edges.copy()
    train["inside_train_area"] = _edge_inside_polygon_flags(train, train_polygon).values
    train["inside_predict_area"] = _edge_inside_polygon_flags(train, predict_polygon).values
    predict["inside_train_area"] = _edge_inside_polygon_flags(predict, train_polygon).values
    predict["inside_predict_area"] = _edge_inside_polygon_flags(predict, predict_polygon).values
    train["surface_ai_edge_source"] = "train_graph"
    predict["surface_ai_edge_source"] = "predict_graph"
    combined = pd.concat([train, predict], axis=0, ignore_index=True)
    if "edge_id" in combined.columns:
        combined["_prefer_predict"] = (
            combined["surface_ai_edge_source"] == "predict_graph"
        ).astype(int)
        combined = (
            combined.sort_values("_prefer_predict")
            .drop_duplicates("edge_id", keep="last")
            .drop(columns="_prefer_predict")
        )
    return gpd.GeoDataFrame(combined, geometry="geometry", crs="EPSG:4326")


_SURFACE_AI_EDGES_CACHE_SCHEMA = "surface_ai_edges_cache_v1"


def _geometry_wkt_for_edges_cache(geom: Any) -> str:
    if geom is None:
        return ""
    try:
        return str(geom.wkt)
    except Exception:
        return str(geom)


def _precache_graphml_stat_fingerprint(settings: Settings) -> str:
    if not settings.has_precache_area_polygon:
        return "no_precache_polygon"
    parts: list[str] = []
    for label, path in (
        ("graph_base", graph_base_path(settings)),
        ("graph_green", graph_green_path(settings)),
    ):
        if path.is_file():
            st = path.stat()
            parts.append(f"{label}:{path.resolve()}:{st.st_size}:{st.st_mtime_ns}")
        else:
            parts.append(f"{label}:missing")
    return "|".join(parts)


def _tiles_gdf_tile_ids_digest(tiles_gdf: gpd.GeoDataFrame) -> str:
    if tiles_gdf is None or tiles_gdf.empty or "tile_id" not in tiles_gdf.columns:
        return "no_tiles"
    ids = sorted(str(x) for x in tiles_gdf["tile_id"].tolist())
    return hashlib.sha256("\n".join(ids).encode("utf-8")).hexdigest()[:32]


def surface_ai_edges_cache_payload(
    *,
    settings: Settings,
    config: SurfaceAIConfig,
    train_polygon: Any,
    predict_polygon: Any,
    tile_coverage_polygon: Any,
    tiles_gdf: gpd.GeoDataFrame,
    tiles_dir: Path,
    tms_server: str,
    tile_zoom: int,
) -> dict[str, Any]:
    precache = parse_precache_polygon(settings) if settings.has_precache_area_polygon else None
    area_id = ""
    if settings.has_precache_area_polygon:
        try:
            wkt = settings.precache_area_polygon_wkt_stripped
            cfp = area_precache_content_fingerprint(settings)
            area_id = area_precache_directory_id(wkt, settings.precache_area_name, cfp)
        except Exception:
            area_id = ""
    return {
        "schema": _SURFACE_AI_EDGES_CACHE_SCHEMA,
        "area_precache_directory_id": area_id,
        "train_poly_wkt": _geometry_wkt_for_edges_cache(train_polygon),
        "predict_poly_wkt": _geometry_wkt_for_edges_cache(predict_polygon),
        "tile_coverage_wkt": _geometry_wkt_for_edges_cache(tile_coverage_polygon),
        "precache_poly_wkt": _geometry_wkt_for_edges_cache(precache)
        if precache is not None
        else "",
        "train_area_mode": str(config.train_area_mode),
        "predict_area_mode": str(config.predict_area_mode),
        "train_graph_source_priority": list(config.train_graph_source_priority),
        "predict_graph_source_priority": list(config.predict_graph_source_priority),
        "osmnx_simplify": bool(config.osmnx_simplify),
        "osmnx_retain_all": bool(config.osmnx_retain_all),
        "osmnx_truncate_by_edge": bool(config.osmnx_truncate_by_edge),
        "osmnx_network_type": str(config.osmnx_network_type or "all"),
        "osmnx_custom_filter": (config.osmnx_custom_filter or "").strip(),
        "tiles_dir_resolved": str(Path(tiles_dir).resolve()),
        "tms_server": str(tms_server),
        "tile_zoom": int(tile_zoom),
        "tiles_tile_id_digest": _tiles_gdf_tile_ids_digest(tiles_gdf),
        "precache_graph_files": _precache_graphml_stat_fingerprint(settings),
        "osmnx_cache_dir": str(Path(settings.osmnx_cache_dir).resolve()),
    }


def surface_ai_edges_cache_fingerprint(
    *,
    settings: Settings,
    config: SurfaceAIConfig,
    train_polygon: Any,
    predict_polygon: Any,
    tile_coverage_polygon: Any,
    tiles_gdf: gpd.GeoDataFrame,
    tiles_dir: Path,
    tms_server: str,
    tile_zoom: int,
) -> str:
    payload = surface_ai_edges_cache_payload(
        settings=settings,
        config=config,
        train_polygon=train_polygon,
        predict_polygon=predict_polygon,
        tile_coverage_polygon=tile_coverage_polygon,
        tiles_gdf=tiles_gdf,
        tiles_dir=tiles_dir,
        tms_server=tms_server,
        tile_zoom=tile_zoom,
    )
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:40]


def _surface_ai_edges_cache_resolved_dir(raw: str) -> Path:
    p = Path(raw).expanduser()
    return p if p.is_absolute() else (Path.cwd() / p)


def surface_ai_edges_cache_read_roots(settings: Settings, config: SurfaceAIConfig) -> list[Path]:
    """Каталоги только для **чтения** ``{fingerprint}/train_edges.parquet`` (без записи в area_precache и т.д.).

    Порядок: явный ``edges_cache_dir`` → ``cache/area_precache/<arena_id>/surface_ai_edges``
    (тот же ``arena_id``, что у ``area_green_edges/<arena_id>/``) → ``<base_dir>/experiments/.surface_ai_edges_cache``.
    """
    roots: list[Path] = []
    raw = (config.edges_cache_dir or "").strip()
    if raw:
        roots.append(_surface_ai_edges_cache_resolved_dir(raw))
    if settings.has_precache_area_polygon:
        try:
            # Тот же arena_id, что у ``cache/area_green_edges/<id>/`` и ``cache/area_precache/<id>/`` — только чтение.
            roots.append(precache_area_dir(settings) / "surface_ai_edges")
        except Exception:
            pass
    roots.append(Path(settings.cache_dir) / "surface_ai" / "edges")
    roots.append(Path(settings.base_dir) / "experiments" / ".surface_ai_edges_cache")
    return roots


def surface_ai_edges_cache_write_root(settings: Settings, config: SurfaceAIConfig) -> Path:
    """Каталог для записи parquet-кэша (не под ``settings.cache_dir``)."""
    raw = (config.edges_cache_dir or "").strip()
    if raw:
        return _surface_ai_edges_cache_resolved_dir(raw)
    return Path(settings.base_dir) / "experiments" / ".surface_ai_edges_cache"


def _surface_ai_edges_cache_path_under_data_cache(settings: Settings, target: Path) -> bool:
    """True, если путь лежит внутри ``cache_dir`` (tiles, area_precache, …) — туда не пишем."""
    try:
        cache_root = Path(settings.cache_dir).resolve()
        t = target.resolve()
        return t == cache_root or cache_root in t.parents
    except (OSError, ValueError):
        return False


def _try_load_surface_ai_edges_cache(
    cache_roots: Sequence[Path],
    fp: str,
) -> tuple[gpd.GeoDataFrame, gpd.GeoDataFrame, dict[str, Any], Path] | None:
    for cache_root in cache_roots:
        d = cache_root / fp
        meta_path = d / "meta.json"
        train_pq = d / "train_edges.parquet"
        predict_pq = d / "predict_edges.parquet"
        if not meta_path.is_file() or not train_pq.is_file() or not predict_pq.is_file():
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if (
            str(meta.get("fingerprint") or "") != fp
            or meta.get("schema") != _SURFACE_AI_EDGES_CACHE_SCHEMA
        ):
            continue
        try:
            train_edges = gpd.read_parquet(train_pq)
            predict_edges = gpd.read_parquet(predict_pq)
        except Exception:
            continue
        if not isinstance(train_edges, gpd.GeoDataFrame):
            train_edges = gpd.GeoDataFrame(
                train_edges,
                geometry="geometry",
                crs=getattr(train_edges, "crs", None) or "EPSG:4326",
            )
        if not isinstance(predict_edges, gpd.GeoDataFrame):
            predict_edges = gpd.GeoDataFrame(
                predict_edges,
                geometry="geometry",
                crs=getattr(predict_edges, "crs", None) or "EPSG:4326",
            )
        run_meta = meta.get("run_meta") if isinstance(meta.get("run_meta"), dict) else {}
        return train_edges, predict_edges, run_meta, d
    return None


def _write_surface_ai_edges_cache(
    settings: Settings,
    config: SurfaceAIConfig,
    cache_root: Path,
    fp: str,
    train_edges: gpd.GeoDataFrame,
    predict_edges: gpd.GeoDataFrame,
    *,
    run_meta: dict[str, Any],
) -> None:
    if not config.edges_cache_write:
        return
    if _surface_ai_edges_cache_path_under_data_cache(settings, cache_root):
        _log_surface_ai.warning(
            "Surface AI: запись кэша рёбер отклонена — каталог внутри data/cache (%s). "
            "Используйте base_dir/experiments/.surface_ai_edges_cache или SURFACE_AI_EDGES_CACHE_DIR вне cache.",
            cache_root,
        )
        return
    d = cache_root / fp
    d.mkdir(parents=True, exist_ok=True)
    train_edges.to_parquet(d / "train_edges.parquet", index=False)
    predict_edges.to_parquet(d / "predict_edges.parquet", index=False)
    keys = (
        "train_graph_source",
        "train_graph_path",
        "train_graph_fallback_reasons",
        "graph_source",
        "graph_path",
        "predict_graph_source",
        "predict_graph_path",
        "predict_graph_fallback_reasons",
    )
    slim = {k: run_meta[k] for k in keys if k in run_meta}
    meta = {
        "schema": _SURFACE_AI_EDGES_CACHE_SCHEMA,
        "fingerprint": fp,
        "run_meta": slim,
    }
    (d / "meta.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")


def mark_dataset_area_flags(dataset: pd.DataFrame, config: SurfaceAIConfig) -> pd.DataFrame:
    df = dataset.copy()
    for col in ("inside_train_area", "inside_predict_area"):
        if col not in df.columns:
            df[col] = False
        df[col] = df[col].fillna(False).astype(bool)
    if config.use_satellite_features:
        sampled = pd.to_numeric(df.get("sampled_pixel_count", 0), errors="coerce").fillna(0)
        missing = pd.to_numeric(df.get("tile_missing_share", 1.0), errors="coerce").fillna(1.0)
        df["has_tile_features"] = (sampled > 0) & (missing < 1.0)
    else:
        df["has_tile_features"] = True
    known_inside_train = df["inside_train_area"].astype(bool) & df["is_surface_known"].astype(bool)
    strict_train_candidate = (
        df["inside_train_area"].astype(bool)
        & df["has_tile_features"].astype(bool)
        & df["is_surface_known"].astype(bool)
    )
    df["train_candidate_fallback_reason"] = ""
    df["is_train_candidate_osm_fallback"] = False
    if int(strict_train_candidate.sum()) == 0 and int(known_inside_train.sum()) >= int(
        config.min_known_edges
    ):
        _log_surface_ai.warning(
            "Surface AI: no known train candidates with tile features; "
            "falling back to OSM/geometry features for %d known train-area edges",
            int(known_inside_train.sum()),
        )
        df["is_train_candidate"] = known_inside_train
        fallback_rows = known_inside_train & ~df["has_tile_features"].astype(bool)
        df.loc[fallback_rows, "is_train_candidate_osm_fallback"] = True
        df.loc[fallback_rows, "train_candidate_fallback_reason"] = (
            "no_tile_features_osm_geometry_fallback"
        )
    else:
        df["is_train_candidate"] = strict_train_candidate
    predict_area_mask = (
        df["inside_predict_area"].astype(bool)
        if config.predict_only_inside_polygon
        else pd.Series(True, index=df.index)
    )
    strict_prediction_candidate = (
        predict_area_mask
        & df["has_tile_features"].astype(bool)
        & ~df["is_surface_known"].astype(bool)
    )
    unknown_predict_area = predict_area_mask & ~df["is_surface_known"].astype(bool)
    df["is_prediction_candidate_osm_fallback"] = False
    if int(strict_prediction_candidate.sum()) == 0 and int(unknown_predict_area.sum()) > 0:
        _log_surface_ai.warning(
            "Surface AI: no unknown prediction candidates with tile features; "
            "falling back to OSM/geometry features for %d unknown predict-area edges",
            int(unknown_predict_area.sum()),
        )
        df["is_prediction_candidate"] = unknown_predict_area
        fallback_rows = unknown_predict_area & ~df["has_tile_features"].astype(bool)
        df.loc[fallback_rows, "is_prediction_candidate_osm_fallback"] = True
        df.loc[fallback_rows, "train_candidate_fallback_reason"] = df.loc[
            fallback_rows, "train_candidate_fallback_reason"
        ].where(
            df.loc[fallback_rows, "train_candidate_fallback_reason"].astype(str).str.len() > 0,
            "no_tile_features_prediction_osm_geometry_fallback",
        )
    else:
        df["is_prediction_candidate"] = strict_prediction_candidate
    df["surface_true"] = df["surface_true_concrete"].where(
        df["is_surface_known"].astype(bool), None
    )
    return df


def write_tile_usage_report(
    tiles_gdf: gpd.GeoDataFrame,
    edges_gdf: gpd.GeoDataFrame,
    polygon: Any,
    artifacts: SurfaceAIArtifacts,
    *,
    predict_edges_gdf: gpd.GeoDataFrame | None = None,
    train_polygon: Any = None,
    predict_polygon: Any = None,
    config: SurfaceAIConfig | None = None,
    total_cached_tiles: int | None = None,
) -> dict[str, Any]:
    train_edges_gdf = edges_gdf
    predict_edges_gdf = predict_edges_gdf if predict_edges_gdf is not None else edges_gdf
    train_polygon = train_polygon if train_polygon is not None else polygon
    predict_polygon = predict_polygon if predict_polygon is not None else polygon
    total_cached_tiles = int(
        total_cached_tiles if total_cached_tiles is not None else len(tiles_gdf)
    )

    if tiles_gdf.empty:
        pd.DataFrame(
            columns=[
                "tile_id",
                "x",
                "y",
                "path",
                "inside_train_area",
                "inside_predict_area",
                "intersects_train_edge",
                "intersects_predict_edge",
                "sampled_by_train_edge",
                "sampled_by_predict_edge",
                "sampled_pixel_count",
                "sampled_edge_count",
                "unused_reason",
            ]
        ).to_csv(artifacts.tile_usage_csv, index=False, encoding="utf-8")
        plot_tile_usage_map(tiles_gdf, artifacts.tile_usage_map_png)
        if config is None or save_heavy_artifacts(config):
            plot_tile_usage_map(tiles_gdf, artifacts.tile_usage_map_train_png, zone="train")
            plot_tile_usage_map(tiles_gdf, artifacts.tile_usage_map_predict_png, zone="predict")
        return {
            "tiles_total_in_cache": total_cached_tiles,
            "tiles_matching_server_zoom": 0,
            "tiles_in_train_area": 0,
            "tiles_intersect_train_edges": 0,
            "tiles_sampled_by_train_edges": 0,
            "tiles_in_predict_area": 0,
            "tiles_intersect_predict_edges": 0,
            "tiles_sampled_by_predict_edges": 0,
            "train_tile_usage_share": 0.0,
            "predict_tile_usage_share": 0.0,
            "edges_with_tile_samples": 0,
            "edges_without_tile_samples": int(len(train_edges_gdf)),
        }

    def usage_union(edges: gpd.GeoDataFrame) -> Any:
        if edges is None or edges.empty:
            return None
        gdf = edges.copy()
        if gdf.crs is None:
            gdf = gdf.set_crs("EPSG:4326", allow_override=True)
        else:
            gdf = gdf.to_crs("EPSG:4326")
        mode = str(
            (config.tile_edge_match_mode if config else "samples_and_buffer")
            or "samples_and_buffer"
        )
        if "buffer" in mode:
            projected = gdf.to_crs(_utm_crs_for(gdf))
            buffered = projected.geometry.buffer(
                float(config.edge_tile_buffer_m if config else 10.0)
            )
            return gpd.GeoSeries(buffered, crs=projected.crs).to_crs("EPSG:4326").unary_union
        return unary_union(list(gdf.geometry.values))

    tiles = tiles_gdf.copy()
    tiles["inside_train_area"] = tiles.geometry.intersects(train_polygon)
    tiles["inside_predict_area"] = tiles.geometry.intersects(predict_polygon)
    train_union = usage_union(train_edges_gdf)
    predict_union = usage_union(predict_edges_gdf)
    tiles["intersects_train_edge"] = (
        tiles.geometry.intersects(train_union) if train_union is not None else False
    )
    tiles["intersects_predict_edge"] = (
        tiles.geometry.intersects(predict_union) if predict_union is not None else False
    )
    tiles["sampled_by_train_edge"] = tiles["intersects_train_edge"]
    tiles["sampled_by_predict_edge"] = tiles["intersects_predict_edge"]
    tiles["sampled_edge_count"] = tiles["sampled_by_train_edge"].astype(int) + tiles[
        "sampled_by_predict_edge"
    ].astype(int)
    tiles["sampled_pixel_count"] = 0
    tiles["used_in_features"] = tiles["sampled_by_train_edge"] | tiles["sampled_by_predict_edge"]

    def unused_reason(row: pd.Series) -> str:
        if bool(row["sampled_by_train_edge"]) and bool(row["sampled_by_predict_edge"]):
            return "used_for_train_and_predict"
        if bool(row["sampled_by_train_edge"]):
            return "used_for_train_only"
        if bool(row["sampled_by_predict_edge"]):
            return "used_for_predict_only"
        if not bool(row["inside_train_area"]) and not bool(row["inside_predict_area"]):
            return "outside_train_and_predict_area"
        return "no_road_edge_intersection"

    tiles["unused_reason"] = tiles.apply(unused_reason, axis=1)
    tiles.drop(columns="geometry").to_csv(artifacts.tile_usage_csv, index=False, encoding="utf-8")
    plot_tile_usage_map(tiles, artifacts.tile_usage_map_png)
    if config is None or save_heavy_artifacts(config):
        plot_tile_usage_map(tiles, artifacts.tile_usage_map_train_png, zone="train")
        plot_tile_usage_map(tiles, artifacts.tile_usage_map_predict_png, zone="predict")
    train_inside = int(tiles["inside_train_area"].sum())
    train_used = int((tiles["inside_train_area"] & tiles["sampled_by_train_edge"]).sum())
    predict_inside = int(tiles["inside_predict_area"].sum())
    predict_used = int((tiles["inside_predict_area"] & tiles["sampled_by_predict_edge"]).sum())
    out = {
        "tiles_total_in_cache": total_cached_tiles,
        "tiles_matching_server_zoom": int(len(tiles)),
        "tiles_in_train_area": train_inside,
        "tiles_intersect_train_edges": int(tiles["intersects_train_edge"].sum()),
        "tiles_sampled_by_train_edges": train_used,
        "tiles_in_predict_area": predict_inside,
        "tiles_intersect_predict_edges": int(tiles["intersects_predict_edge"].sum()),
        "tiles_sampled_by_predict_edges": predict_used,
        "train_tile_usage_share": float(train_used / train_inside) if train_inside else 0.0,
        "predict_tile_usage_share": float(predict_used / predict_inside) if predict_inside else 0.0,
        "edges_with_tile_samples": int((train_edges_gdf["edge_id"].notna()).sum()),
        "edges_without_tile_samples": 0,
    }
    out.update(
        {
            "tiles_inside_precache_polygon": predict_inside,
            "tiles_intersect_graph_edges": int(tiles["intersects_train_edge"].sum()),
            "tiles_sampled_by_edges": train_used,
            "tile_usage_share_inside_polygon": float(predict_used / predict_inside)
            if predict_inside
            else 0.0,
            "unused_tiles_inside_polygon": int(max(0, predict_inside - predict_used)),
        }
    )
    return out


def write_spatial_prior_ablation(
    artifacts: SurfaceAIArtifacts, baseline_table: pd.DataFrame
) -> dict[str, Any]:
    concrete = baseline_table[baseline_table["target"].astype(str).str.contains("concrete")].copy()
    keys = [
        "combined_rf",
        "combined_rf_without_spatial_prior",
        "combined_rf_balanced",
        "combined_rf_balanced_without_spatial_prior",
    ]
    rows = concrete[concrete["model_key"].isin(keys)][
        [
            c
            for c in [
                "model",
                "macro_f1",
                "balanced_accuracy",
                "recall_bad_surface",
                "dangerous_upgrade_rate_effective",
            ]
            if c in concrete.columns
        ]
    ]
    lines = [
        "Surface AI spatial prior ablation",
        "",
        rows.to_string(index=False) if not rows.empty else "No ablation rows were evaluated.",
        "",
        "Interpretation:",
        "If quality drops only slightly, the spatial prior helps but is not critical.",
        "If quality drops strongly, the model is locally tied to this study area.",
    ]
    artifacts.spatial_prior_ablation_txt.write_text("\n".join(lines) + "\n", encoding="utf-8")
    out: dict[str, Any] = {"enabled": True}
    by_key = concrete.set_index("model_key") if not concrete.empty else pd.DataFrame()
    if (
        not by_key.empty
        and "combined_rf" in by_key.index
        and "combined_rf_without_spatial_prior" in by_key.index
    ):
        out["macro_f1_delta_without_spatial_prior"] = float(
            by_key.loc["combined_rf_without_spatial_prior", "macro_f1"]
            - by_key.loc["combined_rf", "macro_f1"]
        )
        out["dangerous_upgrade_delta_without_spatial_prior"] = float(
            by_key.loc["combined_rf_without_spatial_prior", "dangerous_upgrade_rate_effective"]
            - by_key.loc["combined_rf", "dangerous_upgrade_rate_effective"]
        )
    return out


def plot_tile_usage_map(tiles_gdf: gpd.GeoDataFrame, path: Path, *, zone: str = "any") -> None:
    plt = _import_pyplot()
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set_axis_off()
    if tiles_gdf.empty:
        ax.text(0.5, 0.5, "No cached tiles", ha="center", va="center", transform=ax.transAxes)
    else:
        tiles = tiles_gdf.copy()
        if "inside_precache_polygon" not in tiles.columns:
            tiles["inside_precache_polygon"] = False
        if "used_in_features" not in tiles.columns:
            tiles["used_in_features"] = False
        if zone == "train":
            inside_col = "inside_train_area"
            used_col = "sampled_by_train_edge"
        elif zone == "predict":
            inside_col = "inside_predict_area"
            used_col = "sampled_by_predict_edge"
        else:
            inside_col = (
                "inside_precache_polygon"
                if "inside_precache_polygon" in tiles.columns
                else "inside_predict_area"
            )
            used_col = "used_in_features"
        if inside_col not in tiles.columns:
            tiles[inside_col] = False
        if used_col not in tiles.columns:
            tiles[used_col] = False
        outside = tiles[~tiles[inside_col].astype(bool)]
        unused = tiles[tiles[inside_col].astype(bool) & ~tiles[used_col].astype(bool)]
        used = tiles[tiles[used_col].astype(bool)]
        if not outside.empty:
            outside.boundary.plot(ax=ax, color="#bdbdbd", linewidth=0.4, label="outside")
        if not unused.empty:
            unused.boundary.plot(ax=ax, color="#ffd92f", linewidth=0.6, label="inside unused")
        if not used.empty:
            used.boundary.plot(ax=ax, color="#1a9850", linewidth=0.8, label="used")
        ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_confusion_matrix(metrics: dict[str, Any], path: Path, *, title: str) -> None:
    plt = _import_pyplot()
    labels = list(metrics.get("confusion_matrix_labels") or [])
    cm = np.asarray(
        metrics.get("confusion_matrix") or np.zeros((len(labels), len(labels))), dtype=float
    )
    fig_w = max(7.0, 0.55 * max(1, len(labels)))
    fig, ax = plt.subplots(figsize=(fig_w, fig_w))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_title(title)
    ax.set_xticks(np.arange(len(labels)), labels=labels, rotation=45, ha="right")
    ax.set_yticks(np.arange(len(labels)), labels=labels)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if cm[i, j] > 0:
                ax.text(j, i, int(cm[i, j]), ha="center", va="center", color="#111111", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def feature_importance_df(model: Any) -> pd.DataFrame:
    if not isinstance(model, Pipeline):
        return pd.DataFrame(columns=["feature", "importance"])
    estimator = model.named_steps.get("model")
    if not hasattr(estimator, "feature_importances_"):
        return pd.DataFrame(columns=["feature", "importance"])
    pre = model.named_steps.get("preprocess")
    try:
        names = list(pre.get_feature_names_out())
    except Exception:
        names = [f"feature_{i}" for i in range(len(estimator.feature_importances_))]
    values = np.asarray(estimator.feature_importances_, dtype=float)
    n = min(len(names), len(values))
    return (
        pd.DataFrame({"feature": names[:n], "importance": values[:n]})
        .sort_values("importance", ascending=False)
        .reset_index(drop=True)
    )


def plot_feature_importance(feature_importance: pd.DataFrame, path: Path) -> None:
    plt = _import_pyplot()
    if feature_importance.empty:
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.axis("off")
        ax.text(0.5, 0.5, "No feature importance for selected model", ha="center", va="center")
        fig.savefig(path, dpi=180, bbox_inches="tight")
        plt.close(fig)
        return
    df = feature_importance.head(30).iloc[::-1].copy()
    fig, ax = plt.subplots(figsize=(10, max(4.0, 0.34 * len(df))))
    ax.barh(df["feature"], df["importance"], color="#3B6EA8")
    ax.set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def write_model_card(
    artifacts: SurfaceAIArtifacts,
    *,
    selected: dict[str, Any],
    group_selected: dict[str, Any] | None = None,
    config: SurfaceAIConfig,
    dataset: pd.DataFrame,
    dangerous_metrics: dict[str, Any] | None = None,
    tile_coverage: dict[str, Any] | None = None,
    calibration_metrics: dict[str, Any] | None = None,
    spatial_ablation: dict[str, Any] | None = None,
) -> dict[str, Any]:
    known = dataset[dataset["is_surface_known"]]
    train = dataset[dataset["surface_ai_split"] == "train"]
    test = dataset[dataset["surface_ai_split"] == "test"]
    metrics = selected["metrics"]
    feature_set = models_feature_set_from_key(selected["model_key"])
    card = {
        "model_name": f"surface_ai_{selected['model_key']}",
        "target": "surface_concrete",
        "concrete_target_mode": config.concrete_target_mode,
        "group_target_mode": config.group_target_mode,
        "direct_group_model": bool(config.train_direct_group_model),
        "classes": sorted(known["surface_train_label"].astype(str).unique().tolist()),
        "features": feature_set,
        "training_edges": int(len(train)),
        "test_edges": int(len(test)),
        "spatial_split_m": float(config.spatial_grid_m),
        "accuracy": metrics.get("accuracy"),
        "balanced_accuracy": metrics.get("balanced_accuracy"),
        "macro_f1": metrics.get("macro_f1"),
        "weighted_f1": metrics.get("weighted_f1"),
        "selected_by": selected.get("selected_by"),
        "calibrated": bool(selected.get("calibrated", False)),
        "calibration_method": selected.get("calibration_method", config.calibration_method),
        "ece_top_label_before": None,
        "ece_top_label_after": (calibration_metrics or {}).get("ece_top_label"),
        "spatial_prior_ablation": spatial_ablation
        or {"enabled": bool(config.run_spatial_prior_ablation)},
        "dangerous_error_metrics": dangerous_metrics or {},
        "tile_coverage": tile_coverage or {},
        "neighbor_features": {
            "enabled": bool(config.use_neighbor_features),
            "hops": int(config.neighbor_hops),
        },
        "limitations": [
            "class imbalance",
            "rare surfaces are hard to learn",
            "satellite tiles contain shadows/cars/tree crowns",
        ],
        "safe_to_use_for_routing": bool(
            (dangerous_metrics or {}).get("dangerous_upgrade_rate_effective", 1.0)
            <= float(config.max_dangerous_upgrade_rate_effective)
            and selected["metrics"].get("recall_bad_surface", 0.0)
            >= float(config.min_bad_surface_recall)
            and (calibration_metrics or {}).get("ece_top_label", 1.0)
            <= float(config.max_calibration_ece)
            and bool(selected.get("calibrated", False))
        ),
    }
    with open(artifacts.model_card_json, "w", encoding="utf-8") as f:
        json.dump(_json_safe(card), f, ensure_ascii=False, indent=2)
    return card


def write_group_direct_model_card(
    artifacts: SurfaceAIArtifacts,
    *,
    selected: dict[str, Any],
    config: SurfaceAIConfig,
    dataset: pd.DataFrame,
    calibration_metrics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    train = dataset[dataset["surface_ai_split"] == "train"]
    test = dataset[dataset["surface_ai_split"] == "test"]
    metrics = selected["metrics"]
    card = {
        "model_name": f"surface_ai_{selected['model_key']}",
        "target": "group_direct",
        "group_target_mode": config.group_target_mode,
        "classes": sorted(
            dataset.loc[dataset["is_surface_known"], "surface_group_direct_label"]
            .astype(str)
            .unique()
            .tolist()
        ),
        "features": models_feature_set_from_key(selected["model_key"]),
        "training_edges": int(len(train)),
        "test_edges": int(len(test)),
        "accuracy": metrics.get("accuracy"),
        "balanced_accuracy": metrics.get("balanced_accuracy"),
        "macro_f1": metrics.get("macro_f1"),
        "weighted_f1": metrics.get("weighted_f1"),
        "dangerous_upgrade_rate_effective": metrics.get("dangerous_upgrade_rate_effective"),
        "calibrated": bool(selected.get("calibrated", False)),
        "calibration_method": selected.get("calibration_method", config.calibration_method),
        "ece_top_label_after": (calibration_metrics or {}).get("ece_top_label"),
        "safe_to_use_for_routing": False,
    }
    with open(artifacts.group_direct_model_card_json, "w", encoding="utf-8") as f:
        json.dump(_json_safe(card), f, ensure_ascii=False, indent=2)
    return card


def models_feature_set_from_key(model_key: str) -> list[str]:
    fs = _candidate_feature_set(model_key)
    if fs == "osm":
        return ["osm"]
    if fs == "satellite":
        return ["satellite"]
    if fs == "combined":
        return ["osm", "geometry", "satellite"]
    if fs == "osm_geometry":
        return ["osm", "geometry"]
    return []


def write_report(
    artifacts: SurfaceAIArtifacts,
    *,
    summary: dict[str, Any],
    label_meta: dict[str, Any],
    selected: dict[str, Any],
    group_selected: dict[str, Any] | None = None,
    baseline_table: pd.DataFrame,
    config: SurfaceAIConfig,
    run_meta: dict[str, Any],
    tile_coverage: dict[str, Any] | None = None,
    area_meta: dict[str, Any] | None = None,
    holdout_metrics: dict[str, Any] | None = None,
) -> None:
    top = baseline_table[baseline_table["target"].astype(str).str.contains("concrete")].sort_values(
        ["macro_f1", "balanced_accuracy"],
        ascending=False,
    )
    lines = [
        "Surface AI experiment report",
        "",
        f"Output dir: {artifacts.output_dir}",
        f"Train area mode: {config.train_area_mode}",
        f"Predict area mode: {config.predict_area_mode}",
        f"Train graph source: {run_meta.get('train_graph_source')}",
        f"Train graph path: {run_meta.get('train_graph_path')}",
        f"Predict graph source: {run_meta.get('predict_graph_source')}",
        f"Predict graph path: {run_meta.get('predict_graph_path')}",
        f"Graph source: {run_meta.get('graph_source')}",
        f"Graph path: {run_meta.get('graph_path')}",
        f"Tiles dir: {run_meta.get('tiles_dir')}",
        f"Tile zoom: {run_meta.get('tile_zoom')}",
        f"Total cached tiles: {(tile_coverage or {}).get('tiles_total_in_cache')}",
        f"Matching server/zoom tiles: {(tile_coverage or {}).get('tiles_matching_server_zoom')}",
        f"Train area tiles: {(tile_coverage or {}).get('tiles_in_train_area')}",
        f"Predict area tiles: {(tile_coverage or {}).get('tiles_in_predict_area')}",
        f"Area metrics: {area_meta or {}}",
        "",
        "Dataset:",
        f"  Compact output: {config.compact_output}",
        f"  Max output files: {config.max_output_files}",
        f"  Save full predictions GeoJSON: {config.save_full_predictions_geojson}",
        f"  Total edges: {summary.get('total_edges')}",
        f"  Known surface edges: {summary.get('known_surface_edges')}",
        f"  Unknown surface edges: {summary.get('unknown_surface_edges')}",
        f"  Unknown share: {summary.get('unknown_share'):.3f}",
        f"  Train edges total: {summary.get('train_edges_total')}",
        f"  Train edges with tile features: {summary.get('train_edges_with_tile_features')}",
        f"  Train known surface edges: {summary.get('train_known_surface_edges')}",
        f"  Train unknown surface edges: {summary.get('train_unknown_surface_edges')}",
        f"  Predict edges inside polygon: {summary.get('predict_edges_inside_polygon')}",
        f"  Predict unknown surface edges inside polygon: {summary.get('predict_unknown_surface_edges_inside_polygon')}",
        f"  Predictions produced inside polygon: {summary.get('predictions_produced_inside_polygon')}",
        f"  Frequent concrete classes: {label_meta.get('frequent_surface_classes')}",
        f"  Rare concrete classes: {label_meta.get('rare_surface_classes')}",
        "",
        "Model selection:",
        f"  Selected model: {selected.get('model_name')} ({selected.get('model_key')})",
        f"  Main criterion: {selected.get('selected_by')}",
        f"  Safety recall threshold: {selected.get('safety_recall_threshold')}",
        f"  Safety threshold satisfied by selected pool: {selected.get('safety_recall_threshold_satisfied')}",
        f"  Selected metrics: {selected.get('metrics')}",
        f"  Selected group direct model: {(group_selected or {}).get('model_name')} ({(group_selected or {}).get('model_key')})",
        f"  Group direct metrics: {(group_selected or {}).get('metrics')}",
        f"  Global test metrics: {selected.get('metrics')}",
        f"  Predict polygon holdout metrics: {holdout_metrics or {}}",
        f"  Concrete target mode: {config.concrete_target_mode}",
        f"  Group target mode: {config.group_target_mode}",
        f"  Tile coverage: {tile_coverage or {}}",
        "",
        "Baseline ranking by macro_f1:",
    ]
    for _, row in top.iterrows():
        lines.append(
            f"  {row['model']}: macro_f1={row['macro_f1']:.4f}, "
            f"balanced_accuracy={row['balanced_accuracy']:.4f}, "
            f"recall_bad_surface={row['recall_bad_surface']:.4f}"
        )
    lines.extend(
        [
            "",
            "Safety policy:",
            f"  enabled: {config.enable_safety_policy}",
            f"  min_confidence: {config.min_confidence}",
            f"  min_margin: {config.min_margin}",
            f"  paved_good_min_confidence: {config.paved_good_min_confidence}",
            f"  bad_surface_min_confidence: {config.bad_surface_min_confidence}",
            "  Known OSM surface is never replaced by ML.",
            "  Main routing is not connected to this model yet.",
            "",
            "Limitations:",
            "  Satellite tiles can include shadows, cars, tree crowns, roofs, and yards.",
            "  Rare surface classes are grouped into rare_other_* train labels.",
            "  The output is prepared for future routing integration but safe_to_use_for_routing=false.",
            "",
            "Tile-driven graph warning:",
            "  If tile coverage area is large, but train graph has few edges, possible causes are cached tiles without roads, wrong server/zoom, graph-source fallback failure, restrictive filters, fragmented tile coverage, or partial Overpass response.",
            "",
            "Artifacts:",
        ]
    )
    for field in artifacts.__dataclass_fields__:
        if field != "output_dir":
            lines.append(f"  {field}: {getattr(artifacts, field)}")
    text = "\n".join(lines) + "\n"
    artifacts.report_txt.write_text(text, encoding="utf-8")
    artifacts.train_vs_predict_report_txt.write_text(text, encoding="utf-8")


def write_metrics_json(
    artifacts: SurfaceAIArtifacts,
    *,
    selected: dict[str, Any],
    group_selected: dict[str, Any] | None = None,
    models: dict[str, Any],
    group_models: dict[str, Any] | None = None,
    baseline_table: pd.DataFrame,
    summary: dict[str, Any],
    label_meta: dict[str, Any],
    config: SurfaceAIConfig,
    run_meta: dict[str, Any],
    tile_coverage: dict[str, Any] | None = None,
    calibration_metrics: dict[str, Any] | None = None,
    area_meta: dict[str, Any] | None = None,
    holdout_metrics: dict[str, Any] | None = None,
) -> None:
    payload = {
        "selected_model": selected,
        "selected_group_direct_model": group_selected,
        "model_metrics": {
            key: {
                "metrics": value.get("metrics") or value.get("concrete_metrics"),
                "group_metrics": value.get("group_metrics"),
                "feature_set": value.get("feature_set"),
            }
            for key, value in models.items()
            if not key.startswith("_")
        },
        "group_direct_model_metrics": {
            key: {
                "metrics": value.get("metrics"),
                "feature_set": value.get("feature_set"),
            }
            for key, value in (group_models or {}).items()
            if not key.startswith("_")
        },
        "baseline_table": baseline_table.to_dict(orient="records"),
        "dataset_summary": summary,
        "label_meta": label_meta,
        "config": asdict(config),
        "run_meta": run_meta,
        "tile_coverage": tile_coverage or {},
        "tile_usage": tile_coverage or {},
        "area_meta": area_meta or {},
        "global_tile_coverage_test_metrics": selected.get("metrics"),
        "predict_polygon_holdout_metrics": holdout_metrics or {},
        "calibration_metrics": calibration_metrics or {},
    }
    with open(artifacts.metrics_json, "w", encoding="utf-8") as f:
        json.dump(_json_safe(payload), f, ensure_ascii=False, indent=2)


def write_model_joblib(
    artifacts: SurfaceAIArtifacts,
    *,
    selected: dict[str, Any],
    models: dict[str, Any],
    feature_importance: pd.DataFrame,
    config: SurfaceAIConfig,
    label_meta: dict[str, Any],
) -> None:
    key = selected["model_key"]
    bundle = {
        "model": models[key]["model"],
        "calibrated_model": models[key].get("calibrated_model"),
        "model_key": key,
        "feature_set": models[key]["feature_set"],
        "selected": selected,
        "surface_values": CONCRETE_SURFACE_VALUES,
        "surface_group_map": SURFACE_GROUP_MAP,
        "label_meta": label_meta,
        "feature_importance": feature_importance,
        "config": asdict(config),
        "uses_calibrated_confidence": bool(selected.get("calibrated", False)),
    }
    joblib.dump(bundle, artifacts.model_joblib)


def write_group_direct_joblib(
    artifacts: SurfaceAIArtifacts,
    *,
    selected: dict[str, Any],
    models: dict[str, Any],
    config: SurfaceAIConfig,
) -> None:
    key = selected["model_key"]
    bundle = {
        "model": models[key]["model"],
        "calibrated_model": models[key].get("calibrated_model"),
        "model_key": key,
        "feature_set": models[key]["feature_set"],
        "selected": selected,
        "labels": models[key]["labels"],
        "target": "group_direct",
        "config": asdict(config),
        "uses_calibrated_confidence": bool(selected.get("calibrated", False)),
    }
    joblib.dump(bundle, artifacts.group_direct_model_joblib)


def run_surface_ai_experiment(
    *,
    settings: Settings | None = None,
    config: SurfaceAIConfig | None = None,
    max_edges: int | None = None,
    output_dir: Path | None = None,
    progress: ProgressFactory = progress_iter,
) -> SurfaceAIArtifacts:
    settings = settings or Settings()
    config = config or SurfaceAIConfig.from_env()
    artifacts = artifact_paths(experiment_output_dir(settings, config, output_dir))
    run_meta: dict[str, Any] = {
        "tiles_dir": config.tiles_dir or str(Path(settings.cache_dir) / "tiles"),
        "tile_zoom": int(config.tile_zoom or settings.satellite_zoom),
        "tms_server": config.tms_server or settings.tms_server,
    }

    precache_polygon = parse_precache_polygon(settings)
    tiles_dir = Path(run_meta["tiles_dir"])
    total_cached_tiles = count_cached_tile_images(tiles_dir)
    for _ in progress(range(1), "[1/10] Scan cached tiles", total=1):
        tiles_gdf = scan_cached_tiles(
            tiles_dir,
            str(run_meta["tms_server"]),
            int(run_meta["tile_zoom"]),
            precache_polygon=precache_polygon,
        )
        train_polygon, predict_polygon, tile_coverage_polygon, area_meta = (
            build_train_predict_polygons(
                settings,
                config,
                tiles_gdf,
            )
        )
        area_meta.update(
            {
                "tiles_total_in_cache": total_cached_tiles,
                "tiles_matching_server_zoom": int(len(tiles_gdf)),
            }
        )
        if save_heavy_artifacts(config):
            _write_polygon_geojson(artifacts.train_polygon_geojson, train_polygon, "train_polygon")
            _write_polygon_geojson(
                artifacts.predict_polygon_geojson, predict_polygon, "predict_polygon"
            )
            _write_polygon_geojson(
                artifacts.tile_coverage_polygon_geojson,
                tile_coverage_polygon,
                "tile_coverage_polygon",
            )

    edges_cache_fp = surface_ai_edges_cache_fingerprint(
        settings=settings,
        config=config,
        train_polygon=train_polygon,
        predict_polygon=predict_polygon,
        tile_coverage_polygon=tile_coverage_polygon,
        tiles_gdf=tiles_gdf,
        tiles_dir=tiles_dir,
        tms_server=str(run_meta["tms_server"]),
        tile_zoom=int(run_meta["tile_zoom"]),
    )
    edges_cache_read_roots = surface_ai_edges_cache_read_roots(settings, config)
    edges_cache_write_root = surface_ai_edges_cache_write_root(settings, config)
    train_edges: gpd.GeoDataFrame | None = None
    predict_edges: gpd.GeoDataFrame | None = None
    if config.reuse_edges_cache:
        loaded = _try_load_surface_ai_edges_cache(edges_cache_read_roots, edges_cache_fp)
        if loaded is not None:
            train_edges, predict_edges, cached_rm, cache_hit_dir = loaded
            run_meta.update(cached_rm)
            _log_surface_ai.info(
                "Surface AI: рёбра из кэша (fingerprint=%s, path=%s)",
                edges_cache_fp,
                cache_hit_dir,
            )
        else:
            roots_fmt = ", ".join(str(p) for p in edges_cache_read_roots)
            _log_surface_ai.info(
                "Surface AI: кэш рёбер не найден (fingerprint=%s); искали под: %s — полная загрузка графа",
                edges_cache_fp,
                roots_fmt,
            )

    if train_edges is None or predict_edges is None:
        for _ in progress(range(1), "[2/10] Load train graph", total=1):
            train_raw, train_meta = load_edges_for_surface_ai_polygon(
                settings,
                config,
                train_polygon,
                priority=config.train_graph_source_priority,
                scope="train",
            )
            run_meta["train_graph_source"] = train_meta.get("graph_source")
            run_meta["train_graph_path"] = train_meta.get("graph_path")
            run_meta["train_graph_fallback_reasons"] = train_meta.get("graph_fallback_reasons", [])
            run_meta["graph_source"] = run_meta["train_graph_source"]
            run_meta["graph_path"] = run_meta["train_graph_path"]

        for _ in progress(range(1), "[3/10] Filter train graph", total=1):
            train_edges = filter_edges_to_polygon(train_raw, train_polygon)
            for col in AI_OSM_FEATURES:
                if col not in train_edges.columns:
                    train_edges[col] = None

        for _ in progress(range(1), "[4/10] Load predict graph", total=1):
            predict_raw, predict_meta = load_edges_for_surface_ai_polygon(
                settings,
                config,
                predict_polygon,
                priority=config.predict_graph_source_priority,
                scope="predict",
            )
            run_meta["predict_graph_source"] = predict_meta.get("graph_source")
            run_meta["predict_graph_path"] = predict_meta.get("graph_path")
            run_meta["predict_graph_fallback_reasons"] = predict_meta.get(
                "graph_fallback_reasons", []
            )

        for _ in progress(range(1), "[5/10] Filter predict graph", total=1):
            predict_edges = filter_edges_to_polygon(predict_raw, predict_polygon)
            for col in AI_OSM_FEATURES:
                if col not in predict_edges.columns:
                    predict_edges[col] = None

        try:
            _write_surface_ai_edges_cache(
                settings,
                config,
                edges_cache_write_root,
                edges_cache_fp,
                train_edges,
                predict_edges,
                run_meta=run_meta,
            )
        except Exception as exc:
            _log_surface_ai.warning("Surface AI: не удалось записать кэш рёбер: %s", exc)
    else:
        for _ in progress(range(1), "[2–5/10] Edges from disk cache", total=1):
            pass

    if save_heavy_artifacts(config):
        write_edges_geojson(train_edges, artifacts.train_edges_geojson)
        write_edges_geojson(predict_edges, artifacts.predict_edges_geojson)
    edges = combine_train_predict_edges(train_edges, predict_edges, train_polygon, predict_polygon)
    if max_edges is not None:
        edges = limit_edges_for_experiment(
            edges,
            max_edges,
            random_state=config.random_state,
            min_known_edges=config.min_known_edges,
        )

    dataset, label_meta = build_surface_ai_dataset(
        edges,
        settings,
        config,
        train_polygon,
        progress=progress,
    )
    dataset = mark_dataset_area_flags(dataset, config)
    dataset["surface_ai_split"] = spatial_train_cal_test_split(dataset, edges, config)
    if config.use_neighbor_features:
        dataset = add_neighbor_features(dataset)
    summary = dataset_summary(dataset)
    if save_heavy_artifacts(config):
        write_dataset_csv(dataset, artifacts.dataset_csv)
        write_dataset_csv(dataset, artifacts.dataset_all_tile_edges_csv)

    concrete_models, concrete_table = train_evaluate_task_models(
        dataset,
        config,
        label_meta,
        target="concrete_compact",
        candidates=config.model_candidates,
        progress=progress,
    )
    concrete_selected = select_model_for_target(
        concrete_models, concrete_table, config, target="concrete_compact"
    )
    concrete_models["_selected"] = concrete_selected
    group_models, group_table = train_evaluate_task_models(
        dataset,
        config,
        label_meta,
        target="group_direct",
        candidates=config.group_model_candidates,
        progress=progress,
    )
    group_selected = select_model_for_target(
        group_models, group_table, config, target="group_direct"
    )
    group_models["_selected"] = group_selected
    apply_posthoc_calibration_to_selected(
        dataset,
        concrete_selected,
        concrete_models,
        config,
        target="concrete_compact",
    )
    apply_posthoc_calibration_to_selected(
        dataset,
        group_selected,
        group_models,
        config,
        target="group_direct",
    )
    holdout_metrics = {
        "concrete_compact": evaluate_selected_on_split(
            dataset,
            concrete_selected,
            concrete_models,
            config,
            target="concrete_compact",
            split_name="predict_holdout",
        ),
        "group_direct": evaluate_selected_on_split(
            dataset,
            group_selected,
            group_models,
            config,
            target="group_direct",
            split_name="predict_holdout",
        ),
    }
    baseline_table = pd.concat([concrete_table, group_table], axis=0, ignore_index=True)

    predictions = predict_all_edges(
        dataset, concrete_models, group_models, config, progress=progress
    )
    predictions_inside = predictions[
        predictions.get(
            "is_prediction_candidate", pd.Series(False, index=predictions.index)
        ).astype(bool)
    ].copy()
    summary["predictions_produced_inside_polygon"] = int(len(predictions_inside))
    if save_heavy_artifacts(config):
        write_predictions_csv(predictions, artifacts.predictions_csv)
    if config.save_full_predictions_geojson and save_heavy_artifacts(config):
        write_predictions_geojson(predictions, edges, artifacts.predictions_geojson)
    write_predictions_csv(predictions_inside, artifacts.predictions_inside_polygon_csv)
    if save_heavy_artifacts(config):
        write_predictions_geojson(
            predictions_inside, predict_edges, artifacts.predictions_inside_polygon_geojson
        )
    write_runtime_router_predictions_from_experiment(
        predictions_inside,
        predict_edges,
        settings=settings,
        group_selected=group_selected,
        artifacts=artifacts,
        precache_polygon=precache_polygon,
    )
    write_baseline_tables(baseline_table, artifacts)

    tile_coverage = (
        write_tile_usage_report(
            tiles_gdf,
            train_edges,
            train_polygon,
            artifacts,
            predict_edges_gdf=predict_edges,
            train_polygon=train_polygon,
            predict_polygon=predict_polygon,
            config=config,
            total_cached_tiles=total_cached_tiles,
        )
        if config.tile_usage_report
        else {}
    )
    dangerous_overall = dict(group_selected.get("metrics", {}))
    dangerous_flat = {
        "dangerous_upgrade_rate_raw": dangerous_overall.get("dangerous_upgrade_rate_raw", 0.0),
        "dangerous_upgrade_rate_effective": dangerous_overall.get(
            "dangerous_upgrade_rate_effective", 0.0
        ),
        "dangerous_upgrade_length_m_effective": dangerous_overall.get(
            "dangerous_upgrade_length_m_effective", 0.0
        ),
    }
    spatial_ablation = (
        write_spatial_prior_ablation(artifacts, baseline_table)
        if save_heavy_artifacts(config)
        else {"enabled": bool(config.run_spatial_prior_ablation)}
    )
    concrete_calibration = (
        calibration_artifacts_for_selected(
            dataset,
            concrete_selected,
            concrete_models,
            artifacts,
            config,
            target="concrete_compact",
        )
        if save_heavy_artifacts(config)
        else {}
    )
    group_calibration = calibration_artifacts_for_selected(
        dataset,
        group_selected,
        group_models,
        artifacts,
        config,
        target="group_direct",
    )
    feature_importance = feature_importance_df(
        concrete_models[concrete_selected["model_key"]]["model"]
    )
    neighbor_importance = feature_importance[
        feature_importance["feature"].astype(str).str.contains("neighbor_", regex=False)
    ].copy()
    if neighbor_importance.empty:
        neighbor_importance = feature_importance.head(30).copy()
    predictions_predict_area = predictions[
        predictions.get("inside_predict_area", pd.Series(False, index=predictions.index)).astype(
            bool
        )
    ].copy()
    dangerous_global = write_dangerous_errors_split_csv(
        predictions,
        artifacts.dangerous_errors_global_test_csv,
        split_name="test",
        config=config,
    )
    dangerous_holdout = write_dangerous_errors_split_csv(
        predictions,
        artifacts.dangerous_errors_predict_holdout_csv,
        split_name="predict_holdout",
        config=config,
    )
    for step in progress(range(6), "[9/10] Visualizations", total=6):
        if step == 0:
            plot_surface_maps(predictions_predict_area, predict_edges, artifacts, config)
        elif step == 1:
            plot_confusion_matrix(
                concrete_selected["metrics"],
                artifacts.confusion_matrix_concrete_compact_png,
                title="Concrete compact confusion matrix",
            )
            if save_heavy_artifacts(config):
                plot_confusion_matrix(
                    concrete_selected["metrics"],
                    artifacts.confusion_matrix_concrete_png,
                    title="Concrete surface confusion matrix",
                )
                plot_confusion_matrix(
                    concrete_selected["metrics"],
                    artifacts.confusion_matrix_concrete_legacy_png,
                    title="Concrete legacy comparison matrix",
                )
        elif step == 2:
            plot_confusion_matrix(
                group_selected["metrics"],
                artifacts.confusion_matrix_group_direct_png,
                title="Surface group direct confusion matrix",
            )
            if save_heavy_artifacts(config):
                plot_confusion_matrix(
                    group_selected["metrics"],
                    artifacts.confusion_matrix_group_png,
                    title="Surface group direct confusion matrix",
                )
        elif step == 3:
            plot_feature_importance(feature_importance, artifacts.feature_importance_png)
            if save_heavy_artifacts(config):
                plot_feature_importance(
                    neighbor_importance, artifacts.neighbor_feature_importance_png
                )
        elif step == 4:
            plot_dangerous_errors_split_map(
                dangerous_global,
                edges,
                artifacts.dangerous_errors_global_test_effective_png,
                split_name="global_test",
                mode="effective",
                expected_count=int(dangerous_overall.get("dangerous_upgrade_count_effective", 0)),
            )
            plot_dangerous_errors_split_map(
                dangerous_holdout,
                edges,
                artifacts.dangerous_errors_predict_holdout_effective_png,
                split_name="predict_holdout",
                mode="effective",
                expected_count=int(
                    (holdout_metrics.get("group_direct") or {}).get(
                        "dangerous_upgrade_count_effective", 0
                    )
                ),
            )
            if save_heavy_artifacts(config):
                plot_dangerous_errors_split_map(
                    dangerous_global,
                    edges,
                    artifacts.dangerous_errors_global_test_raw_png,
                    split_name="global_test",
                    mode="raw",
                    expected_count=int(dangerous_overall.get("dangerous_upgrade_count_raw", 0)),
                )
                plot_dangerous_errors_split_map(
                    dangerous_holdout,
                    edges,
                    artifacts.dangerous_errors_predict_holdout_raw_png,
                    split_name="predict_holdout",
                    mode="raw",
                    expected_count=int(
                        (holdout_metrics.get("group_direct") or {}).get(
                            "dangerous_upgrade_count_raw", 0
                        )
                    ),
                )
                write_dangerous_errors_csv(predictions, artifacts.dangerous_errors_csv)
        else:
            pass

    for _ in progress(range(1), "[10/10] Export reports/model", total=1):
        graph_fp = {
            "train": graph_fingerprint(train_edges),
            "predict": graph_fingerprint(predict_edges),
            "tile_coverage_polygon_hash": polygon_hash(tile_coverage_polygon),
            "precache_polygon_hash": polygon_hash(precache_polygon),
        }
        run_config = {
            "run_id": artifacts.output_dir.name,
            "git_commit": current_git_commit(),
            "train_area_mode": config.train_area_mode,
            "predict_area_mode": config.predict_area_mode,
            "train_graph_source": run_meta.get("train_graph_source"),
            "predict_graph_source": run_meta.get("predict_graph_source"),
            "tile_coverage_area_km2": area_meta.get("tile_coverage_area_km2"),
            "predict_polygon_area_km2": area_meta.get("predict_polygon_area_km2"),
            "tiles_total": tile_coverage.get("tiles_total_in_cache"),
            "tiles_used_train": tile_coverage.get("tiles_sampled_by_train_edges"),
            "tiles_used_predict": tile_coverage.get("tiles_sampled_by_predict_edges"),
            "random_state": config.random_state,
            "model_candidates": ",".join(config.model_candidates),
            "group_model_candidates": ",".join(config.group_model_candidates),
            "selected_model": concrete_selected.get("model_key"),
            "selected_group_model": group_selected.get("model_key"),
            "feature_sets": {
                "concrete": concrete_models[concrete_selected["model_key"]]["feature_set"],
                "group_direct": group_models[group_selected["model_key"]]["feature_set"],
            },
            "env_settings": asdict(config),
            "graph_fingerprint": graph_fp,
            "neighbor_features_leakage_guard": True,
            "holdout_labels_masked_for_neighbor_features": bool(
                config.mask_holdout_labels_for_neighbors
            ),
            "holdout_neighbor_test_labels_used": False,
        }
        initial_file_count = len([p for p in artifacts.output_dir.iterdir() if p.is_file()])
        warnings = build_warning_flags(
            config,
            concrete_selected,
            group_selected,
            holdout_metrics,
            dangerous_global_rows=int(dangerous_global["dangerous_upgrade_effective"].sum())
            if not dangerous_global.empty
            else 0,
            dangerous_global_expected=int(
                dangerous_overall.get("dangerous_upgrade_count_effective", 0)
            ),
            output_file_count=initial_file_count,
        )
        safety = safety_decision_summary(config, group_selected, group_calibration, warnings)
        summary.update(
            {
                "selected_concrete_model": concrete_selected.get("model_key"),
                "selected_group_model": group_selected.get("model_key"),
                "main_metrics": group_selected.get("metrics"),
                "safety_decision": safety,
                "warnings": warnings,
                "safety_min_bad_surface_recall": config.min_bad_surface_recall,
                "safety_max_dangerous_upgrade_rate_effective": config.max_dangerous_upgrade_rate_effective,
                "safety_max_calibration_ece": config.max_calibration_ece,
                "safety_min_paved_rough_recall": config.min_paved_rough_recall,
            }
        )
        write_run_summary_csv(artifacts.run_summary_csv, summary)
        if save_heavy_artifacts(config):
            write_metrics_json(
                artifacts,
                selected=concrete_selected,
                group_selected=group_selected,
                models=concrete_models,
                group_models=group_models,
                baseline_table=baseline_table,
                summary=summary,
                label_meta=label_meta,
                config=config,
                run_meta=run_meta,
                tile_coverage=tile_coverage,
                calibration_metrics={
                    "concrete": concrete_calibration,
                    "group_direct": group_calibration,
                },
                area_meta=area_meta,
                holdout_metrics=holdout_metrics,
            )
            with open(artifacts.group_direct_metrics_json, "w", encoding="utf-8") as f:
                json.dump(_json_safe(group_selected), f, ensure_ascii=False, indent=2)
            write_model_joblib(
                artifacts,
                selected=concrete_selected,
                models=concrete_models,
                feature_importance=feature_importance,
                config=config,
                label_meta=label_meta,
            )
            write_group_direct_joblib(
                artifacts,
                selected=group_selected,
                models=group_models,
                config=config,
            )
            write_model_card(
                artifacts,
                selected=concrete_selected,
                group_selected=group_selected,
                config=config,
                dataset=dataset,
                dangerous_metrics=dangerous_flat,
                tile_coverage=tile_coverage,
                calibration_metrics=concrete_calibration,
                spatial_ablation=spatial_ablation,
            )
            write_group_direct_model_card(
                artifacts,
                selected=group_selected,
                config=config,
                dataset=dataset,
                calibration_metrics=group_calibration,
            )
            write_report(
                artifacts,
                summary=summary,
                label_meta=label_meta,
                selected=concrete_selected,
                group_selected=group_selected,
                baseline_table=baseline_table,
                config=config,
                run_meta=run_meta,
                tile_coverage=tile_coverage,
                area_meta=area_meta,
                holdout_metrics=holdout_metrics,
            )
        write_results_workbook(
            artifacts,
            baseline_table=baseline_table,
            summary=summary,
            area_meta=area_meta,
            tile_coverage=tile_coverage,
            selected=concrete_selected,
            group_selected=group_selected,
            holdout_metrics=holdout_metrics,
            calibration_metrics={
                "concrete": concrete_calibration,
                "group_direct": group_calibration,
            },
            dangerous_metrics=dangerous_flat,
            predictions_inside=predictions_inside[prediction_columns(predictions_inside)].head(
                5000
            ),
            dangerous_global=dangerous_global,
            dangerous_holdout=dangerous_holdout,
            run_config=run_config,
            artifact_manifest=expected_compact_manifest(artifacts)
            if is_compact_output(config)
            else artifact_manifest(artifacts.output_dir),
        )

    return artifacts
