"""Сервис анализа озеленения по спутниковым снимкам."""

import hashlib
import json
import logging
import os
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import geopandas as gpd
import numpy as np

from ..config import ROUTING_ALGO_VERSION, Settings
from .cache import CacheService
from .tiles import TileService

logger = logging.getLogger(__name__)

# Пороги NDI/ExG в compute_vegetation_masks; при изменении — увеличить для сброса кэша .npz
TILE_VEG_MASK_VERSION = "ndisexg_v2_tileval"
# Версия pickle green_edges: смена инвалидирует старые файлы (в т.ч. «залипшие» нули).
GREEN_EDGES_CACHE_SCHEMA = "green_edges_v6"

# Семантика зелёного результата на ребре (edge-cache / отчёт качества).
GREEN_EDGE_STATUS_VALID = "valid_green_result"
GREEN_EDGE_STATUS_ZERO = "confirmed_zero_green"
GREEN_EDGE_STATUS_INVALID = "invalid_imagery_or_incomplete_analysis"


def _is_trustworthy_edge_record(r: Any) -> bool:
    """Готовый к переиспользованию результат: не «отравленный» невалидным снимком."""
    if not isinstance(r, dict):
        return False
    st = r.get("status") or r.get("green_status")
    return st in (GREEN_EDGE_STATUS_VALID, GREEN_EDGE_STATUS_ZERO)


def _edge_cache_covers_all_edges(edge_cache: dict, index_arr: np.ndarray) -> bool:
    for idx in index_arr:
        r = edge_cache.get(idx)
        if r is None or not _is_trustworthy_edge_record(r):
            return False
    return len(index_arr) > 0


def normalize_edge_index_key(idx: Any) -> Any:
    """Стабильный ключ ребра OSMnx (MultiIndex) для pickle между процессами."""
    if isinstance(idx, tuple):
        return tuple(np.asarray(x).item() for x in idx)
    return np.asarray(idx).item()


try:
    from PIL import Image, ImageDraw

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


class GreenAnalyzer:
    """Озеленение по тайлам: маски **T** (деревья) и **G** (трава) считаются один раз на тайл.

    Для коридора **M** вокруг дороги доли в процентах:
    ``P_trees = 100·Σ(M∩T)/Σ(M)``, ``P_grass = 100·Σ(M∩G)/Σ(M)`` по сумме пикселей
    по всем тайлам ребра (не среднее по тайлам).

    Тепловой комфорт (тень/экспозиция) считается отдельно в :mod:`services.heat`:
    крона деревьев и трава по-разному ослабляют солнечный штраф — «зелень как
    таковая» не равна тепловому бонусу без учёта ориентации и слота времени.
    """

    def __init__(
        self,
        tile_service: TileService,
        cache_service: CacheService,
        settings: Settings,
    ) -> None:
        self._tiles = tile_service
        self._cache = cache_service
        self._settings = settings
        self._satellite_warning: str | None = None
        # LRU при чтении масок с диска в цикле по рёбрам (без гигабайтного dict в RAM)
        self._tile_mask_read_lru: OrderedDict[
            tuple[int, int, int], tuple[np.ndarray, np.ndarray]
        ] = OrderedDict()
        self._tile_mask_read_lru_max: int = 8192
        self._last_satellite_quality: dict[str, Any] | None = None
        self._last_edge_cache_snapshot: dict[Any, Any] | None = None

    def consume_satellite_warning(self) -> str | None:
        """Одноразово отдать предупреждение о неполных тайлах (режим green в ответе)."""
        w = self._satellite_warning
        self._satellite_warning = None
        return w

    def green_analysis_is_acceptable(self) -> bool:
        """True, если последний спутниковый проход можно считать завершённым и без отравления кэша.

        Политика **консервативная**: ``persistable_for_cache`` ложен при сбоях масок
        HTTP/тайлов или предупреждении — дисковый edge-cache и ``graph_green`` не
        помечаются как полные (см. агрегацию в ``calculate_satellite_batch``).
        """
        q = self._last_satellite_quality
        if not q:
            return False
        return bool(q.get("persistable_for_cache"))

    def last_satellite_quality_report(self) -> dict[str, Any] | None:
        """Снимок качества для meta.json area precache (может быть None до первого расчёта)."""
        return self._last_satellite_quality

    def try_apply_area_green_edges_cache(self, edges_gdf: gpd.GeoDataFrame) -> bool:
        """Подставить зелёные признаки из ``cache/area_green_edges/.../green_edges.pkl`` без агрегации.

        Возвращает True, если для текущего графа арены найден валидный статический кэш.
        """
        if not self._settings.has_precache_area_polygon:
            return False
        if (
            not self._settings.cache_tile_analysis
            or self._settings.disable_satellite_green
            or self._settings.force_recalculate
        ):
            return False
        from .area_graph_cache import (
            AREA_GREEN_EDGES_SCHEMA,
            area_green_edges_bundle_is_valid,
            area_green_edges_content_fingerprint,
            area_green_edges_pkl_path,
            load_area_green_edges_bundle_meta,
        )

        n = len(edges_gdf)
        if not area_green_edges_bundle_is_valid(self._settings, n):
            return False
        side = load_area_green_edges_bundle_meta(self._settings)
        if not side or side.get("schema") != AREA_GREEN_EDGES_SCHEMA:
            return False
        if side.get("fingerprint") != area_green_edges_content_fingerprint(self._settings):
            return False

        path = area_green_edges_pkl_path(self._settings).as_posix()
        raw = self._cache.load(path)
        if not isinstance(raw, dict) or not raw:
            return False

        trees_l: list = []
        grass_l: list = []
        total_l: list = []
        n_semantic = 0
        for idx in edges_gdf.index:
            nk = normalize_edge_index_key(idx)
            r = raw.get(nk)
            if r is None:
                r = raw.get(idx)  # type: ignore[arg-type]
            if not isinstance(r, dict):
                logger.info(
                    "area_green_edges: нет записи для ребра %s — повторная агрегация",
                    nk,
                )
                return False
            trees_l.append(float(r.get("trees", 0.0)))
            grass_l.append(float(r.get("grass", 0.0)))
            total_l.append(float(r.get("total", 0.0)))
            if _is_trustworthy_edge_record(r):
                n_semantic += 1

        edges_gdf["trees_percent"] = trees_l
        edges_gdf["grass_percent"] = grass_l
        edges_gdf["green_percent"] = total_l
        self._apply_green_coefficients(edges_gdf)
        buf_m = self._settings.road_buffer_meters
        self._log_green_stats(edges_gdf, buf_m)

        self._last_satellite_quality = {
            "invalid_tiles_total": 0,
            "n_tg_fail_total": 0,
            "edges_semantic_ok": int(n_semantic),
            "edges_total": int(n),
            "persistable_for_cache": bool(side.get("green_edges_quality_ok", True)),
            "all_edges_semantic_ok": n_semantic == n and n > 0,
        }
        self._satellite_warning = None
        logger.info(
            "Статический кэш area_green_edges: признаки рёбер загружены с диска "
            "(%d рёбер, семантика ok=%d/%d)",
            n,
            n_semantic,
            n,
        )
        return True

    # ==================================================================
    # Анализ изображений
    # ==================================================================

    @staticmethod
    def compute_vegetation_masks(img: Any) -> tuple[np.ndarray, np.ndarray] | None:
        """Булевы маски деревьев **T** и травы **G** (H, W), взаимно не пересекаются."""
        if img is None:
            return None
        if img.mode != "RGB":
            img = img.convert("RGB")

        px = np.array(img, dtype=np.float32)
        r, g, b = px[:, :, 0], px[:, :, 1], px[:, :, 2]

        ndi = (g - r) / (r + g + 0.001)
        exg = g - (r + b) / 2.0
        brightness = (r + g + b) / 3.0
        max_rgb = np.maximum(np.maximum(r, g), b)
        min_rgb = np.minimum(np.minimum(r, g), b)
        saturation = (max_rgb - min_rgb) / (max_rgb + 0.001)

        base_green = (
            (ndi > 0.01) & (exg > 1) & (g > r) & (g > 30) & (brightness > 5) & (brightness < 250)
        )

        trees_mask = base_green & (
            (brightness < 120) | ((brightness < 160) & (ndi > 0.05) & (saturation > 0.1))
        )
        grass_mask = (
            base_green & ~trees_mask & ((brightness >= 60) & (brightness < 220) & (ndi > 0.01))
        )
        return trees_mask, grass_mask

    @staticmethod
    def analyze_image(
        img: Any,
        mask: np.ndarray | None = None,
        return_details: bool = False,
    ) -> dict | float:
        """Доли зелени в %: при маске **M** — ``100·sum(M∩T)/sum(M)`` и аналогично трава."""
        empty: dict = {"trees": 0.0, "grass": 0.0, "total": 0.0}
        vm = GreenAnalyzer.compute_vegetation_masks(img)
        if vm is None:
            return empty if return_details else 0.0
        trees_mask, grass_mask = vm

        if mask is not None:
            mb = mask > 0
            denom = float(mb.sum())
            if denom <= 0:
                return empty if return_details else 0.0
            tp = float((trees_mask & mb).sum()) / denom * 100.0
            gp = float((grass_mask & mb).sum()) / denom * 100.0
        else:
            denom = float(trees_mask.size)
            if denom <= 0:
                return empty if return_details else 0.0
            tp = float(trees_mask.sum()) / denom * 100.0
            gp = float(grass_mask.sum()) / denom * 100.0

        if return_details:
            return {"trees": tp, "grass": gp, "total": tp + gp}
        return tp + gp

    @staticmethod
    def create_corridor_mask(
        edge_geom: Any,
        tile_bounds: tuple[float, ...],
        img_size: tuple[int, int],
        buffer_meters: int,
    ) -> np.ndarray:
        """Маска коридора вокруг линии дороги (для попиксельного анализа)."""
        if not PIL_AVAILABLE:
            return np.zeros((img_size[1], img_size[0]), dtype=np.uint8)

        min_lon, min_lat, max_lon, max_lat = tile_bounds
        w, h = img_size

        def _to_pixel(lon: float, lat: float) -> tuple[int, int]:
            px = int((lon - min_lon) / (max_lon - min_lon) * w)
            py = int((max_lat - lat) / (max_lat - min_lat) * h)
            return px, py

        mask_img = Image.new("L", (w, h), 0)
        draw = ImageDraw.Draw(mask_img)

        lat_c = (min_lat + max_lat) / 2
        m_per_deg = 111_000 * np.cos(np.radians(lat_c))
        tw = (max_lon - min_lon) * m_per_deg
        th = (max_lat - min_lat) * 111_000
        if tw > 0 and th > 0:
            mpp = max(tw / w, th / h)
            lw = int((buffer_meters * 2) / mpp)
            lw = max(5, min(lw, min(w, h) // 3))
        else:
            lw = 20

        def _draw_line_coords(coords: list) -> None:
            if len(coords) < 2:
                return
            pixels = [_to_pixel(lon, lat) for lon, lat in coords]
            for i in range(len(pixels) - 1):
                draw.line([pixels[i], pixels[i + 1]], fill=255, width=lw)

        gt = getattr(edge_geom, "geom_type", None)
        if gt == "LineString":
            _draw_line_coords(list(edge_geom.coords))
        elif gt == "MultiLineString":
            for part in edge_geom.geoms:
                _draw_line_coords(list(part.coords))

        return np.array(mask_img)

    # ==================================================================
    # Пакетный спутниковый анализ
    # ==================================================================

    def calculate_satellite_batch(self, edges_gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        """Пакетный расчёт зелени для каждого ребра по космоснимкам.

        1. Определяет покрывающие ребро TMS-тайлы.
        2. Строит маску коридора вокруг дороги.
        3. Анализирует зелень (NDI / ExG).
        4. Разделяет на **деревья** и **траву**.
        """
        zoom = self._settings.satellite_zoom
        buf_m = self._settings.road_buffer_meters
        buf_deg = buf_m / 111_000.0

        logger.info(
            "Анализ зелени (космоснимки): zoom=%d, буфер=%dм, режим=%s",
            zoom,
            buf_m,
            "коридор" if self._settings.analyze_corridor else "весь тайл",
        )

        if not self._tiles.pil_available:
            self._last_satellite_quality = {
                "invalid_tiles_total": 0,
                "n_tg_fail_total": 0,
                "edges_semantic_ok": 0,
                "edges_total": len(edges_gdf),
                "persistable_for_cache": False,
                "all_edges_semantic_ok": False,
            }
            self._last_edge_cache_snapshot = None
            return self._fill_empty_green(edges_gdf)

        self._last_edge_cache_snapshot = None
        edge_tiles: dict = {}
        n_edges = len(edges_gdf)
        index_arr = edges_gdf.index.values
        geoms = edges_gdf.geometry.values

        for pos in range(n_edges):
            idx = index_arr[pos]
            geom = geoms[pos]
            if geom is None:
                continue
            b = geom.bounds
            x1, y1 = self._tiles.lat_lon_to_tile(b[3] + buf_deg, b[0] - buf_deg, zoom)
            x2, y2 = self._tiles.lat_lon_to_tile(b[1] - buf_deg, b[2] + buf_deg, zoom)
            tiles = [(x, y) for x in range(x1, x2 + 1) for y in range(y1, y2 + 1)]
            edge_tiles[idx] = tiles

        edge_cache = self._load_edge_cache(edges_gdf, zoom, buf_m)
        n_tg_fail_total = 0

        tiles_needed: set[tuple[int, int]] = set()
        for pos in range(n_edges):
            idx = index_arr[pos]
            if idx in edge_cache:
                continue
            tl = edge_tiles.get(idx)
            if tl:
                tiles_needed.update(tl)

        tile_masks: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] = {}
        if _edge_cache_covers_all_edges(edge_cache, index_arr):
            logger.info(
                "Все результаты в кэше (%d рёбер, семантика valid/zero)",
                len(edge_cache),
            )
        elif not tiles_needed:
            logger.debug("Тайлы не нужны: все рёбра уже в edge-кэше")
        else:
            self._satellite_warning = None
            self._tile_mask_read_lru.clear()
            n_need = len(tiles_needed)
            tiles_list = sorted(tiles_needed)
            batch_cap = self._settings.green_tile_batch_size
            if batch_cap <= 0:
                batch_cap = n_need
            else:
                batch_cap = min(batch_cap, n_need)

            n_tg_cache = n_tg_compute = n_tg_fail = 0
            jpeg_attempted = jpeg_delivered = 0

            if n_need > batch_cap:
                logger.info(
                    "Спутник: разбиение на пакеты по %d тайлов (GREEN_TILE_BATCH_SIZE), всего %d",
                    batch_cap,
                    n_need,
                )
            if self._settings.cache_tile_analysis:
                logger.info(
                    "Маски T/G пишутся в tile_green_masks/*.npz; в RAM не копится словарь на все тайлы "
                    "(CACHE_TILE_ANALYSIS=true)"
                )

            for start in range(0, n_need, batch_cap):
                chunk_list = tiles_list[start : start + batch_cap]
                chunk_set = set(chunk_list)
                if n_need > batch_cap:
                    logger.info(
                        "Спутник: пакет тайлов %d–%d из %d",
                        start + 1,
                        min(start + batch_cap, n_need),
                        n_need,
                    )
                if self._settings.cache_tile_analysis and not self._settings.force_recalculate:
                    need_jpeg = {
                        xy
                        for xy in chunk_set
                        if not self._tile_mask_cache_usable_without_image(xy[0], xy[1], zoom)
                    }
                else:
                    need_jpeg = set(chunk_set)

                if need_jpeg:
                    tile_images, _ = self._tiles.download_batch(need_jpeg, zoom)
                else:
                    tile_images = {}

                n_dl = len(tile_images)
                jpeg_attempted += len(need_jpeg)
                jpeg_delivered += n_dl
                if need_jpeg and n_dl < len(need_jpeg):
                    self._satellite_warning = (
                        f"Загружено спутниковых тайлов {jpeg_delivered} из {jpeg_attempted} "
                        f"(пакет {start // batch_cap + 1}); оценка озеленения может быть неполной."
                    )
                    logger.warning("%s", self._satellite_warning)
                part_masks, nc, ncm, nf = self._parallel_build_tile_masks(
                    tile_images, zoom, chunk_set
                )
                if self._settings.cache_tile_analysis:
                    # Маски уже в .npz; не держим сотни тысяч ndarray в одном dict (OOM/своп).
                    pass
                else:
                    tile_masks.update(part_masks)
                n_tg_cache += nc
                n_tg_compute += ncm
                n_tg_fail += nf
                n_tg_fail_total += nf
                del tile_images
                del part_masks

            if (
                jpeg_attempted > 0
                and jpeg_delivered < jpeg_attempted
                and self._satellite_warning is None
            ):
                self._satellite_warning = (
                    f"Загружено спутниковых тайлов {jpeg_delivered} из {jpeg_attempted}; "
                    "оценка озеленения по снимку может быть неполной."
                )
                logger.warning("%s", self._satellite_warning)

            masks_done = len(tile_masks) if not self._settings.cache_tile_analysis else n_need
            logger.info(
                "Маски T/G: готово %d / %d (tile_green_masks hit %d, miss %d, fail %d); "
                "%% по коридору: 100·Σ(M∩T)/Σ(M)",
                masks_done,
                len(tiles_needed),
                n_tg_cache,
                n_tg_compute,
                n_tg_fail,
            )

        # После тайлов/масок — долгий CPU-проход по рёбрам (коридор ∩ T/G); без логов кажется,
        # что «зелень перестала грузиться», хотя сеть уже не нужна.
        _agg_log_step = max(2500, min(10000, max(1, n_edges // 15)))
        logger.info(
            "Спутник: агрегация зелени по рёбрам коридора (%d шт.), прогресс каждые ~%d…",
            n_edges,
            _agg_log_step,
        )

        trees_l, grass_l, total_l = [], [], []

        for pos in range(n_edges):
            if pos > 0 and pos % _agg_log_step == 0:
                logger.info(
                    "Спутник: рёбра коридора %d / %d",
                    pos,
                    n_edges,
                )
            idx = index_arr[pos]
            if idx in edge_cache:
                r = edge_cache[idx]
                trees_l.append(r["trees"])
                grass_l.append(r["grass"])
                total_l.append(r["total"])
                continue

            geom = geoms[pos]
            if idx not in edge_tiles or geom is None:
                trees_l.append(0.0)
                grass_l.append(0.0)
                total_l.append(0.0)
                edge_cache[idx] = {
                    "trees": 0.0,
                    "grass": 0.0,
                    "total": 0.0,
                    "status": GREEN_EDGE_STATUS_INVALID,
                }
                continue

            sum_m = 0
            sum_t = 0
            sum_g = 0
            missing_tile_mask = False
            ram_masks: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] | None = (
                None if self._settings.cache_tile_analysis else tile_masks
            )
            for tx, ty in edge_tiles[idx]:
                pair = self._resolve_tile_masks_pair(tx, ty, zoom, ram_masks)
                if pair is None:
                    missing_tile_mask = True
                    continue
                t_mask, g_mask = pair
                h, w = t_mask.shape[0], t_mask.shape[1]
                tb = self._tiles.get_tile_bounds(tx, ty, zoom)

                if self._settings.analyze_corridor:
                    m_arr = self.create_corridor_mask(geom, tb, (w, h), buf_m)
                    mb = m_arr > 0
                else:
                    mb = np.ones((h, w), dtype=bool)

                sm = int(mb.sum())
                if sm == 0:
                    continue
                sum_m += sm
                sum_t += int(np.logical_and(t_mask, mb).sum())
                sum_g += int(np.logical_and(g_mask, mb).sum())

            if sum_m > 0:
                tp = 100.0 * float(sum_t) / float(sum_m)
                gp = 100.0 * float(sum_g) / float(sum_m)
                top = tp + gp
            else:
                tp = gp = top = 0.0

            if missing_tile_mask or n_tg_fail_total > 0:
                st = GREEN_EDGE_STATUS_INVALID
            elif sum_m == 0:
                st = GREEN_EDGE_STATUS_INVALID
            elif top <= 1e-12:
                st = GREEN_EDGE_STATUS_ZERO
            else:
                st = GREEN_EDGE_STATUS_VALID

            trees_l.append(tp)
            grass_l.append(gp)
            total_l.append(top)
            edge_cache[idx] = {
                "trees": tp,
                "grass": gp,
                "total": top,
                "status": st,
            }

        logger.info("Спутник: агрегация по рёбрам коридора завершена (%d шт.)", n_edges)

        # Строгость: сбой маски / HTTP или warning → не сохраняем «полный» кэш (см. docstring).
        skip_edge_persist = self._satellite_warning is not None or n_tg_fail_total > 0
        all_semantic_ok = _edge_cache_covers_all_edges(edge_cache, index_arr)
        persistable = (not skip_edge_persist) and all_semantic_ok
        n_trust = sum(
            1 for idx in index_arr if _is_trustworthy_edge_record(edge_cache.get(idx, {}))
        )
        self._last_satellite_quality = {
            "invalid_tiles_total": 0,
            "n_tg_fail_total": n_tg_fail_total,
            "edges_semantic_ok": n_trust,
            "edges_total": int(n_edges),
            "persistable_for_cache": persistable,
            "all_edges_semantic_ok": all_semantic_ok,
        }
        self._save_edge_cache(
            edge_cache,
            edges_gdf,
            zoom,
            buf_m,
            skip_disk=not persistable,
        )

        edges_gdf["trees_percent"] = trees_l
        edges_gdf["grass_percent"] = grass_l
        edges_gdf["green_percent"] = total_l
        self._apply_green_coefficients(edges_gdf)
        self._log_green_stats(edges_gdf, buf_m)
        if persistable:
            self._last_edge_cache_snapshot = {
                normalize_edge_index_key(k): dict(v) for k, v in edge_cache.items()
            }
        else:
            self._last_edge_cache_snapshot = None
        return edges_gdf

    # ==================================================================
    # Приватные методы
    # ==================================================================

    def _tile_mask_cache_path(self, tx: int, ty: int, zoom: int) -> str:
        key = hashlib.sha256(
            f"{self._settings.tms_server!s}|{zoom}|{tx}|{ty}|{TILE_VEG_MASK_VERSION}".encode()
        ).hexdigest()[:28]
        sub = os.path.join(self._cache.cache_dir, "tile_green_masks")
        return os.path.join(sub, f"{key}.npz")

    def _tile_mask_cache_usable_without_image(self, tx: int, ty: int, zoom: int) -> bool:
        """Есть ли файл маски — тогда JPEG не качаем (разбор .npz в воркере)."""
        if not self._settings.cache_tile_analysis or self._settings.force_recalculate:
            return False
        return os.path.isfile(self._tile_mask_cache_path(tx, ty, zoom))

    def _load_green_tile_masks_npz(
        self, tx: int, ty: int, zoom: int
    ) -> tuple[np.ndarray, np.ndarray] | None:
        """Чтение готовых масок с диска (без PIL), для агрегации при CACHE_TILE_ANALYSIS."""
        path = self._tile_mask_cache_path(tx, ty, zoom)
        if not os.path.isfile(path):
            return None
        try:
            z = np.load(path)
            t = z["trees"].astype(bool)
            g = z["grass"].astype(bool)
            if t.shape != g.shape:
                return None
            return (t, g)
        except Exception as exc:
            logger.debug("tile mask npz read %s: %s", path, exc)
            return None

    def _resolve_tile_masks_pair(
        self,
        tx: int,
        ty: int,
        zoom: int,
        ram: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] | None,
    ) -> tuple[np.ndarray, np.ndarray] | None:
        if ram is not None:
            return ram.get((tx, ty))
        key = (tx, ty, zoom)
        od = self._tile_mask_read_lru
        if key in od:
            od.move_to_end(key)
            return od[key]
        pair = self._load_green_tile_masks_npz(tx, ty, zoom)
        if pair is None:
            return None
        od[key] = pair
        while len(od) > self._tile_mask_read_lru_max:
            od.popitem(last=False)
        return pair

    def _get_or_compute_tile_masks(
        self, img: Any, tx: int, ty: int, zoom: int
    ) -> tuple[tuple[np.ndarray, np.ndarray] | None, str]:
        """Один раз NDI/ExG на тайл; чтение/запись ``.npz``.

        Returns:
            (маски или None, источник: ``cache`` | ``compute`` | ``fail``).
        """
        path = self._tile_mask_cache_path(tx, ty, zoom)
        h, w = img.size[1], img.size[0]
        if self._settings.cache_tile_analysis and os.path.isfile(path):
            try:
                z = np.load(path)
                t = z["trees"].astype(bool)
                g = z["grass"].astype(bool)
                if t.shape == (h, w) and g.shape == (h, w):
                    return (t, g), "cache"
            except Exception as exc:
                logger.debug("tile mask cache read %s: %s", path, exc)

        vm = self.compute_vegetation_masks(img)
        if vm is None:
            return None, "fail"
        tbool, gbool = vm
        if self._settings.cache_tile_analysis:
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                # savez_compressed добавляет .npz, если путь не оканчивается на .npz
                root, ext = os.path.splitext(path)
                tmp = root + ".tmp" + (ext if ext else ".npz")
                np.savez_compressed(
                    tmp,
                    trees=tbool.astype(np.uint8),
                    grass=gbool.astype(np.uint8),
                )
                os.replace(tmp, path)
            except Exception as exc:
                logger.debug("tile mask cache write %s: %s", path, exc)
        return (tbool, gbool), "compute"

    def _parallel_build_tile_masks(
        self,
        tile_images: dict[tuple[int, int], Any],
        zoom: int,
        all_tiles: set[tuple[int, int]],
    ) -> tuple[
        dict[tuple[int, int], tuple[np.ndarray, np.ndarray]],
        int,
        int,
        int,
    ]:
        """Собрать маски по тайлам; счётчики cache hit / compute / fail (нет снимка или NDI)."""
        out: dict[tuple[int, int], tuple[np.ndarray, np.ndarray]] = {}
        n_cache = n_compute = n_fail = 0
        tiles_list = list(all_tiles)
        workers = max(1, self._settings.tile_download_threads)

        def job(xy: tuple[int, int]):
            if self._settings.cache_tile_analysis and not self._settings.force_recalculate:
                cached = self._load_green_tile_masks_npz(xy[0], xy[1], zoom)
                if cached is not None:
                    return xy, cached, "cache"
            img = tile_images.get(xy)
            if img is None:
                return xy, None, "fail"
            pair, src = self._get_or_compute_tile_masks(img, xy[0], xy[1], zoom)
            return xy, pair, src

        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(job, xy) for xy in tiles_list]
            for fut in as_completed(futures):
                xy, pair, src = fut.result()
                if src == "cache":
                    n_cache += 1
                elif src == "compute":
                    n_compute += 1
                else:
                    n_fail += 1
                if pair is not None:
                    out[xy] = pair
        return out, n_cache, n_compute, n_fail

    def _edge_cache_path(self, edges_gdf: gpd.GeoDataFrame, zoom: int, buf_m: int) -> str:
        """Путь к pickle кэша по bbox + параметрам анализа (в т.ч. TMS и алгоритм)."""
        bounds = edges_gdf.total_bounds
        payload = {
            "analyze_corridor": self._settings.analyze_corridor,
            "bounds": [round(float(bounds[i]), 5) for i in range(4)],
            "buf_m": int(buf_m),
            "disable_satellite_green": self._settings.disable_satellite_green,
            "routing_algo_version": str(ROUTING_ALGO_VERSION),
            "schema": GREEN_EDGES_CACHE_SCHEMA,
            "tile_mask_ver": TILE_VEG_MASK_VERSION,
            "tms_server": self._settings.tms_server,
            "zoom": int(zoom),
        }
        h = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        sub = os.path.join(self._cache.cache_dir, "green_edges")
        os.makedirs(sub, exist_ok=True)
        return os.path.join(sub, f"{h}.pkl")

    @staticmethod
    def _edge_cache_is_degenerate_all_zeros(cached: dict[Any, Any], n_edges: int) -> bool:
        """Полный кэш из нулей без подтверждённой семантики — часто артефакт сбоя тайлов/TMS.

        ``confirmed_zero_green`` с нулевыми процентами — валидно и не считается дегенератом.
        """
        if n_edges < 100 or len(cached) < n_edges:
            return False
        for r in cached.values():
            if not isinstance(r, dict):
                return False
            if (
                float(r.get("trees", 0) or 0) != 0.0
                or float(r.get("grass", 0) or 0) != 0.0
                or float(r.get("total", 0) or 0) != 0.0
            ):
                return False
        for r in cached.values():
            if r.get("status") == GREEN_EDGE_STATUS_ZERO:
                continue
            return True
        return False

    def _load_edge_cache(self, edges_gdf: gpd.GeoDataFrame, zoom: int, buf_m: int) -> dict:
        if not self._settings.cache_tile_analysis:
            return {}
        if self._settings.force_recalculate:
            logger.info("FORCE_RECALCULATE=True, пересчитываем")
            return {}
        path = self._edge_cache_path(edges_gdf, zoom, buf_m)
        cached = self._cache.load(path)
        if cached:
            trusted = {
                k: v
                for k, v in cached.items()
                if isinstance(v, dict) and _is_trustworthy_edge_record(v)
            }
            dropped = len(cached) - len(trusted)
            if dropped:
                logger.info(
                    "green_edges: отброшено %d записей без валидного status (v6+), осталось %d",
                    dropped,
                    len(trusted),
                )
            cached = trusted
            logger.info(
                "Кэш анализа рёбер (%s…): %d доверенных записей",
                os.path.basename(path)[:16],
                len(cached),
            )
            n_edges = len(edges_gdf)
            if (
                self._settings.green_edge_reject_all_zero_cache
                and self._edge_cache_is_degenerate_all_zeros(cached, n_edges)
            ):
                logger.warning(
                    "green_edges: игнорируем pickle — полный кэш только из нулей "
                    "(вероятен старый сбой тайлов/TMS). Будет пересчёт; при необходимости "
                    "смените TMS_SERVER или удалите %s вручную",
                    os.path.dirname(path),
                )
                return {}
        return cached or {}

    def _save_edge_cache(
        self,
        cache: dict,
        edges_gdf: gpd.GeoDataFrame,
        zoom: int,
        buf_m: int,
        *,
        skip_disk: bool = False,
    ) -> None:
        if not self._settings.cache_tile_analysis:
            return
        if skip_disk:
            logger.warning(
                "green_edges: pickle на диск не пишем (неполные тайлы / fail масок — "
                "иначе нули закрепились бы как «готовый» кэш). Повторите запрос после "
                "исправления сети или TMS."
            )
            return
        path = self._edge_cache_path(edges_gdf, zoom, buf_m)
        self._cache.save(path, cache)

    @staticmethod
    def _apply_green_coefficients(gdf: gpd.GeoDataFrame) -> None:
        """Рассчитать ``green_coeff`` и ``green_type`` по процентам.

        ``green_coeff`` — базовый коэффициент озеленения (0.3–1.2).
        Профильная чувствительность применяется позже в GraphBuilder.
        """
        trees = gdf["trees_percent"].values
        grass = gdf["grass_percent"].values
        total = gdf["green_percent"].values

        penalty = np.maximum(0, (10 - total) / 100)
        gdf["green_coeff"] = np.clip(
            1.0 + penalty - trees / 100 * 0.6 - grass / 100 * 0.25,
            0.3,
            1.2,
        )

        n = len(gdf)
        tg = trees + grass
        gt = np.full(n, "none", dtype=object)
        gt[trees >= 15.0] = "trees"
        sel = gt == "none"
        gt[sel & (tg >= 25.0)] = "park"
        sel = gt == "none"
        gt[sel & (grass >= 10.0)] = "grass"
        sel = gt == "none"
        gt[sel & (tg >= 3.0)] = "sparse"
        gdf["green_type"] = gt

    @staticmethod
    def _fill_empty_green(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
        """Заполнить нулями, если спутниковые данные недоступны."""
        gdf["green_percent"] = 0.0
        gdf["trees_percent"] = 0.0
        gdf["grass_percent"] = 0.0
        gdf["green_coeff"] = 1.0
        gdf["green_type"] = "none"
        return gdf

    @staticmethod
    def _log_green_stats(gdf: gpd.GeoDataFrame, buf_m: int) -> None:
        logger.info(
            "Статистика зелени (коридор %dм): деревья=%.1f%%, трава=%.1f%%, всего=%.1f%%",
            buf_m,
            gdf["trees_percent"].mean(),
            gdf["grass_percent"].mean(),
            gdf["green_percent"].mean(),
        )
        logger.info("Категории: %s", dict(gdf["green_type"].value_counts()))
