import os
import random
import srtm
import osmnx as ox
from shapely.geometry import box
import networkx as nx

# Получаем директорию, где находится скрипт
script_dir = os.path.dirname(os.path.abspath(__file__))

# Укажите директорию для кэша
cache_dir = os.path.join(script_dir, "osmnx_cache")
os.makedirs(cache_dir, exist_ok=True)  # Создаем папку, если её не существует
ox.settings.cache_folder = cache_dir  # Устанавливаем её как кэш OSMnx
ox.settings.useful_tags_way += ['surface']

# Инициализируем SRTM (автоматически скачивает нужные тайлы)
elevation_data = srtm.get_data()

# Координаты начальной и конечной точек
start_coords = (53.183458, 50.075996)  # (latitude, longitude)
end_coords = (53.209593, 50.174361)    # (latitude, longitude)

# Координаты для прямоугольника
buffer = 0.01

# Координаты для прямоугольника (с расширением)
min_lat = min(start_coords[0], end_coords[0]) - buffer
min_lon = min(start_coords[1], end_coords[1]) - buffer
max_lat = max(start_coords[0], end_coords[0]) + buffer
max_lon = max(start_coords[1], end_coords[1]) + buffer

# Создаем прямоугольник (bounding box)
bbox = box(min_lon, min_lat, max_lon, max_lat)

custom_filter = (
    '[\"highway\"~\"construction|cycleway|footway|living_street|path|pedestrian|platform|'
    'primary|primary_link|residential|secondary|secondary_link|service|steps|tertiary|'
    'tertiary_link|track|unclassified\"]'
)

G = ox.graph_from_polygon(
    bbox,
    custom_filter=custom_filter,
    simplify=False,
    retain_all=True  # сохраняем даже несвязанные компоненты (может быть полезно для дворов)
)

# Преобразуем граф в GeoDataFrame
edges = ox.graph_to_gdfs(G, nodes=False, edges=True)

# Сохраняем данные в формат Shapefile с явной кодировкой utf-8
edges.set_geometry('geometry', inplace=True)

# Разбиваем многочастные геометрии на отдельные части
edges = edges.explode()

# Функция для определения высоты из SRTM
def get_elevation(lon, lat):
    """Получает высоту по координатам (longitude, latitude)"""
    height = elevation_data.get_elevation(lat, lon)
        return height

# Добавляем разницу высот
def calculate_elevation_diff(line):
    try:
        # line.coords[0] = (lon, lat), line.coords[-1] = (lon, lat)
        start_height = get_elevation(line.coords[0][0], line.coords[0][1])
        end_height = get_elevation(line.coords[-1][0], line.coords[-1][1])

        if start_height is None or end_height is None:
            return 0  # Замена None на 0
        return end_height - start_height
    except Exception as e:
        print(f"Ошибка при вычислении высоты для линии: {line}. Ошибка: {e}")
        return 0

# Словарь коэффициентов для типов покрытий
surface_coefficients = {
    'asphalt': 1.0,
    'concrete': 1.1,
    'concrete:plates': 1.3,      # плиты — немного хуже, чем цельный бетон
    'paved': 1.2,
    'paving_stones': 1.4,        # брусчатка — хуже, чем бетон
    'sett': 1.5,                 # булыжник — трясёт
    'compacted': 1.5,
    'fine_gravel': 1.7,          # мелкий щебень
    'gravel': 2.0,
    'unpaved': 2.5,
    'dirt': 3.0,
    'ground': 3.0,
    'sand': 3.5,
    'grass': 4.0,
}

default_surface_coefficient = 1.0  # если покрытие отсутствует или неизвестно
# Коэффициенты для типа дороги (чем меньше, тем предпочтительнее)
highway_coefficients = {
    'cycleway': 0.3,             # велосипедная дорожка — лучший выбор
    'path': 0.5,                 # пешеходная тропа
    'footway': 1.0,              # обычная пешеходная дорожка
    'residential': 1.0,
    'living_street': 1.0,
    'pedestrian': 1.0,
    'service': 1.1,
    'unclassified': 1.1,
    'track': 1.2,
    'tertiary': 1.2,
    'tertiary_link': 1.2,
    'secondary': 1.3,
    'secondary_link': 1.3,
    'primary': 1.4,
    'primary_link': 1.4,
    'steps': 10.0,               # нежелательный маршрут
    'construction': 100.0        # крайне нежелательно — игнорировать
}
default_highway_coefficient = 1.0  # если покрытие отсутствует или неизвестно

# Добавляем расчет веса дороги
def calculate_weight(length, elevation_diff, surface_type, highway_type, ignore_surface=False, ignore_highway=False):
    mg = 16.66667
    nu = 0.06

    # Коэффициент покрытия
    if ignore_surface:
        surface_coeff = 1.0
    else:
        if isinstance(surface_type, list):
            surface_key = surface_type[0] if surface_type else None
        else:
            surface_key = surface_type
        surface_coeff = surface_coefficients.get(surface_key, default_surface_coefficient)

    # Коэффициент типа дороги
    if ignore_highway:
        highway_coeff = 1.0
    else:
        if isinstance(highway_type, list):
            highway_key = highway_type[0] if highway_type else None
        else:
            highway_key = highway_type
        highway_coeff = highway_coefficients.get(highway_key, default_highway_coefficient)

    # Базовая формула веса
    if elevation_diff >= 0:
        base_weight = mg * (nu * length + elevation_diff)
    else:
        base_weight = mg * (nu * length - abs(elevation_diff))

    final_weight = base_weight * surface_coeff * highway_coeff
    return max(final_weight, 0)

# Применяем функцию к каждому объекту геометрии
edges['elevation_diff'] = edges.geometry.apply(calculate_elevation_diff)
# Вес, учитывающий рельеф и покрытие
# Добавим расчет новых весов
edges['weight_full'] = edges.apply(lambda row: calculate_weight(
    row['length'], row['elevation_diff'], row.get('surface'), row.get('highway')), axis=1)

edges['weight_elevation_only'] = edges.apply(lambda row: calculate_weight(
    row['length'], row['elevation_diff'], row.get('surface'), row.get('highway'),
    ignore_surface=True, ignore_highway=True), axis=1)
# Выводим первые 5 строк с нужными столбцами
edges = edges.reset_index()

# Создаем словари для быстрого поиска весов
weight_full_dict = edges.set_index(['u', 'v', 'key'])['weight_full'].to_dict()
weight_elevation_only_dict = edges.set_index(['u', 'v', 'key'])['weight_elevation_only'].to_dict()

print(edges[['length', 'weight_full', 'weight_elevation_only', 'elevation_diff']].head(5))

# Добавляем веса в рёбра графа G
for u, v, key, data in G.edges(keys=True, data=True):
    data['weight_full'] = weight_full_dict.get((u, v, key))
    data['weight_elevation_only'] = weight_elevation_only_dict.get((u, v, key))
    # 'length' уже есть в data по умолчанию из OSMnx

# Получаем список всех узлов
all_nodes = list(G.nodes)

# Генерируем 20 случайных пар узлов
random_pairs = [(random.choice(all_nodes), random.choice(all_nodes)) for _ in range(20)]

# Инициализируем суммарные стоимости
total_cost_full = 0.0
total_cost_elevation = 0.0
total_cost_elevation_evaluated_by_full = 0.0
successful_routes = 0

for idx, (start_node, end_node) in enumerate(random_pairs):
    if start_node == end_node:
        continue  # пропускаем маршрут в саму себя

    try:
        # Прямой маршрут
        route_full = nx.shortest_path(G, source=start_node, target=end_node, weight='weight_full')
        route_elev = nx.shortest_path(G, source=start_node, target=end_node, weight='weight_elevation_only')

        # Обратный маршрут
        route_full_back = nx.shortest_path(G, source=end_node, target=start_node, weight='weight_full')
        route_elev_back = nx.shortest_path(G, source=end_node, target=start_node, weight='weight_elevation_only')

        # Считаем стоимость маршрутов по нужным весам
        def route_cost(route, weight_key):
            return sum(G.edges[route[i], route[i+1], 0][weight_key] for i in range(len(route)-1))

        # Прямой
        cost_full = route_cost(route_full, 'weight_full')
        cost_elev = route_cost(route_elev, 'weight_elevation_only')
        cost_elev_eval_full = route_cost(route_elev, 'weight_full')

        # Обратный
        cost_full_back = route_cost(route_full_back, 'weight_full')
        cost_elev_back = route_cost(route_elev_back, 'weight_elevation_only')
        cost_elev_eval_full_back = route_cost(route_elev_back, 'weight_full')

        # Накопление
        total_cost_full += cost_full + cost_full_back
        total_cost_elevation += cost_elev + cost_elev_back
        total_cost_elevation_evaluated_by_full += cost_elev_eval_full + cost_elev_eval_full_back

        successful_routes += 2

        print(f"Маршрут {idx + 1}: OK")

    except nx.NetworkXNoPath:
        print(f"Маршрут {idx + 1}: Нет пути между {start_node} и {end_node}")
        continue

# Вывод результатов
print("\n=== Сводка по маршрутам ===")
print(f"Количество успешных маршрутов (включая обратные): {successful_routes}")
print(f"Суммарная стоимость по полному весу (рельеф + покрытие): {total_cost_full:.2f}")
print(f"Суммарная стоимость по рельефу: {total_cost_elevation:.2f}")
print(f"Суммарная стоимость маршрутов по рельефу, оцененная по полным весам: {total_cost_elevation_evaluated_by_full:.2f}")

difference = total_cost_elevation_evaluated_by_full - total_cost_full
if total_cost_full > 0:
    percent_diff = (difference / total_cost_full) * 100
    print(f"Разница в стоимости: {difference:.2f}")
    print(f"Отклонение в процентах: {percent_diff:.2f}%")
else:
    print("Невозможно рассчитать проценты: суммарная стоимость по полному весу равна 0.")