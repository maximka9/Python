from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
import json
from flask_restx import Api, Resource, fields
from flask_cors import CORS
app = Flask(__name__)
CORS(app)  # Включаем CORS для всего приложения
api = Api(app)
# Определите модель запроса с помощью пространства имён (namespace)
ns = api.namespace('route', description='Route operations')

# Модель данных запроса для ваших точек
route_model = api.model('RouteWithCriteria', {
    'start_point': fields.List(fields.Float, required=True, description='Starting point [lat, lon]'),
    'end_point': fields.List(fields.Float, required=True, description='Ending point [lat, lon]'),
    'criteria': fields.String(required=True, description='Routing criteria: "weight" or "length"')
})

# Определите модель ответа
route_response_model = api.model('RouteResponse', {
    'route': fields.List(fields.Nested(api.model('RouteSegment', {
        'id': fields.Integer(description='Edge ID'),
        'cost': fields.Float(description='Cost of the edge'),
        'geometry': fields.Raw(description='GeoJSON geometry of the edge')
    })), description='List of route segments with geometry and cost'),
    'total_cost': fields.Float(description='Total cost of the route')
})
def create_connection():
    return psycopg2.connect(
        host='localhost',
        database='dorogi_2024',
        user='postgres',
        password='Rk.rdtyysqvjhc98'
    )
@ns.route('/')
class RouteResource(Resource):
    @ns.expect(route_model)
    @ns.marshal_with(route_response_model)
    def post(self):
        data = request.get_json()
        start_point = data['start_point']
        end_point = data['end_point']
        criteria = data['criteria']  # Получаем выбранный критерий

        conn = create_connection()
        start_vertex = get_nearest_vertex(start_point[0], start_point[1], conn)
        end_vertex = get_nearest_vertex(end_point[0], end_point[1], conn)
        route, total_cost = calculate_route(start_vertex, end_vertex, criteria, conn)  # Передаем criteria
        conn.close()

        return {
            'route': route,
            'total_cost': total_cost
        }

def get_nearest_vertex(lat, lon, conn):
    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        query = f"""
        SELECT id, ST_Distance(the_geom, ST_SetSRID(ST_MakePoint({lon}, {lat}), 4326)) AS distance
        FROM edges_vertices_pgr
        ORDER BY distance
        LIMIT 1;
        """
        cur.execute(query)
        return cur.fetchone()['id']

def calculate_route(start_vertex, end_vertex, criteria, conn):
    route = []
    total_cost = 0

    if criteria == 'weight':
        cost_column = 'weight'
    elif criteria == 'length':
        cost_column = 'length'
    else:
        raise ValueError('Invalid criteria')

    edges_query = f"""
        SELECT seq, di.node, di.edge, e.{cost_column} AS cost, ST_AsGeoJSON(e.geometry) as geom
        FROM pgr_dijkstra(
            'SELECT id, source, target, {cost_column} AS cost FROM edges',
            %s, %s, directed := true
        ) as di
        JOIN edges e ON di.edge = e.id
    """
    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(edges_query, (start_vertex, end_vertex))
        route_segments = cur.fetchall()

        for segment in route_segments:
            if segment['edge'] is not None and segment['edge'] > 0:
                edge_data = {
                    'id': segment['edge'],
                    'cost': segment['cost'],
                    'geometry': json.loads(segment['geom'])
                }
                route.append(edge_data)
                total_cost += segment['cost']

    return route, total_cost


    return route, total_cost
if __name__ == '__main__':
    app.run(debug=True)