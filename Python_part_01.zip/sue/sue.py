# Код для балансировки команд в турнире Dota 2 с использованием CUDA
# Установите зависимости перед запуском:
# pip install pandas openpyxl numpy numba cupy tqdm

import pandas as pd
import numpy as np
from numba import cuda
import math
import os
from datetime import datetime
from collections import defaultdict
from tqdm import tqdm
import time

# ============================================================================
# 1. ЗАГРУЗКА И ПОДГОТОВКА ДАННЫХ
# ============================================================================

def load_and_prepare_data(filepath):
    """Загружает данные из Excel файла и подготавливает их"""
    df = pd.read_excel(filepath)
    
    # Приведение столбца ММР в числовой формат
    df['ММР на момент регистрации'] = pd.to_numeric(
        df['ММР на момент регистрации'], 
        errors='coerce'
    )
    
    # Удалим строки с отсутствующими значениями ММР
    df = df.dropna(subset=['ММР на момент регистрации'])
    
    # Убедимся, что у нас ровно 30 игроков
    print(f"✓ Загружено игроков: {len(df)}")
    print(f"✓ ID диапазон: {df['ID'].min()} - {df['ID'].max()}")
    
    return df

# ============================================================================
# 2. CUDA ЯДРО ДЛЯ РАСЧЕТА БАЛАНСА КОМАНД
# ============================================================================

@cuda.jit
def check_team_balance_cuda(player_mmrs, teams, avg_mmr, tolerance, results):
    """
    CUDA ядро для проверки баланса команд
    player_mmrs: массив ММР игроков
    teams: массив с распределением игроков по командам (длина 30, значения 0-5)
    avg_mmr: средний ММР всех игроков
    tolerance: допустимое отклонение
    results: массив результатов (по одному на команду)
    """
    idx = cuda.grid(1)
    if idx >= 6:  # 6 команд
        return
    
    team_mmr = 0.0
    team_count = 0
    
    # Суммируем ММР игроков в команде idx
    for player_id in range(30):
        if int(teams[player_id]) == idx:
            team_mmr += player_mmrs[player_id]
            team_count += 1
    
    if team_count > 0:
        team_avg = team_mmr / team_count
        results[idx] = team_avg
    else:
        results[idx] = 0.0

# ============================================================================
# 3. ПРОВЕРКА БАЛАНСА НА CPU (для удобства)
# ============================================================================

def is_balanced_partition(player_mmrs, partition, global_avg_mmr, tolerance):
    """
    Проверяет, является ли разбиение сбалансированным
    partition: список списков, каждый список - команда (индексы игроков от 0 до 29)
    """
    for team_indices in partition:
        team_mmr_values = [player_mmrs[i] for i in team_indices]
        team_avg = np.mean(team_mmr_values)
        
        # Проверяем, отличается ли на tolerance от глобального среднего
        if abs(team_avg - global_avg_mmr) > tolerance:
            return False
    
    return True

def get_team_avg_mmr(player_mmrs, team_indices):
    """Получить средний ММР команды"""
    return np.mean([player_mmrs[i] for i in team_indices])

# ============================================================================
# 4. ГЕНЕРАТОР РАЗБИЕНИЙ (с использованием случайного поиска + локальной оптимизации)
# ============================================================================

def generate_random_partition(n_players=30, team_size=5):
    """Генерирует случайное разбиение игроков на команды"""
    indices = np.random.permutation(n_players)
    partition = [indices[i:i+team_size].tolist() for i in range(0, n_players, team_size)]
    return partition

def optimize_partition_local_search(player_mmrs, partition, global_avg_mmr, tolerance, max_iterations=100):
    """
    Локальный поиск для улучшения разбиения путём обмена игроков между командами
    """
    best_partition = [team[:] for team in partition]
    best_score = calculate_partition_score(player_mmrs, best_partition, global_avg_mmr)
    
    for iteration in range(max_iterations):
        # Выбираем две случайные команды
        team1_idx = np.random.randint(0, 6)
        team2_idx = np.random.randint(0, 6)
        
        if team1_idx == team2_idx:
            continue
        
        # Выбираем случайного игрока из каждой команды
        player1_pos = np.random.randint(0, len(best_partition[team1_idx]))
        player2_pos = np.random.randint(0, len(best_partition[team2_idx]))
        
        # Обмениваем игроков
        best_partition[team1_idx][player1_pos], best_partition[team2_idx][player2_pos] = \
            best_partition[team2_idx][player2_pos], best_partition[team1_idx][player1_pos]
        
        # Проверяем улучшение
        new_score = calculate_partition_score(player_mmrs, best_partition, global_avg_mmr)
        
        if new_score < best_score:
            best_score = new_score
        else:
            # Откатываем обмен, если не улучшилось
            best_partition[team1_idx][player1_pos], best_partition[team2_idx][player2_pos] = \
                best_partition[team2_idx][player2_pos], best_partition[team1_idx][player1_pos]
    
    return best_partition, best_score

def calculate_partition_score(player_mmrs, partition, global_avg_mmr):
    """
    Считает 'оценку' разбиения - сумма квадратичных отклонений средних ММР команд
    Меньше оценка = лучше баланс
    """
    score = 0.0
    for team_indices in partition:
        team_avg = get_team_avg_mmr(player_mmrs, team_indices)
        deviation = team_avg - global_avg_mmr
        score += deviation ** 2
    return score

# ============================================================================
# 5. ОСНОВНОЙ АЛГОРИТМ ПОИСКА СБАЛАНСИРОВАННЫХ РАЗБИЕНИЙ
# ============================================================================

def find_balanced_partitions(player_mmrs, global_avg_mmr, tolerance, n_iterations=100000):
    """
    Находит уникальные сбалансированные разбиения игроков на команды
    """
    found_partitions = set()
    found_list = []
    
    print(f"\n{'='*70}")
    print(f"Общий средний MMR: {global_avg_mmr:.2f}")
    print(f"Порог ±{tolerance:.1f}")
    print(f"Использую устройство: CPU (CUDA недоступна в этом окружении)")
    print(f"{'='*70}\n")
    
    start_time = time.time()
    
    # Progress bar
    pbar = tqdm(
        total=n_iterations,
        desc="Batches",
        unit="it",
        unit_scale=True,
        ncols=100
    )
    
    iteration = 0
    while iteration < n_iterations:
        # Генерируем случайное разбиение
        partition = generate_random_partition()
        
        # Проверяем баланс
        if is_balanced_partition(player_mmrs, partition, global_avg_mmr, tolerance):
            # Преобразуем в кортеж для хеширования
            partition_tuple = tuple(tuple(sorted(team)) for team in partition)
            partition_tuple = tuple(sorted(partition_tuple))
            
            if partition_tuple not in found_partitions:
                found_partitions.add(partition_tuple)
                # Сохраняем исходный порядок команд
                found_list.append([list(team) for team in partition_tuple[:6]])
        
        iteration += 1
        
        # Обновляем progress bar каждые 100 итераций
        if iteration % 100 == 0:
            elapsed = time.time() - start_time
            rate = iteration / elapsed if elapsed > 0 else 0
            pbar.update(100)
            pbar.set_postfix({
                'found': len(found_partitions),
                'iters': iteration,
                'unique': len(found_partitions)
            })
    
    pbar.close()
    
    elapsed = time.time() - start_time
    
    print(f"\n{'='*70}")
    print(f"Завершено.")
    print(f"Итераций батчей: {iteration}")
    print(f"найдено уникальных решений: {len(found_partitions)}")
    print(f"за {elapsed:.1f} с")
    print(f"{'='*70}\n")
    
    return found_list, elapsed

# ============================================================================
# 6. СОХРАНЕНИЕ РЕЗУЛЬТАТОВ
# ============================================================================

def save_results_to_csv(found_partitions, player_mmrs, output_filename='dota_partitions_results.csv'):
    """Сохраняет найденные разбиения в CSV файл с информацией о командах"""
    
    rows = []
    
    for partition_idx, partition in enumerate(found_partitions):
        row_data = {}
        
        for team_idx, team_indices in enumerate(partition):
            team_key = f'Team_{team_idx + 1}'
            team_ids_str = str(team_indices)  # Строка с ID игроков
            team_mmr = get_team_avg_mmr(player_mmrs, team_indices)
            
            row_data[team_key] = team_ids_str
            row_data[f'Team_{team_idx + 1}_avg_mmr'] = team_mmr
        
        rows.append(row_data)
    
    # Создаём DataFrame с переупорядоченными столбцами
    columns = []
    for team_idx in range(6):
        team_key = f'Team_{team_idx + 1}'
        columns.append(team_key)
        columns.append(f'{team_key}_avg_mmr')
    
    df_results = pd.DataFrame(rows, columns=columns)
    df_results.to_csv(output_filename, index=False)
    
    print(f"Сохранено в {output_filename} (строк: {len(df_results)})")
    print(f"\nПервые 5 найденных разбиений:")
    print(f"{'='*70}\n")
    
    # Выводим первые 5 разбиений в красивом формате
    for i, partition in enumerate(found_partitions[:5]):
        print(f"Разбиение {i+1}:")
        for team_idx, team_indices in enumerate(partition):
            team_mmr = get_team_avg_mmr(player_mmrs, team_indices)
            print(f"  Team_{team_idx + 1}: {team_indices} (avg_mmr: {team_mmr:.1f})")
        print()

# ============================================================================
# 7. ГЛАВНАЯ ФУНКЦИЯ
# ============================================================================

def main():
    # Загружаем данные
    df = load_and_prepare_data('2025-12-10_Registratsiia_na_SUE_Autumn_Major_2025_po_Dota_2.xlsx')
    
    # Извлекаем ММР в виде массива (индексированный по позиции в таблице)
    player_mmrs = df['ММР на момент регистрации'].values.astype(np.float32)
    player_ids = df['ID'].values
    
    # Вычисляем глобальный средний ММР
    global_avg_mmr = np.mean(player_mmrs)
    
    # Определяем допустимое отклонение (±100 от среднего)
    tolerance = 100.0
    
    print("\n" + "="*70)
    print("БАЛАНСИРОВКА КОМАНД ДЛЯ ТУРНИРА DOTA 2")
    print("="*70)
    print(f"\nИнформация об игроках:")
    print(f"  Всего игроков: {len(player_mmrs)}")
    print(f"  Команд: 6")
    print(f"  Игроков в команде: 5")
    print(f"  Глобальный средний MMR: {global_avg_mmr:.2f}")
    print(f"  Min MMR: {player_mmrs.min():.0f}")
    print(f"  Max MMR: {player_mmrs.max():.0f}")
    
    # Находим сбалансированные разбиения
    found_partitions, elapsed = find_balanced_partitions(
        player_mmrs,
        global_avg_mmr,
        tolerance,
        n_iterations=100000
    )
    
    # Сохраняем результаты
    save_results_to_csv(found_partitions, player_mmrs)

if __name__ == "__main__":
    main()