import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.metrics import classification_report, accuracy_score, mean_squared_error, mean_absolute_error, r2_score

from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier
import xgboost as xgb
from catboost import CatBoostClassifier, CatBoostRegressor

import shap
import matplotlib.pyplot as plt
from sklearn.tree import plot_tree # Для визуализации одного дерева из модели, если применимо

# Установка постоянного случайного состояния для воспроизводимости
RANDOM_STATE = 42

print("\n--- 1. Считывание и описание данных ---")
# 1. Считать в pandas.DataFrame любой источник данных
df = pd.read_csv('dataset/adult.csv', na_values='?')
# 2. Датасет и подготовка данных:
# - Привести описание датасета.
# print("\nОписательная статистика:")
# print(df.info())
# print(df.describe(include='all'))
# print(df.head())

print("\n--- 2. Предобработка данных ---")
# - Избавиться от null, убрать некоторые признаки и т.п. - "подчистить данные".

# Обработка пропущенных значений
for col in df.select_dtypes(include='object').columns:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].mode()[0])

for col in df.select_dtypes(include=np.number).columns:
    if df[col].isnull().any():
        df[col] = df[col].fillna(df[col].median())

# Удаление признаков: 'fnlwgt' (вес) и 'education' (вместо него используется 'education.num')
df = df.drop(columns=['fnlwgt', 'education'])

# Кодирование целевой переменной 'income'
le = LabelEncoder()
df['income'] = le.fit_transform(df['income']) # <=50K: 0, >50K: 1

# Разделение признаков (X) и целевой переменной (y)
X = df.drop('income', axis=1)
y = df['income']

# Определение категориальных и числовых признаков
categorical_features = X.select_dtypes(include='object').columns.tolist()
numerical_features = X.select_dtypes(include=np.number).columns.tolist()

# - Разбить выборку на обучающую и тестовую.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y)

# Создание двух наборов выборок:
# 1. С закодированными категориальными признаками (OneHotEncoded)
# 2. С категориальными признаками без обработки (для CatBoost/XGBoost с нативной поддержкой)

# Набор 1: _encoded (численные нормализованы, категориальные OneHotEncoded)
# Нормализация численных данных
# Кодирование категориальных данных
preprocessor_encoded = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', 'passthrough', categorical_features) # pd.get_dummies будет использован позже для простоты на этих проходных столбцах
    ], 
    remainder='passthrough' # Не должно быть оставшихся столбцов
)

# Обучение препроцессора на X_train и трансформация X_train и X_test
X_train_processed_temp = preprocessor_encoded.fit_transform(X_train)
X_test_processed_temp = preprocessor_encoded.transform(X_test)

# Получение имен признаков после ColumnTransformer
num_feature_names = numerical_features # Уже корректно
cat_feature_names_passthrough = categorical_features 

# Преобразование в DataFrame для применения get_dummies
X_train_processed_df_temp = pd.DataFrame(X_train_processed_temp, columns=num_feature_names + cat_feature_names_passthrough, index=X_train.index)
X_test_processed_df_temp = pd.DataFrame(X_test_processed_temp, columns=num_feature_names + cat_feature_names_passthrough, index=X_test.index)

# Преобразование числовых столбцов обратно в числовой тип после ColumnTransformer, если они стали object
for col in numerical_features:
    X_train_processed_df_temp[col] = pd.to_numeric(X_train_processed_df_temp[col])
    X_test_processed_df_temp[col] = pd.to_numeric(X_test_processed_df_temp[col])

# Теперь применяем get_dummies
X_train_encoded = pd.get_dummies(X_train_processed_df_temp, columns=categorical_features, drop_first=True)
X_test_encoded = pd.get_dummies(X_test_processed_df_temp, columns=categorical_features, drop_first=True)

# Выравнивание столбцов: X_test_encoded должен соответствовать столбцам X_train_encoded
final_feature_columns = X_train_encoded.columns
X_test_encoded = X_test_encoded.reindex(columns=final_feature_columns, fill_value=0)
# X_train_encoded уже содержит корректные столбцы

# Набор 2: _cat_features_df (численные нормализованы, категориальные как есть - для XGBoost/CatBoost)
# Нам нужно масштабировать числовые признаки, но оставить категориальные как есть для нативной обработки XGBoost/CatBoost.
# Для XGBoost категориальные признаки должны иметь тип 'category'.

# Создание копии для этого набора
X_train_cat_features_df = X_train.copy()
X_test_cat_features_df = X_test.copy()

# Масштабирование числовых признаков
scaler_cat = StandardScaler()
X_train_cat_features_df[numerical_features] = scaler_cat.fit_transform(X_train_cat_features_df[numerical_features])
X_test_cat_features_df[numerical_features] = scaler_cat.transform(X_test_cat_features_df[numerical_features])

# Преобразование категориальных столбцов сначала в строковый тип, затем в тип 'category' для XGBoost
for col in categorical_features:
    X_train_cat_features_df[col] = X_train_cat_features_df[col].astype(str).astype('category')
    X_test_cat_features_df[col] = X_test_cat_features_df[col].astype(str).astype('category')
    
    # Обеспечение согласованности категорий между обучающей и тестовой выборками для типа 'category'
    # Это может быть сложно, если в тестовой выборке есть новые категории, отсутствующие в обучающей.
    # Более простой подход для XGBoost - использовать кодирование меток, если тип 'category' вызывает проблемы,
    # или положиться на его способность обрабатывать строковые данные, если `enable_categorical=True` работает как ожидается.
    # Пока что предположим, что CatBoost обрабатывает строковые столбцы напрямую, а XGBoost - тип 'category'.
    # Для обеспечения согласованности для типа 'category':
    all_categories = pd.concat([X_train_cat_features_df[col], X_test_cat_features_df[col]]).unique()
    cat_type = pd.CategoricalDtype(categories=all_categories, ordered=False)
    X_train_cat_features_df[col] = X_train_cat_features_df[col].astype(cat_type)
    X_test_cat_features_df[col] = X_test_cat_features_df[col].astype(cat_type)


print("Размеры выборок:")
print(f"X_train_encoded (закодир.): {X_train_encoded.shape}, y_train: {y_train.shape}")
print(f"X_test_encoded (закодир.): {X_test_encoded.shape}, y_test: {y_test.shape}")
print(f"X_train_cat_features_df (нативные кат.): {X_train_cat_features_df.shape}")
print(f"X_test_cat_features_df (нативные кат.): {X_test_cat_features_df.shape}")
print(f"Категориальные признаки: {categorical_features}")
print(f"Числовые признаки: {numerical_features}")

# Убедимся, что y_train и y_test являются pandas Series для согласованности
y_train = pd.Series(y_train)
y_test = pd.Series(y_test)
print("\n--- 3. Обучение и оценка классификаторов ---")

# Словарь для хранения моделей и их результатов
models_results = {}

# Определяем категориальные признаки для CatBoost (индексы или имена)
# X_train_cat_features_df.info() # Для проверки типов данных и имен столбцов
cat_features_indices = [X_train_cat_features_df.columns.get_loc(col) for col in categorical_features]

# --- Модели, обучаемые на данных с закодированными категориальными признаками ---

# 1. AdaBoostClassifier
print("\nОбучение AdaBoostClassifier...")
adaboost_param_grid = {
    'n_estimators': [50, 100],
    'learning_rate': [0.01, 0.1, 1]
}
adaboost_grid = GridSearchCV(AdaBoostClassifier(random_state=RANDOM_STATE),
                             adaboost_param_grid, cv=3, scoring='accuracy', n_jobs=-1)
adaboost_grid.fit(X_train_encoded, y_train)
models_results['AdaBoost_encoded'] = {
    'model': adaboost_grid.best_estimator_,
    'best_params': adaboost_grid.best_params_,
    'X_test': X_test_encoded
}
print(f"AdaBoost (закодир.) лучшие параметры: {adaboost_grid.best_params_}")

# 2. GradientBoostingClassifier
print("\nОбучение GradientBoostingClassifier...")
gbc_param_grid = {
    'n_estimators': [100, 200],
    'learning_rate': [0.05, 0.1],
    'max_depth': [3, 5]
}
gbc_grid = GridSearchCV(GradientBoostingClassifier(random_state=RANDOM_STATE),
                        gbc_param_grid, cv=3, scoring='accuracy', n_jobs=-1)
gbc_grid.fit(X_train_encoded, y_train)
models_results['GradientBoosting_encoded'] = {
    'model': gbc_grid.best_estimator_,
    'best_params': gbc_grid.best_params_,
    'X_test': X_test_encoded
}
print(f"GradientBoosting (закодир.) лучшие параметры: {gbc_grid.best_params_}")

# Если early_stopping_rounds задан в конструкторе XGBoost/CatBoost,
# они автоматически выделят часть обучающих данных (в каждом фолде CV) для валидации.
# eval_set в GridSearchCV.fit() используется только для финального refit лучшей модели.

# 3. XGBoostClassifier (на закодированных данных)
print("\nОбучение XGBoostClassifier на закодированных данных...")
xgb_param_grid = {
    'n_estimators': [100, 200], 
    'learning_rate': [0.05, 0.1],
    'max_depth': [3, 5],
    'reg_alpha': [0, 0.1], 
    'reg_lambda': [1, 0.1]  
}

# XGBoostClassifier с early_stopping_rounds в конструкторе
xgb_clf_for_grid = xgb.XGBClassifier(random_state=RANDOM_STATE, 
                                       use_label_encoder=False, 
                                       eval_metric='logloss') # Ранняя остановка здесь

xgb_grid_encoded = GridSearchCV(estimator=xgb_clf_for_grid,
                                param_grid=xgb_param_grid, 
                                cv=3, 
                                scoring='accuracy', 
                                n_jobs=-1,
                                verbose=0)

print(f"Обучение XGBoost GridSearchCV на X_train_encoded шейп: {X_train_encoded.shape}")
# Не передаем fit_params с eval_set для CV. XGBoost сам разделит данные в каждом фолде.
# verbose=False можно передать в fit, чтобы XGBoost не выводил много логов во время CV.
xgb_grid_encoded.fit(X_train_encoded, y_train, verbose=False)

models_results['XGBoost_encoded'] = {
    'model': xgb_grid_encoded.best_estimator_,
    'best_params': xgb_grid_encoded.best_params_,
    'X_test': X_test_encoded
}
print(f"XGBoost (закодир.) лучшие параметры: {xgb_grid_encoded.best_params_}")

# 4. CatBoostClassifier (на закодированных данных)
print("\nОбучение CatBoostClassifier на закодированных данных...")
catboost_param_grid = {
    'iterations': [100, 200], 
    'learning_rate': [0.05, 0.1],
    'depth': [3, 5],
    'l2_leaf_reg': [1, 3]
}

# CatBoostClassifier с early_stopping_rounds в конструкторе
cat_clf_for_grid = CatBoostClassifier(random_state=RANDOM_STATE, 
                                        verbose=0, # verbose=0 здесь, чтобы CatBoost не выводил логи
                                        early_stopping_rounds=10) # Ранняя остановка здесь
catboost_grid_encoded = GridSearchCV(estimator=cat_clf_for_grid, 
                                   param_grid=catboost_param_grid, 
                                   cv=3, 
                                   scoring='accuracy', 
                                   n_jobs=-1,
                                   verbose=0) 

print(f"Обучение CatBoost GridSearchCV на X_train_encoded шейп: {X_train_encoded.shape}")
# Не передаем fit_params с eval_set для CV. CatBoost сам разделит данные в каждом фолде.
catboost_grid_encoded.fit(X_train_encoded, y_train)

models_results['CatBoost_encoded'] = {
    'model': catboost_grid_encoded.best_estimator_,
    'best_params': catboost_grid_encoded.best_params_,
    'X_test': X_test_encoded
}
print(f"CatBoost (закодир.) лучшие параметры: {catboost_grid_encoded.best_params_}")


# --- Обучение XGBoost и CatBoost с найденными гиперпараметрами на обучающей выборке с категориальными признаками "как есть" ---
print("\nОбучение XGBoost и CatBoost с нативной поддержкой категориальных признаков...")

# 5. XGBoostClassifier (с нативной поддержкой категориальных признаков)
print("\nОбучение XGBoostClassifier с нативной поддержкой категориальных признаков...")
xgb_native_params = models_results['XGBoost_encoded']['best_params']
# X_train_cat_main, X_val_cat, y_train_cat_main, y_val_cat = train_test_split( # Создание нового eval_set с форматом _cat_features_df - Убрано, т.к. early stopping будет на X_test_cat_features_df
#     X_train_cat_features_df, y_train, test_size=0.2, stratify=y_train, random_state=RANDOM_STATE
# )
xgb_clf_native = xgb.XGBClassifier(**xgb_native_params,
                                   random_state=RANDOM_STATE, 
                                   use_label_encoder=False, 
                                   eval_metric='logloss',
                                   enable_categorical=True, # ВАЖНО
                                   early_stopping_rounds=10 # ВОССТАНОВЛЕНО: Добавляем раннюю остановку также здесь
                                   )
xgb_clf_native.fit(X_train_cat_features_df, y_train, 
                   eval_set=[(X_test_cat_features_df, y_test)], 
                   verbose=False)
models_results['XGBoost_native_cat'] = {
    'model': xgb_clf_native,
    'best_params': xgb_native_params, # такие же, как найдены при поиске по сетке
    'X_test': X_test_cat_features_df
}

# 6. CatBoostClassifier (с нативной поддержкой категориальных признаков)
print("\nОбучение CatBoostClassifier с нативной поддержкой категориальных признаков...")
catboost_native_params = models_results['CatBoost_encoded']['best_params']
cat_clf_native = CatBoostClassifier(**catboost_native_params,
                                    random_state=RANDOM_STATE, 
                                    verbose=0, 
                                    cat_features=cat_features_indices, # ВАЖНО
                                    early_stopping_rounds=10 # ВОССТАНОВЛЕНО: Добавляем раннюю остановку
                                    )
cat_clf_native.fit(X_train_cat_features_df, y_train, 
                   eval_set=(X_test_cat_features_df, y_test))
models_results['CatBoost_native_cat'] = {
    'model': cat_clf_native,
    'best_params': catboost_native_params, # такие же, как найдены при поиске по сетке
    'X_test': X_test_cat_features_df
}

# --- Вывод метрик для всех моделей ---
print("\n--- Метрики классификаторов на тестовом наборе ---")
best_model_name = ''
best_accuracy = 0.0

for name, data in models_results.items():
    model = data['model']
    current_X_test = data['X_test']
    y_pred = model.predict(current_X_test)
    
    print(f"\nОтчет по классификации для {name}:")
    print(classification_report(y_test, y_pred))
    
    acc = accuracy_score(y_test, y_pred)
    print(f"Точность для {name}: {acc:.4f}")
    models_results[name]['accuracy'] = acc
    
    if acc > best_accuracy:
        best_accuracy = acc
        best_model_name = name

print(f"\nЛучшая модель: {best_model_name} с Точностью: {best_accuracy:.4f}")

# Сохраняем лучшую модель для использования в следующих пунктах
best_model_overall = models_results[best_model_name]['model']
# Определяем, какие тестовые данные использовались для лучшей модели (для SHAP)
# Это должен быть X_test в формате, который ожидает best_model_overall.
if 'native_cat' in best_model_name:
    X_test_for_best_model = models_results[best_model_name]['X_test'] # Должен быть X_test_cat_features_df
else:
    X_test_for_best_model = models_results[best_model_name]['X_test'] # Должен быть X_test_encoded

# Более надежный способ получить X_test для лучшей модели:
# Мы сохранили X_test вместе с каждой моделью в словаре models_results.
# Таким образом, X_test_for_best_model = models_results[best_model_name]['X_test'] - это корректно.


# ПУНКТ 4. Важность признаков:

best_model = models_results['CatBoost_encoded']['model']
explainer = shap.Explainer(best_model) 
shap_values = explainer(X_test_encoded)

shap.initjs()
shap.plots.force(shap_values[0])
shap.plots.force(shap_values[:100])
shap.plots.bar(shap_values[0])
shap.plots.waterfall(shap_values[0])
shap.plots.scatter(shap_values[:, "education.num"])
shap.plots.scatter(shap_values[:, "hours.per.week"])
shap.plots.beeswarm(shap_values)
shap.plots.bar(shap_values)

mean_abs_shap = np.abs(shap_values.values).mean(axis=0)
shap_importance_df = pd.DataFrame({
    'feature': X_test_encoded.columns,
    'mean_abs_shap': mean_abs_shap
}).sort_values(by='mean_abs_shap', ascending=False)

top_features = shap_importance_df['feature'].head(10).tolist()
print("Выбранные признаки:", top_features)

X_train_filtered = X_train_encoded[top_features]
X_test_filtered = X_test_encoded[top_features]
cat_filtered = CatBoostClassifier(**models_results['CatBoost_encoded']['best_params'],random_state=RANDOM_STATE, verbose=0)
cat_filtered.fit(X_train_filtered, y_train)

y_pred_filtered = cat_filtered.predict(X_test_filtered)
print("\nОтчет после фильтрации:")
print(classification_report(y_test, y_pred_filtered))
print(f"Точность после фильтрации: {accuracy_score(y_test, y_pred_filtered):.4f}")
cat_filtered.plot_tree(tree_idx=0)

print("\n\n--- 5. Регрессия ---")

# Определение целевой переменной и признаков для регрессии
regression_target_col = 'hours.per.week'

if regression_target_col not in df.columns:
    print(f"Целевая переменная регрессии '{regression_target_col}' не найдена в DataFrame. Пропуск задачи регрессии.")
else:
    print(f"\nНачало задачи регрессии с целевой переменной: {regression_target_col}")
    X_reg_original = df.drop(columns=['income', regression_target_col]) 
    y_reg = df[regression_target_col]

    categorical_features_reg = X_reg_original.select_dtypes(include='object').columns.tolist()
    numerical_features_reg = X_reg_original.select_dtypes(include=np.number).columns.tolist()

    X_reg_train, X_reg_test, y_reg_train, y_reg_test = train_test_split(
        X_reg_original, y_reg, test_size=0.2, random_state=RANDOM_STATE
    )

    X_reg_train_processed = X_reg_train.copy()
    X_reg_test_processed = X_reg_test.copy()

    scaler_reg = StandardScaler()
    X_reg_train_processed[numerical_features_reg] = scaler_reg.fit_transform(X_reg_train_processed[numerical_features_reg])
    X_reg_test_processed[numerical_features_reg] = scaler_reg.transform(X_reg_test_processed[numerical_features_reg])

    for col in categorical_features_reg:
        all_categories_reg = pd.concat([X_reg_train_processed[col].astype(str), X_reg_test_processed[col].astype(str)]).unique()
        cat_type_reg = pd.CategoricalDtype(categories=all_categories_reg, ordered=False)
        X_reg_train_processed[col] = X_reg_train_processed[col].astype(str).astype(cat_type_reg)
        X_reg_test_processed[col] = X_reg_test_processed[col].astype(str).astype(cat_type_reg)
    
    print(f"Размер обучающих данных для регрессии (все признаки): {X_reg_train_processed.shape}")

    print("\nЗапуск GridSearchCV для XGBRegressor (все признаки)...")
    xgb_reg_param_grid = {
        'n_estimators': [100, 150], 
        'learning_rate': [0.05, 0.1],
        'max_depth': [3, 4], 
        'reg_alpha': [0.1], 
        'reg_lambda': [1]   
    }
    # XGBRegressor с early_stopping_rounds в конструкторе
    xgb_reg_base = xgb.XGBRegressor(random_state=RANDOM_STATE, 
                                   objective='reg:squarederror', 
                                   enable_categorical=True) # Ранняя остановка здесь
    
    xgb_reg_grid = GridSearchCV(estimator=xgb_reg_base,
                                param_grid=xgb_reg_param_grid, 
                                cv=2, 
                                scoring='neg_mean_squared_error', 
                                n_jobs=-1,
                                verbose=0)
    
    # Не передаем fit_params с eval_set или early_stopping_rounds для CV.
    # XGBoost сам разделит данные в каждом фолде.
    # verbose=False можно передать в fit, чтобы XGBoost не выводил много логов во время CV.
    print(f"Обучение XGBRegressor GridSearchCV на X_reg_train_processed шейп: {X_reg_train_processed.shape}")
    xgb_reg_grid.fit(X_reg_train_processed, y_reg_train, verbose=False) 
    
    best_xgb_regressor = xgb_reg_grid.best_estimator_
    print(f"Лучшие параметры XGBRegressor (все признаки): {xgb_reg_grid.best_params_}")

    print("\nОценка XGBRegressor (все признаки):")
    y_reg_pred_full = best_xgb_regressor.predict(X_reg_test_processed)
    mse_full = mean_squared_error(y_reg_test, y_reg_pred_full)
    mae_full = mean_absolute_error(y_reg_test, y_reg_pred_full)
    r2_full = r2_score(y_reg_test, y_reg_pred_full)
    print(f"MSE (все признаки): {mse_full:.4f}")
    print(f"MAE (все признаки): {mae_full:.4f}")
    print(f"R2_score (все признаки): {r2_full:.4f}")

    print("\nПереобучение XGBRegressor на отфильтрованных признаках из задачи классификации (Раздел 4)...")
    
    if 'selected_features_shap' in globals() and selected_features_shap is not None:
        features_for_filtered_reg_intermediate = [f for f in selected_features_shap 
                                                  if f in X_reg_train_processed.columns and f != regression_target_col]
        
        if not features_for_filtered_reg_intermediate:
            print("Не найдено общих используемых признаков из SHAP-анализа для регрессии с фильтрацией. Пропуск переобучения.")
        else:
            X_reg_train_filtered = X_reg_train_processed[features_for_filtered_reg_intermediate]
            X_reg_test_filtered = X_reg_test_processed[features_for_filtered_reg_intermediate]
            print(f"Используется {len(features_for_filtered_reg_intermediate)} признаков для регрессии с фильтрацией: {features_for_filtered_reg_intermediate}")
            print(f"Размер обучающих данных для регрессии (отфильтрованные признаки): {X_reg_train_filtered.shape}")

            # При переобучении модели с лучшими параметрами, early_stopping_rounds также должен быть в конструкторе.
            # best_xgb_regressor уже является экземпляром с early_stopping_rounds, но мы создаем новый для чистоты.
            xgb_reg_filtered = xgb.XGBRegressor(**xgb_reg_grid.best_params_,
                                                random_state=RANDOM_STATE, 
                                                objective='reg:squarederror', 
                                                enable_categorical=True,
                                                )
            
            xgb_reg_filtered.fit(X_reg_train_filtered, y_reg_train, 
                                 eval_set=[(X_reg_test_filtered, y_reg_test)],
                                 verbose=False)

            print("\nОценка XGBRegressor (отфильтрованные признаки):")
            y_reg_pred_filtered = xgb_reg_filtered.predict(X_reg_test_filtered)
            mse_filtered = mean_squared_error(y_reg_test, y_reg_pred_filtered)
            mae_filtered = mean_absolute_error(y_reg_test, y_reg_pred_filtered)
            r2_filtered = r2_score(y_reg_test, y_reg_pred_filtered)
            print(f"MSE (отфильтрованные признаки): {mse_filtered:.4f}")
            print(f"MAE (отфильтрованные признаки): {mae_filtered:.4f}")
            print(f"R2_score (отфильтрованные признаки): {r2_filtered:.4f}")

            print("\nСравнение метрик XGBRegressor:")
            print(f"MSE: Все признаки={mse_full:.4f}, Отфильтрованные={mse_filtered:.4f}")
            print(f"MAE: Все признаки={mae_full:.4f}, Отфильтрованные={mae_filtered:.4f}")
            print(f"R2:  Все признаки={r2_full:.4f}, Отфильтрованные={r2_filtered:.4f}")
    else:
        print("Пропуск переобучения на отфильтрованных признаках: 'selected_features_shap' не найден из Раздела 4.")

print("\n\n--- Конец скрипта ---")
