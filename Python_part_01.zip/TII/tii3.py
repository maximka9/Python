import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('dataset/players_info.csv')
# 2.1. Предобработка для бинарной классификации 
cols_to_numeric = ['age', 'weight_(in kg)', 'height_(in cm)', 'ovr', 'pac', 'sho', 'pas', 'dri', 'def', 'phy',
                   'pac+-', 'sho+-', 'pas+-', 'dri+-', 'def+-', 'phy+-']
for col in cols_to_numeric:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

df.dropna(subset=['age', 'ovr', 'height_(in cm)', 'weight_(in kg)', 'gender', 'position', 'preffered_foot'], inplace=True)
df_bin = df.copy()
target_bin = 'gender'
le_gender = LabelEncoder()
df_bin[target_bin] = le_gender.fit_transform(df_bin[target_bin])

numerical_features_bin = ['age', 'weight_(in kg)', 'height_(in cm)', 'ovr', 'pac', 'sho', 'pas', 'dri', 'def', 'phy']
categorical_features_bin = ['preffered_foot', 'position']

df_bin = pd.get_dummies(df_bin, columns=categorical_features_bin, dummy_na=False)

features_to_drop_bin = [target_bin, 'rank', 'player_name', 'club', 'nationality', 'league', 'alt_position', 'image_url',
                        'pac+-', 'sho+-', 'pas+-', 'dri+-', 'def+-', 'phy+-'] 

features_to_drop_bin_existing = [col for col in features_to_drop_bin if col in df_bin.columns]
X_bin = df_bin.drop(columns=features_to_drop_bin_existing)
y_bin = df_bin[target_bin]

X_bin = X_bin.apply(pd.to_numeric, errors='coerce')
X_bin.fillna(0, inplace=True) 
# 2.2. Классификация на "сырых" данных 
k_initial_bin = 5
X_train_bin, X_test_bin, y_train_bin, y_test_bin = train_test_split(X_bin, y_bin, test_size=0.3, random_state=42, stratify=y_bin)
knn_raw_bin = KNeighborsClassifier(n_neighbors=k_initial_bin)
knn_raw_bin.fit(X_train_bin, y_train_bin)
y_pred_raw_bin = knn_raw_bin.predict(X_test_bin)
accuracy_raw_bin = accuracy_score(y_test_bin, y_pred_raw_bin)
print(f"Точность (Сырые данные): {accuracy_raw_bin:.4f}")
print(classification_report(y_test_bin, y_pred_raw_bin, target_names=le_gender.classes_))
# --- 2.3. Классификация на нормализованных данных ---
scaler_bin = StandardScaler()
X_train_bin_norm = scaler_bin.fit_transform(X_train_bin)
X_test_bin_norm = scaler_bin.transform(X_test_bin)
X_bin_norm_full = scaler_bin.transform(X_bin) # Для кросс-валидации на полном датасете
knn_norm_bin = KNeighborsClassifier(n_neighbors=k_initial_bin)
knn_norm_bin.fit(X_train_bin_norm, y_train_bin)
y_pred_norm_bin = knn_norm_bin.predict(X_test_bin_norm)
accuracy_norm_bin = accuracy_score(y_test_bin, y_pred_norm_bin)
print(f"Точность (Нормализованные данные): {accuracy_norm_bin:.4f}")
print(classification_report(y_test_bin, y_pred_norm_bin, target_names=le_gender.classes_))
# 2.4. Классификация с отфильтрованными признаками

X_bin_norm_full_df = pd.DataFrame(X_bin_norm_full, columns=X_bin.columns)

existing_numerical_features_bin = [col for col in numerical_features_bin if col in X_bin_norm_full_df.columns]
X_bin_numeric_for_corr = X_bin_norm_full_df[existing_numerical_features_bin]

M_corr_bin = X_bin_numeric_for_corr.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(M_corr_bin, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
plt.title('Бинарная классификация: Тепловая карта корреляции числовых признаков')
plt.show()
np.fill_diagonal(M_corr_bin.values, 0)
M_corr_abs_bin = M_corr_bin.abs()
np.fill_diagonal(M_corr_abs_bin.values, 0)


T_corr_bin = 0.3
filtered_M_corr_bin = M_corr_abs_bin.where(M_corr_abs_bin > T_corr_bin, 0)
F_bin = filtered_M_corr_bin.sum(axis=1)
F_sorted_bin = F_bin.sort_values(ascending=False)
T_filter_bin = 1 
selected_numerical_features_bin = F_sorted_bin[F_sorted_bin > T_filter_bin].index.tolist()
print(F_sorted_bin)


one_hot_cols_bin = [col for col in X_bin.columns if col not in numerical_features_bin]
final_selected_features_bin = selected_numerical_features_bin + one_hot_cols_bin
X_bin_filt = X_bin[final_selected_features_bin]

X_train_bin_filt, X_test_bin_filt, y_train_bin_filt, y_test_bin_filt = train_test_split(X_bin_filt, y_bin, test_size=0.3, random_state=42, stratify=y_bin)
scaler_bin_filt = StandardScaler()
X_train_bin_filt_norm = scaler_bin_filt.fit_transform(X_train_bin_filt)
X_test_bin_filt_norm = scaler_bin_filt.transform(X_test_bin_filt)
X_bin_filt_norm_full = scaler_bin_filt.transform(X_bin_filt) 

knn_filt_bin = KNeighborsClassifier(n_neighbors=k_initial_bin)
knn_filt_bin.fit(X_train_bin_filt_norm, y_train_bin_filt)
y_pred_filt_bin = knn_filt_bin.predict(X_test_bin_filt_norm)
accuracy_filt_bin = accuracy_score(y_test_bin_filt, y_pred_filt_bin)
print(f"Точность (Нормализованные, Отфильтрованные): {accuracy_filt_bin:.4f}")
print(classification_report(y_test_bin_filt, y_pred_filt_bin, target_names=le_gender.classes_))

# 2.5. Подбор гиперпараметра k

k_range_bin = range(1, 21)
from sklearn.model_selection import validation_curve
train_scores_bin, test_scores_bin = validation_curve(
    KNeighborsClassifier(), X_bin_filt_norm_full, y_bin,
    param_name="n_neighbors", param_range=k_range_bin,
    cv=5, scoring="accuracy", n_jobs=-1)

train_scores_mean_bin = np.mean(train_scores_bin, axis=1)
test_scores_mean_bin = np.mean(test_scores_bin, axis=1)

plt.figure(figsize=(10, 6))
plt.plot(k_range_bin, train_scores_mean_bin, label="Точность на обучении", marker='o')
plt.plot(k_range_bin, test_scores_mean_bin, label="Точность на кросс-валидации", marker='o')
plt.title("Бинарный kNN: Точность vs. k (Отфильтрованные, нормализованные данные)")
plt.xlabel("Количество соседей (k)")
plt.ylabel("Точность")
plt.xticks(k_range_bin)
plt.legend()
plt.grid(True)
plt.show()

best_k_bin_idx = np.argmax(test_scores_mean_bin)
best_k_bin = k_range_bin[best_k_bin_idx]
print(f"Лучшее k для бинарной классификации: {best_k_bin} с точностью: {test_scores_mean_bin[best_k_bin_idx]:.4f}")
# 3.1. Предобработка для многоклассовой классификации
df_multi = df.copy()
target_multi = 'position'
top_n_positions = 7
main_positions = df_multi[target_multi].value_counts()[:top_n_positions].index
df_multi['position_grouped'] = df_multi[target_multi].apply(lambda x: x if x in main_positions else 'Other')
target_multi_grouped = 'position_grouped'

le_pos = LabelEncoder()
df_multi[target_multi_grouped] = le_pos.fit_transform(df_multi[target_multi_grouped])

numerical_features_multi = ['age', 'weight_(in kg)', 'height_(in cm)', 'ovr', 'pac', 'sho', 'pas', 'dri', 'def', 'phy']
categorical_features_multi = ['preffered_foot', 'gender'] 

for col in numerical_features_multi:
    df_multi[numerical_features_multi] = df_multi[numerical_features_multi].fillna(
    df_multi[numerical_features_multi].median()
)
df_multi = pd.get_dummies(df_multi, columns=categorical_features_multi, dummy_na=False)

features_to_drop_multi = [target_multi, target_multi_grouped, 'rank', 'player_name', 'club', 'nationality', 'league', 'alt_position', 'image_url',
                           'pac+-', 'sho+-', 'pas+-', 'dri+-', 'def+-', 'phy+-']
features_to_drop_multi_existing = [col for col in features_to_drop_multi if col in df_multi.columns]

X_multi = df_multi.drop(columns=features_to_drop_multi_existing)
y_multi = df_multi[target_multi_grouped]
X_multi = X_multi.apply(pd.to_numeric, errors='coerce').fillna(0)
# 3.2. Классификация на нормализованных данных
scaler_multi = StandardScaler()
X_multi_norm = scaler_multi.fit_transform(X_multi)
k_initial_multi = 5
X_train_multi, X_test_multi, y_train_multi, y_test_multi = train_test_split(X_multi_norm, y_multi, test_size=0.3, random_state=42, stratify=y_multi)
knn_multi_full = KNeighborsClassifier(n_neighbors=k_initial_multi)
knn_multi_full.fit(X_train_multi, y_train_multi)
y_pred_multi_full = knn_multi_full.predict(X_test_multi)
accuracy_multi_full = accuracy_score(y_test_multi, y_pred_multi_full)
print(f"Точность (Нормализованные, Все признаки): {accuracy_multi_full:.4f}")
print(classification_report(y_test_multi, y_pred_multi_full, target_names=le_pos.classes_, zero_division=0))
# 3.3. Отбор признаков

X_multi_norm_df = pd.DataFrame(X_multi_norm, columns=X_multi.columns)
existing_numerical_features_multi = [col for col in numerical_features_multi if col in X_multi_norm_df.columns]
X_multi_numeric_for_corr = X_multi_norm_df[existing_numerical_features_multi]

M_corr_multi = X_multi_numeric_for_corr.corr()
M_corr_abs_multi = M_corr_multi.abs()
np.fill_diagonal(M_corr_abs_multi.values, 0)

T_corr_multi = 0.3
filtered_M_corr_multi = M_corr_abs_multi.where(M_corr_abs_multi > T_corr_multi, 0)
F_multi = filtered_M_corr_multi.sum(axis=1)
F_sorted_multi = F_multi.sort_values(ascending=False)
T_filter_multi = 1.0
selected_numerical_features_multi = F_sorted_multi[F_sorted_multi > T_filter_multi].index.tolist()

one_hot_cols_multi = [col for col in X_multi.columns if col not in numerical_features_multi]
final_selected_features_multi = selected_numerical_features_multi + one_hot_cols_multi
X_multi_filt_raw = X_multi[final_selected_features_multi]

scaler_multi_filt = StandardScaler()
X_multi_filt_norm_full = scaler_multi_filt.fit_transform(X_multi_filt_raw) 

X_train_multi_filt, X_test_multi_filt, y_train_multi_filt, y_test_multi_filt = train_test_split(
    X_multi_filt_norm_full, y_multi, test_size=0.3, random_state=42, stratify=y_multi)

knn_multi_filt = KNeighborsClassifier(n_neighbors=k_initial_multi)
knn_multi_filt.fit(X_train_multi_filt, y_train_multi_filt)
y_pred_multi_filt = knn_multi_filt.predict(X_test_multi_filt)
accuracy_multi_filt = accuracy_score(y_test_multi_filt, y_pred_multi_filt)
print(f"Точность (Нормализованные, Отфильтрованные): {accuracy_multi_filt:.4f}")
print(classification_report(y_test_multi_filt, y_pred_multi_filt, target_names=le_pos.classes_, zero_division=0))
# 3.3. Подбор гиперпараметра k (Кросс-валидация)
k_range_multi = range(1, 21)
train_scores_multi, test_scores_multi = validation_curve(
    KNeighborsClassifier(), X_multi_filt_norm_full, y_multi, 
    param_name="n_neighbors", param_range=k_range_multi,
    cv=5, scoring="accuracy", n_jobs=-1)

train_scores_mean_multi = np.mean(train_scores_multi, axis=1)
test_scores_mean_multi = np.mean(test_scores_multi, axis=1)

plt.figure(figsize=(10, 6))
plt.plot(k_range_multi, train_scores_mean_multi, label="Точность на обучении", marker='o')
plt.plot(k_range_multi, test_scores_mean_multi, label="Точность на кросс-валидации", marker='o')
plt.title("Многоклассовый kNN: Точность vs. k (Отфильтрованные, нормализованные данные)")
plt.xlabel("Количество соседей (k)")
plt.ylabel("Точность")
plt.xticks(k_range_multi)
plt.legend()
plt.grid(True)
plt.show()

best_k_multi_idx = np.argmax(test_scores_mean_multi)
best_k_multi = k_range_multi[best_k_multi_idx]
print(f"Лучшее k для многоклассовой классификации: {best_k_multi} с точностью: {test_scores_mean_multi[best_k_multi_idx]:.4f}")

# 3.4. Анализ лучшего многоклассового классификатора 
best_knn_multi = KNeighborsClassifier(n_neighbors=best_k_multi)

best_knn_multi.fit(X_train_multi_filt, y_train_multi_filt) 
y_pred_best_multi = best_knn_multi.predict(X_test_multi_filt)
print(f"Метрики для лучшего многоклассового kNN (k={best_k_multi}):")
print(f"Точность: {accuracy_score(y_test_multi_filt, y_pred_best_multi):.4f}")
print("Отчет по классификации:")
print(classification_report(y_test_multi_filt, y_pred_best_multi, target_names=le_pos.classes_, zero_division=0))
cm_multi = confusion_matrix(y_test_multi_filt, y_pred_best_multi, labels=le_pos.transform(le_pos.classes_))
plt.figure(figsize=(10, 8))
sns.heatmap(cm_multi, annot=True, fmt='d', cmap='Blues', xticklabels=le_pos.classes_, yticklabels=le_pos.classes_)
plt.title(f'Матрица ошибок для многоклассового kNN (k={best_k_multi})')
plt.xlabel('Предсказанная метка')
plt.ylabel('Истинная метка')
plt.show()