import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
import seaborn as sns
import scipy.stats as stats
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# --- 1. Загрузка данных ---
# Предполагается, что файл 'players_info.csv' находится в папке 'dataset' относительно скрипта
try:
    df = pd.read_csv('dataset/players_info.csv')
except FileNotFoundError:
    exit()

# Преобразование некоторых колонок в числовые, обрабатывая возможные ошибки
cols_to_numeric = ['age', 'weight_(in kg)', 'height_(in cm)', 'ovr', 'pac', 'sho', 'pas', 'dri', 'def', 'phy',
                   'pac+-', 'sho+-', 'pas+-', 'dri+-', 'def+-', 'phy+-']
for col in cols_to_numeric:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

# Удаление строк с NaN значениями в ключевых числовых колонках для корректной визуализации
df.dropna(subset=['age', 'ovr', 'height_(in cm)', 'weight_(in kg)'], inplace=True)


# --- 2. Описание датасета ---
"""
## Описание датасета: players_info.csv

Датасет содержит информацию о футболистах, включая их рейтинг, возраст, клуб, национальность и различные игровые характеристики.

| Признак         | Описание                                                                 | Тип данных   |
|-----------------|--------------------------------------------------------------------------|--------------|
| rank            | Общий рейтинг игрока                                                      | int          |
| player_name     | Полное имя игрока                                                        | string       |
| age             | Возраст игрока на 2024 год                                               | int          |
| gender          | Пол игрока; F - женский, M - мужской                                     | category     |
| club            | Название клуба, за который игрок выступает в настоящее время              | string       |
| nationality     | Национальность игрока                                                     | string       |
| position        | Предпочтительная игровая позиция                                         | string       |
| league          | Лига, в которой игрок выступает в настоящее время                         | string       |
| preferred_foot  | Предпочтительная нога (например, 'Left', 'Right')                        | string       |
| weight_(in kg)  | Вес в кг                                                                 | int          |
| height_(in cm)  | Рост в см                                                                | int          |
| alt_position    | Альтернативные позиции, на которых может играть игрок                     | object       |
| ovr             | Общий рейтинг игрока (Overall)                                           | int          |
| pac             | Рейтинг скорости (Pace)                                                  | int          |
| sho             | Рейтинг ударов (Shooting)                                                | int          |
| pas             | Рейтинг передач (Passing)                                                | int          |
| dri             | Рейтинг дриблинга (Dribbling)                                            | int          |
| def             | Рейтинг защиты (Defending)                                               | int          |
| phy             | Рейтинг физической подготовки (Physicality)                              | int          |
| pac+-           | Изменение рейтинга скорости (+/-) по сравнению с предыдущей версией       | int          |
| sho+-           | Изменение рейтинга ударов (+/-)                                          | int          |
| pas+-           | Изменение рейтинга передач (+/-)                                         | int          |
| dri+-           | Изменение рейтинга дриблинга (+/-)                                       | int          |
| def+-           | Изменение рейтинга защиты (+/-)                                          | int          |
| phy+-           | Изменение рейтинга физической подготовки (+/-)                           | int          |
| image_url       | URL-адрес изображения игрока                                             | string       |
"""

# --- 3. Matplotlib ---
print("\n--- 3. Matplotlib ---")

plt.figure(figsize=(10, 6))
plt.hist(df['age'].dropna(), bins=20, color='skyblue', edgecolor='black')
plt.title('Распределение возрастов игроков')
plt.xlabel('Возраст')
plt.ylabel('Количество игроков')
plt.grid(axis='y', alpha=0.75)
plt.show()

plt.figure(figsize=(10, 6))
plt.scatter(df['height_(in cm)'], df['weight_(in kg)'], alpha=0.5, color='green')
plt.title('Соотношение роста и веса игроков')
plt.xlabel('Рост (см)')
plt.ylabel('Вес (кг)')
plt.grid(True)
plt.show()

avg_ovr_gender = df.groupby('gender')['ovr'].mean().sort_values()
plt.figure(figsize=(8, 5))
avg_ovr_gender.plot(kind='bar', color=['pink', 'lightblue'])
plt.title('Средний общий рейтинг (OVR) по полу')
plt.xlabel('Пол')
plt.ylabel('Средний OVR')
plt.xticks(rotation=0)
plt.show()

fig, axes = plt.subplots(1, 2, figsize=(15, 6))
axes[0].hist(df['pac'].dropna(), bins=15, color='lightcoral', edgecolor='black')
axes[0].set_title('Распределение рейтинга скорости (PAC)')
axes[0].set_xlabel('PAC')
axes[0].set_ylabel('Количество игроков')
axes[1].hist(df['sho'].dropna(), bins=15, color='lightseagreen', edgecolor='black')
axes[1].set_title('Распределение рейтинга ударов (SHO)')
axes[1].set_xlabel('SHO')
axes[1].set_ylabel('Количество игроков')
plt.suptitle('Суб-графики: PAC и SHO', fontsize=16)
plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

fig_interactive, ax_interactive = plt.subplots(figsize=(10,7))
plt.subplots_adjust(bottom=0.25)
min_age, max_age = int(df['age'].min()), int(df['age'].max())
initial_age = min_age
filtered_df = df[df['age'] == initial_age]
scatter_plot = ax_interactive.scatter(filtered_df['dri'], filtered_df['ovr'], alpha=0.6, color='purple')
ax_interactive.set_xlabel('Дриблинг (DRI)')
ax_interactive.set_ylabel('Общий рейтинг (OVR)')
ax_interactive.set_title(f'DRI vs OVR для игроков возраста: {initial_age}')
ax_interactive.grid(True)
age_text = ax_interactive.text(0.05, 0.95, f'Возраст: {initial_age}', transform=ax_interactive.transAxes, fontsize=12, verticalalignment='top')
ax_slider = plt.axes([0.2, 0.1, 0.65, 0.03], facecolor='lightgoldenrodyellow')
age_slider = Slider(
    ax=ax_slider,
    label='Возраст',
    valmin=min_age,
    valmax=max_age,
    valinit=initial_age,
    valstep=1
)
def update(val):
    current_age = int(age_slider.val)
    filtered_df = df[df['age'] == current_age]
    if not filtered_df.empty:
        scatter_plot.set_offsets(np.c_[filtered_df['dri'], filtered_df['ovr']])
        ax_interactive.set_xlim(df['dri'].min(), df['dri'].max())
        ax_interactive.set_ylim(df['ovr'].min(), df['ovr'].max())
    else:
        scatter_plot.set_offsets(np.empty((0,2)))
    ax_interactive.set_title(f'DRI vs OVR для игроков возраста: {current_age}')
    age_text.set_text(f'Возраст: {current_age}')
    fig_interactive.canvas.draw_idle()
age_slider.on_changed(update)
plt.show()

# --- 4. Pandas Plotting ---
print("\n--- 4. Pandas Plotting ---")

df.plot.scatter(x='age', y='ovr', figsize=(10, 6), alpha=0.5, color='orange')
plt.title('Возраст vs Общий рейтинг (OVR) - Pandas')
plt.xlabel('Возраст')
plt.ylabel('Общий рейтинг (OVR)')
plt.grid(True)
plt.show()

df['phy'].plot.hist(bins=20, figsize=(10, 6), color='teal', edgecolor='black')
plt.title('Распределение рейтинга физической подготовки (PHY) - Pandas')
plt.xlabel('PHY')
plt.ylabel('Количество игроков')
plt.grid(axis='y', alpha=0.75)
plt.show()

if 'ovr' in df.columns and 'preferred_foot' in df.columns:
    df.boxplot(column='ovr', by='preferred_foot', figsize=(10, 7), grid=True)
    plt.title('Общий рейтинг (OVR) по предпочитаемой ноге - Pandas')
    plt.suptitle('')
    plt.xlabel('Предпочитаемая нога')
    plt.ylabel('Общий рейтинг (OVR)')
    plt.show()
else:
    print("Пропуск Pandas boxplot: Колонки 'ovr' и/или 'preferred_foot' отсутствуют.")
    if 'preferred_foot' not in df.columns:
        print(f"Диагностика: Колонка 'preferred_foot' не найдена. Доступные колонки: {df.columns.tolist()}")
    # 'ovr' должен существовать, учитывая предыдущие графики, но проверка не помешает
    if 'ovr' not in df.columns:
        print(f"Диагностика: Колонка 'ovr' не найдена. Доступные колонки: {df.columns.tolist()}")

# --- 5. Seaborn ---
print("\n--- 5. Seaborn ---")

numerical_features_for_pairplot = ['age', 'ovr', 'pac', 'sho', 'phy', 'height_(in cm)', 'weight_(in kg)']
numerical_features_for_pairplot = [col for col in numerical_features_for_pairplot if col in df.columns and df[col].notna().any()]
sns.pairplot(df[numerical_features_for_pairplot].dropna())
plt.suptitle('Pairplot числовых признаков - Seaborn', y=1.02)
plt.show()

sns.jointplot(x='dri', y='pas', data=df, kind='scatter', height=8, color='darkred', joint_kws={'alpha':0.5})
plt.suptitle('Jointplot: Дриблинг (DRI) vs Передачи (PAS) - Seaborn', y=1.02)
plt.xlabel('Дриблинг (DRI)')
plt.ylabel('Передачи (PAS)')
plt.show()

top_n_positions = df['position'].value_counts().nlargest(5).index
df_top_positions = df[df['position'].isin(top_n_positions)]
plt.figure(figsize=(12, 7))
sns.violinplot(x='position', y='ovr', data=df_top_positions, palette='muted')
plt.title('OVR по топ-5 позициям - Seaborn Violinplot')
plt.xlabel('Позиция')
plt.ylabel('Общий рейтинг (OVR)')
plt.show()

numerical_cols_for_heatmap = df.select_dtypes(include=np.number).columns.tolist()
main_stats_for_heatmap = ['age', 'ovr', 'pac', 'sho', 'pas', 'dri', 'def', 'phy', 'weight_(in kg)', 'height_(in cm)']
main_stats_for_heatmap = [col for col in main_stats_for_heatmap if col in numerical_cols_for_heatmap and df[col].notna().any()]
correlation_matrix = df[main_stats_for_heatmap].corr()
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
plt.title('Тепловая карта корреляции числовых признаков - Seaborn')
plt.show()

# --- 6. Scipy.stats ---
print("\n--- 6. Scipy.stats ---")

plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
stats.probplot(df['ovr'].dropna(), dist="norm", plot=plt)
plt.title('QQ-график для OVR')
plt.subplot(1, 2, 2)
plt.hist(df['ovr'].dropna(), bins=20, color='mediumpurple', edgecolor='black', density=True)
plt.xlabel('OVR')
plt.ylabel('Плотность')
mu, std = stats.norm.fit(df['ovr'].dropna())
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = stats.norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
title = "Подогнанное нормальное распределение: mu = {:.2f}, std = {:.2f}".format(mu, std)
plt.title(title)
plt.tight_layout()
plt.show()

# --- 7. Plotly ---
print("\n--- 7. Plotly ---")

fig_plotly_scatter = px.scatter(df, x='height_(in cm)', y='weight_(in kg)', color='gender',
                                hover_name='player_name',
                                title='Рост vs Вес игроков (Plotly)',
                                labels={'height_(in cm)': 'Рост (см)', 'weight_(in kg)': 'Вес (кг)', 'gender': 'Пол'})
fig_plotly_scatter.show()

top_nationalities = df['nationality'].value_counts().nlargest(10)
fig_plotly_bar = px.bar(top_nationalities, x=top_nationalities.index, y=top_nationalities.values,
                        title='Топ-10 национальностей игроков (Plotly)',
                        labels={'x': 'Национальность', 'y': 'Количество игроков'})
fig_plotly_bar.show()

fig_plotly_subplots = make_subplots(rows=1, cols=2, subplot_titles=('Распределение PAC', 'Распределение SHO'))
fig_plotly_subplots.add_trace(
    go.Histogram(x=df['pac'].dropna(), name='PAC', marker_color='lightcoral'),
    row=1, col=1
)
fig_plotly_subplots.add_trace(
    go.Histogram(x=df['sho'].dropna(), name='SHO', marker_color='lightseagreen'),
    row=1, col=2
)
fig_plotly_subplots.update_layout(title_text='Суб-графики: PAC и SHO (Plotly)', height=500)
fig_plotly_subplots.show()

fig_plotly_3d = px.scatter_3d(df.dropna(subset=['pac', 'sho', 'pas', 'ovr']),
                              x='pac', y='sho', z='pas',
                              color='ovr', hover_name='player_name',
                              title='3D Scatter: PAC, SHO, PAS (цвет по OVR) - Plotly',
                              labels={'pac': 'Скорость (PAC)', 'sho': 'Удары (SHO)', 'pas': 'Передачи (PAS)', 'ovr': 'Общий рейтинг'})
fig_plotly_3d.update_layout(margin=dict(l=0, r=0, b=0, t=40))
fig_plotly_3d.show()
