import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import numpy as np
import matplotlib.pyplot as plt
import graphviz
df = pd.read_csv('dataset/bank-additional-full.csv', sep=';')
print(f"Размер датасета: {df.shape}")
print(f"Первые 5 строк:\n{df.head()}")

if 'duration' in df.columns:
    df = df.drop('duration', axis=1)

for col in df.select_dtypes(include=['object']).columns:
    if 'unknown' in df[col].unique():
        df[col] = df[col].replace('unknown', np.nan)
        mode_val = df[col].mode()[0]
        df[col] = df[col].fillna(mode_val)
        print(f"NaN в '{col}' заменены на '{mode_val}'.")

categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
categorical_cols.remove('y')

df = pd.get_dummies(df, columns=categorical_cols)

y_le = LabelEncoder()
df['y'] = y_le.fit_transform(df['y'])
class_names = y_le.classes_

X = df.drop('y', axis=1)
y = df['y']
feature_names = X.columns.tolist() 
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X = pd.DataFrame(X_scaled, columns=feature_names)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
print(f"Размер обучающей выборки: {X_train.shape}, {y_train.shape}")
print(f"Размер тестовой выборки: {X_test.shape}, {y_test.shape}")

def print_metrics(y_true, y_pred, model_name="Модель"):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f_measure = f1_score(y_true, y_pred, average='weighted', zero_division=0)
    print(f"Метрики для {model_name} на обучающей выборке:")
    print(f"  Accuracy: {accuracy:.4f}")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall: {recall:.4f}")
    print(f"  F-measure: {f_measure:.4f}")
    return accuracy, precision, recall, f_measure
param_grid_dt = {
    'max_depth': [None, 5, 10, 15, 20],
    'max_features': [None, 'sqrt', 'log2', 0.5, 0.7],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 5]
}

grid_search_dt = GridSearchCV(DecisionTreeClassifier(random_state=42),
                              param_grid_dt, cv=5, scoring='f1_weighted', n_jobs=-1)
grid_search_dt.fit(X_train, y_train)
best_dt_model = grid_search_dt.best_estimator_
print(f"Лучшие гиперпараметры для DecisionTreeClassifier: {grid_search_dt.best_params_}")

y_pred_train_dt = best_dt_model.predict(X_train)
metrics_dt_before_filter = print_metrics(y_train, y_pred_train_dt, "DecisionTreeClassifier (до фильтрации)")
importances_dt = best_dt_model.feature_importances_
feature_importances_dt = pd.Series(importances_dt, index=feature_names).sort_values(ascending=False)
print("\nВажность признаков (DecisionTreeClassifier):")
print(feature_importances_dt)

threshold_dt = 0.01
important_features_dt = feature_importances_dt[feature_importances_dt > threshold_dt].index.tolist()
print(f"\nПризнаки, отобранные после фильтрации (порог > {threshold_dt}): {important_features_dt}")


X_train_dt_filtered = X_train[important_features_dt]
X_test_dt_filtered = X_test[important_features_dt]
selected_features_dt_final = important_features_dt[:]
grid_search_dt_filtered = GridSearchCV(DecisionTreeClassifier(random_state=42),
                                     param_grid_dt, cv=5, scoring='f1_weighted', n_jobs=-1)
grid_search_dt_filtered.fit(X_train_dt_filtered, y_train)

best_dt_model_filtered = grid_search_dt_filtered.best_estimator_
print(f"Лучшие гиперпараметры для DecisionTreeClassifier (после фильтрации): {grid_search_dt_filtered.best_params_}")

y_pred_train_dt_filtered = best_dt_model_filtered.predict(X_train_dt_filtered)
metrics_dt_after_filter = print_metrics(y_train, y_pred_train_dt_filtered, "DecisionTreeClassifier (после фильтрации)")

print("\nСравнение метрик DecisionTreeClassifier до и после фильтрации признаков:")
print(f"До фильтрации: Accuracy={metrics_dt_before_filter[0]:.4f}, Precision={metrics_dt_before_filter[1]:.4f}, Recall={metrics_dt_before_filter[2]:.4f}, F-measure={metrics_dt_before_filter[3]:.4f}")
print(f"После фильтрации: Accuracy={metrics_dt_after_filter[0]:.4f}, Precision={metrics_dt_after_filter[1]:.4f}, Recall={metrics_dt_after_filter[2]:.4f}, F-measure={metrics_dt_after_filter[3]:.4f}")

dt_improved_by_filtering = metrics_dt_after_filter[3] > metrics_dt_before_filter[3]
param_grid_rf = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

grid_search_rf = GridSearchCV(RandomForestClassifier(random_state=42),
                              param_grid_rf, cv=3, scoring='f1_weighted', n_jobs=-1, verbose=1) # cv=3 для ускорения
grid_search_rf.fit(X_train, y_train)
best_rf_model = grid_search_rf.best_estimator_
print(f"Лучшие гиперпараметры для RandomForestClassifier: {grid_search_rf.best_params_}")
y_pred_train_rf = best_rf_model.predict(X_train)
metrics_rf_before_filter = print_metrics(y_train, y_pred_train_rf, "RandomForestClassifier (до фильтрации)")

importances_rf = best_rf_model.feature_importances_
feature_importances_rf = pd.Series(importances_rf, index=feature_names).sort_values(ascending=False)
print("\nВажность признаков (RandomForestClassifier):")
print(feature_importances_rf)

threshold_rf = 0.001
important_features_rf = feature_importances_rf[feature_importances_rf > threshold_rf].index.tolist()
print(f"\nПризнаки, отобранные после фильтрации (порог > {threshold_rf}): {important_features_rf}")
X_train_rf_filtered = X_train[important_features_rf]
X_test_rf_filtered = X_test[important_features_rf]
selected_features_rf_final = important_features_rf[:]

grid_search_rf_filtered = GridSearchCV(RandomForestClassifier(random_state=42),param_grid_rf, cv=3, scoring='f1_weighted', n_jobs=-1, verbose=1) 
grid_search_rf_filtered.fit(X_train_rf_filtered, y_train)
best_rf_model_filtered = grid_search_rf_filtered.best_estimator_
print(f"Лучшие гиперпараметры для RandomForestClassifier (после фильтрации): {grid_search_rf_filtered.best_params_}")
y_pred_train_rf_filtered = best_rf_model_filtered.predict(X_train_rf_filtered)
metrics_rf_after_filter = print_metrics(y_train, y_pred_train_rf_filtered, "RandomForestClassifier (после фильтрации)")
print("\nСравнение метрик RandomForestClassifier до и после фильтрации признаков:")
print(f"До фильтрации: Accuracy={metrics_rf_before_filter[0]:.4f}, Precision={metrics_rf_before_filter[1]:.4f}, Recall={metrics_rf_before_filter[2]:.4f}, F-measure={metrics_rf_before_filter[3]:.4f}")
print(f"После фильтрации: Accuracy={metrics_rf_after_filter[0]:.4f}, Precision={metrics_rf_after_filter[1]:.4f}, Recall={metrics_rf_after_filter[2]:.4f}, F-measure={metrics_rf_after_filter[3]:.4f}")

rf_improved_by_filtering = metrics_rf_after_filter[3] > metrics_rf_before_filter[3]
param_grid_knn = {
    'n_neighbors': list(range(1, 21))
}

grid_search_knn = GridSearchCV(KNeighborsClassifier(n_jobs=-1),param_grid_knn, cv=5, scoring='f1_weighted', n_jobs=-1)
grid_search_knn.fit(X_train, y_train)
best_knn_model = grid_search_knn.best_estimator_
print(f"Лучшие гиперпараметры для KNeighborsClassifier: {grid_search_knn.best_params_}")
y_pred_train_knn = best_knn_model.predict(X_train)
metrics_knn_before_filter = print_metrics(y_train, y_pred_train_knn, "KNeighborsClassifier (до фильтрации)")

X_train_knn_filtered = X_train[important_features_rf]
X_test_knn_filtered = X_test[important_features_rf]
selected_features_knn_final = important_features_rf[:]

grid_search_knn_filtered = GridSearchCV(KNeighborsClassifier(n_jobs=-1),
                                      param_grid_knn, cv=5, scoring='f1_weighted', n_jobs=-1)
grid_search_knn_filtered.fit(X_train_knn_filtered, y_train)

best_knn_model_filtered = grid_search_knn_filtered.best_estimator_

print(f"Лучшие гиперпараметры для KNeighborsClassifier (после фильтрации): {grid_search_knn_filtered.best_params_}")

y_pred_train_knn_filtered = best_knn_model_filtered.predict(X_train_knn_filtered)
metrics_knn_after_filter = print_metrics(y_train, y_pred_train_knn_filtered, "KNeighborsClassifier (после фильтрации)")

print(f"До фильтрации: Accuracy={metrics_knn_before_filter[0]:.4f}, Precision={metrics_knn_before_filter[1]:.4f}, Recall={metrics_knn_before_filter[2]:.4f}, F-measure={metrics_knn_before_filter[3]:.4f}")
print(f"После фильтрации: Accuracy={metrics_knn_after_filter[0]:.4f}, Precision={metrics_knn_after_filter[1]:.4f}, Recall={metrics_knn_after_filter[2]:.4f}, F-measure={metrics_knn_after_filter[3]:.4f}")

knn_improved_by_filtering = metrics_knn_after_filter[3] > metrics_knn_before_filter[3]
final_filtered_features = None
if dt_improved_by_filtering or rf_improved_by_filtering or knn_improved_by_filtering:
    print("Обнаружено улучшение метрик после фильтрации хотя бы для одной модели.")
    candidate_feature_sets = []
    if dt_improved_by_filtering and selected_features_dt_final:
        candidate_feature_sets.append(set(selected_features_dt_final))
        print(f"DT улучшился с признаками: {selected_features_dt_final}")
    if rf_improved_by_filtering and selected_features_rf_final:
        candidate_feature_sets.append(set(selected_features_rf_final))
        print(f"RF улучшился с признаками: {selected_features_rf_final}")
    if knn_improved_by_filtering and selected_features_knn_final: # KNN использует признаки от RF
        candidate_feature_sets.append(set(selected_features_knn_final))
        print(f"KNN улучшился с признаками (от RF): {selected_features_knn_final}")
    else:
        union_of_features = set().union(*candidate_feature_sets)
        final_filtered_features = sorted(list(union_of_features)) # Сортируем для консистентности
        print(f"\nИтоговый набор отфильтрованных признаков (объединение): {final_filtered_features}")

    dt_params_for_final = grid_search_dt_filtered.best_params_ if dt_improved_by_filtering else grid_search_dt.best_params_
    final_dt_model = DecisionTreeClassifier(**dt_params_for_final, random_state=42)
    final_dt_model.fit(X_train_final_filtered, y_train)
    print("DecisionTreeClassifier переобучен.")

    rf_params_for_final = grid_search_rf_filtered.best_params_ if rf_improved_by_filtering else grid_search_rf.best_params_
    final_rf_model = RandomForestClassifier(**rf_params_for_final, random_state=42, n_jobs=-1)
    final_rf_model.fit(X_train_final_filtered, y_train)
    print("RandomForestClassifier переобучен.")

    knn_params_for_final = grid_search_knn_filtered.best_params_ if knn_improved_by_filtering else grid_search_knn.best_params_
    final_knn_model = KNeighborsClassifier(**knn_params_for_final, n_jobs=-1)
    final_knn_model.fit(X_train_final_filtered, y_train)
    print("KNeighborsClassifier переобучен.")

else:
    print("Улучшения метрик после фильтрации не наблюдалось ни для одной модели. Пункт 6 пропускается.")
    if dt_improved_by_filtering:
        final_dt_model = best_dt_model_filtered
        X_test_dt_for_eval = X_test_dt_filtered
        print("Для DT в п.7 будет использована модель после индивидуальной фильтрации.")
    else:
        final_dt_model = best_dt_model
        X_test_dt_for_eval = X_test # Используем X_test с полным набором признаков
        print("Для DT в п.7 будет использована модель до фильтрации.")

    if rf_improved_by_filtering:
        final_rf_model = best_rf_model_filtered
        X_test_rf_for_eval = X_test_rf_filtered
        print("Для RF в п.7 будет использована модель после индивидуальной фильтрации.")
    else:
        final_rf_model = best_rf_model
        X_test_rf_for_eval = X_test
        print("Для RF в п.7 будет использована модель до фильтрации.")

    if knn_improved_by_filtering:
        final_knn_model = best_knn_model_filtered
        X_test_knn_for_eval = X_test_knn_filtered
        print("Для KNN в п.7 будет использована модель после индивидуальной фильтрации.")
    else:
        final_knn_model = best_knn_model
        X_test_knn_for_eval = X_test
        print("Для KNN в п.7 будет использована модель до фильтрации.")
    final_filtered_features = feature_names
current_dt_feature_names = None
if 'X_train_final_filtered' in locals() and final_filtered_features is not None: # Если пункт 6 был выполнен с фильтрацией
    current_dt_feature_names = final_filtered_features
elif 'X_test_dt_for_eval' in locals() and X_test_dt_for_eval.shape[1] != X_train.shape[1]: # Если DT использует индивидуально отфильтрованные признаки
    current_dt_feature_names = selected_features_dt_final
else:
    current_dt_feature_names = feature_names
dot_data = export_graphviz(final_dt_model,
                           out_file=None,
                           feature_names=current_dt_feature_names,
                           class_names=[str(cls) for cls in class_names], # Убедимся, что имена классов - строки
                           filled=True,
                           rounded=True,
                           special_characters=True,
                           max_depth=3)
graph = graphviz.Source(dot_data)
print("\nСравнение лучших моделей на ТЕСТОВОЙ выборке:")

def print_test_metrics(y_true, y_pred, model_name):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f_measure = f1_score(y_true, y_pred, average='weighted', zero_division=0)
    print(f"Метрики для {model_name} на ТЕСТОВОЙ выборке:")
    print(f"  Accuracy: {accuracy:.4f}")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall: {recall:.4f}")
    print(f"  F-measure: {f_measure:.4f}")
    return accuracy, precision, recall, f_measure

if 'X_test_final_filtered' in locals():
    y_pred_test_dt = final_dt_model.predict(X_test_final_filtered)
    print_test_metrics(y_test, y_pred_test_dt, "DecisionTreeClassifier (на общем отфильтрованном наборе)")
elif 'X_test_dt_for_eval' in locals():
    y_pred_test_dt = final_dt_model.predict(X_test_dt_for_eval)
    model_name_dt = "DecisionTreeClassifier (после инд. фильтрации)" if X_test_dt_for_eval.shape[1] != X_test.shape[1] else "DecisionTreeClassifier (без фильтрации)"
    print_test_metrics(y_test, y_pred_test_dt, model_name_dt)
if 'X_test_final_filtered' in locals():
    y_pred_test_rf = final_rf_model.predict(X_test_final_filtered)
    print_test_metrics(y_test, y_pred_test_rf, "RandomForestClassifier (на общем отфильтрованном наборе)")
elif 'X_test_rf_for_eval' in locals():
    y_pred_test_rf = final_rf_model.predict(X_test_rf_for_eval)
    model_name_rf = "RandomForestClassifier (после инд. фильтрации)" if X_test_rf_for_eval.shape[1] != X_test.shape[1] else "RandomForestClassifier (без фильтрации)"
    print_test_metrics(y_test, y_pred_test_rf, model_name_rf)
if 'X_test_final_filtered' in locals():
    y_pred_test_knn = final_knn_model.predict(X_test_final_filtered)
    print_test_metrics(y_test, y_pred_test_knn, "KNeighborsClassifier (на общем отфильтрованном наборе)")
elif 'X_test_knn_for_eval' in locals():
    y_pred_test_knn = final_knn_model.predict(X_test_knn_for_eval)
    model_name_knn = "KNeighborsClassifier (после инд. фильтрации)" if X_test_knn_for_eval.shape[1] != X_test.shape[1] else "KNeighborsClassifier (без фильтрации)"
    print_test_metrics(y_test, y_pred_test_knn, model_name_knn)

display(graph)