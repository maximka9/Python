# Necessary imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.feature_selection import RFE
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# Глобальная настройка для графиков
plt.style.use('seaborn-v0_8-whitegrid') # Используем стиль seaborn

# Вспомогательная функция для отображения важности коэффициентов
def plot_coefficient_importance(model, feature_names, title):
    if not hasattr(model, 'coef_'):
        print(f"Модель {model.__class__.__name__} не имеет атрибута .coef_.")
        return
    
    coefs = pd.Series(model.coef_, index=feature_names)
    # Раскомментируйте следующую строку, чтобы отфильтровать нулевые коэффициенты (например, для Lasso):
    # coefs = coefs[coefs != 0]
    if coefs.empty:
        print(f"Нет ненулевых коэффициентов для отображения для {title}")
        return
        
    sorted_coefs = coefs.abs().sort_values(ascending=False) # Сортировка по абсолютному значению для определения важности
    coefs_to_plot = coefs.loc[sorted_coefs.index]
    
    plt.figure(figsize=(10, max(5, len(coefs_to_plot) * 0.3)))
    # Раскомментируйте, чтобы сортировать по значению коэффициента (для отображения направления влияния):
    # coefs_to_plot.sort_values().plot(kind='barh') 
    sns.barplot(x=coefs_to_plot.values, y=coefs_to_plot.index, orient='h')
    plt.title(title)
    plt.xlabel("Значение коэффициента")
    plt.ylabel("Признак")
    plt.tight_layout()
    plt.show()

# Helper function to print metrics
def print_regression_metrics(y_true, y_pred, model_name):
    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    print(f"Метрики для {model_name} на ТЕСТОВОМ наборе:")
    print(f"  MSE: {mse:.4f}")
    print(f"  MAE: {mae:.4f}")
    print(f"  R^2: {r2:.4f}")
    return {'mse': mse, 'mae': mae, 'r2': r2}

# --- 1. Считать в pandas.DataFrame --- 
print("--- 1. Считывание данных ---")
try:
    df = pd.read_csv('dataset/players_info.csv')
    print("Данные успешно загружены.")
    print(f"Размер датасета: {df.shape}")
    # print(f"Первые 5 строк:\n{df.head()}")
    # print(f"Типы данных:\n{df.dtypes}")
except FileNotFoundError:
    print("Ошибка: Файл 'dataset/players_info.csv' не найден.")
    exit()

# --- 2. Датасет и подготовка данных, этап 1 ---
print("\n--- 2. Подготовка данных, этап 1 ---")

# 2.1 Описание датасета
print("\n--- 2.1 Описание датасета ---")
print("Датасет содержит информацию об игроках, включая их характеристики, рейтинги и клубную принадлежность.")
print("Целевая переменная для регрессии: 'ovr' (общий рейтинг игрока).")

# 2.2 Предобработка данных
print("\n--- 2.2 Предобработка данных ---")

# Копирование DataFrame для избежания SettingWithCopyWarning
df_processed = df.copy()

# Удаление ненужных столбцов
columns_to_drop = ['rank', 'player_name', 'image_url']
# Столбцы с изменениями рейтинга (+-) могут быть сложны для прямой интерпретации в базовой регрессии
# или могут требовать специальной обработки. Пока удалим их для упрощения.
# Если они важны, можно будет их обработать (например, преобразовать в числовые значения).
columns_to_drop.extend([col for col in df_processed.columns if '+-' in col])

print(f"Удаляемые столбцы: {columns_to_drop}")
df_processed.drop(columns=columns_to_drop, axis=1, inplace=True, errors='ignore')

# Обработка alt_position: преобразуем в количество альтернативных позиций
if 'alt_position' in df_processed.columns:
    print("Обработка столбца 'alt_position'...")
    try:
        # Попытка оценить строку как список и взять его длину
        # Это может быть небезопасно, если строки не являются валидными литералами списков Python
        # Более безопасный способ - использовать регулярные выражения или строковые методы для подсчета
        df_processed['num_alt_positions'] = df_processed['alt_position'].apply(
            lambda x: len(eval(x)) if isinstance(x, str) and x.startswith('[') and x.endswith(']') else 0
        )
    except Exception as e:
        print(f"Ошибка при обработке alt_position: {e}. Удаляем столбец.")
        df_processed.drop(columns=['alt_position'], axis=1, inplace=True, errors='ignore')
    else:
        df_processed.drop(columns=['alt_position'], axis=1, inplace=True, errors='ignore')
        print("Столбец 'alt_position' преобразован в 'num_alt_positions'.")

# Переименование столбцов для удобства (удаление специальных символов)
df_processed.rename(columns={
    'weight_(in kg)': 'weight_kg',
    'height_(in cm)': 'height_cm'
}, inplace=True)

# Проверка и удаление NaN
print(f"Количество NaN до удаления: {df_processed.isnull().sum().sum()}")
df_processed.dropna(inplace=True) # Удаляем строки с любыми NaN для простоты
print(f"Количество NaN после удаления: {df_processed.isnull().sum().sum()}")
print(f"Размер датасета после удаления NaN: {df_processed.shape}")

if 'ovr' not in df_processed.columns:
    print("Ошибка: Целевая переменная 'ovr' отсутствует в датасете после предобработки.")
    exit()

# Определение признаков и целевой переменной
X = df_processed.drop('ovr', axis=1)
y = df_processed['ovr']

# Определение категориальных и числовых признаков
categorical_features = X.select_dtypes(include=['object', 'category']).columns.tolist()
# Убедимся, что gender и preferred_foot правильно определены как категориальные, если они object
for col in ['gender', 'preferred_foot', 'club', 'nationality', 'position', 'league']:
    if col in X.columns and X[col].dtype == 'object':
        X[col] = X[col].astype('category')

categorical_features = X.select_dtypes(include=['object', 'category']).columns.tolist()
numerical_features = X.select_dtypes(include=np.number).columns.tolist()

print(f"Категориальные признаки: {categorical_features}")
print(f"Числовые признаки: {numerical_features}")

# Сохранение копии X и y перед удалением категориальных и нормализацией для этапа 2
X_original = X.copy()
y_original = y.copy()

# Временно убираем категориальные признаки для этапа 1
X_stage1 = X.drop(columns=categorical_features, errors='ignore')
numerical_features_stage1 = X_stage1.columns.tolist() # Обновляем список числовых признаков для этапа 1
print(f"Признаки для этапа 1 (после удаления категориальных): {numerical_features_stage1}")

# 2.3 Нормализация числовых данных (для X_stage1)
print("\n--- 2.3 Нормализация числовых данных (этап 1) ---")
scaler_stage1 = StandardScaler()
if not X_stage1.empty and len(numerical_features_stage1) > 0:
    X_scaled_stage1_array = scaler_stage1.fit_transform(X_stage1[numerical_features_stage1])
    X_scaled_stage1 = pd.DataFrame(X_scaled_stage1_array, columns=numerical_features_stage1, index=X_stage1.index)
    print("Числовые данные для этапа 1 нормализованы.")
else:
    print("Нет числовых данных для нормализации на этапе 1 или X_stage1 пуст.")
    X_scaled_stage1 = pd.DataFrame(index=X_stage1.index) # Пустой DataFrame с правильным индексом
    # Если X_stage1 пуст, дальнейшие шаги с ним могут вызвать ошибки. Необходимо обработать.

# 2.4 Визуализация heatmap-матрицы коррелированности признаков (для X_scaled_stage1 и y)
print("\n--- 2.4 Heatmap корреляций (этап 1) ---")
if not X_scaled_stage1.empty and not y.loc[X_scaled_stage1.index].empty:
    temp_df_for_corr = X_scaled_stage1.copy()
    temp_df_for_corr['target_ovr'] = y.loc[X_scaled_stage1.index] # Используем y, выровненный по индексам X_scaled_stage1
    plt.figure(figsize=(12, 10))
    sns.heatmap(temp_df_for_corr.corr(), annot=True, fmt=".2f", cmap="coolwarm", vmin=-1, vmax=1)
    plt.title("Матрица корреляций признаков (и target_ovr) - Этап 1")
    plt.show()
else:
    print("X_scaled_stage1 или соответствующий y пуст, невозможно построить heatmap.")

# 2.5 Визуализация взаимосвязи между target-переменной и каждым из признаков (этап 1)
print("\n--- 2.5 Взаимосвязь target с признаками (этап 1) ---")
if not X_scaled_stage1.empty and not y.loc[X_scaled_stage1.index].empty:
    for feature in X_scaled_stage1.columns:
        plt.figure(figsize=(8, 5))
        sns.scatterplot(x=X_scaled_stage1[feature], y=y.loc[X_scaled_stage1.index])
        plt.title(f'Взаимосвязь: target_ovr vs {feature}')
        plt.xlabel(feature)
        plt.ylabel('target_ovr')
        plt.show()
else:
    print("X_scaled_stage1 или соответствующий y пуст, невозможно построить графики взаимосвязей.")

# 2.6 Разбить выборку на обучающую и тестовую (для данных этапа 1)
print("\n--- 2.6 Разделение выборки на обучающую и тестовую (этап 1) ---")
if X_scaled_stage1.empty:
    print("Невозможно разделить выборку: X_scaled_stage1 пуст.")
    X_train_s1, X_test_s1, y_train_s1, y_test_s1 = pd.DataFrame(), pd.DataFrame(), pd.Series(dtype='float64'), pd.Series(dtype='float64')
    feature_names_s1 = []
else:
    # Используем y.loc[X_scaled_stage1.index] чтобы гарантировать соответствие y и X_scaled_stage1 после dropna
    y_aligned_s1 = y.loc[X_scaled_stage1.index] 
    X_train_s1, X_test_s1, y_train_s1, y_test_s1 = train_test_split(
        X_scaled_stage1, y_aligned_s1, test_size=0.2, random_state=42
    )
    print(f"Размеры выборок этапа 1: X_train_s1: {X_train_s1.shape}, X_test_s1: {X_test_s1.shape}, y_train_s1: {y_train_s1.shape}, y_test_s1: {y_test_s1.shape}")
    feature_names_s1 = X_train_s1.columns.tolist()

# Сохраняем исходные X_original, y_original для этапа 2 - уже сделано выше.
# Теперь нужно также разделить X_original и y_original на обучающую и тестовую выборки
# для использования в этапе 2. Важно использовать те же индексы, что и при разделении X_scaled_stage1

if not X_original.empty and not y_original.loc[X_original.index].empty:
    y_aligned_orig = y_original.loc[X_original.index]
    X_train_orig, X_test_orig, y_train_orig, y_test_orig = train_test_split(
    X_original, y_aligned_orig, test_size=0.2, random_state=42 # Используем те же параметры разделения
    )
    print(f"Размеры оригинальных выборок для этапа 2: X_train_orig: {X_train_orig.shape}, X_test_orig: {X_test_orig.shape}")
else:
    print("X_original или соответствующий y_original пуст, нечего делить для этапа 2.")
    X_train_orig, X_test_orig, y_train_orig, y_test_orig = pd.DataFrame(), pd.DataFrame(), pd.Series(dtype='float64'), pd.Series(dtype='float64')

# --- 3. Регрессия МНК (OLS) --- 
print("\n--- 3. Регрессия МНК (OLS) ---")

# Проверяем, что X_train_s1 не пустой перед обучением
if X_train_s1.empty or X_test_s1.empty:
    print("Обучающая или тестовая выборка для этапа 1 пусты. Пропуск регрессии МНК.")
    lr_s1_metrics = {'mse': np.nan, 'mae': np.nan, 'r2': np.nan} # Заполнитель для метрик
    lr_s1_model = None # Заполнитель для модели
else:
    lr_s1_model = LinearRegression()
    lr_s1_model.fit(X_train_s1, y_train_s1)
    print("Модель LinearRegression (этап 1) обучена.")

    # Предсказания и метрики
    y_pred_lr_s1 = lr_s1_model.predict(X_test_s1)
    lr_s1_metrics = print_regression_metrics(y_test_s1, y_pred_lr_s1, "LinearRegression (Этап 1)")

    # Коэффициенты
    print(f"Коэффициенты (coef_): {lr_s1_model.coef_}")
    print(f"Intercept: {lr_s1_model.intercept_:.4f}")

    # График важности коэффициентов
    if feature_names_s1: # Убедимся, что есть имена признаков
        plot_coefficient_importance(lr_s1_model, feature_names_s1, "Важность коэффициентов LinearRegression (Этап 1)")
    else:
        print("Нет имен признаков для построения графика важности коэффициентов.")

# Сохраняем лучшую модель (в данном случае единственную OLS) для этапа 2, хотя по заданию это для Ridge/Lasso/EN
# Но для единообразия и возможного сравнения, сохраним.
best_lr_s1_model = lr_s1_model 

# --- 4. Регрессии с регуляризацией (Ridge, LASSO, Elastic Net) - Этап 1 ---
print("\n--- 4. Регрессии с регуляризацией (Этап 1) ---")

# Параметры для GridSearchCV
alpha_range = np.logspace(-4, 2, 20) # Более широкий диапазон alpha, 20 точек
l1_ratio_range = [0.1, 0.3, 0.5, 0.7, 0.9, 0.95, 0.99, 1]

# Переменные для хранения лучших моделей и их метрик
best_ridge_s1_model = None
ridge_s1_metrics = {'mse': np.nan, 'mae': np.nan, 'r2': np.nan}
best_lasso_s1_model = None
lasso_s1_metrics = {'mse': np.nan, 'mae': np.nan, 'r2': np.nan}
best_elasticnet_s1_model = None
elasticnet_s1_metrics = {'mse': np.nan, 'mae': np.nan, 'r2': np.nan}

if X_train_s1.empty or X_test_s1.empty:
    print("Обучающая или тестовая выборка для этапа 1 пусты. Пропуск регрессий с регуляризацией.")
else:
    # --- Ridge Regression ---
    print("\n--- 4.1 Ridge Regression (Этап 1) ---")
    param_grid_ridge = {'alpha': alpha_range}
    grid_ridge = GridSearchCV(Ridge(random_state=42, max_iter=10000), param_grid_ridge, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
    grid_ridge.fit(X_train_s1, y_train_s1)
    best_ridge_s1_model = grid_ridge.best_estimator_

    print(f"Лучшие гиперпараметры для Ridge: {grid_ridge.best_params_}")
    print(f"Коэффициенты (coef_): {best_ridge_s1_model.coef_}")
    print(f"Intercept: {best_ridge_s1_model.intercept_:.4f}")
    
    y_pred_ridge_s1 = best_ridge_s1_model.predict(X_test_s1)
    ridge_s1_metrics = print_regression_metrics(y_test_s1, y_pred_ridge_s1, "Ridge (Этап 1)")
    if feature_names_s1:
        plot_coefficient_importance(best_ridge_s1_model, feature_names_s1, "Важность коэффициентов Ridge (Этап 1)")

    # --- LASSO Regression ---
    print("\n--- 4.2 LASSO Regression (Этап 1) ---")
    param_grid_lasso = {'alpha': alpha_range}
    grid_lasso = GridSearchCV(Lasso(random_state=42, max_iter=30000), param_grid_lasso, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
    grid_lasso.fit(X_train_s1, y_train_s1)
    best_lasso_s1_model = grid_lasso.best_estimator_

    print(f"Лучшие гиперпараметры для LASSO: {grid_lasso.best_params_}")
    print(f"Коэффициенты (coef_): {best_lasso_s1_model.coef_}")
    print(f"Intercept: {best_lasso_s1_model.intercept_:.4f}")

    y_pred_lasso_s1 = best_lasso_s1_model.predict(X_test_s1)
    lasso_s1_metrics = print_regression_metrics(y_test_s1, y_pred_lasso_s1, "LASSO (Этап 1)")
    if feature_names_s1:
        plot_coefficient_importance(best_lasso_s1_model, feature_names_s1, "Важность коэффициентов LASSO (Этап 1)")

    # --- Elastic Net Regression ---
    print("\n--- 4.3 Elastic Net Regression (Этап 1) ---")
    param_grid_elasticnet = {'alpha': alpha_range, 'l1_ratio': l1_ratio_range}
    grid_elasticnet = GridSearchCV(ElasticNet(random_state=42, max_iter=30000), param_grid_elasticnet, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
    grid_elasticnet.fit(X_train_s1, y_train_s1)
    best_elasticnet_s1_model = grid_elasticnet.best_estimator_

    print(f"Лучшие гиперпараметры для Elastic Net: {grid_elasticnet.best_params_}")
    print(f"Коэффициенты (coef_): {best_elasticnet_s1_model.coef_}")
    print(f"Intercept: {best_elasticnet_s1_model.intercept_:.4f}")

    y_pred_elasticnet_s1 = best_elasticnet_s1_model.predict(X_test_s1)
    elasticnet_s1_metrics = print_regression_metrics(y_test_s1, y_pred_elasticnet_s1, "Elastic Net (Этап 1)")
    if feature_names_s1:
        plot_coefficient_importance(best_elasticnet_s1_model, feature_names_s1, "Важность коэффициентов Elastic Net (Этап 1)")

# --- 5. Датасет и подготовка данных, этап 2 (с категориальными признаками) ---
print("\n--- 5. Подготовка данных, этап 2 (с категориальными признаками) ---")

if X_train_orig.empty or X_test_orig.empty:
    print("Исходные выборки для этапа 2 пусты. Пропуск этапа 2.")
    # Создаем пустые переменные, чтобы скрипт не падал
    X_train_s2_processed = pd.DataFrame()
    X_test_s2_processed = pd.DataFrame()
    y_train_s2 = y_train_orig # Это будет пустая Series, если y_train_orig пуст
    y_test_s2 = y_test_orig   # Это будет пустая Series, если y_test_orig пуст
    feature_names_s2 = []
else:
    # Целевые переменные для этапа 2 - это оригинальные y_train_orig и y_test_orig
    y_train_s2 = y_train_orig
    y_test_s2 = y_test_orig

    # Определение категориальных и числовых признаков из X_train_orig
    categorical_features_s2 = X_train_orig.select_dtypes(include=['object', 'category']).columns.tolist()
    numerical_features_s2 = X_train_orig.select_dtypes(include=np.number).columns.tolist()

    # Исключаем 'club' из категориальных признаков для этапа 2
    if 'club' in categorical_features_s2:
        categorical_features_s2.remove('club')
        print("Признак 'club' исключен из категориальных для этапа 2.")

    print(f"Категориальные признаки для этапа 2 (после исключения 'club'): {categorical_features_s2}")
    print(f"Числовые признаки для этапа 2: {numerical_features_s2}")

    # Создание preprocessor
    preprocessor_s2 = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features_s2),
            ('num', StandardScaler(), numerical_features_s2)
        ],
        remainder='passthrough' # Оставить столбцы, которые не были указаны (на всякий случай)
    )

    # Применение preprocessor к обучающей выборке
    X_train_s2_processed_array = preprocessor_s2.fit_transform(X_train_orig)
    
    # Получение имен признаков после OneHotEncoding и конкатенации
    try:
        # Имена признаков после OneHotEncoder
        ohe_feature_names = preprocessor_s2.named_transformers_['cat'].get_feature_names_out(categorical_features_s2)
        # Полный список имен признаков
        feature_names_s2 = list(ohe_feature_names) + numerical_features_s2
    except Exception as e:
        print(f"Ошибка при получении имен признаков из ColumnTransformer: {e}")
        # В случае ошибки, создаем временные имена, если трансформация была успешной
        num_transformed_cols = X_train_s2_processed_array.shape[1]
        feature_names_s2 = [f'feature_{i}' for i in range(num_transformed_cols)]

    X_train_s2_processed = pd.DataFrame(X_train_s2_processed_array, columns=feature_names_s2, index=X_train_orig.index)
    print("Обучающая выборка этапа 2 обработана (OneHotEncoding + StandardScaler).")
    print(f"Размер X_train_s2_processed: {X_train_s2_processed.shape}")

    # Применение preprocessor к тестовой выборке
    X_test_s2_processed_array = preprocessor_s2.transform(X_test_orig)
    X_test_s2_processed = pd.DataFrame(X_test_s2_processed_array, columns=feature_names_s2, index=X_test_orig.index)
    print("Тестовая выборка этапа 2 обработана.")
    print(f"Размер X_test_s2_processed: {X_test_s2_processed.shape}")

# --- 6. Регрессии, этап 2 (с категориальными признаками) ---
print("\n--- 6. Регрессии, этап 2 ---")

# Заполнители для метрик и моделей этапа 2
lr_s2_metrics = {}
ridge_s2_metrics = {}
lasso_s2_metrics = {}
elasticnet_s2_metrics = {}

lr_s2_model = None
ridge_s2_model = None
lasso_s2_model = None
elasticnet_s2_model = None

if X_train_s2_processed.empty or X_test_s2_processed.empty:
    print("Обработанные выборки для этапа 2 пусты. Пропуск обучения моделей этапа 2.")
else:
    # --- 6.1 LinearRegression (Этап 2) ---
    print("\n--- 6.1 LinearRegression (Этап 2) ---")
    lr_s2_model = LinearRegression()
    lr_s2_model.fit(X_train_s2_processed, y_train_s2)
    print("Модель LinearRegression (этап 2) обучена.")
    y_pred_lr_s2 = lr_s2_model.predict(X_test_s2_processed)
    lr_s2_metrics = print_regression_metrics(y_test_s2, y_pred_lr_s2, "LinearRegression (Этап 2)")
    print(f"Коэффициенты (coef_): {lr_s2_model.coef_[:10]}... (первые 10 для краткости)")
    print(f"Intercept: {lr_s2_model.intercept_:.4f}")

    # --- 6.2 Ridge Regression (Этап 2, с лучшими параметрами из этапа 1) ---
    print("\n--- 6.2 Ridge Regression (Этап 2) ---")
    if best_ridge_s1_model is not None:
        # Создаем новую модель с теми же параметрами, но не обученную
        ridge_s2_model = Ridge(**best_ridge_s1_model.get_params())
        ridge_s2_model.fit(X_train_s2_processed, y_train_s2)
        print(f"Модель Ridge (этап 2) обучена с параметрами: {ridge_s2_model.get_params()}")
        y_pred_ridge_s2 = ridge_s2_model.predict(X_test_s2_processed)
        ridge_s2_metrics = print_regression_metrics(y_test_s2, y_pred_ridge_s2, "Ridge (Этап 2)")
        print(f"Коэффициенты (coef_): {ridge_s2_model.coef_[:10]}... (первые 10)")
        print(f"Intercept: {ridge_s2_model.intercept_:.4f}")
    else:
        print("Лучшая модель Ridge из этапа 1 отсутствует.")

    # --- 6.3 LASSO Regression (Этап 2, с лучшими параметрами из этапа 1) ---
    print("\n--- 6.3 LASSO Regression (Этап 2) ---")
    if best_lasso_s1_model is not None:
        lasso_s2_model_params = best_lasso_s1_model.get_params()
        lasso_s2_model_params['max_iter'] = 30000 # Убедимся, что и здесь достаточно итераций
        lasso_s2_model = Lasso(**lasso_s2_model_params)
        lasso_s2_model.fit(X_train_s2_processed, y_train_s2)
        print(f"Модель LASSO (этап 2) обучена с параметрами: {lasso_s2_model.get_params()}")
        y_pred_lasso_s2 = lasso_s2_model.predict(X_test_s2_processed)
        lasso_s2_metrics = print_regression_metrics(y_test_s2, y_pred_lasso_s2, "LASSO (Этап 2)")
        print(f"Коэффициенты (coef_): {lasso_s2_model.coef_[:10]}... (первые 10)")
        print(f"Intercept: {lasso_s2_model.intercept_:.4f}")
    else:
        print("Лучшая модель LASSO из этапа 1 отсутствует.")

    # --- 6.4 Elastic Net Regression (Этап 2, с лучшими параметрами из этапа 1) ---
    print("\n--- 6.4 Elastic Net Regression (Этап 2) ---")
    if best_elasticnet_s1_model is not None:
        elasticnet_s2_model_params = best_elasticnet_s1_model.get_params()
        elasticnet_s2_model_params['max_iter'] = 30000 # Убедимся, что и здесь достаточно итераций
        elasticnet_s2_model = ElasticNet(**elasticnet_s2_model_params)
        elasticnet_s2_model.fit(X_train_s2_processed, y_train_s2)
        print(f"Модель Elastic Net (этап 2) обучена с параметрами: {elasticnet_s2_model.get_params()}")
        y_pred_elasticnet_s2 = elasticnet_s2_model.predict(X_test_s2_processed)
        elasticnet_s2_metrics = print_regression_metrics(y_test_s2, y_pred_elasticnet_s2, "Elastic Net (Этап 2)")
        print(f"Коэффициенты (coef_): {elasticnet_s2_model.coef_[:10]}... (первые 10)")
        print(f"Intercept: {elasticnet_s2_model.intercept_:.4f}")
    else:
        print("Лучшая модель Elastic Net из этапа 1 отсутствует.")

    # --- 6.5 Сравнение метрик (Этап 1 vs Этап 2) ---
    print("\n--- 6.5 Сравнение метрик (Этап 1 - без категориальных, Этап 2 - с категориальными) ---")
    if lr_s1_metrics and lr_s2_metrics:
        print(f"Linear Regression: S1 R^2={lr_s1_metrics.get('r2', np.nan):.4f} -> S2 R^2={lr_s2_metrics.get('r2', np.nan):.4f}")
    if ridge_s1_metrics and ridge_s2_metrics and best_ridge_s1_model:
        print(f"Ridge:             S1 R^2={ridge_s1_metrics.get('r2', np.nan):.4f} -> S2 R^2={ridge_s2_metrics.get('r2', np.nan):.4f}")
    if lasso_s1_metrics and lasso_s2_metrics and best_lasso_s1_model:
        print(f"LASSO:             S1 R^2={lasso_s1_metrics.get('r2', np.nan):.4f} -> S2 R^2={lasso_s2_metrics.get('r2', np.nan):.4f}")
    if elasticnet_s1_metrics and elasticnet_s2_metrics and best_elasticnet_s1_model:
        print(f"Elastic Net:       S1 R^2={elasticnet_s1_metrics.get('r2', np.nan):.4f} -> S2 R^2={elasticnet_s2_metrics.get('r2', np.nan):.4f}")

    # --- 6.6 Выбор лучшей модели (Этап 2) ---
    print("\n--- 6.6 Выбор лучшей модели (Этап 2) ---")
    models_s2_results = {
        "Linear Regression": {"model": lr_s2_model, "metrics": lr_s2_metrics, "features": feature_names_s2},
        "Ridge": {"model": ridge_s2_model, "metrics": ridge_s2_metrics, "features": feature_names_s2},
        "LASSO": {"model": lasso_s2_model, "metrics": lasso_s2_metrics, "features": feature_names_s2},
        "Elastic Net": {"model": elasticnet_s2_model, "metrics": elasticnet_s2_metrics, "features": feature_names_s2}
    }
    
    best_s2_model_name = None
    best_s2_r2 = -np.inf
    best_s2_model_info = None

    for name, info in models_s2_results.items():
        if info["model"] is not None and info["metrics"] and info["metrics"].get('r2', -np.inf) > best_s2_r2:
            best_s2_r2 = info["metrics"]['r2']
            best_s2_model_name = name
            best_s2_model_info = info
            
    if best_s2_model_name:
        print(f"Лучшая модель этапа 2: {best_s2_model_name} с R^2 = {best_s2_r2:.4f}")
        best_overall_s2_model = best_s2_model_info["model"]
        # График важности коэффициентов для лучшей модели этапа 2
        if best_s2_model_info["features"]:
             plot_coefficient_importance(best_overall_s2_model, best_s2_model_info["features"], f"Важность коэффициентов лучшей модели ({best_s2_model_name}) (Этап 2)")
    else:
        print("Не удалось определить лучшую модель этапа 2.")
        best_overall_s2_model = None # Убедимся, что переменная определена, если лучшая модель не найдена

    # --- 6.7 Recursive Feature Elimination (RFE) ---
    print("\n--- 6.7 Recursive Feature Elimination (RFE) ---")
    if best_overall_s2_model is not None and not X_train_s2_processed.empty:
        n_features_total = X_train_s2_processed.shape[1]
        n_features_to_select_rfe = max(1, int(n_features_total / 2)) # Выбираем половину признаков, но не менее 1
        print(f"RFE: Выбираем {n_features_to_select_rfe} из {n_features_total} признаков.")

        # Используем LinearRegression как оценщик для RFE для стабильности
        rfe_estimator = LinearRegression()
        rfe_selector = RFE(estimator=rfe_estimator, n_features_to_select=n_features_to_select_rfe, step=0.1) # step=0.1 для более плавной селекции (отбор по 10% за шаг)
        
        print("Обучение RFE...")
        rfe_selector.fit(X_train_s2_processed, y_train_s2)
        
        X_train_rfe = rfe_selector.transform(X_train_s2_processed)
        X_test_rfe = rfe_selector.transform(X_test_s2_processed)
        
        # Получаем имена отобранных RFE признаков
        selected_features_rfe_names = X_train_s2_processed.columns[rfe_selector.support_].tolist()
        print(f"Признаки, отобранные RFE: {selected_features_rfe_names[:10]}... (первые 10, если есть)")

        # Обучаем лучшую модель (по типу) на RFE-признаках
        # Создаем новый экземпляр лучшей модели с теми же параметрами
        if isinstance(best_overall_s2_model, LinearRegression):
            model_for_rfe_features = LinearRegression()
        elif isinstance(best_overall_s2_model, Ridge):
            model_for_rfe_features = Ridge(**best_overall_s2_model.get_params())
        elif isinstance(best_overall_s2_model, Lasso):
            lasso_rfe_params = best_overall_s2_model.get_params()
            lasso_rfe_params['max_iter'] = 30000 # Убедимся, что и здесь достаточно итераций
            model_for_rfe_features = Lasso(**lasso_rfe_params)
        elif isinstance(best_overall_s2_model, ElasticNet): # Проверка типа для ElasticNet
            elasticnet_rfe_params = best_overall_s2_model.get_params()
            elasticnet_rfe_params['max_iter'] = 30000 # Убедимся, что и здесь достаточно итераций
            model_for_rfe_features = ElasticNet(**elasticnet_rfe_params)
        else:
            print("Неизвестный тип лучшей модели, используем LinearRegression для RFE-признаков.")
            model_for_rfe_features = LinearRegression() # Резервный вариант
            
        print(f"Обучение модели типа '{type(model_for_rfe_features).__name__}' на RFE-признаках...")
        model_for_rfe_features.fit(X_train_rfe, y_train_s2)
        
        # График важности коэффициентов для модели на RFE-признаках
        plot_coefficient_importance(model_for_rfe_features, selected_features_rfe_names, f"Важность коэф. ({type(model_for_rfe_features).__name__}) после RFE")

        # Метрики для модели на RFE-признаках
        y_pred_rfe = model_for_rfe_features.predict(X_test_rfe)
        rfe_metrics = print_regression_metrics(y_test_s2, y_pred_rfe, f"{type(model_for_rfe_features).__name__} после RFE")
    elif X_train_s2_processed.empty:
        print("Пропуск RFE: X_train_s2_processed пуст.")
        rfe_metrics = {}
    else:
        print("Пропуск RFE: лучшая модель этапа 2 не определена.")
        rfe_metrics = {}

# --- 7. Сделать вывод ---
print("\n--- 7. Выводы ---")

# 7.1 Лучший регрессор, обученный на данных без категориальных признаков (Этап 1)
print("\n--- 7.1 Лучший регрессор (Этап 1 - без категориальных признаков) ---")
models_s1_results = {
    "Linear Regression": lr_s1_metrics,
    "Ridge": ridge_s1_metrics,
    "LASSO": lasso_s1_metrics,
    "Elastic Net": elasticnet_s1_metrics
}

best_s1_model_name = None
best_s1_r2 = -np.inf

for name, metrics in models_s1_results.items():
    if metrics and metrics.get('r2', -np.inf) > best_s1_r2:
        best_s1_r2 = metrics['r2']
        best_s1_model_name = name

if best_s1_model_name:
    print(f"Лучший регрессор этапа 1: {best_s1_model_name}")
    print(f"  MSE: {models_s1_results[best_s1_model_name].get('mse', np.nan):.4f}")
    print(f"  MAE: {models_s1_results[best_s1_model_name].get('mae', np.nan):.4f}")
    print(f"  R^2: {models_s1_results[best_s1_model_name].get('r2', np.nan):.4f}")
else:
    print("Не удалось определить лучший регрессор этапа 1 (возможно, этап 1 был пропущен).")

# 7.2 Лучший регрессор, обученный на данных с категориальными признаками (Этап 2, до RFE)
print("\n--- 7.2 Лучший регрессор (Этап 2 - с категориальными признаками, до RFE) ---")
if best_s2_model_name and best_s2_model_info:
    print(f"Лучший регрессор этапа 2 (до RFE): {best_s2_model_name}")
    print(f"  MSE: {best_s2_model_info['metrics'].get('mse', np.nan):.4f}")
    print(f"  MAE: {best_s2_model_info['metrics'].get('mae', np.nan):.4f}")
    print(f"  R^2: {best_s2_model_info['metrics'].get('r2', np.nan):.4f}")
else:
    print("Не удалось определить лучший регрессор этапа 2 (возможно, этап 2 был пропущен).")

# 7.3 Вывод о результатах использования Recursive Feature Elimination (RFE)
print("\n--- 7.3 Вывод о результатах RFE ---")
if (best_s2_model_name and 
    best_s2_model_info and 
    'r2' in best_s2_model_info['metrics'] and 
    best_s2_model_info['metrics']['r2'] is not np.nan and 
    rfe_metrics and 
    'r2' in rfe_metrics and 
    rfe_metrics['r2'] is not np.nan):
    
    r2_before_rfe = best_s2_model_info['metrics']['r2']
    r2_after_rfe = rfe_metrics['r2']
    
    print(f"R^2 лучшей модели ({best_s2_model_name}) до RFE: {r2_before_rfe:.4f}")
    print(f"R^2 модели ({type(model_for_rfe_features).__name__}) после RFE: {r2_after_rfe:.4f}")
    
    if r2_after_rfe > r2_before_rfe:
        print("Вывод: RFE улучшил(а) R^2 метрику.")
    elif r2_after_rfe < r2_before_rfe:
        print("Вывод: RFE ухудшил(а) R^2 метрику.")
    else:
        print("Вывод: RFE не изменил(а) R^2 метрику.")
    print(f"  MSE до RFE: {best_s2_model_info['metrics'].get('mse', np.nan):.4f} -> MSE после RFE: {rfe_metrics.get('mse', np.nan):.4f}")
    print(f"  MAE до RFE: {best_s2_model_info['metrics'].get('mae', np.nan):.4f} -> MAE после RFE: {rfe_metrics.get('mae', np.nan):.4f}")
else:
    print("Недостаточно данных для сравнения результатов RFE (возможно, какой-то из этапов был пропущен или модель не была обучена).")

print("\n--- Лабораторная работа №5 завершена ---")
