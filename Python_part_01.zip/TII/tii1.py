import pandas as pd
import numpy as np

# --- 1. Загрузка данных ---
print("--- 1. Загрузка данных ---")
df = pd.read_csv('dataset/daily_forex_rates.csv', parse_dates=['date'])
print("Датасет успешно загружен.")

# --- 2. Описание датасета ---
print("\n--- 2. Описание датасета ---")
print("Датасет 'Daily Forex Exchange Rates' содержит исторические и актуальные курсы обмена для более чем 160 валют.")
print("Столбцы:")
print("- currency: Код валюты для иностранной валюты (тип: str).")
print("- base_currency: Код валюты для базовой валюты (тип: str).")
print("- currency_name: Название валюты (тип: str).")
print("- exchange_rate: Обменный курс валюты по отношению к базовой валюте (тип: float).")
print("- date: Дата, когда был зафиксирован обменный курс (тип: datetime).")
print("Числовая колонка для анализа: exchange_rate.")

# Используем срез данных для демонстрации (первые 50000 строк)
df_sample = df.head(50000).copy()
print(f"\nДля демонстрации используется сэмпл из {len(df_sample)} строк.")

# --- 3. Основные операции с DataFrame ---
print("\n--- 3. Основные операции с DataFrame ---")

# --- 3.1 .head() ---
print("\n--- 3.1 .head() ---")
print(df_sample.head())

# --- 3.2 .describe() ---
print("\n--- 3.2 .describe() ---")
print(df_sample.describe(include='all'))

# --- 3.3 Считывание значения конкретной ячейки ---
print("\n--- 3.3 Считывание значения конкретной ячейки ---")
cell_value_iloc = df_sample.iloc[1]['exchange_rate']
print(f"Значение ячейки [1, 'exchange_rate'] (iloc): {cell_value_iloc}")
cell_value_loc = df_sample.loc[df_sample.index[1], 'currency_name']
print(f"Значение ячейки [{df_sample.index[1]}, 'currency_name'] (loc): {cell_value_loc}")

# --- 3.4 Фильтрация строк по диапазону индекса ---
print("\n--- 3.4 Фильтрация строк по диапазону индекса ---")
filtered_by_index = df_sample.iloc[2:6]
print("Строки с позиционными индексами от 2 до 5:")
print(filtered_by_index)

# --- 3.5 Фильтрация набора данных по какому-либо условию ---
print("\n--- 3.5 Фильтрация набора данных по какому-либо условию ---")
usd_mean_rate = df_sample[df_sample['currency'] == 'USD']['exchange_rate'].mean()
filter_value = usd_mean_rate * 0.9 if pd.notna(usd_mean_rate) and usd_mean_rate > 0 else df_sample['exchange_rate'].mean()
print(f"Фильтруем строки, где exchange_rate > {filter_value:.2f}")
filtered_by_condition = df_sample[df_sample['exchange_rate'] > filter_value]
print(filtered_by_condition.head())

# --- 3.6 Работа с пропущенными значениями ---
print("\n--- 3.6 Работа с пропущенными значениями ---")

# --- 3.6.a Работа с NaN в 'currency_name' (удаление строк) ---
print("\n--- 3.6.a Удаление строк с NaN в 'currency_name' ---")
initial_nans_currency_name = df_sample['currency_name'].isnull().sum()
if initial_nans_currency_name > 0:
    df_no_na_currency_name = df_sample.dropna(subset=['currency_name'])
    print(f"Размер df после удаления NA из 'currency_name': {df_no_na_currency_name.shape} (было {df_sample.shape[0]} строк)")
    print(f"Пропуски в 'currency_name' после удаления: {df_no_na_currency_name['currency_name'].isnull().sum()}")
else:
    print("В 'currency_name' нет исходных пропусков.")

# --- 3.6.b Работа с NaN в 'exchange_rate' (генерация, удаление, заполнение специфичным средним) ---
print("\n--- 3.6.b Работа с NaN в 'exchange_rate' ---")
df_exchange_rate_demo = df_sample.copy()

# Генерируем ~1% пропусков в 'exchange_rate' (макс. 10)
num_nans_to_create_er = 0
if len(df_exchange_rate_demo) > 100: # Достаточно строк для 1%
    num_nans_to_create_er = min(max(1, len(df_exchange_rate_demo) // 100), 10)
elif len(df_exchange_rate_demo) > 0: # Мало строк, создаем 1 NaN
    num_nans_to_create_er = 1

if num_nans_to_create_er > 0:
    nan_indices_er = np.random.choice(df_exchange_rate_demo.index, num_nans_to_create_er, replace=False)
    df_exchange_rate_demo.loc[nan_indices_er, 'exchange_rate'] = np.nan
    print(f"Сгенерировано пропусков в 'exchange_rate': {df_exchange_rate_demo['exchange_rate'].isnull().sum()}")

    # i) Удаление строк с NaN в 'exchange_rate'
    print("\n   i) Удаление строк с NaN из 'exchange_rate':")
    df_no_na_exchange_rate = df_exchange_rate_demo.dropna(subset=['exchange_rate'])
    print(f"     Размер df после удаления NA из 'exchange_rate': {df_no_na_exchange_rate.shape} (было {df_exchange_rate_demo.shape[0]} строк)")

    # ii) Заполнение пропущенных 'exchange_rate' средним по ВАЛЮТЕ
    print("\n   ii) Заполнение NaN 'exchange_rate' средним по КАЖДОЙ ВАЛЮТЕ:")
    df_filled_specific_mean = df_exchange_rate_demo.copy()
    currency_specific_means = df_filled_specific_mean.groupby('currency')['exchange_rate'].transform('mean')
    df_filled_specific_mean['exchange_rate'] = df_filled_specific_mean['exchange_rate'].fillna(currency_specific_means)
    print(f"     Пропуски в 'exchange_rate' после заполнения специфичным средним: {df_filled_specific_mean['exchange_rate'].isnull().sum()}")
    print("     Пример заполненных NaN в 'exchange_rate':")
    print(df_filled_specific_mean.loc[nan_indices_er, ['currency', 'currency_name', 'exchange_rate']].head())
else:
    print("Недостаточно данных для генерации пропусков в 'exchange_rate'.")

# df_sample остается чистым (неизменным) для следующих пунктов задания

# --- 3.7 Создание нового поля ---
print("\n--- 3.7 Создание нового поля ---")
df_copy_new_field = df_sample.copy()

# а) Через выражение
df_copy_new_field['inverted_rate_expr'] = 1 / (df_copy_new_field['exchange_rate'] + 1e-6)
print("\nа) Новое поле 'inverted_rate_expr':")
print(df_copy_new_field[['exchange_rate', 'inverted_rate_expr']].head())

# б) Через DataFrame.apply
def classify_rate_df(row, mean_rate_param):
    if pd.isna(row['exchange_rate']): return 'unknown'
    if row['exchange_rate'] < mean_rate_param * 0.5: return 'low'
    elif row['exchange_rate'] < mean_rate_param * 1.5: return 'medium'
    else: return 'high'
global_mean_rate = df_copy_new_field['exchange_rate'].mean() # Вычисляем один раз
df_copy_new_field['rate_category_df_apply'] = df_copy_new_field.apply(classify_rate_df, axis=1, mean_rate_param=global_mean_rate)
print("\nб) Новое поле 'rate_category_df_apply':")
print(df_copy_new_field[['exchange_rate', 'rate_category_df_apply']].head())

# в) Через Series.apply
df_copy_new_field['exchange_rate_rounded_series_apply'] = df_copy_new_field['exchange_rate'].apply(lambda x: round(x, 2) if pd.notna(x) else x)
print("\nв) Новое поле 'exchange_rate_rounded_series_apply':")
print(df_copy_new_field[['exchange_rate', 'exchange_rate_rounded_series_apply']].head())

# --- 3.8 Сортировка по какому-либо из полей ---
print("\n--- 3.8 Сортировка по 'exchange_rate' (убывание) ---")
df_sorted = df_sample.sort_values(by='exchange_rate', ascending=False)
print(df_sorted[['currency', 'exchange_rate']].head())

# --- 3.9 Вычисление нескольких статистик по колонкам ---
print("\n--- 3.9 Статистики для 'exchange_rate' ---")
stats = df_sample['exchange_rate'].agg(['mean', 'median', 'std', 'min', 'max', 'sum', 'count'])
print(stats)

# --- 3.10 .value_counts() ---
print("\n--- 3.10 .value_counts() для 'currency' ---")
currency_counts = df_sample['currency'].value_counts()
print(currency_counts.head())

# --- 3.11 .unique() ---
print("\n--- 3.11 .unique() для 'currency_name' ---")
unique_currency_names = df_sample['currency_name'].unique()
print(f"Уникальные 'currency_name' (первые 10):\n{unique_currency_names[:10]}")

# --- 3.12 Удаление текущего индекса и создание нового индекса ---
print("\n--- 3.12 Работа с индексом (reset_index, set_index) ---")
df_indexed_copy = df_sample.copy()
df_reset = df_indexed_copy.reset_index()
print("DataFrame после reset_index():")
print(df_reset.head(2))

# Создание нового MultiIndex
print("\nУстановка MultiIndex на основе 'date' и 'currency':")
# Убедимся, что комбинация date, currency будет уникальной для set_index в рамках сэмпла, иначе будет ошибка
# Или используем .drop_duplicates() перед set_index, если это допустимо
df_for_set_index = df_reset.drop_duplicates(subset=['date', 'currency'])
if not df_for_set_index.set_index(['date', 'currency']).index.is_unique:
    print("Предупреждение: Индекс из ('date', 'currency') не уникален даже после drop_duplicates. Это может быть не тем, что ожидается для основного индекса.")
df_set_indexed = df_for_set_index.set_index(['date', 'currency'])
print(df_set_indexed.head(2))
print(f"Тип нового индекса: {type(df_set_indexed.index)}")

# --- 4. .groupby() ---
print("\n--- 4. .groupby() и агрегатные функции ---")
grouped_by_currency_mean = df_sample.groupby('currency')['exchange_rate'].mean()
print("Средний 'exchange_rate' по каждой 'currency':")
print(grouped_by_currency_mean.head())

grouped_multi_agg = df_sample.groupby(['currency', 'base_currency'])['exchange_rate'].agg(['mean', 'min', 'max', 'count'])
print("\nАгрегаты ('mean', 'min', 'max', 'count' of 'exchange_rate') по 'currency' и 'base_currency':")
print(grouped_multi_agg.head())

# --- 5. .pivot() ---
print("\n--- 5. .pivot() ---")
unique_dates_pivot = df_sample['date'].unique()[:3]
unique_currencies_pivot = df_sample['currency'].unique()[:4]
df_pivot_sample = df_sample[
    df_sample['date'].isin(unique_dates_pivot) & df_sample['currency'].isin(unique_currencies_pivot)
].drop_duplicates(subset=['date', 'currency']) # .pivot требует уникальных комбинаций index/columns

if not df_pivot_sample.empty:
    try:
        df_pivoted = df_pivot_sample.pivot(index='date', columns='currency', values='exchange_rate')
        print("Результат .pivot(index='date', columns='currency', values='exchange_rate'):")
        print(df_pivoted)
    except ValueError as e:
        print(f"Ошибка .pivot(): {e}. Это может произойти, если комбинации index/columns не уникальны. Рассмотрите pivot_table.")
else:
    print("Недостаточно данных для .pivot() после фильтрации/удаления дубликатов.")

# --- 6. .pivot_table() ---
print("\n--- 6. .pivot_table() ---")
target_currencies_pt = df_sample['currency'].unique()[:5]
df_pt_sample = df_sample[df_sample['currency'].isin(target_currencies_pt)]

pivot_table_result = pd.pivot_table(df_pt_sample,
                                    values='exchange_rate',
                                    index='base_currency',
                                    columns='currency',
                                    aggfunc=np.mean)
print("Результат .pivot_table(values='exchange_rate', index='base_currency', columns='currency', aggfunc=np.mean):")
print(pivot_table_result.head())

# .pivot_table с загрублением числового признака (exchange_rate)
# Используем значения из гистограммы (пункт 8) или просто pd.cut
# Для примера, используем pd.cut здесь
df_sample_binned_pt = df_sample.copy()
df_sample_binned_pt['rate_bin_for_pivot'] = pd.cut(df_sample_binned_pt['exchange_rate'], bins=3, labels=['low', 'medium', 'high'])
pivot_table_binned = pd.pivot_table(df_sample_binned_pt,
                                    values='exchange_rate',
                                    index='rate_bin_for_pivot', # Используем загрубленный признак
                                    columns='currency',
                                    aggfunc='count',
                                    fill_value=0)
print("\nПример pivot_table с загрубленным 'exchange_rate' (rate_bin_for_pivot) в индексе:")
print(pivot_table_binned.head())
# df_sample_binned_pt.drop(columns=['rate_bin_for_pivot'], inplace=True) # Очистка, если df_sample_binned_pt используется дальше

# --- 7. Квантили распределения ---
print("\n--- 7. Квантили распределения для 'exchange_rate' ---")
rates_no_nan_quantile = df_sample['exchange_rate'].dropna()
if not rates_no_nan_quantile.empty:
    quantiles_vals = [0.25, 0.5, 0.75]
    calculated_quantiles = np.quantile(rates_no_nan_quantile, quantiles_vals)
    print(f"Квантили ({quantiles_vals}): {calculated_quantiles}")

    percentiles_vals = [10, 50, 90]
    calculated_percentiles = np.percentile(rates_no_nan_quantile, percentiles_vals)
    print(f"Перцентили ({percentiles_vals}): {calculated_percentiles}")
else:
    print("Нет данных в 'exchange_rate' для вычисления квантилей после dropna().")

# --- 8. Гистограмма ---
print("\n--- 8. Гистограмма (текст) для 'exchange_rate' ---")
rates_no_nan_hist = df_sample['exchange_rate'].dropna()
if not rates_no_nan_hist.empty:
    num_bins_hist = 5
    try:
        hist_values, bin_edges = np.histogram(rates_no_nan_hist, bins=num_bins_hist)
        print(f"Значения гистограммы: {hist_values}")
        print(f"Границы бинов: {bin_edges}")
        print("Текстовое представление гистограммы:")
        for i in range(len(hist_values)):
            max_hist_val = hist_values.max()
            scale_factor = int(hist_values[i] / max_hist_val * 20) if max_hist_val > 0 else 0
            print(f"Бин {bin_edges[i]:.2f}-{bin_edges[i+1]:.2f}: {'*' * scale_factor}")
        # Эти bin_edges могут быть использованы для pd.cut в пункте 6, если нужно точное соответствие.
    except ValueError as e:
        print(f"Ошибка при построении гистограммы: {e}.")
else:
    print("Нет данных в 'exchange_rate' для вычисления гистограммы после dropna().")

# --- 9. .iterrows() ---
print("\n--- 9. .iterrows() (первые 3 строки) ---")
for index, row in df_sample.head(3).iterrows():
    date_val = row['date'].strftime('%Y-%m-%d') if pd.notna(row['date']) else "N/A"
    currency_val = row['currency']
    exchange_rate_val = row.get('exchange_rate', 'N/A')
    if isinstance(exchange_rate_val, (int, float)) and pd.notna(exchange_rate_val):
        print(f"Индекс: {index}, Дата: {date_val}, Валюта: {currency_val}, Курс: {exchange_rate_val:.4f}")
    else:
        print(f"Индекс: {index}, Дата: {date_val}, Валюта: {currency_val}, Курс: {exchange_rate_val}")

# --- 10. MultiIndex ---
print("\n--- 10. DataFrame с MultiIndex ---")

# а) Получить DataFrame с MultiIndex через groupby
df_multi_prep = df_sample.copy().drop_duplicates(subset=['date', 'currency', 'base_currency'])
df_multi_idx_groupby = df_multi_prep.groupby(['date', 'currency'])['exchange_rate'].mean().to_frame()
print("\nа) DataFrame с MultiIndex (создан через groupby(['date', 'currency'])):")
print(df_multi_idx_groupby.head())

# б) Переставить местами уровни индекса
df_swapped_levels = df_multi_idx_groupby.swaplevel(0, 1)
print("\nб) Переставленные уровни индекса (swaplevel(0, 1)):")
print(df_swapped_levels.head())

# в) Транспонировать таблицу с MultiIndex
# Сначала unstack, чтобы получить больше колонок для наглядности транспонирования
df_unstacked_for_T = df_multi_idx_groupby.unstack(level='currency')
df_transposed = df_unstacked_for_T.T
print("\nв) Транспонированная таблица (unstack + T):")
print(df_transposed.head())

# г) Удалить один из уровней индекса
df_dropped_level = df_multi_idx_groupby.droplevel(0) # Удаляем первый уровень (предположительно 'date')
print("\nг) Удален первый уровень индекса:")
print(df_dropped_level.head())

# Добавление нового уровня индекса (инициализированный константой)
df_reset_for_new_level = df_multi_idx_groupby.reset_index()
df_reset_for_new_level['new_level_const'] = 'ConstantSource1'
df_new_multi_level = df_reset_for_new_level.set_index(['new_level_const', 'date', 'currency'])
print("\nг) Добавлен новый уровень индекса ('new_level_const'):")
print(df_new_multi_level.head())


# --- 11. .merge() ---
print("\n--- 11. .merge() ---")
df1_merge = df_sample[['currency', 'currency_name']].drop_duplicates(subset=['currency']).head(3)
unique_dates_m = df_sample['date'].unique()
date_for_df2_m = unique_dates_m[1] if len(unique_dates_m) > 1 else unique_dates_m[0]
df2_merge_src = df_sample[df_sample['date'] == date_for_df2_m][['currency', 'exchange_rate']].drop_duplicates(subset=['currency'])
df2_merge = df2_merge_src[df2_merge_src['currency'].isin(df1_merge['currency'])].head(3)

if not df1_merge.empty and not df2_merge.empty:
    print("df1 для merge:")
    print(df1_merge)
    print("\ndf2 для merge:")
    print(df2_merge)
    merged_inner = pd.merge(df1_merge, df2_merge, on='currency')
    print("\nInner Merge по 'currency':")
    print(merged_inner)

    temp_df1_left = df1_merge.copy()
    if 'NEWCUR' not in temp_df1_left['currency'].values:
         new_row_left = pd.DataFrame([{'currency': 'NEWCUR', 'currency_name': 'New Currency For Left'}])
         temp_df1_left = pd.concat([temp_df1_left, new_row_left], ignore_index=True)
    merged_left = pd.merge(temp_df1_left, df2_merge, on='currency', how='left')
    print("\nLeft Merge по 'currency':")
    print(merged_left)
else:
    print("Недостаточно данных для демонстрации .merge().")

# --- 12. .concat() ---
print("\n--- 12. .concat() ---")
df_concat1 = df_sample.head(2)
df_concat2 = df_sample.tail(2)

if not df_concat1.empty and not df_concat2.empty :
    print("df_concat1:")
    print(df_concat1)
    print("\ndf_concat2:")
    print(df_concat2)
    concatenated_df = pd.concat([df_concat1, df_concat2])
    print("\nРезультат pd.concat([df_concat1, df_concat2]):")
    print(concatenated_df)
else:
    print("Недостаточно данных для демонстрации .concat().")

print("\n--- Лабораторная работа завершена ---") 